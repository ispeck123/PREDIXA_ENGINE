#!/usr/bin/env python3
"""
cash_order_master_execution_report_v6.py

Execution enrichment using OPTION-3 matching:

Matching:
order_master
    |
    |-- GTT/OCO ID stored during GTT placement
    |
    v
Fyers order response log
    |
    |-- orderTag / gtt id
    |-- tradedPrice
    |-- exchange order id
    |-- status

No order_id matching.
No bucket_id dependency.

Expected order_master fields (adapt aliases if required):
- Id / OrderId
- Symbol / StockTick
- EntryPrice
- OrderStatus
- GttId / OcoId / GTTId / OCOId

Run:
python cash_order_master_execution_report_v6.py \
    --fyers-log fyers_order_response.log

The existing DB fetch function should be connected in load_order_master().
"""

import argparse
import ast
import json
import logging
import os
import re
import pandas as pd


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)

logger = logging.getLogger(__name__)


def parse_object(line):
    try:
        return ast.literal_eval(line.strip())
    except Exception:
        try:
            return json.loads(line)
        except Exception:
            return None


def normalize(value):
    if value is None:
        return ""

    return (
        str(value)
        .lower()
        .replace("nse:", "")
        .replace("-eq", "")
        .strip()
    )


def extract_gtt_id(value):

    if not value:
        return None

    value = str(value)

    # GTT80 from 1:GTT80
    m = re.search(r"GTT([A-Za-z0-9_-]+)", value, re.I)

    if m:
        return m.group(1)

    return value


def load_fyers_execution(log_file):

    executions = []

    with open(log_file, "r", errors="ignore") as f:

        for line in f:

            obj = parse_object(line)

            if not isinstance(obj, dict):
                continue


            data = None

            if "orders" in obj:
                data = obj["orders"]

            elif "trades" in obj:
                data = obj["trades"]


            if not data:
                continue


            order_tag = data.get(
                "orderTag"
            )

            if not order_tag:
                continue


            executions.append({

                "gtt_key":
                    extract_gtt_id(order_tag),

                "order_tag":
                    order_tag,

                "broker_order_id":
                    data.get("id")
                    or data.get("orderNumber"),

                "exchange_order_id":
                    data.get("exchOrdId")
                    or data.get("exchangeOrderNo"),

                "symbol":
                    data.get("symbol"),

                "fill_price":
                    data.get("tradedPrice")
                    or data.get("tradePrice"),

                "filled_qty":
                    data.get("filledQty")
                    or data.get("tradedQty"),

                "status":
                    data.get("status"),

                "fill_time":
                    data.get("orderDateTime")

            })


    logger.info(
        "Fyers executions loaded=%s",
        len(executions)
    )

    return pd.DataFrame(executions)



def load_order_master():
    """
    Replace this function body with your existing MySQL order_master query.

    Must return dataframe containing:
    - symbol
    - entry_price
    - gtt_id or oco_id
    """

    raise NotImplementedError(
        "Connect existing order_master DB query here"
    )



def match_execution(order, fyers_df):

    gtt_value = (
        order.get("gtt_id")
        or order.get("oco_id")
        or order.get("gttId")
        or order.get("ocoId")
    )


    key = extract_gtt_id(gtt_value)


    if not key:
        return None


    matches = fyers_df[
        fyers_df["gtt_key"].astype(str)
        ==
        str(key)
    ]


    if matches.empty:
        return None


    # prefer filled execution

    filled = matches[
        matches.fill_price.notna()
    ]


    if not filled.empty:
        return filled.iloc[-1].to_dict()


    return matches.iloc[-1].to_dict()



def generate_report():

    args = parser.parse_args()

    orders = load_order_master()

    fyers = load_fyers_execution(
        args.fyers_log
    )

    output=[]


    for _, row in orders.iterrows():

        item=row.to_dict()

        execution = match_execution(
            item,
            fyers
        )


        if execution:

            item.update({

                "broker_order_id":
                    execution["broker_order_id"],

                "exchange_order_id":
                    execution["exchange_order_id"],

                "broker_symbol":
                    execution["symbol"],

                "order_tag":
                    execution["order_tag"],

                "actual_fill_price":
                    execution["fill_price"],

                "filled_qty":
                    execution["filled_qty"],

                "broker_status":
                    execution["status"],

                "fill_timestamp":
                    execution["fill_time"],

            })


        else:

            item.update({

                "broker_order_id":None,
                "exchange_order_id":None,
                "broker_symbol":None,
                "order_tag":None,
                "actual_fill_price":None,
                "filled_qty":None,
                "broker_status":None,
                "fill_timestamp":None,

            })


        if (
            item.get("entry_price")
            and item.get("actual_fill_price")
        ):

            item["entry_slippage"] = (
                float(item["actual_fill_price"])
                -
                float(item["entry_price"])
            )


        item["oco_confirmed"] = (
            "YES"
            if (
                item.get("gtt_id")
                or item.get("oco_id")
            )
            else "NO"
        )


        output.append(item)



    result=pd.DataFrame(output)

    os.makedirs(
        args.output,
        exist_ok=True
    )


    result.to_csv(
        os.path.join(
            args.output,
            "completed_order_execution_log.csv"
        ),
        index=False
    )


    logger.info(
        "Report generated rows=%s",
        len(result)
    )



parser=argparse.ArgumentParser()

parser.add_argument(
    "--fyers-log",
    required=True
)

parser.add_argument(
    "--output",
    default="reports"
)


if __name__=="__main__":
    generate_report()
