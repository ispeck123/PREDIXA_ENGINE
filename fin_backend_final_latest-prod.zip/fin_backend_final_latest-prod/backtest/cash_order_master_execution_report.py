#!/usr/bin/env python3
"""
cash_order_master_execution_report.py

Execution-layer report generator using ONLY order_master data.

Features:
1. Real fill price extraction from order_master/order_status JSON
   - Uses tradedPrice / fill_price fields when available
   - Never assumes signal entry price is the fill price

2. Fill timestamp extraction

3. Entry slippage calculation

4. OCO/GTT safety validation
   - Uses existing order_master fields only
   - If oco_id exists => confirmed
   - No broker DB dependency

5. Broker reconciliation summary
   - Based on order_master stored broker fields

6. MFE / MAE / bars-after-fill calculation
   - Reads OHLC CSV files:
       SYMBOL_timeframe.csv

Example:
python cash_order_master_execution_report.py \
    --input order_master.csv \
    --csv-dir data/indian_stock_data/latest_data_csv \
    --output reports

Expected CSV columns:
tradeDate,open,high,low,close,qty

"""

import os
import json
import argparse
import logging
import glob
from datetime import datetime

import pandas as pd


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)

log = logging.getLogger(__name__)


TIMEFRAME_MAP = {
    1: "daily",
    2: "sixty",
    3: "fifteen",
    5: "one_twenty_five",
    6: "twenty_five",
    25: "seventy_five",
}


def parse_json(value):
    if isinstance(value, dict):
        return value

    if not value:
        return {}

    try:
        return json.loads(value)
    except Exception:
        return {}


def normalize_symbol(s):
    return (
        str(s)
        .lower()
        .replace("nse:", "")
        .replace("-eq", "")
        .replace("_", "")
        .strip()
    )


def timeframe_name(value):
    try:
        return TIMEFRAME_MAP.get(int(value), str(value).lower())
    except:
        return str(value).lower()


class CSVCache:

    def __init__(self, folder):
        self.folder = folder
        self.cache = {}

    def load(self):

        files = glob.glob(
            os.path.join(self.folder, "*.csv")
        )

        log.info(
            "CSV scan started. Files=%s",
            len(files)
        )

        for f in files:

            name = os.path.basename(f).replace(".csv","").lower()

            tf = None

            for x in sorted(
                TIMEFRAME_MAP.values(),
                key=len,
                reverse=True
            ):
                if name.endswith("_"+x):
                    tf = x
                    break

            if not tf:
                continue

            symbol = name[:-len(tf)-1]

            try:
                df = pd.read_csv(f)

                if "tradeDate" not in df.columns:
                    log.warning(
                        "Skipped %s missing tradeDate",
                        f
                    )
                    continue

                df["tradeDate"] = pd.to_datetime(
                    df["tradeDate"]
                )

                df = df.sort_values("tradeDate")

                key = (
                    normalize_symbol(symbol),
                    tf
                )

                self.cache[key] = df

                log.info(
                    "Loaded %s candles=%s",
                    key,
                    len(df)
                )

            except Exception as e:
                log.exception(
                    "CSV failed %s %s",
                    f,
                    e
                )

        log.info(
            "CSV CACHE READY %s files",
            len(self.cache)
        )


def extract_execution(row):

    status = parse_json(
        row.get("order_status")
    )

    actual_fill = None
    fill_time = None

    candidates = [
        status,
        row
    ]

    for obj in candidates:

        for k in [
            "tradedPrice",
            "tradePrice",
            "filled_entry_price",
            "fill_price",
            "actual_filled_entry_price"
        ]:
            if obj.get(k):
                actual_fill = float(obj[k])
                break

        if actual_fill:
            break


    for obj in candidates:

        for k in [
            "fill_timestamp",
            "trade_timestamp",
            "orderDateTime",
            "filled_at"
        ]:
            if obj.get(k):
                fill_time = obj[k]
                break

        if fill_time:
            break


    return actual_fill, fill_time



def calculate_mfe_mae(
    row,
    cache
):

    symbol = normalize_symbol(
        row.get("symbol")
        or row.get("stock_tick")
    )

    tf = timeframe_name(
        row.get("time_frame")
    )


    key = (
        symbol,
        tf
    )

    if key not in cache.cache:
        return None, None, None


    df = cache.cache[key]


    fill_price = row["actual_fill_price"]

    fill_time = pd.to_datetime(
        row["fill_timestamp"],
        errors="coerce"
    )


    if pd.isna(fill_time):
        return None,None,None


    candles = df[
        df.tradeDate >= fill_time
    ]


    if candles.empty:
        return None,None,None


    side = str(
        row.get("side","BUY")
    ).upper()


    if side in ["SELL","-1"]:
        mfe = (
            fill_price -
            candles.low.min()
        )

        mae = (
            fill_price -
            candles.high.max()
        )

    else:
        mfe = (
            candles.high.max()
            -
            fill_price
        )

        mae = (
            candles.low.min()
            -
            fill_price
        )


    risk = abs(
        row.get("stoploss", fill_price)
        -
        fill_price
    )


    if risk == 0:
        risk = 1


    return (
        round(mfe/risk,3),
        round(mae/risk,3),
        len(candles)
    )


def main():

    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--input",
        required=True
    )

    parser.add_argument(
        "--csv-dir",
        required=True
    )

    parser.add_argument(
        "--output",
        default="reports"
    )

    args = parser.parse_args()


    os.makedirs(
        args.output,
        exist_ok=True
    )


    df = pd.read_csv(args.input)


    cache = CSVCache(
        args.csv_dir
    )

    cache.load()


    result=[]


    for _,r in df.iterrows():

        row=r.to_dict()


        fill,ts = extract_execution(row)

        row["actual_fill_price"] = fill
        row["fill_timestamp"] = ts


        signal = row.get(
            "entry_price"
        )


        if fill and signal:
            row["entry_slippage"] = round(
                fill-signal,
                4
            )
        else:
            row["entry_slippage"]=None


        oco_id = (
            row.get("oco_id")
            or row.get("gtt_oco_id")
        )

        row["oco_confirmed"] = (
            "YES"
            if oco_id
            else "NO"
        )

        row["oco_id"]=oco_id


        if fill and ts:

            mfe,mae,bars = calculate_mfe_mae(
                row,
                cache.cache
            )

            row["mfe_R"]=mfe
            row["mae_R"]=mae
            row["bars_after_fill"]=bars

        else:
            row["mfe_R"]=None
            row["mae_R"]=None
            row["bars_after_fill"]=None


        result.append(row)


    out=pd.DataFrame(result)


    outfile=os.path.join(
        args.output,
        "completed_order_execution_log.csv"
    )

    out.to_csv(
        outfile,
        index=False
    )


    log.info(
        "Generated %s rows=%s",
        outfile,
        len(out)
    )


    summary=pd.DataFrame({

        "metric":[
            "total_orders",
            "actual_fill_available",
            "oco_confirmed"
        ],

        "count":[
            len(out),
            out.actual_fill_price.notna().sum(),
            (out.oco_confirmed=="YES").sum()
        ]

    })


    summary.to_csv(
        os.path.join(
            args.output,
            "execution_reconciliation.csv"
        ),
        index=False
    )


if __name__=="__main__":
    main()
