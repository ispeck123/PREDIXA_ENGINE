#!/usr/bin/env python
"""
Export wet-run execution reports from order_master.

Creates:
1) Completed-order execution log CSV
2) Setup-to-fill funnel CSV
3) Summary JSON

Important limitation:
order_master does not contain real broker fill price, broker exit price, or OCO confirmation columns.
So this script exports those as UNKNOWN / assumed from signal prices unless the values exist inside order_status.

Run from project root:
    python backtest/export_order_master_wet_run_report.py --progress

Optional zone fields join:
    python backtest/export_order_master_wet_run_report.py \
      --zone-fields-jsonl outputs/futures_selected_zone_fields.jsonl \
      --progress
"""

from __future__ import annotations

import argparse
import ast
import csv
import json
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Tuple

from sqlalchemy import text

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from shared.db.dbconn import DBConnection


DEFAULT_TIMEFRAMES = [1, 2, 5, 6, 25]


def now_label() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def json_default(value: Any) -> Any:
    if isinstance(value, datetime):
        return value.isoformat(sep=" ")
    return str(value)


def json_dump_file(path: str, payload: Mapping[str, Any]) -> None:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, ensure_ascii=False, default=json_default)
        handle.write("\n")


def parse_datetime_text(value: Any) -> Optional[str]:
    if value is None or value == "":
        return None
    if isinstance(value, datetime):
        return value.strftime("%Y-%m-%d %H:%M:%S")
    text_value = str(value).strip()
    return text_value or None


def safe_float(value: Any) -> Optional[float]:
    try:
        if value is None or value == "":
            return None
        return float(value)
    except Exception:
        return None


def safe_int(value: Any) -> Optional[int]:
    try:
        if value is None or value == "":
            return None
        return int(float(value))
    except Exception:
        return None


def parse_bool(value: Any) -> Optional[bool]:
    if value is None or value == "":
        return None
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    text_value = str(value).strip().lower()
    if text_value in {"1", "true", "yes", "y"}:
        return True
    if text_value in {"0", "false", "no", "n"}:
        return False
    return None


def parse_status(value: Any) -> Dict[str, Any]:
    """
    Supports:
      "{'status': 'failed', 'reason': 'Stoploss hit', ...}"
      '{"status":"failed","reason":"Stoploss hit"}'
      "BACKTEST_PENDING_ENTRY"
    """
    if value is None:
        return {}
    if isinstance(value, Mapping):
        return dict(value)
    text_value = str(value).strip()
    if not text_value:
        return {}
    if text_value.startswith("{") and text_value.endswith("}"):
        try:
            parsed = ast.literal_eval(text_value)
            if isinstance(parsed, Mapping):
                return dict(parsed)
        except Exception:
            pass
        try:
            parsed = json.loads(text_value)
            if isinstance(parsed, Mapping):
                return dict(parsed)
        except Exception:
            pass
    return {"raw_order_status": text_value}


def parse_csv_int_list(value: Optional[str], default: Optional[List[int]] = None) -> List[int]:
    if value is None or str(value).strip() == "":
        return list(default or [])
    output = []
    for item in str(value).split(","):
        item = item.strip()
        if item:
            output.append(int(item))
    return output


def parse_csv_str_list(value: Optional[str]) -> List[str]:
    if value is None or str(value).strip() == "":
        return []
    return [item.strip().upper() for item in str(value).split(",") if item.strip()]


def status_text(status_dict: Mapping[str, Any]) -> str:
    return str(status_dict.get("status") or status_dict.get("raw_order_status") or "").lower()


def read_jsonl(path: str) -> Iterable[Dict[str, Any]]:
    with open(path, "r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, 1):
            line = line.strip()
            if not line:
                continue
            try:
                parsed = json.loads(line)
                if isinstance(parsed, dict):
                    yield parsed
            except Exception as exc:
                print(f"[WARN] invalid JSON ignored: {path}:{line_number} -> {exc}")


def load_zone_fields(path: Optional[str]) -> Dict[int, Dict[str, Any]]:
    """
    Expected row shape from extract_selected_zone_fields_from_payload_jsonl.py:
      {
        "order_id": 1895,
        "zone_type": "GDZ",
        "retest_count": 0,
        "penetration_pct": 0.0,
        "entry_tertile": 1,
        ...
      }
    """
    if not path:
        return {}
    if not os.path.exists(path):
        raise FileNotFoundError(path)
    lookup: Dict[int, Dict[str, Any]] = {}
    for row in read_jsonl(path):
        order_id = safe_int(row.get("order_id"))
        if order_id is None:
            continue
        lookup[order_id] = {
            "zone_type": row.get("zone_type"),
            "retest_count": row.get("retest_count"),
            "penetration_pct": row.get("penetration_pct"),
            "entry_tertile": row.get("entry_tertile"),
            "selected_zone_id": row.get("selected_zone_id"),
            "selected_zone_source": row.get("_zone_field_source") or row.get("source"),
        }
    return lookup


def freshness_limit(zone_type: Any) -> Optional[int]:
    text_value = str(zone_type or "").upper()
    if text_value in {"BZ", "SZ", "GSZ"}:
        return 0
    if text_value == "GDZ":
        return 1
    return None


def freshness_status(zone_type: Any, retest_count: Any) -> str:
    limit = freshness_limit(zone_type)
    retest = safe_int(retest_count)
    if limit is None or retest is None:
        return "UNKNOWN"
    if retest <= limit:
        return "FRESH_PASS"
    return "NON_FRESH_BLOCK_BY_G4"


def is_freshness_suppressed(zone_type: Any, retest_count: Any) -> Optional[bool]:
    status = freshness_status(zone_type, retest_count)
    if status == "UNKNOWN":
        return None
    return status == "NON_FRESH_BLOCK_BY_G4"


def is_entry_filled(row: Mapping[str, Any], status: Mapping[str, Any]) -> bool:
    if parse_bool(row.get("is_trade_started")) is True:
        return True
    if row.get("entry_timestamp") not in (None, ""):
        return True
    if status.get("entry_hit") is True:
        return True
    return False


def is_completed_order(row: Mapping[str, Any], status: Mapping[str, Any]) -> bool:
    st = status_text(status)
    if row.get("completed_on") not in (None, ""):
        return True
    if st in {"success", "failed"}:
        return True
    return False


def exit_leg_from_status(status: Mapping[str, Any]) -> str:
    st = status_text(status)
    reason = str(status.get("reason") or "").lower()
    if st == "success" or "target" in reason:
        return "TARGET"
    if st == "failed" or "stoploss" in reason or "stop loss" in reason:
        return "SL"
    return "UNKNOWN"


def actual_exit_price(row: Mapping[str, Any], status: Mapping[str, Any]) -> Tuple[Optional[float], str]:
    for key in ("actual_exit_price", "exit_price", "filled_exit_price"):
        value = safe_float(status.get(key))
        if value is not None:
            return value, f"order_status.{key}"
    leg = exit_leg_from_status(status)
    if leg == "TARGET":
        return safe_float(row.get("target_price")), "assumed_target_price_from_order_master"
    if leg == "SL":
        return safe_float(row.get("stoploss_price")), "assumed_stoploss_price_from_order_master"
    return None, "UNKNOWN"


def actual_filled_entry(row: Mapping[str, Any], status: Mapping[str, Any]) -> Tuple[Optional[float], str]:
    for key in ("actual_filled_entry_price", "filled_entry_price", "entry_fill_price"):
        value = safe_float(status.get(key))
        if value is not None:
            return value, f"order_status.{key}"
    return safe_float(row.get("entry_price")), "assumed_signal_entry_price_from_order_master"


def entry_slippage(signal_entry: Any, actual_entry: Any, order_type: Any) -> Optional[float]:
    signal = safe_float(signal_entry)
    actual = safe_float(actual_entry)
    if signal is None or actual is None:
        return None
    side = str(order_type or "").upper()
    if side == "BUY":
        return round(actual - signal, 6)
    if side == "SELL":
        return round(signal - actual, 6)
    return round(actual - signal, 6)


def oco_confirmed(status: Mapping[str, Any]) -> Tuple[str, str]:
    keys = [
        "oco_confirmed",
        "gtt_oco_confirmed",
        "oco_placed_and_confirmed",
        "oco_placed",
        "gtt_oco_placed",
    ]
    for key in keys:
        if key in status:
            value = parse_bool(status.get(key))
            if value is True:
                return "YES", f"order_status.{key}"
            if value is False:
                return "NO", f"order_status.{key}"
    return "UNKNOWN", "order_master_has_no_oco_confirmation_column"


def build_where(args: argparse.Namespace) -> Tuple[str, Dict[str, Any]]:
    clauses = []
    params: Dict[str, Any] = {}

    timeframes = parse_csv_int_list(args.timeframes, DEFAULT_TIMEFRAMES)
    if timeframes:
        placeholders = []
        for index, value in enumerate(timeframes):
            key = f"tf_{index}"
            placeholders.append(f":{key}")
            params[key] = value
        clauses.append(f"time_frame IN ({', '.join(placeholders)})")

    symbols = parse_csv_str_list(args.symbols)
    if symbols:
        placeholders = []
        for index, value in enumerate(symbols):
            key = f"sym_{index}"
            placeholders.append(f":{key}")
            params[key] = value
        clauses.append(f"UPPER(stock_tick) IN ({', '.join(placeholders)})")

    if args.order_id is not None:
        clauses.append("order_id = :order_id")
        params["order_id"] = int(args.order_id)

    if args.purchased_from:
        clauses.append("purchased_on >= :purchased_from")
        params["purchased_from"] = args.purchased_from

    if args.purchased_to:
        clauses.append("purchased_on <= :purchased_to")
        params["purchased_to"] = args.purchased_to

    if args.completed_from:
        clauses.append("completed_on >= :completed_from")
        params["completed_from"] = args.completed_from

    if args.completed_to:
        clauses.append("completed_on <= :completed_to")
        params["completed_to"] = args.completed_to

    if args.only_completed:
        clauses.append(
            "(completed_on IS NOT NULL "
            "OR order_status LIKE '%success%' "
            "OR order_status LIKE '%failed%' "
            "OR order_status LIKE '%Target hit%' "
            "OR order_status LIKE '%Stoploss hit%')"
        )

    if not args.include_null_status:
        clauses.append("order_status IS NOT NULL")

    where_sql = " WHERE " + " AND ".join(clauses) if clauses else ""
    return where_sql, params


def fetch_orders(args: argparse.Namespace) -> List[Dict[str, Any]]:
    where_sql, params = build_where(args)
    sql = f"""
        SELECT
            order_id,
            trade_signal_id,
            stock_tick,
            stock_id,
            country_id,
            time_frame,
            order_type,
            entry_price,
            stoploss_price,
            target_price,
            stock_quantity,
            purchased_cmp_date,
            purchased_on,
            order_status,
            is_trade_started,
            is_evaluated,
            entry_timestamp,
            completed_on,
            lstm_rf_model_prediction,
            lstm_rf_model_prob,
            arima_ab_model_prediction,
            arima_ab_model_prob
        FROM {args.table_name}
        {where_sql}
        ORDER BY order_id ASC
    """
    db = DBConnection()
    session = db.get_session()
    try:
        rows = session.execute(text(sql), params).mappings().all()
        return [dict(row) for row in rows]
    finally:
        session.close()
        try:
            db.close_engine()
        except Exception:
            pass


def completed_execution_row(row: Mapping[str, Any], zone_lookup: Mapping[int, Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    status = parse_status(row.get("order_status"))
    if not is_completed_order(row, status):
        return None

    order_id = safe_int(row.get("order_id"))
    zone = zone_lookup.get(order_id or -1, {})
    signal_entry = safe_float(row.get("entry_price"))
    filled_entry, filled_entry_source = actual_filled_entry(row, status)
    slippage = entry_slippage(signal_entry, filled_entry, row.get("order_type"))
    exit_price, exit_price_source = actual_exit_price(row, status)
    exit_leg = exit_leg_from_status(status)
    oco_flag, oco_source = oco_confirmed(status)
    retest_count = zone.get("retest_count")
    zone_type = zone.get("zone_type")
    fresh_status = freshness_status(zone_type, retest_count)

    return {
        "order_id": order_id,
        "trade_signal_id": row.get("trade_signal_id"),
        "symbol": row.get("stock_tick"),
        "TF": row.get("time_frame"),
        "zone_type": zone_type,
        "selected_zone_id": zone.get("selected_zone_id"),
        "signalled_entry": signal_entry,
        "signalled_sl": safe_float(row.get("stoploss_price")),
        "signalled_target": safe_float(row.get("target_price")),
        "actual_filled_entry_price": filled_entry,
        "fill_timestamp": parse_datetime_text(row.get("entry_timestamp")),
        "entry_slippage": slippage,
        "OCO_confirmed_flag": oco_flag,
        "which_leg_exited": exit_leg,
        "actual_exit_price": exit_price,
        "exit_timestamp": parse_datetime_text(row.get("completed_on")),
        "retest_count": retest_count,
        "freshness_status_at_emission": fresh_status,
        "penetration_pct": zone.get("penetration_pct"),
        "entry_tertile": zone.get("entry_tertile"),
        "order_status_status": status.get("status"),
        "order_status_reason": status.get("reason"),
        "profit_amount": status.get("profit_amount"),
        "profit_pct": status.get("profit_pct"),
        "loss_amount": status.get("loss_amount"),
        "loss_pct": status.get("loss_pct"),
        "mfe_R": status.get("mfe_R"),
        "mae_R": status.get("mae_R"),
        "bars_after_fill": status.get("bars_after_fill"),
        "stock_quantity": row.get("stock_quantity"),
        "purchased_cmp_date": row.get("purchased_cmp_date"),
        "purchased_on": parse_datetime_text(row.get("purchased_on")),
        "is_trade_started": row.get("is_trade_started"),
        "is_evaluated": row.get("is_evaluated"),
        "filled_entry_price_source": filled_entry_source,
        "exit_price_source": exit_price_source,
        "oco_source": oco_source,
        "zone_source": zone.get("selected_zone_source"),
    }


def build_completed_execution_log(orders: Iterable[Mapping[str, Any]], zone_lookup: Mapping[int, Dict[str, Any]]) -> List[Dict[str, Any]]:
    output = []
    for row in orders:
        item = completed_execution_row(row, zone_lookup)
        if item is not None:
            output.append(item)
    return output


def build_funnel(orders: List[Mapping[str, Any]], zone_lookup: Mapping[int, Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    total_orders = len(orders)
    filled_count = 0
    completed_count = 0
    target_count = 0
    sl_count = 0
    pending_count = 0
    not_triggered_count = 0
    oco_yes = 0
    oco_no = 0
    oco_unknown = 0
    freshness_known = 0
    freshness_would_block = 0
    freshness_pass = 0

    for row in orders:
        order_id = safe_int(row.get("order_id"))
        status = parse_status(row.get("order_status"))

        if is_entry_filled(row, status):
            filled_count += 1
            flag, _ = oco_confirmed(status)
            if flag == "YES":
                oco_yes += 1
            elif flag == "NO":
                oco_no += 1
            else:
                oco_unknown += 1

        if is_completed_order(row, status):
            completed_count += 1

        leg = exit_leg_from_status(status)
        if leg == "TARGET":
            target_count += 1
        elif leg == "SL":
            sl_count += 1

        st = status_text(status)
        if st == "pending":
            pending_count += 1
        elif st == "not_triggered":
            not_triggered_count += 1

        zone = zone_lookup.get(order_id or -1, {})
        suppression = is_freshness_suppressed(zone.get("zone_type"), zone.get("retest_count"))
        if suppression is True:
            freshness_known += 1
            freshness_would_block += 1
        elif suppression is False:
            freshness_known += 1
            freshness_pass += 1

    zone_rows_present = len(zone_lookup)
    zone_rows_joined = len([1 for row in orders if safe_int(row.get("order_id")) in zone_lookup])

    funnel_rows = [
        {
            "stage_order": 1,
            "stage": "Setups generated / persisted in order_master",
            "count": total_orders,
            "available_from_order_master": "YES",
            "notes": "order_master only contains setups inserted/persisted. Suppressed-before-insert setups need an emission/gate audit log.",
        },
        {
            "stage_order": 2,
            "stage": "Suppressed at Execute-TF freshness gate G4",
            "count": freshness_would_block if freshness_known else None,
            "available_from_order_master": "PARTIAL" if freshness_known else "NO",
            "notes": "Computed only for joined zone rows using rule BZ/SZ/GSZ limit=0, GDZ limit=1. This is would-block among persisted rows, not true suppressed-before-insert count.",
        },
        {
            "stage_order": 3,
            "stage": "Suppressed at circuit-limit gate",
            "count": None,
            "available_from_order_master": "NO",
            "notes": "order_master has no lower_ckt / upper_ckt / gate-decision columns.",
        },
        {
            "stage_order": 4,
            "stage": "Suppressed — other",
            "count": None,
            "available_from_order_master": "NO",
            "notes": "Rows suppressed outside allowlist/universe gate D-1/other pre-insert gates are not present in order_master.",
        },
        {
            "stage_order": 5,
            "stage": "GTT Single entries placed",
            "count": total_orders,
            "available_from_order_master": "ASSUMED",
            "notes": "Assumed each order_master row represents a persisted/sent GTT Single entry. No broker_gtt_id/status column exists to prove broker placement.",
        },
        {
            "stage_order": 6,
            "stage": "Filled — entry confirmed",
            "count": filled_count,
            "available_from_order_master": "YES",
            "notes": "Count where is_trade_started=1 OR entry_timestamp is not null OR order_status.entry_hit=True.",
        },
        {
            "stage_order": 7,
            "stage": "Filled with OCO confirmed",
            "count": oco_yes if (oco_yes or oco_no) else None,
            "available_from_order_master": "PARTIAL" if (oco_yes or oco_no) else "NO",
            "notes": "order_master has no OCO confirmation column. Counted only if order_status contains oco_confirmed/gtt_oco_confirmed/etc.",
        },
        {
            "stage_order": 8,
            "stage": "Completed",
            "count": completed_count,
            "available_from_order_master": "YES",
            "notes": "completed_on not null OR order_status status is success/failed.",
        },
        {
            "stage_order": 9,
            "stage": "Exited by Target",
            "count": target_count,
            "available_from_order_master": "YES",
            "notes": "Derived from order_status.status/reason.",
        },
        {
            "stage_order": 10,
            "stage": "Exited by SL",
            "count": sl_count,
            "available_from_order_master": "YES",
            "notes": "Derived from order_status.status/reason.",
        },
        {
            "stage_order": 11,
            "stage": "Still pending",
            "count": pending_count,
            "available_from_order_master": "YES",
            "notes": "Derived from order_status.status=pending.",
        },
        {
            "stage_order": 12,
            "stage": "Entry not triggered",
            "count": not_triggered_count,
            "available_from_order_master": "YES",
            "notes": "Derived from order_status.status=not_triggered.",
        },
    ]

    summary = {
        "total_order_master_rows": total_orders,
        "filled_count": filled_count,
        "completed_count": completed_count,
        "target_exit_count": target_count,
        "sl_exit_count": sl_count,
        "pending_count": pending_count,
        "not_triggered_count": not_triggered_count,
        "oco_yes": oco_yes,
        "oco_no": oco_no,
        "oco_unknown_for_filled": oco_unknown,
        "zone_rows_present_in_zone_jsonl": zone_rows_present,
        "zone_rows_joined_to_order_master": zone_rows_joined,
        "freshness_known_count": freshness_known,
        "freshness_pass_count": freshness_pass,
        "freshness_would_block_by_g4_count": freshness_would_block,
    }
    return funnel_rows, summary


def write_csv(path: str, rows: List[Mapping[str, Any]]) -> None:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        with output.open("w", newline="", encoding="utf-8") as handle:
            handle.write("")
        return
    fieldnames = list(rows[0].keys())
    with output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Export completed-order execution log and setup-to-fill funnel from order_master.")
    parser.add_argument("--table-name", default="order_master")
    parser.add_argument("--timeframes", default="1,2,5,6,25", help="Comma-separated TF filter. Default: 1,2,5,6,25")
    parser.add_argument("--symbols", default=None, help="Comma-separated symbols, example: NIFTY,UNIONBANK")
    parser.add_argument("--order-id", type=int, default=None)
    parser.add_argument("--purchased-from", default=None, help="Filter purchased_on >= this value")
    parser.add_argument("--purchased-to", default=None, help="Filter purchased_on <= this value")
    parser.add_argument("--completed-from", default=None, help="Filter completed_on >= this value")
    parser.add_argument("--completed-to", default=None, help="Filter completed_on <= this value")
    parser.add_argument("--only-completed", action="store_true", help="Fetch only completed rows from DB. Funnel will then be completed-only.")
    parser.add_argument("--include-null-status", action="store_true", help="Include rows where order_status is NULL.")
    parser.add_argument("--zone-fields-jsonl", default=None, help="Optional output from extract_selected_zone_fields_from_payload_jsonl.py")
    parser.add_argument("--output-dir", default=None, help="Default: outputs/order_master_wet_run_<timestamp>")
    parser.add_argument("--run-label", default=None, help="Optional label used in output folder name")
    parser.add_argument("--progress", action="store_true")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    label = args.run_label or now_label()
    output_dir = args.output_dir or f"outputs/order_master_wet_run_{label}"
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    if args.progress:
        print("[1/4] Loading zone field JSONL, if supplied...")
    zone_lookup = load_zone_fields(args.zone_fields_jsonl)

    if args.progress:
        print("[2/4] Reading order_master...")
    orders = fetch_orders(args)

    if args.progress:
        print(f"Loaded {len(orders)} order rows")
        print("[3/4] Building reports...")
    completed_rows = build_completed_execution_log(orders, zone_lookup)
    funnel_rows, summary = build_funnel(orders, zone_lookup)

    completed_csv = os.path.join(output_dir, "completed_order_execution_log.csv")
    funnel_csv = os.path.join(output_dir, "setup_to_fill_funnel.csv")
    summary_json = os.path.join(output_dir, "summary.json")

    if args.progress:
        print("[4/4] Writing outputs...")
    write_csv(completed_csv, completed_rows)
    write_csv(funnel_csv, funnel_rows)

    summary.update({
        "table_name": args.table_name,
        "timeframes": parse_csv_int_list(args.timeframes, DEFAULT_TIMEFRAMES),
        "symbols": parse_csv_str_list(args.symbols),
        "order_id": args.order_id,
        "purchased_from": args.purchased_from,
        "purchased_to": args.purchased_to,
        "completed_from": args.completed_from,
        "completed_to": args.completed_to,
        "only_completed": args.only_completed,
        "zone_fields_jsonl": args.zone_fields_jsonl,
        "completed_order_execution_log_csv": completed_csv,
        "setup_to_fill_funnel_csv": funnel_csv,
    })
    json_dump_file(summary_json, summary)

    print("ORDER MASTER WET-RUN EXPORT COMPLETE")
    print(f"completed_order_execution_log_csv: {completed_csv}")
    print(f"setup_to_fill_funnel_csv: {funnel_csv}")
    print(f"summary_json: {summary_json}")


if __name__ == "__main__":
    main()
