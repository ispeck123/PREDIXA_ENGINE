#!/usr/bin/env python
"""
Append MFE / MAE / bars_after_fill into an existing generated CSV.

Input:
    completed_order_execution_log.csv

Output:
    completed_order_execution_log_with_mfe_mae.csv

The script uses:
    symbol
    TF
    expiry_date
    fill_timestamp
    exit_timestamp
    signalled_entry
    signalled_sl
    order_type

and replays candle CSV data.
"""

import argparse
import glob
import os
from pathlib import Path

import pandas as pd


def find_csv(symbol, tf, expiry, data_dirs):
    exp = ""
    if expiry:
        exp = str(expiry).replace("-", "")

    candidates = []

    for folder in data_dirs:
        candidates.extend([
            os.path.join(folder, f"{symbol}_{exp}_{tf}.csv"),
            os.path.join(folder, f"{symbol}_{tf}.csv"),
        ])

    for path in candidates:
        if os.path.exists(path):
            return path

    for folder in data_dirs:
        matches = glob.glob(os.path.join(folder, f"*{symbol}*{tf}*.csv"))
        if matches:
            return matches[0]

    return None


def load_candles(path):
    df = pd.read_csv(path)

    date_col = None
    for col in ["tradeDate", "timestamp", "datetime", "date", "time"]:
        if col in df.columns:
            date_col = col
            break

    if date_col is None:
        raise Exception(f"No date column found: {path}")

    df["_dt"] = pd.to_datetime(df[date_col], errors="coerce", dayfirst=True)

    for col in ["high", "low", "close"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    return df.dropna(subset=["_dt", "high", "low", "close"]).sort_values("_dt")


def mfe_mae(entry, stop, side, highs, lows):
    risk = abs(entry - stop)

    if risk == 0:
        return 0, 0

    if side.upper() == "BUY":
        mfe = (max(highs) - entry) / risk
        mae = (entry - min(lows)) / risk
    else:
        mfe = (entry - min(lows)) / risk
        mae = (max(lows) - entry) / risk

    return round(mfe, 4), round(mae, 4)


def process_row(row, data_dirs):
    entry_time = pd.to_datetime(row["fill_timestamp"], errors="coerce")
    exit_time = pd.to_datetime(row["exit_timestamp"], errors="coerce")

    if pd.isna(entry_time) or pd.isna(exit_time):
        return row

    symbol = str(row["symbol"]).lower()
    tf = str(row["TF"]).lower()

    candle_file = find_csv(
        symbol=symbol,
        tf=tf,
        expiry=row.get("expiry_date"),
        data_dirs=data_dirs,
    )

    if candle_file is None:
        row["mfe_mae_error"] = "candle file not found"
        return row

    try:
        df = load_candles(candle_file)

        df = df[
            (df["_dt"] >= entry_time) &
            (df["_dt"] <= exit_time)
        ]

        highs = df["high"].tolist()
        lows = df["low"].tolist()

        entry = float(row["signalled_entry"])
        stop = float(row["signalled_sl"])
        side = str(row.get("order_type", "BUY"))

        mfe_R, mae_R = mfe_mae(
            entry,
            stop,
            side,
            highs,
            lows,
        )

        row["mfe_R"] = mfe_R
        row["mae_R"] = mae_R
        row["bars_after_fill"] = len(df)
        row["mfe_mae_source_csv"] = candle_file

    except Exception as exc:
        row["mfe_mae_error"] = str(exc)

    return row


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument("--input-csv", required=True)
    parser.add_argument("--output-csv", required=True)
    parser.add_argument("--data-dirs", nargs="+", required=True)

    args = parser.parse_args()

    df = pd.read_csv(args.input_csv)

    rows = []

    for _, row in df.iterrows():
        rows.append(process_row(row, args.data_dirs))

    result = pd.DataFrame(rows)

    Path(args.output_csv).parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(args.output_csv, index=False)

    print("MFE/MAE append completed")
    print(f"Input : {args.input_csv}")
    print(f"Output: {args.output_csv}")


if __name__ == "__main__":
    main()
