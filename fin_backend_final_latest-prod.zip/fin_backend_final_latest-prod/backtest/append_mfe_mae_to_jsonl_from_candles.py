#!/usr/bin/env python
"""
Append MFE / MAE / bars_after_fill into existing JSONL using candle CSV replay.

Input:
- Existing JSONL folder/file containing order records.
- One or more candle CSV directories.

The script uses:
    entry_timestamp -> start candle
    completed_on    -> exit candle

It appends into order_status:
    mfe_R
    mae_R
    bars_after_fill

Example:
{
 'status':'failed',
 'reason':'Stoploss hit',
 'entry_hit':True,
 'loss_amount':-246.6,
 'loss_pct':-2.05,
 'mfe_R':1.43,
 'mae_R':1.11,
 'bars_after_fill':39
}

Run:
python append_mfe_mae_to_jsonl_from_candles.py \
 --input-dir outputs/cash_order_master_engine_rerun_20260820 \
 --input-jsonl engine_rerun_payloads.jsonl \
 --data-dirs ./data/indian_stock_data/latest_data_csv \
 --output-jsonl outputs/engine_rerun_with_mfe_mae.jsonl
"""

from __future__ import annotations

import argparse
import ast
import csv
import glob
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd


def parse_status(value):
    if isinstance(value, dict):
        return dict(value)
    if value is None:
        return {}
    text = str(value).strip()
    try:
        return dict(ast.literal_eval(text))
    except Exception:
        try:
            return dict(json.loads(text))
        except Exception:
            return {"raw_order_status": text}


def parse_dt(value):
    if value is None or value == "":
        return None
    if isinstance(value, datetime):
        return value
    return pd.to_datetime(value, errors="coerce", dayfirst=True).to_pydatetime()


def find_candle_file(symbol, execute_tf, exp_num, data_dirs):
    candidates = []
    for folder in data_dirs:
        if exp_num:
            candidates.append(os.path.join(folder, f"{symbol}_{exp_num}_{execute_tf}.csv"))
        candidates.append(os.path.join(folder, f"{symbol}_{execute_tf}.csv"))

    for path in candidates:
        if os.path.exists(path):
            return path

    # fallback search
    for folder in data_dirs:
        pattern = os.path.join(folder, f"*{symbol}*{execute_tf}*.csv")
        found = glob.glob(pattern)
        if found:
            return found[0]

    return None


def load_candles(path):
    df = pd.read_csv(path)

    date_col = None
    for c in ["tradeDate", "timestamp", "datetime", "date", "time"]:
        if c in df.columns:
            date_col = c
            break

    if date_col is None:
        raise RuntimeError(f"No datetime column in {path}")

    df["_dt"] = pd.to_datetime(df[date_col], errors="coerce", dayfirst=True)

    for col in ["high", "low", "close"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    df = df.dropna(subset=["_dt", "high", "low", "close"])
    return df.sort_values("_dt")


def calculate_mfe_mae(entry, stop, side, highs, lows):
    risk = abs(float(entry) - float(stop))

    if risk == 0 or not highs:
        return 0, 0

    if str(side).upper() == "BUY":
        mfe = (max(highs) - entry) / risk
        mae = (entry - min(lows)) / risk
    else:
        mfe = (entry - min(lows)) / risk
        mae = (max(highs) - entry) / risk

    return round(mfe, 4), round(mae, 4)


def process_record(record, data_dirs):
    status = parse_status(record.get("order_status"))

    if not status:
        return record

    if not record.get("entry_timestamp"):
        return record

    if not record.get("completed_on"):
        return record

    symbol = record.get("symbol") or record.get("stock_tick")
    execute_tf = record.get("execute_tf")
    exp_num = record.get("exp_num")

    if not symbol or not execute_tf:
        return record

    candle_file = find_candle_file(
        symbol=str(symbol).lower(),
        execute_tf=str(execute_tf),
        exp_num=exp_num,
        data_dirs=data_dirs,
    )

    if not candle_file:
        status["mfe_mae_error"] = "candle file not found"
        record["order_status"] = status
        return record

    try:
        df = load_candles(candle_file)

        entry_time = parse_dt(record["entry_timestamp"])
        exit_time = parse_dt(record["completed_on"])

        df = df[(df["_dt"] >= entry_time) & (df["_dt"] <= exit_time)]

        highs = df["high"].tolist()
        lows = df["low"].tolist()

        entry = record.get("entry_price")
        stop = record.get("stoploss_price")

        if entry is None:
            entry = record.get("source_order", {}).get("entry_price")
        if stop is None:
            stop = record.get("source_order", {}).get("stoploss_price")

        mfe_R, mae_R = calculate_mfe_mae(
            float(entry),
            float(stop),
            record.get("order_type", "BUY"),
            highs,
            lows,
        )

        status["mfe_R"] = mfe_R
        status["mae_R"] = mae_R
        status["bars_after_fill"] = len(df)
        status["mfe_mae_candle_file"] = candle_file

        record["order_status"] = status

    except Exception as exc:
        status["mfe_mae_error"] = str(exc)
        record["order_status"] = status

    return record


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-dir", required=True)
    parser.add_argument("--input-jsonl", required=True)
    parser.add_argument("--data-dirs", required=True, nargs="+")
    parser.add_argument("--output-jsonl", required=True)
    args = parser.parse_args()

    input_path = os.path.join(args.input_dir, args.input_jsonl)

    Path(args.output_jsonl).parent.mkdir(parents=True, exist_ok=True)

    total = 0

    with open(input_path, "r", encoding="utf-8") as inp, open(args.output_jsonl, "w", encoding="utf-8") as out:
        for line in inp:
            if not line.strip():
                continue

            record = json.loads(line)
            record = process_record(record, args.data_dirs)

            out.write(json.dumps(record, ensure_ascii=False, default=str) + "\n")
            total += 1

    print(f"Completed MFE/MAE append. Records processed: {total}")
    print(f"Output: {args.output_jsonl}")


if __name__ == "__main__":
    main()
