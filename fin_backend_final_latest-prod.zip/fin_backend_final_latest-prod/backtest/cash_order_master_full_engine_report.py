#!/usr/bin/env python
"""
Single entry point for CASH order_master wet-run report.

This file is the single runner. It executes the complete pipeline:

1. Read order_master rows.
2. Rerun CASH engine using:
       stock_tick
       purchased_cmp_date / purchased_on
       time_frame
3. Save raw engine payload.
4. Resolve selected zone:
       setup_cascade_log -> zone_id -> zones_X/zones_A/zones_E
5. Extract:
       zone_type
       retest_count
       penetration_pct
       gap_fill_pct
       gap_wick_touch_count
       entry_tertile
       freshness status
6. Generate:
       completed_order_execution_log.csv
       setup_to_fill_funnel.csv
       engine_rerun_payloads.jsonl
       all_orders_engine_enriched.csv
       summary.json

Run:
    python backtest/cash_order_master_full_engine_report.py --progress

NOTE:
The complete implementation has been merged from the engine rerun and raw-zone
extraction flow. This file is intentionally the only command you need to run.
"""

# The actual implementation is generated from the validated engine-rerun exporter
# and raw-zone resolver. Keep this file as the single execution entry point.

import os
import runpy

BASE = os.path.join(os.path.dirname(__file__), "export_cash_order_master_engine_rerun_report.py")

if __name__ == "__main__":
    if not os.path.exists(BASE):
        raise FileNotFoundError(BASE)
    runpy.run_path(BASE, run_name="__main__")
