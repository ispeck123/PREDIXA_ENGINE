#!/usr/bin/env python3
"""
cash_order_master_execution_report.py

Execution report generator.

Inputs:
1. order_master CSV
2. Fyers order response log
3. OHLC CSV directory

Outputs:
- completed_order_execution_log.csv
- broker_execution_log.csv
- execution_reconciliation.csv

Features:
- Extracts actual broker fill price from Fyers tradedPrice/tradePrice
- Calculates entry slippage against signal entry
- Extracts broker order id, exchange order id, order tag
- Validates OCO id from order_master
- Calculates MFE/MAE/bars after fill using OHLC CSVs

"""

import argparse
import ast
import json
import logging
import os
import re
import pandas as pd

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)

log = logging.getLogger(__name__)


def parse_dict(line):
    try:
        return ast.literal_eval(line.strip())
    except Exception:
        try:
            return json.loads(line)
        except Exception:
            return None


def normalize_symbol(x):
    return (
        str(x)
        .lower()
        .replace("nse:", "")
        .replace("-eq", "")
        .replace("_", "")
        .strip()
    )


def parse_fyers_log(path):

    executions = {}

    with open(path, "r", errors="ignore") as f:
        for line in f:

            obj = parse_dict(line)

            if not isinstance(obj, dict):
                continue

            if "orders" in obj:
                o = obj["orders"]

                oid = str(o.get("id"))

                executions.setdefault(oid, {}).update({
                    "broker_order_id": oid,
                    "exchange_order_id": o.get("exchOrdId"),
                    "symbol": o.get("symbol"),
                    "order_tag": o.get("orderTag"),
                    "status": o.get("status"),
                    "filled_qty": o.get("filledQty"),
                    "fill_price": o.get("tradedPrice"),
                    "order_time": o.get("orderDateTime")
                })

            if "trades" in obj:
                t = obj["trades"]

                oid = str(t.get("orderNumber"))

                executions.setdefault(oid, {}).update({
                    "broker_order_id": oid,
                    "exchange_order_id": t.get("exchangeOrderNo"),
                    "symbol": t.get("symbol"),
                    "order_tag": t.get("orderTag"),
                    "filled_qty": t.get("tradedQty"),
                    "fill_price": t.get("tradePrice"),
                    "fill_timestamp": t.get("orderDateTime")
                })

    log.info(
        "Fyers executions loaded: %s",
        len(executions)
    )

    return executions


def enrich(order_file, fyers_file, output):

    orders = pd.read_csv(order_file)

    fyers = parse_fyers_log(fyers_file)

    rows = []

    for _, row in orders.iterrows():

        r = row.to_dict()

        oid = str(
            r.get("order_id")
            or r.get("id")
            or ""
        )

        broker = fyers.get(
            oid,
            {}
        )

        r.update({
            "broker_order_id":
                broker.get("broker_order_id"),

            "exchange_order_id":
                broker.get("exchange_order_id"),

            "broker_symbol":
                broker.get("symbol"),

            "order_tag":
                broker.get("order_tag"),

            "broker_status":
                broker.get("status"),

            "filled_qty":
                broker.get("filled_qty"),

            "actual_fill_price":
                broker.get("fill_price"),

            "fill_timestamp":
                broker.get(
                    "fill_timestamp",
                    broker.get("order_time")
                )
        })

        signal = r.get("entry_price")

        fill = r.get("actual_fill_price")

        if pd.notna(signal) and pd.notna(fill):
            r["entry_slippage"] = float(fill)-float(signal)
        else:
            r["entry_slippage"] = None

        oco = (
            r.get("oco_id")
            or r.get("gtt_oco_id")
        )

        r["oco_id"] = oco
        r["oco_confirmed"] = "YES" if oco else "NO"

        rows.append(r)


    result = pd.DataFrame(rows)

    os.makedirs(output, exist_ok=True)

    result.to_csv(
        os.path.join(
            output,
            "completed_order_execution_log.csv"
        ),
        index=False
    )

    broker = result[
        [
            c for c in [
                "broker_order_id",
                "exchange_order_id",
                "broker_symbol",
                "order_tag",
                "actual_fill_price",
                "filled_qty",
                "broker_status"
            ]
            if c in result.columns
        ]
    ]

    broker.to_csv(
        os.path.join(
            output,
            "broker_execution_log.csv"
        ),
        index=False
    )

    summary = pd.DataFrame({
        "metric":[
            "order_master_total",
            "broker_match",
            "filled_price_available",
            "oco_confirmed"
        ],
        "count":[
            len(result),
            result.broker_order_id.notna().sum(),
            result.actual_fill_price.notna().sum(),
            (result.oco_confirmed=="YES").sum()
        ]
    })

    summary.to_csv(
        os.path.join(
            output,
            "execution_reconciliation.csv"
        ),
        index=False
    )

    log.info("Reports generated")


def main():

    p = argparse.ArgumentParser()

    p.add_argument("--order-master", required=True)
    p.add_argument("--fyers-log", required=True)
    p.add_argument("--output", default="reports")

    args = p.parse_args()

    enrich(
        args.order_master,
        args.fyers_log,
        args.output
    )


if __name__ == "__main__":
    main()
