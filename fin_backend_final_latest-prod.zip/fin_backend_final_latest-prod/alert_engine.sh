#!/bin/bash

PID_FILE="alert_engine.pid"
SCRIPT_PATH="./alert_engine/entry_main.py"
CONDA_ENV_NAME="fin_model"

start_alert_engine() {
  echo "Starting Alert Engine..."
  source "$(conda info --base)/etc/profile.d/conda.sh"
  conda activate "$CONDA_ENV_NAME"
  which python

  nohup python "$SCRIPT_PATH" > alert_engine.log 2>&1 &
  echo $! > "$PID_FILE"
  echo "Alert Engine started with PID $(cat $PID_FILE)"
}

stop_alert_engine() {
  if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    echo "Stopping Alert Engine with PID $PID..."
    kill "$PID" && rm -f "$PID_FILE"
    echo "Alert Engine stopped."
  else
    echo "No Alert Engine process found."
  fi
}

restart_alert_engine() {
  stop_alert_engine
  sleep 1
  start_alert_engine
}

case "$1" in
  start)
    start_alert_engine
    ;;
  stop)
    stop_alert_engine
    ;;
  restart)
    restart_alert_engine
    ;;
  *)
    echo "Usage: $0 {start|stop|restart}"
    ;;
esac
