#!/bin/bash

PID_FILE="finprod_backend.pid"
APP_MODULE="apps.finprod_backend.app:app"

start_backend() {
  echo "Starting FastAPI backend..."
  #uvicorn $APP_MODULE --reload --host 0.0.0.0 --port 2560 > finprod_backend.log 2>&1 &
  gunicorn -w 30 --reload -k uvicorn.workers.UvicornWorker $APP_MODULE -b 0.0.0.0:2560 --access-logfile - --error-logfile - > finprod_backend.log 2>&1 &

  echo $! > "$PID_FILE"
  echo "Finprod Backend started with PID $(cat $PID_FILE)"
}

stop_backend() {
  if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    echo "Stopping finprod backend with PID $PID..."
    kill "$PID" && rm -f "$PID_FILE"
    echo "Finprod Backend stopped."
  else
    echo "No finprod backend process found."
  fi
}

restart_backend() {
  stop_backend
  sleep 1
  start_backend
}

case "$1" in
  start)
    start_backend
    ;;
  stop)
    stop_backend
    ;;
  restart)
    restart_backend
    ;;
  *)
    echo "Usage: $0 {start|stop|restart}"
    ;;
esac
