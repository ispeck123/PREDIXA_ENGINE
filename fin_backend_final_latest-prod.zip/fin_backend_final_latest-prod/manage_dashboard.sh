#!/bin/bash

PID_FILE="dashboard.pid"
APP_MODULE="apps.dashboard.main:app"
CONDA_ENV_NAME="finpro"

start_backend() {
  echo "Starting FastAPI backend..."
  echo "Activating Conda environment: $CONDA_ENV_NAME"
  source "$(conda info --base)/etc/profile.d/conda.sh"
  conda activate "$CONDA_ENV_NAME"
  which python
  uvicorn $APP_MODULE --access-log --log-level debug --host 0.0.0.0 --port 9000 > dashboard.log 2>&1 &
  echo $! > "$PID_FILE"
  echo "dashboard started with PID $(cat $PID_FILE)"
}
# 2580
stop_backend() {
  if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    echo "Stopping dashboard with PID $PID..."
    kill "$PID" && rm -f "$PID_FILE"
    echo "dashboard stopped."
  else
    echo "No dashboard process found."
  fi
}

restart_backend() {
  stop_backend
  sleep 1
  start_backend
}

case "$1" in
  start)
    start_backend
    ;;
  stop)
    stop_backend
    ;;
  restart)
    restart_backend
    ;;
  *)
    echo "Usage: $0 {start|stop|restart}"
    ;;
esac
