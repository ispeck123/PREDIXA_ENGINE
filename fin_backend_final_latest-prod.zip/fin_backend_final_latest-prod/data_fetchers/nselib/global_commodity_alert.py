import requests, json, time
from alert_engine.personal_telegram_alerts import PTELEGRAM_MSG
from shared.db.db_model import GLOBAL_COMMODITY_ALERTS
from shared.db.dbconn import DBConnection
from threading import Thread
from concurrent.futures import ThreadPoolExecutor, as_completed

tmsg = PTELEGRAM_MSG()


def get_gold_price_usd():
    api_key = "e52ff94a5e536d68593174fe7b3f7e3fe52ff94a"
    """
    Fetches the current gold price in USD from the GoldPricez API.

    Parameters:
        api_key (str): Your GoldPricez API key.

    Returns:
        float: Current gold price in USD per ounce, or None if the request fails.
    """
    url = "https://goldpricez.com/api/rates/currency/usd/measure/ounce"
    headers = {
        "X-API-KEY": api_key
    }

    try:
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()  # Raise an exception for HTTP errors
        data = response.json()
        data = json.loads(data)
        print(data, type(data))
        # Extract the gold price from the response
        gold_price = data.get('ounce_price_usd')
        if gold_price:
            return float(gold_price)
        else:
            print("Gold price not found in the response.")
            return None

    except requests.exceptions.RequestException as e:
        print(f"An error occurred while fetching gold price: {e}")
        return None





def check_and_notify(alert: GLOBAL_COMMODITY_ALERTS, current_price):
    if current_price is None:
        return

    price_min = float(alert.price_range_min or 0)
    price_max = float(alert.price_range_max or 0)

    if price_min == 0 or price_max == 0:
        return  # Invalid range

    if price_min <= current_price <= price_max:
        alert_type = alert.alert_type.lower()
        title = f"XAU/USD {alert_type.upper()} Alert"
        body = f"Current price ${current_price} is within your {alert_type} range: ${price_min} - ${price_max}"

        telegram_msg = f"📈 *XAU/USD {alert_type.upper()} Alert*\n\n" \
                       f"💰 *Current Price*: ${current_price}\n" \
                       f"🎯 *Target Range*: ${price_min} - ${price_max}\n\n" \
                       f"_Alert triggered automatically._"
        tmsg.send_msg(message=telegram_msg)
        print("✅ Telegram alert sent")

        if not alert.recurrent:
            dbc = DBConnection()
            db = dbc.get_session()
            alert.is_active = False
            db.merge(alert)
            db.commit()
            db.close()

def refresh_alert_subscriptions():
    global cached_alerts
    dbc = DBConnection()
    db = dbc.get_session()
    cached_alerts = db.query(GLOBAL_COMMODITY_ALERTS).filter(GLOBAL_COMMODITY_ALERTS.is_active == True).filter(GLOBAL_COMMODITY_ALERTS.stock_symbol == 'XAUUSD').all()
    db.close()
    print(f"🔄 Loaded {len(cached_alerts)} gold alerts")

def dynamic_subscription_loop(interval_seconds=60):
    while True:
        refresh_alert_subscriptions()
        time.sleep(interval_seconds)

def alert_loop():
    print("🚀 Starting XAU/USD alert monitoring loop...")
    while True:
        if cached_alerts:
            gold_price = get_gold_price_usd()
            with ThreadPoolExecutor(max_workers=10) as pool:
                futures = [
                    pool.submit(check_and_notify, alert, gold_price)
                    for alert in cached_alerts
                ]
                for future in as_completed(futures):
                    future.result()
        time.sleep(120)

def start_alert_engine():
    refresh_alert_subscriptions()
    Thread(target=alert_loop, daemon=True).start()
    Thread(target=dynamic_subscription_loop, daemon=True).start()
    try:
        print("🟢 Gold alert engine started and running...")
        while True:
            time.sleep(60)
    except KeyboardInterrupt:
        print("🛑 Stopped manually.")
