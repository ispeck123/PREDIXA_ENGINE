from data_fetchers.nselib.futures_utility import Future_Data_Handler
from shared.db.db_model import FuturesMaster
from shared.db.dbconn import DBConnection
from sqlalchemy import distinct
from nselib.derivatives import expiry_dates_future
from datetime import datetime
import pandas as pd
import numpy as np
import re

class future_data_downloader:
    def __init__(self):
        self.time_format = "%d-%m-%Y"
        self.fdh = Future_Data_Handler()

    def join_numbers_from_string(self, input_string):
        # Find all digits using regex
        numbers = re.findall(r'\d+', input_string)
        # Join all found numbers into one string
        result = ''.join(numbers)
        return result

    def download_stock_futures_by_expirycandle(self, st_sym, exp_date, file_name):
        end_date = datetime.now().strftime(self.time_format)
        start_date = self.fdh.get_contract_start_date(exp_date)
        self.fdh.get_future_ohlc(st_sym, exp_date, start_date, end_date, file_name)

    def get_all_stock_symbols(self):
        dbc = DBConnection()
        session = dbc.get_session()
        symbols = session.query(distinct(FuturesMaster.symbol)).all()
        sym_list = [s[0] for s in symbols]
        dbc.close_engine()
        return sym_list

    def get_expiry_list(self):
        return expiry_dates_future()

    def calculate(self):
        all_symbols = self.get_all_stock_symbols()
        exp_list = self.get_expiry_list()
        converted_list = [datetime.strptime(date_str, "%d-%b-%Y").strftime(self.time_format) for date_str in exp_list] # %Y-%m-%d
        for syms in all_symbols:
            for expirty_dt in converted_list:
                # print(syms, expirty_dt)
                try:
                    joined_numbers = self.join_numbers_from_string(expirty_dt)
                    ft_file_name = f"{syms}_{joined_numbers}.csv"
                    # print(ft_file_name)
                    self.download_stock_futures_by_expirycandle(syms, expirty_dt, ft_file_name)
                except Exception as ex:
                    pass





class future_data_getter:
    def __init__(self):
        pass

    def get_formatted_stock_chart_data(self, file_name: str):
        df = pd.read_csv(file_name)
        df['tradeDate'] = pd.to_datetime(df['tradeDate'], dayfirst = True)
        df_1 = df[['tradeDate', 'open', 'high', 'low', 'close']].copy(deep=True)
        df_1.rename(columns = {'tradeDate': 'time'}, inplace = True)
        df_1['time'] = (df_1['time'].astype(np.int64) // 10**9).astype(int)
        df_sorted = df_1.sort_values(by='time', ascending=True)
        df_sorted = df_sorted.drop_duplicates(subset=['time'])
        df_sorted.replace([np.inf, -np.inf], np.nan, inplace=True)
        df_sorted.fillna(0, inplace=True)
        return df_sorted.to_dict(orient = 'records')
    
    def get_commodity_formatted_stock_chart_data(self, file_name: str):
        df = pd.read_csv(file_name)
        df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst = True)
        df_1 = df[['timestamp', 'open', 'high', 'low', 'close']].copy(deep=True)
        df_1.rename(columns = {'timestamp': 'time'}, inplace = True)
        df_1['time'] = (df_1['time'].astype(np.int64) // 10**9).astype(int)
        df_sorted = df_1.sort_values(by='time', ascending=True)
        df_sorted = df_sorted.drop_duplicates(subset=['time'])
        df_sorted.replace([np.inf, -np.inf], np.nan, inplace=True)
        df_sorted.fillna(0, inplace=True)
        return df_sorted.to_dict(orient = 'records')