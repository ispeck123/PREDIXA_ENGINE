from nselib import derivatives
import pandas as pd
from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
from calendar import monthrange, THURSDAY
import os

class Future_Data_Handler:
    def __init__(self):
        pass

    def get_contract_start_date(self, expiry_date_str: str):
        """
        Given an expiry date, finds the estimated contract start date
        based on 3-month rolling futures rule and NSE expiry logic.

        Parameters:
        - expiry_date_str (str): Expiry date in 'dd-mm-yyyy' format

        Returns:
        - start_date (datetime.date): Estimated start date when contract started trading
        """
        # Parse the expiry date
        expiry_date = datetime.strptime(expiry_date_str, "%d-%m-%Y").date()
        # Step 1: Go 3 months back from expiry
        three_months_back = expiry_date - relativedelta(months=3)
        # Step 2: Find the previous month's expiry (last Thursday)
        previous_month = three_months_back.month
        previous_year = three_months_back.year
        def last_thursday(year, month):
            last_day = monthrange(year, month)[1]
            for day in range(last_day, 0, -1):
                if datetime(year, month, day).weekday() == THURSDAY:
                    return datetime(year, month, day).date()
        previous_expiry = last_thursday(previous_year, previous_month)
        # Step 3: Assume trading starts the next day (Friday)
        potential_start = previous_expiry + timedelta(days=1)
        # Step 4: If Friday is weekend, move to Monday
        if potential_start.weekday() == 5:  # Saturday
            potential_start += timedelta(days=2)
        elif potential_start.weekday() == 6:  # Sunday
            potential_start += timedelta(days=1)
        return potential_start.strftime('%d-%m-%Y')

    def get_upcoming_expiry_list(self, symbol: str):
        """
        Fetches upcoming (future) expiry dates for the given symbol's futures.
        Parameters:
        - symbol (str): Stock symbol, e.g., 'RELIANCE'
        Returns:
        - List of future expiry dates (datetime.date objects), sorted ascending
        """
        dt_format = '%d-%m-%Y'
        curr_date = datetime.today().date()
        st_date = curr_date - timedelta(days=30)

        # Fetch future price volume data
        data = derivatives.future_price_volume_data(
            symbol=symbol,
            instrument="FUTSTK",
            from_date=st_date.strftime(dt_format),
            to_date=curr_date.strftime(dt_format)
        )
        print(data)
        # if not data:
            # print(f"No futures data found for symbol: {symbol}")
            # return []

        df = pd.DataFrame(data)
        # Convert expiry dates to datetime.date
        df['EXPIRY_DT'] = pd.to_datetime(df['EXPIRY_DT'], errors='coerce').dt.date
        df = df[df['EXPIRY_DT'].notna()]
        df_future = df[df['EXPIRY_DT'] >= curr_date]
        expiry_list = sorted(df_future['EXPIRY_DT'].unique())
        # Filter only future expiries (today or later)
        # today = date.today()
        # future_expiries = sorted([exp for exp in future_expiries if exp >= today])
        print(expiry_list)
        return expiry_list

    def get_future_ohlc(self, symbol: str, expiry_date: str, start_date: str, end_date: str, out_file_name: str):
        """
        Fetches Futures OHLC data for a given symbol and expiry date.
        Parameters:
        - symbol (str): Stock symbol, e.g., 'RELIANCE'
        - expiry_date (str): Expiry date in 'dd-mm-yyyy' format, e.g., '30-05-2024'
        - start_date (str): Start date of data in 'dd-mm-yyyy' format
        - end_date (str): End date of data in 'dd-mm-yyyy' format
        Returns:
        - Pandas DataFrame with Date, Open, High, Low, Close, and Volume
        """
        # Fetch all future price and volume data for the symbol
        data = derivatives.future_price_volume_data(symbol=symbol, instrument="FUTSTK",
                                                    from_date=start_date, to_date=end_date)
        df = pd.DataFrame(data)
        # Convert EXPIRY_DT to datetime for clean filtering
        df['EXPIRY_DT'] = pd.to_datetime(df['EXPIRY_DT']).dt.date
        # Convert input expiry_date string to datetime.date
        from datetime import datetime
        target_expiry = datetime.strptime(expiry_date, "%d-%m-%Y").date()
        # Filter the DataFrame for the specific expiry
        df_filtered = df[df['EXPIRY_DT'] == target_expiry]
        if df_filtered.empty:
            print(f"No futures data found for {symbol} with expiry {expiry_date}.")
            return None
        # Prepare OHLC dataframe
        # print(df_filtered, len(df_filtered))
        # ohlc_df = df_filtered[['TIMESTAMP', 'OPENING_PRICE', 'TRADE_HIGH_PRICE', 'TRADE_LOW_PRICE', 'CLOSING_PRICE', 'TOT_TRADED_QTY']]
        df_filtered.rename(columns={
                                'TIMESTAMP': 'tradeDate',
                                'OPENING_PRICE': 'open',
                                'TRADE_HIGH_PRICE': 'high',
                                'TRADE_LOW_PRICE': 'low',
                                'CLOSING_PRICE': 'close',
                                'TOT_TRADED_QTY': 'qty'
                            }, inplace=True)
        df_filtered.index = pd.to_datetime(df_filtered['tradeDate'])
        df_filtered = df_filtered.sort_index(ascending=True)
        out_file_path = os.path.join('FUTURE_DATA', out_file_name) # TODO
        df_filtered.to_csv(out_file_path)
        print(f"Successfully stored {out_file_path}")
        # ohlc_df['Date'] = pd.to_datetime(ohlc_df['Date'])
        # return ohlc_df.sort_values(by='Date')