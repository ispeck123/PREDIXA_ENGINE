import sys, os
sys.path.insert(0, os.path.abspath("/home/ispeck/STOCK_PROJECT/STP_LATEST"))


from fyers_apiv3 import fyersModel
import logging
from shared.config.settings import fyers_config_credentials as fcc
from data_fetchers.fyers.fyers_session import fyers_access_token_handler
from data_fetchers.fyers.fyers_market_data import FyersMarketData
import time
from datetime import datetime
from shared.db.dbconn import DBConnection
from shared.db.db_model import CommoditiesMaster
from sqlitedict import SqliteDict
import requests
import pandas as pd
from io import StringIO
import re
import time


logger = logging.getLogger()
dbc = DBConnection()

sqlite_db = SqliteDict("finprod.sqlite")
symbols_expiries = sqlite_db['indian_commodity_expiries']

def get_latest_fyers_commodity_symbol_expiry(symbol: str):
    try:
        symbol = symbol.upper()
        # Download and load the CSV (you can cache this locally)
        df = pd.read_csv(fcc.COMMODITY_SYMBOL_CSV_URL, header=None, usecols=[1, 9])

        # symbol column
        df[9] = df[9].astype(str)
        df[1] = df[1].astype(str)

        df = df[df[9].astype(str).str.contains(f"MCX:{symbol}", na=False)]
        df = df[df[9].astype(str).str.contains("FUT", na=False)]

        df["parsed_date"] = df[1].apply(extract_date)
        #df = df.drop_duplicates(subset=["parsed_date"], keep='last').reset_index(drop=True)
        df = df.dropna(subset=["parsed_date"]).sort_values(by="parsed_date", ascending=True)
        df['parsed_date'] = df['parsed_date'].dt.strftime('%d %b %y')

        symbols_expiries = [{"symbol": s, "name": str(n).replace(" ", "_"), "expiry": d} for n, s, d in zip(df[1].values, df[9].values, df["parsed_date"].values) if f"{symbol} {d} FUT" == n]
        return symbols_expiries
    except Exception as e:
        print(f"Error fetching latest symbol: {e}")
        logger.exception(e, exc_info=True, stack_info=True)
        return None

def extract_date(entry):
    match = re.search(r'\b(\d{2})\s([A-Za-z]{3})\s(\d{2})\b', entry)
    if match:
        # year, month, day = match.groups()
        day, month, year = match.groups()
        full_date_str = f"20{year} {month} {day}"
        return datetime.strptime(full_date_str, "%Y %b %d")
    return None


class CommodityPriceFetcher:

    def __init__(self):
        self.client_id = fyers_access_token_handler().get_access_token().split(':')[0]
        self.access_token = fyers_access_token_handler().get_access_token().split(':')[1]
        self.fyers_data = FyersMarketData()
        self.add_all_symbols()
        
    def add_all_symbols(self):
        session = dbc.get_session()
        stocks = session.query(CommoditiesMaster).filter(CommoditiesMaster.is_active == 1).all()
        commodities_symbols = [stock.symbol for stock in stocks]
        commodity_fyers_symbols = []
        for sym in commodities_symbols:
            symbols_with_expiries = get_latest_fyers_commodity_symbol_expiry(sym)
            commodity_fyers_symbols.extend([item["symbol"] for item in symbols_with_expiries]) 
        #print([stock.fyers_symbol for stock in stocks])
        self.fyers_data.add_symbols(commodity_fyers_symbols)
        session.close()
    

    async def get_stock_price_from_fyers(self, stocks):
        try:
            stock_data = []
            stock_dict = {}
            

            for stock in stocks:
                #print(stock)
                stock["expiry_date"] = datetime.strptime(stock["expiry_date"], "%Y-%m-%d")
                latest_price = self.fyers_data.get_latest_price(f"MCX:{stock["symbol"]}{datetime.strftime(stock["expiry_date"], "%y%b").upper()}FUT")             
                #latest_price = all_prices[stock['fyers_symbol']]
                #print(stock['fyers_symbol'], latest_price)

                #logger.info(latest_price)
                if latest_price is not None:
                    stock_data.append({
                        "symbol": stock["symbol"].upper(),
                        "expiry_date": str(stock["expiry_date"]),
                        "fyers_symbol": latest_price.get('symbol', None),
                        "price": latest_price.get('ltp', None),
                        "prev_close": latest_price.get('prev_close_price', None),  # Fyers API does not provide this in real-time updates
                        "day_change": f"+{latest_price.get('ch', None)} Today" if (latest_price.get('ch', None) > 0) else f"{latest_price.get('ch', None)} Today",  # Fyers API does not provide this in real-time updates
                        "day_change_percentage": f"+{latest_price.get('chp', None)} %" if (latest_price.get('chp', None) > 0) else f"{latest_price.get('chp', None)} %",  # Fyers API does not provide this in real-time updates
                        "watchlist_id": None
                    })
            # print(datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"), "Printing stock data")
            #logger.info(stock_data)
            #print("stock_data----------------:", stock_data)            
            return stock_data
        except Exception as ex:
            logger.exception(ex)
            return stock_data
        

# if __name__ == "__main__":
#     cpf = CommodityPriceFetcher()
#     time.sleep(2)
#     session = dbc.get_session()
#     stocks = session.query(CommoditiesMaster).filter(CommoditiesMaster.is_active == 1).all()
#     # for commodity in stocks:
#     #     print(commodity.symbol, cpf.fyers_data.stock_latest_price)
#     print(cpf.fyers_data.stock_latest_price)
#     print(cpf.fyers_data.get_latest_price("MCX:NATGASMINI26JULFUT")["ltp"])
#     session.close()

