#!/usr/bin/env python3
"""
Fyers → Redis Ingestor

- Subscribes to Fyers SymbolUpdate stream.
- For each tick, writes a snapshot hash per symbol: HSET price:{symbol} ...
- Publishes live updates via Redis Pub/Sub on channel: prices:{symbol}
- Uses a background worker thread + Redis pipelines for throughput.
- Deduplicates bursts (same time+close) to reduce fanout.

Config via env vars:
  REDIS_URL          (default: redis://localhost:6379/0)
  SYMBOLS            Comma-separated list, e.g. "NSE:SBIN-EQ,NSE:ADANIENT-EQ"
  FYERS_USE_TOKEN_HANDLER  ("1" to use fyers_access_token_handler(); else provide FYERS_ACCESS_TOKEN)
  FYERS_ACCESS_TOKEN Access token string in format "appid:accesstoken" if not using handler

Requires:
  pip install redis fyers-apiv3
"""

import os
import json
import time
import signal
import logging
import threading
import queue
from typing import Any, Dict, List, Tuple
from shared.db.dbconn import DBConnection
from shared.db.db_model import Ind_StockMaster

dbc = DBConnection()



import redis
try:
    # Fyers v3 SDK
    from fyers_apiv3.FyersWebsocket import data_ws
except ImportError as e:
    raise SystemExit("Missing fyers-apiv3. Install with: pip install fyers-apiv3") from e

# If you have your own token handler, import it. Otherwise set FYERS_ACCESS_TOKEN env var.
try:
    from data_fetchers.fyers.fyers_session import fyers_access_token_handler # <-- replace or remove if not using
except Exception:
    fyers_access_token_handler = None

# -----------------------
# Config & Logging
# -----------------------
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")
SYMBOLS = [s.strip() for s in os.getenv("SYMBOLS", "NSE:SBIN-EQ").split(",") if s.strip()]
USE_HANDLER = os.getenv("FYERS_USE_TOKEN_HANDLER", "0") == "1"
ACCESS_TOKEN = os.getenv("FYERS_ACCESS_TOKEN")

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="%(asctime)s | %(levelname)s | %(threadName)s | %(message)s",
)
log = logging.getLogger("ingestor")

# -----------------------
# Utility
# -----------------------
def now_ms() -> int:
    return int(time.time() * 1000)

def coerce_ts_ms(v: Any) -> int:
    """
    Fyers 'exch_feed_time' may be None / seconds / ms.
    Return milliseconds int; fallback to current time if missing.
    """
    if v is None:
        return now_ms()
    try:
        v = int(v)
        # Heuristic: treat < 10^12 as seconds.
        if v < 1_000_000_000_000:
            v *= 1000
        return v
    except Exception:
        return now_ms()

# -----------------------
# Redis Writer Worker
# -----------------------
class RedisWriter(threading.Thread):
    """
    Background writer that drains a Queue of tick payloads and writes to Redis
    using pipelines. Each item is a dict with keys:
      symbol, open, high, low, close, time
    """
    def __init__(self, r: redis.Redis, q: queue.Queue, batch_size: int = 200, flush_ms: int = 100):
        super().__init__(daemon=True, name="RedisWriter")
        self.r = r
        self.q = q
        self.batch_size = batch_size
        self.flush_ms = flush_ms
        self._stop = threading.Event()

    def stop(self):
        self._stop.set()

    def run(self):
        pipe = self.r.pipeline()
        last_flush = time.time()

        while not self._stop.is_set():
            try:
                item = self.q.get(timeout=self.flush_ms / 1000.0)
                self._write_one(pipe, item)
            except queue.Empty:
                # no item—consider flushing due to time
                pass

            # flush conditions
            if pipe.command_stack and (
                len(pipe.command_stack) >= self.batch_size or
                (time.time() - last_flush) * 1000.0 >= self.flush_ms
            ):
                try:
                    pipe.execute()
                except Exception as e:
                    log.exception("Redis pipeline execute failed: %s", e)
                finally:
                    pipe = self.r.pipeline()
                    last_flush = time.time()

        # Final flush
        if pipe.command_stack:
            try:
                pipe.execute()
            except Exception as e:
                log.exception("Final pipeline flush failed: %s", e)

    def _write_one(self, pipe, p: Dict[str, Any]):
        sym = p["symbol"]
        key = f"price:{sym}"
        # Snapshot hash
        pipe.hset(key, mapping=p)
        # Pub/Sub fanout
        pipe.publish(f"prices:{sym}", json.dumps(p))

# -----------------------
# Fyers Ingestor
# -----------------------
class FyersIngestor:
    def __init__(self):
        self.symbols = self.get_all_symbols()
        # self._resolve_access_token()
        self.access_token = fyers_access_token_handler().get_access_token()

        self.r = redis.Redis.from_url(REDIS_URL, decode_responses=True)
        self.queue: queue.Queue = queue.Queue(maxsize=10_000)
        self.writer = RedisWriter(self.r, self.queue, batch_size=200, flush_ms=100)

        self.last_seen: Dict[str, Tuple[int, Any]] = {}  # symbol -> (time_ms, close)

        self.ws = data_ws.FyersDataSocket(
            access_token=self.access_token,  # "appid:accesstoken"
            log_path="",
            litemode=False,
            write_to_file=False,
            reconnect=True,
            on_connect=self.on_open,
            on_close=self.on_close,
            on_error=self.on_error,
            on_message=self.on_message,
        )

        self._stopping = threading.Event()

    def get_all_symbols(self):
        session = dbc.get_session()
        symbols = session.query(Ind_StockMaster.fyers_symbol).filter(Ind_StockMaster.is_active == 1).all()
        session.close()
        return [s[0] for s in symbols]

    # ----- WS Callbacks -----
    def on_open(self):
        log.info("Fyers WS connected. Subscribing %d symbols.", len(self.symbols))
        try:
            self.ws.subscribe(symbols=self.symbols, data_type="SymbolUpdate")
        except Exception as e:
            log.exception("Subscribe failed: %s", e)
        # Keep the socket active
        self.ws.keep_running()

    def on_close(self, msg):
        log.warning("Fyers WS closed: %s", msg)

    def on_error(self, msg):
        log.error("Fyers WS error: %s", msg)

    def on_message(self, message):
        """
        Fyers may send a dict or a list of dicts.
        We normalize, build compact payloads, dedupe, then enqueue for Redis writer.
        """
        items = message if isinstance(message, list) else [message]
        for m in items:
            if not isinstance(m, dict) or "ltp" not in m:
                continue
            sym = m.get("symbol")
            payload = {
                "symbol": sym,
                "open": m.get("open_price"),
                "high": m.get("high_price"),
                "low":  m.get("low_price"),
                "close": m.get("ltp"),
                "time": coerce_ts_ms(m.get("exch_feed_time")),
            }
            # Deduplicate: same (time, close) per symbol
            sig = (payload["time"], payload["close"])
            if self.last_seen.get(sym) == sig:
                continue
            self.last_seen[sym] = sig

            try:
                self.queue.put_nowait(payload)
            except queue.Full:
                # Drop oldest to make room, then enqueue (avoid blocking WS thread)
                try:
                    _ = self.queue.get_nowait()
                except Exception:
                    pass
                try:
                    self.queue.put_nowait(payload)
                except Exception:
                    log.warning("Dropped tick due to full queue (symbol=%s).", sym)

    # ----- Lifecycle -----
    def start(self):
        log.info("Starting Redis writer…")
        self.writer.start()
        log.info("Connecting to Fyers WS…")
        self.ws.connect()

    def stop(self):
        if self._stopping.is_set():
            return
        self._stopping.set()
        log.info("Stopping ingestor…")
        try:
            self.ws.close_connection()
        except Exception:
            pass
        self.writer.stop()
        self.writer.join(timeout=2.0)
        log.info("Stopped.")

# -----------------------
# Main
# -----------------------
def main():
    log.info("Config: REDIS_URL=%s", REDIS_URL)
    log.info("Symbols: %s", SYMBOLS)
    ing = FyersIngestor()

    def handle_sig(*_):
        ing.stop()

    signal.signal(signal.SIGINT, handle_sig)
    signal.signal(signal.SIGTERM, handle_sig)

    ing.start()

if __name__ == "__main__":
    main()
