from fyers_apiv3 import fyersModel
import logging
from shared.config.settings import fyers_config_credentials as fcc
from data_fetchers.fyers.fyers_session import fyers_access_token_handler
from data_fetchers.fyers.fyers_market_data import FyersMarketData
import time
from datetime import datetime
from shared.db.dbconn import DBConnection
from shared.db.db_model import FuturesMaster


logger = logging.getLogger()
dbc = DBConnection()

class FuturePriceFetcher:

    def __init__(self):
        self.client_id = fyers_access_token_handler().get_access_token().split(':')[0]
        self.access_token = fyers_access_token_handler().get_access_token().split(':')[1]
        self.fyers_data = FyersMarketData()
        self.add_all_symbols()
        
    def add_all_symbols(self):
        session = dbc.get_session()
        stocks = session.query(FuturesMaster).all()
        future_symbols = []
        # for stock in stocks:
            
        #     future_symbols.append(f"NSE:{stock.symbol}{datetime.strftime(stock.expiry_date, "%y%b").upper()}FUT")
        future_symbols = [f"NSE:{stock.symbol}{datetime.strftime(stock.expiry_date, "%y%b").upper()}FUT" for stock in stocks]
        print(future_symbols)
        #print([stock.fyers_symbol for stock in stocks])
        self.fyers_data.add_symbols(future_symbols)
        session.close()
    

    async def get_stock_price_from_fyers(self, stocks):
        try:
            # print(stocks)
            stock_data = []
            stock_dict = {}
            # for stock in stocks:
            #     stock_dict[stock['fyers_symbol']] = stock

            symbols = [f"NSE:{stock.symbol}{datetime.strftime(stock.expiry_date, "%y%b").upper()}FUT" for stock in stocks]
            #print(symbols)
            
            # self.fyers_data.add_symbols(symbols)
            # time.sleep(10)

            for stock in stocks:
                #print(stock)
                latest_price = self.fyers_data.get_latest_price(f"NSE:{stock.symbol}{datetime.strftime(stock.expiry_date, "%y%b").upper()}FUT")             
                #latest_price = all_prices[stock['fyers_symbol']]
                #print(stock['fyers_symbol'], latest_price)


                if latest_price is not None:
                    stock_data.append({
                        "id": stock.id,
                        "symbol": stock.symbol.upper(),
                        "expiry_date": str(stock.expiry_date),
                        "fyers_symbol": latest_price.get('symbol', None),
                        "price": latest_price.get('ltp', None),
                        "prev_close": latest_price.get('prev_close_price', None),  # Fyers API does not provide this in real-time updates
                        "day_change": f"+{latest_price.get('ch', None)} Today" if (latest_price.get('ch', None) > 0) else f"{latest_price.get('ch', None)} Today",  # Fyers API does not provide this in real-time updates
                        "day_change_percentage": f"+{latest_price.get('chp', None)} %" if (latest_price.get('chp', None) > 0) else f"{latest_price.get('chp', None)} %",  # Fyers API does not provide this in real-time updates
                        "watchlist_id": None
                    })
            # print(datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"), "Printing stock data")
            #logger.info(stock_data)
            #print("stock_data----------------:", stock_data)            
            return stock_data
        except Exception as ex:
            logger.exception(ex)
            return stock_data