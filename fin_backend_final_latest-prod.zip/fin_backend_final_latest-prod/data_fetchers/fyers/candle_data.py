from fyers_apiv3 import fyersModel
from datetime import datetime, timedelta
import pandas as pd
import os
from data_fetchers.fyers.fyers_session import fyers_access_token_handler
from shared.config.settings import stock_data_dir_config
import time
import logging


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# client_id = "9OG15PCU6X-100"
# access_token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOlsiZDoxIiwiZDoyIiwieDowIiwieDoxIiwieDoyIl0sImF0X2hhc2giOiJnQUFBQUFCb2NMZVh0SG9KaS0zT3doeDFoT0RPZ2tRckdnaVN4YTRfX1RlM090UXhUMlNMRnJnWXpOMEc3SXVTakpQSFkwSWJTMG1VLXpwdEJiMERNaTYwbDJ2eEUwZndjbWx2Tm9jQURZQWxvTVE1bV85cC1zND0iLCJkaXNwbGF5X25hbWUiOiIiLCJvbXMiOiJLMSIsImhzbV9rZXkiOiI5NjY4ZmQ0MzhiOGU0Njk0ZDgyYjg5NDI3MWI4YjFmMTU3ZWUyZmIzNTQyOGNiMGQ4YWNlMjIzYiIsImlzRGRwaUVuYWJsZWQiOiJOIiwiaXNNdGZFbmFibGVkIjoiTiIsImZ5X2lkIjoiQ0EwMDI4NyIsImFwcFR5cGUiOjEwMCwiZXhwIjoxNzUyMjgwMjAwLCJpYXQiOjE3NTIyMTc0OTUsImlzcyI6ImFwaS5meWVycy5pbiIsIm5iZiI6MTc1MjIxNzQ5NSwic3ViIjoiYWNjZXNzX3Rva2VuIn0.2LQRX-Scam9n6rB_UUANkSS26vuwMXsqhnKDljrZX_Y"

# # Initialize the FyersModel instance with your client_id, access_token, and enable async mode
# fyers = fyersModel.FyersModel(client_id=client_id, is_async=False, token=access_token, log_path="")

# data = data = {
#     "symbol":"NSE:SBIN-EQ",
#     "resolution":"D",
#     "date_format":"0",
#     "range_from":"1690895316",
#     "range_to":"1691068173",
#     "cont_flag":"1"
# }

# response = fyers.history(data=data)
# print(response)


class CandleDateFetcher:

    def __init__(self):
        fyers_access_token = fyers_access_token_handler().get_access_token()
        self.client_id = fyers_access_token.split(':')[0]
        self.access_token = fyers_access_token.split(':')[1]
        self.output_path = os.path.join(stock_data_dir_config.indian_stock_data_dir, 'latest_data_csv')

    def get_resolution_frame_name(self, resolution: str):
        if resolution == "5":
            return "five"
        elif resolution == "15":
            return "fifteen"
        elif resolution == "60":
            return "sixty"
        elif resolution == "1D":
            return "daily"
        elif resolution == "W":
            return "weekly"
        elif resolution == "ME":
            return "monthly"
    
    def fetch_candle_data_custom_resolution(self, 
                                           stock_tick: str,
                                           symbol: str, 
                                           start_date: str = "2020-01-01",
                                           end_date: str = datetime.now().strftime("%Y-%m-%d"),
                                           resolution: str = "5"):
        
        start_date = datetime.strptime(start_date, "%Y-%m-%d")
        end_date = datetime.strptime(end_date, "%Y-%m-%d")
        total_days = (end_date - start_date).days + 1
        print(f"Total days: {total_days}")
        symbol = symbol # f"NSE:{symbol}-EQ"
        days_list = []
        if resolution == "1D" or resolution == "D":
            max_day = 366
        else:
            max_day = 100
        if total_days > max_day:
            divident = total_days // max_day
            remainder = total_days % max_day
            for i in range(divident):
                days_list.append(max_day)
            if remainder > 0:
                days_list.append(remainder)
        else:
            days_list.append(total_days)
        
        if len(days_list) > 0:
            all_candles = []
            fyers = fyersModel.FyersModel(client_id=self.client_id, is_async=False, token=self.access_token, log_path="")
            range_to = end_date
            for days in days_list:
                #print(days)
                #range_to = datetime.now() - timedelta(minutes=1)
                #range_to = range_to.replace(second=0, microsecond=0)
                range_from = range_to - timedelta(days=days-1)
                # print(range_to)
                # print(range_from)
                # print(range_to.timestamp())
                # print(range_from.timestamp())
                range_to = datetime.strftime(range_to, "%Y-%m-%d")
                range_from = datetime.strftime(range_from, "%Y-%m-%d")
                print(range_from)
                print(range_to)

                data = {
                    "symbol": symbol,
                    "resolution": resolution,
                    "date_format": "1",
                    # "range_from": range_from.timestamp(),
                    # "range_to": range_to.timestamp(),
                    "range_from": range_from,
                    "range_to": range_to,
                    "cont_flag": "1"
                }
                
                #print(response)
                retry = 20
                candle_found = False
                for i in range(retry):
                    response = fyers.history(data=data)
                    #print(response)
                    if 'candles' in response:
                        candles = response['candles']
                        if len(candles) > 0:
                            #print("candles", len(candles))
                            candles.extend(all_candles)
                            all_candles = candles
                            #print("all candles", len(all_candles))
                            candle_found = True
                            break
                        else:
                            print(response)
                            logger.info(response)
                            break
                    else:
                        #print(f"No candle found for {symbol} from {range_from} to {range_to}")
                        print(response)
                        logger.info(response)
                    time.sleep(5)
                if candle_found == False:
                    print(f"No candle found for {symbol} from {range_from} to {range_to}")
                    logger.info(f"No candle found for {symbol} from {range_from} to {range_to}")
                range_to = datetime.strptime(range_from, "%Y-%m-%d") - timedelta(days=1)  # Adjust range_to for the next iteration
            
            df = pd.DataFrame(all_candles, columns=['tradeDate', 'open', 'high', 'low', 'close', 'qty'])
            frame_name = self.get_resolution_frame_name(resolution)
            df['tradeDate'] = pd.to_datetime(df['tradeDate'], unit='s', utc=True).dt.tz_convert('Asia/Kolkata')
            df['tradeDate'] = df['tradeDate'].dt.strftime('%d/%m/%Y %H:%M:%S')
            df = df[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]
            full_file_path = f"{self.output_path}/{stock_tick.lower()}_{frame_name}.csv"
            print("Saving:", full_file_path)
            if os.path.exists(full_file_path):
                os.remove(full_file_path)
            logger.info(f"Saving: {full_file_path}")
            df.to_csv(full_file_path, index=False)
    

    def create_125_munite_from_5_munite(self, file_name: str):
        txt_dir = "path/to/directory"
        file_path = os.path.join(txt_dir, file_name)
        print("Reading:", file_path)
        logger.info(f"Reading: {file_path}")

        df = pd.read_csv(file_path)[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]
        
        chunk_size = 125 // 5
        output = []

        # Define operation map
        agg_map = {
            'open': lambda chunk: chunk.iloc[0]['open'],
            'high': lambda chunk: chunk['high'].max(),
            'low': lambda chunk: chunk['low'].min(),
            'close': lambda chunk: chunk.iloc[-1]['close'],
            'qty': lambda chunk: chunk['qty'].sum(),
            'tradeDate': lambda chunk: chunk.iloc[0]['tradeDate']
        }

        for i in range(0, len(df), chunk_size):
            chunk = df.iloc[i:i + chunk_size]
            if len(chunk) < chunk_size:
                break  # Skip incomplete chunk

            new_row = {col: func(chunk) for col, func in agg_map.items()}
            output.append(new_row)

        if output:
            headers = output[0].keys()
            csv_file_name = file_name.replace("five", "one_twenty_five")
            self.dump_csv(headers, csv_file_name, output)
            print("Saved as:", csv_file_name)
            logger.info(f"Saved as: {csv_file_name}")
        else:
            print("No complete 125-minute chunks to save.")
            logger.info("No complete 125-minute chunks to save.")
    

# cls = CandleDateFetcher()
# cls.fetch_candle_data_custom_resolution(symbol="ICICIBANK", start_date="2020-01-01", resolution="1D")