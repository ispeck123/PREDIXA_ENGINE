from fyers_apiv3 import fyersModel
from data_fetchers.fyers.fyers_session import fyers_access_token_handler
from datetime import datetime
import logging

logger = logging.getLogger()
access_tk = fyers_access_token_handler().get_access_token()
client_id = access_tk.rsplit(":", 1)[0]
access_token = access_tk.rsplit(":", 1)[1]

def get_futures_option_data(symbol: str, expiry_to_filter: str):
    try:
        fyers = fyersModel.FyersModel(client_id=client_id, token=access_token,is_async=False, log_path="")
        expiry_date = expiry_to_filter + " 15:30:00"
        try:
            # 2025-10-28 15:30:00
            expiry_date = datetime.strptime(expiry_date, "%Y-%m-%d %H:%M:%S")
        except Exception as e:
            # 28-October-2025 15:30:00
            expiry_date = datetime.strptime(expiry_date, "%d-%B-%Y %H:%M:%S")
        expiry_timestamp = str(int(expiry_date.timestamp()))
        if symbol == "NIFTY":
            symbol_ = "NSE:NIFTY50-INDEX"
        elif symbol == "BANKNIFTY":
            symbol_ = "NSE:NIFTYBANK-INDEX"
        else:
            symbol_ = f"NSE:{symbol}-EQ"
        data = {
            "symbol":symbol_,
            "strikecount":10,
            "timestamp": expiry_timestamp
        }
        #print(data)
        response = fyers.optionchain(data=data)
        #print(response)
        res = {}
        if response.get("code") == 200:
            oi_data = response.get("data")
            options_chain_data = oi_data.get("optionsChain")
            # options_chain_call = [opt.get("oi") for opt in options_chain_data if opt.get("option_type") == "CE"]
            # options_chain_put = [opt.get("oi") for opt in options_chain_data if opt.get("option_type") == "PE"]
            # print(options_chain_call)
            # print(options_chain_put)

            highest_callOi = 0
            strike_price_of_highest_callOi = None
            for opt in options_chain_data:
                if opt.get("option_type") == "CE" and opt.get("oi") > highest_callOi:
                    highest_callOi = opt.get("oi")
                    strike_price_of_highest_callOi = opt.get("strike_price")
            
            highest_putOi = 0
            strike_price_of_highest_putOi = None
            for opt in options_chain_data:
                if opt.get("option_type") == "PE" and opt.get("oi") > highest_putOi:
                    highest_putOi = opt.get("oi")
                    strike_price_of_highest_putOi = opt.get("strike_price")
            res = {
                "stock": symbol,
                "expiry": expiry_to_filter,
                "total_callOi": oi_data.get("callOi"),
                "highest_callOi": highest_callOi,
                "strike_price_of_highest_callOi": strike_price_of_highest_callOi,
                "total_putOi": oi_data.get("putOi"),
                "highest_putOi": highest_putOi,
                "strike_price_of_highest_putOi": strike_price_of_highest_putOi,
                "optionsChain": options_chain_data
            }
        else:
            print(response)
        return res
    except Exception as ex:
        logger.exception(ex)
        return {}