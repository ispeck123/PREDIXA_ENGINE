import pandas as pd
from fyers_apiv3 import fyersModel
from datetime import datetime
from shared.config.settings import stock_data_dir_config
from data_fetchers.fyers.fyers_session import fyers_access_token_handler
from dateutil.relativedelta import relativedelta
from calendar import monthrange, THURSDAY
from datetime import timedelta, datetime
from nselib.derivatives import expiry_dates_future
from shared.db.db_model import FuturesMaster
from sqlalchemy import distinct
from shared.db.dbconn import DBConnection
from concurrent.futures import ThreadPoolExecutor, as_completed
from scripts.stock_logic import proc_delta_stock_items
import re, os, csv, time
import threading
import logging
import requests
from io import StringIO

logger = logging.getLogger()

class Indian_future_data_handler:
    def __init__(self):
        self.time_format = "%d-%m-%Y"
        self.download_path = os.path.join(stock_data_dir_config.indian_stock_future_data_dir, 'latest_data_csv')
        full_access_token = fyers_access_token_handler().get_access_token()
        self.fyers = fyersModel.FyersModel(client_id=full_access_token.rsplit(":", 1)[0], is_async=False, token=full_access_token.rsplit(":", 1)[1], log_path="")
        self.name_interval_dict = {
            "D" : "daily", 
            "60" : "sixty", 
            "15" : "fifteen"
        }
        self.historical_lock = threading.Lock()
        self.last_historical_time = [0]

    def return_now_and_previous_date(self, frame: str):
        now_date = datetime.now()
        if frame == 'D' or frame == 'W' or frame == 'ME':
            start_date = now_date - timedelta(days=365)
        elif frame == '60':
            start_date = now_date - timedelta(days=100)
        elif frame == '15':
            start_date = now_date - timedelta(days=100)
        return now_date, start_date

    def join_numbers_from_string(self, input_string):
        # Find all digits using regex
        numbers = re.findall(r'\d+', input_string)
        # Join all found numbers into one string
        result = ''.join(numbers)
        return result

    def get_all_stock_symbols(self):
        dbc = DBConnection()
        session = dbc.get_session()
        symbols = session.query(distinct(FuturesMaster.symbol)).all()
        sym_list = [s[0] for s in symbols]
        #sym_list = ["AARTIIND", "ABFRL", "ACC", "ABCAPITAL"]
        dbc.close_engine()
        return sym_list
    

    def fetch_future_candles(self, instrument_token, from_date, to_date, interval='day', max_retries=10):
        for attempt in range(max_retries):
            try:
                with self.historical_lock:
                    now = time.time()
                    elapsed = now - self.last_historical_time[0]
                    wait_time = max(0, 1/3 - elapsed)  # 3 requests/sec
                    if wait_time > 0:
                        time.sleep(wait_time)
                    self.last_historical_time[0] = time.time()
                    data = {
                    "symbol": instrument_token,
                    "resolution":interval,
                    "date_format":"1",
                    "range_from":from_date.strftime("%Y-%m-%d"),
                    "range_to":to_date.strftime("%Y-%m-%d"),
                    "cont_flag":"1"
                    }
                    response = self.fyers.history(data=data)
                    if 'candles' in response.keys():
                        df = pd.DataFrame(response['candles'], columns=['tradeDate', 'open', 'high', 'low', 'close', 'qty'])
                        df['tradeDate'] = pd.to_datetime(df['tradeDate'], unit='s', utc=True).dt.tz_convert('Asia/Kolkata').dt.tz_localize(None)
                        df['tradeDate'] = df['tradeDate'].dt.strftime('%d/%m/%Y %H:%M:%S')
                        df = df[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]
                        return df
                    else:
                        print(response, instrument_token, "Retrying .........................")
                        wait = 2 ** attempt
                        time.sleep(wait)
            except Exception as e:
                print(f"Error fetching data for token {instrument_token} {interval}: {e}")
                if '429' in str(e):
                    wait = 2 ** attempt
                    print(f"[{instrument_token}] Rate limit hit. Retrying after {wait}s...")
                    time.sleep(wait)
                else:
                    raise e
    

    
    def get_upcoming_expiry_list(self):
        return expiry_dates_future()
    
    def get_future_ohlc(self, symbol):
        token = self.get_latest_fyers_futures_symbol(symbol)
        print("token", token)
        if token:
            for items in token:
                future_token = items['symbol']
                expiry_date_str = items['expiry']
                format_idt = self.join_numbers_from_string(expiry_date_str)
                file_name = f"{symbol}_{format_idt}.csv"
                for interval in ['D', '60', '15']:
                    end_date, start_date = self.return_now_and_previous_date(interval)
                    df = self.fetch_future_candles(future_token, start_date, end_date, interval)
                    df.to_csv(f"{self.download_path}/{file_name.replace('.csv', f'_{self.name_interval_dict[interval]}.csv')}", index=False)
                    print(f"{self.download_path}/{file_name.replace('.csv', f'_{self.name_interval_dict[interval]}.csv')}")
                    print(f"✅ Future {symbol} {interval} data downloaded.")

    def dump_csv(self, header, csv_file, data):
        print("creating_csv", csv_file)
        csv_dump_path = os.path.join(stock_data_dir_config.indian_stock_future_data_dir,'latest_data_csv', csv_file)
        with open(csv_dump_path, 'w', newline='') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=header)
            writer.writeheader()
            writer.writerows(data)
        print(f'CSV file "{csv_file}" created.') 

    def extract_date(self, entry):
        try:
            if not entry or not isinstance(entry, str):
                return None

            match = re.search(r'\b(\d{1,2})\s([A-Za-z]{3})\s(\d{2})\b', entry.strip())
            if not match:
                return None

            day, month, year = match.groups()
            return datetime.strptime(f"{day} {month} 20{year}", "%d %b %Y")

        except Exception:
            return None

    # def get_latest_fyers_futures_symbol(self, product: str):
    #     try:
    #         # Step 1: Download the latest file  
    #         url = "https://public.fyers.in/sym_details/NSE_FO.csv"
    #         response = requests.get(url)
    #         response.raise_for_status()  # Raise error if request failed
    #         # Step 2: Read into DataFrame (no headers in file)
    #         df = pd.read_csv(StringIO(response.text), header=None)
    #         # Step 3: Filter for product
    #         df = df[df[9].astype(str).str.contains(f"NSE:{product}", na=False)]
    #         df = df[df[9].astype(str).str.contains("FUT", na=False)]
    #         # Step 4: Convert expiry column (index 10) to datetime
    #         df["parsed_date"] = df[1].apply(self.extract_date)
    #         df = df.dropna(subset=["parsed_date"]).sort_values(by="parsed_date")
    #         print("parsed_date", df['parsed_date'])
    #         df['parsed_date'] = df['parsed_date'].dt.strftime('%d-%m-%Y')

    #         fdf = pd.DataFrame({
    #             "symbol": df[9].to_list()[:3],
    #             "expiry": df["parsed_date"].to_list()[:3]
    #         })
    #         # Step 5: Sort and return latest symbol
    #         return fdf.to_dict('records')

    #     except Exception as e:
    #         logger.exception(e)
    #         print(f"Error fetching latest symbol: {product}  {e}")
    #         return None    
    def get_latest_fyers_futures_symbol(self, product: str):
        try:
            url = "https://public.fyers.in/sym_details/NSE_FO.csv"
            response = requests.get(url, timeout=20)
            response.raise_for_status()

            df = pd.read_csv(StringIO(response.text), header=None)

            # symbol column
            df[9] = df[9].astype(str)
            df[1] = df[1].astype(str)

            # match only this product's futures
            # df = df[df[9].str.startswith(f"NSE:{product}", na=False)]
            # df = df[df[9].str.contains("FUT", na=False, regex=False)]
            df = df[df[9].str.match(rf"NSE:{product}\d{{2}}[A-Za-z]+FUT$", na=False)]

            if df.empty:
                print(f"No futures found for {product}")
                return []

            # parse expiry from description column
            df["parsed_date"] = df[1].apply(self.extract_date)
            df["parsed_date"] = pd.to_datetime(df["parsed_date"], errors="coerce")

            df = df.dropna(subset=["parsed_date"]).sort_values("parsed_date")

            if df.empty:
                print(f"No valid expiries found for {product}")
                return []

            # remove duplicate symbols if any
            df = df.drop_duplicates(subset=[9, "parsed_date"])

            result = df[[9, "parsed_date"]].head(3).copy()
            result.columns = ["symbol", "expiry"]
            result["expiry"] = result["expiry"].dt.strftime("%d-%m-%Y")

            return result.to_dict("records")

        except Exception as e:
            logger.exception(e)
            print(f"Error fetching latest symbol: {product} {e}")
            return []


    def process(self, max_workers=10, batch_size=200, delay_between_batches=10):
        all_symbols = self.get_all_stock_symbols()
        # all_symbols = ["ADANIPORTS"]
        # Prepare all (symbol, expiry) combinations
        tasks = [sym for sym in all_symbols]
        for i in range(0, len(tasks), batch_size):
            current_batch = tasks[i:i + batch_size]
            print(f"🔁 Processing batch {i // batch_size + 1} with {len(current_batch)} tasks...")
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = {
                    executor.submit(self.get_future_ohlc, sym): (sym)
                    for sym in current_batch
                }
                for future in as_completed(futures):
                    sym = futures[future]
                    try:
                        future.result()
                    except Exception as e:
                        print(f"❌ Exception in task {sym}: {e}")
                        logger.exception(f"❌ Exception in task {sym}: {e}", stack_info=True, exc_info=1)


            print(f"✅ Batch {i // batch_size + 1} complete. Sleeping for {delay_between_batches} sec...")
            time.sleep(delay_between_batches)  # prevent API ban   

        

class future_data_processer:
    def __init__(self):
        self.ifdh = Indian_future_data_handler()
        self.input_dir = os.path.join(stock_data_dir_config.indian_stock_future_data_dir, 'latest_data_csv')
        self.output_dir = os.path.join(stock_data_dir_config.indian_stock_future_data_dir, 'processed_data_files')
        self.time_format = "%d-%m-%Y"

    def dump_csv(self, header, csv_file, data):
        print("creating_csv", csv_file)
        csv_dump_path = os.path.join(stock_data_dir_config.indian_stock_future_data_dir,'latest_data_csv', csv_file)
        with open(csv_dump_path, 'w', newline='') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=header)
            writer.writeheader()
            writer.writerows(data)
        print(f'CSV file "{csv_file}" created.') 

    def create_75munite_from_15munite(self, file_name: str):
        txt_dir = os.path.join(stock_data_dir_config.indian_stock_future_data_dir, 'latest_data_csv') 
        file_path = os.path.join(txt_dir, file_name)
        print("Reading:", file_path)
        df = pd.read_csv(file_path)[['open', 'high', 'low', 'close', 'qty', 'tradeDate']] # create_75munite_from_15munite
        chunk_size = 5
        output = []
        # Define operation map
        agg_map = {
            'open': lambda chunk: chunk.iloc[0]['open'],
            'high': lambda chunk: chunk['high'].max(),
            'low': lambda chunk: chunk['low'].min(),
            'close': lambda chunk: chunk.iloc[-1]['close'],
            'qty': lambda chunk: chunk['qty'].sum(),
            # 'tradeTime': lambda chunk: chunk.iloc[0]['tradeTime'],
            'tradeDate': lambda chunk: chunk.iloc[0]['tradeDate']
        }
        for i in range(0, len(df), chunk_size):
            chunk = df.iloc[i:i + chunk_size]
            if len(chunk) < chunk_size:
                break  # Skip incomplete chunk

            new_row = {col: func(chunk) for col, func in agg_map.items()}
            output.append(new_row)

        if output:
            headers = output[0].keys()
            csv_file_name = file_name.replace("fifteen", "seventy_five")
            self.dump_csv(headers, csv_file_name, output)
            print("Saved as:", csv_file_name)
        else:
            print("No complete 75-minute chunks to save.")

    def create_monthly_and_weekly_from_daily(self, file_name: str, sample: str):
        txt_dir = os.path.join(stock_data_dir_config.indian_stock_future_data_dir, 'latest_data_csv') 
        file_path = os.path.join(txt_dir, file_name)
        df = pd.read_csv(file_path)[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]
        df['timstamp'] = pd.to_datetime(df['tradeDate'], dayfirst=True)
        df.set_index('timstamp', inplace=True)
        # df = df.sort_values(by='tradeDate', ascending=True)
        # Resample to weekly frequency
        re_sample = 'W-FRI' if sample == 'W' else sample
        grouped = df.groupby(pd.Grouper(freq=re_sample))
        records = []
        for _, group in grouped:
            if group.empty:
                continue
            first_date = group.index[0]
            open_ = group['open'].iloc[0]
            high_ = group['high'].max()
            low_ = group['low'].min()
            close_ = group['close'].iloc[-1]
            qty_ = group['qty'].sum()

            records.append({
                "tradeDate": first_date,
                "open": open_,
                "high": high_,
                "low": low_,
                "close": close_,
                "qty": qty_
            })
        # print(records)
        result_df = pd.DataFrame(records)
        print(result_df.columns, "#####################################", file_name)
        result_df['tradeDate'] = result_df['tradeDate'].dt.strftime("%d/%m/%Y %H:%M:%S")
        result_df = result_df[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]
        mon_val = 'weekly' if sample == 'W' else 'monthly'
        out_file_name = os.path.join(txt_dir, file_name.replace('daily', mon_val))
        result_df.to_csv(out_file_name)



    def process_all_files(self):
        all_file_list = os.listdir(self.input_dir)
        for items in all_file_list:
            if str(items).__contains__("fifteen"):
                self.create_75munite_from_15munite(items)
            if str(items).__contains__("daily"):
                self.create_monthly_and_weekly_from_daily(items, 'W')
                self.create_monthly_and_weekly_from_daily(items, 'ME')
        # all_files_to_process = self.get_all_stock_files()
        # self.remove_old_files(all_files_to_process)
        with ThreadPoolExecutor(max_workers=10) as executor:
            for stock_item in os.listdir(self.input_dir):
                executor.submit(proc_delta_stock_items, stock_item, self.input_dir, self.output_dir)
        print("all_stock_process_complete...................")



