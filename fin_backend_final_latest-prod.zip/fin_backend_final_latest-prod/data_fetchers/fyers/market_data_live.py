from fyers_apiv3.FyersWebsocket import data_ws
from data_fetchers.fyers.fyers_session import fyers_access_token_handler
import logging

logger = logging.getLogger()


class fyers_live_symbol_data:
    def __init__(self):
        self.access_token = fyers_access_token_handler().get_access_token()
        self.fyers = data_ws.FyersDataSocket(
            access_token=self.access_token,       # Access token in the format "appid:accesstoken"
            log_path="",                     # Path to save logs. Leave empty to auto-create logs in the current directory.
            litemode=False,                  # Lite mode disabled. Set to True if you want a lite response.
            write_to_file=False,              # Save response in a log file instead of printing it.
            reconnect=True,                  # Enable auto-reconnection to WebSocket on disconnection.
            on_connect=self.onopen,               # Callback function to subscribe to data upon connection.
            on_close=self.onclose,                # Callback function to handle WebSocket connection close events.
            on_error=self.onerror,                # Callback function to handle WebSocket errors.
            on_message=self.onmessage             # Callback function to handle incoming messages from the WebSocket.
        )
        self.stock_latest_price = {}
        self.fyers.connect()

    def onmessage(self, message):
        """
        Callback function to handle incoming messages from the FyersDataSocket WebSocket.

        Parameters:
            message (dict): The received message from the WebSocket.

        """
        # print("Response:", message)
        #   "time": message.get("exch_feed_time")
        if 'ltp' in message.keys():
            # print("getting data")
            symbol = message.get("symbol")
            candle_data = {
                "symbol": symbol,
                "open": message.get("open_price"),
                "high": message.get("high_price"),
                "low": message.get("low_price"),
                "close": message.get("ltp"),
            }
            # print(candle_data)
            self.stock_latest_price[symbol] = candle_data
            # print("candle_data", symbol, self.stock_latest_price[symbol])


    def onerror(self, message):
        """
        Callback function to handle WebSocket errors.

        Parameters:
            message (dict): The error message received from the WebSocket.


        """
        print("Error:", message)


    def onclose(self, message):
        """
        Callback function to handle WebSocket connection close events.
        """
        print("Connection closed:", message)


    def onopen(self):
        """
        Callback function to subscribe to data type and symbols upon WebSocket connection.

        """
        # Specify the data type and symbols you want to subscribe to
        data_type = "SymbolUpdate"

        # Subscribe to the specified symbols and data type
        # symbols = ['NSE:SBIN-EQ', 'NSE:ADANIENT-EQ']
        # self.fyers.subscribe(symbols=symbols, data_type=data_type)

        # Keep the socket running to receive real-time data
        self.fyers.keep_running()

    def add_syms(self, symbol, websocket):
        self.fyers.subscribe(symbols=symbol, data_type="SymbolUpdate")

    def get_latest_price(self, symbol):
        return self.stock_latest_price.get(symbol)

    # Establish a connection to the Fyers WebSocket
    
