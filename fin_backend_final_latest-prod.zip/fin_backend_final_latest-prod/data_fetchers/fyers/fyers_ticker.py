# from fyers_apiv3.FyersWebsocket import data_ws
# from data_fetchers.fyers.fyers_session import fyers_access_token_handler
# from threading import Lock
# import threading
# import logging
import os, logging
from logging.handlers import RotatingFileHandler

logger = logging.getLogger("FyersTicker")
logger.setLevel(logging.INFO)  # change to DEBUG for per-tick logs

os.makedirs("logs", exist_ok=True)

_fmt = logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
ch = logging.StreamHandler()
ch.setFormatter(_fmt)
fh = RotatingFileHandler("logs/fyers_ticker.log", maxBytes=1_000_000, backupCount=3)
fh.setFormatter(_fmt)

# avoid duplicate handlers if module reloaded
if not logger.handlers:
    logger.addHandler(ch)
    logger.addHandler(fh)

# class FyersTickerManager:
#     def __init__(self):
#         self.access_token = fyers_access_token_handler().get_access_token()  # Must be in format APP_ID:ACCESS_TOKEN

#         self.subscribers = {}         # symbol: set of websocket clients
#         self.latest_prices = {}       # symbol: last_price
#         self.token_lock = Lock()

#         self.fyers = data_ws.FyersDataSocket(
#             access_token=self.access_token,
#             log_path="logs/",
#             litemode=False,
#             write_to_file=False,
#             reconnect=True,
#             on_connect=self._on_open,
#             on_close=self._on_close,
#             on_error=self._on_error,
#             on_message=self._on_message
#         )

#         # Start the WebSocket in a separate thread
#         threading.Thread(target=self.fyers.connect, daemon=True).start()

#     def _on_open(self):
#         print("🟢 Connected to Fyers WebSocket")

#         with self.token_lock:
#             symbols = list(self.subscribers.keys())
#             if symbols:
#                 self.fyers.subscribe(symbols=symbols, data_type="SymbolUpdate")
#                 self.fyers.keep_running()

#     def _on_close(self, message):
#         print(f"🔴 WebSocket closed: {message}")

#     def _on_error(self, message):
#         print(f"❌ WebSocket error: {message}")

#     def _on_message(self, message):
#         try:
#             symbol = message.get("symbol")
#             ltp = message.get("ltp")
#             if symbol and ltp is not None:
#                 self.latest_prices[symbol] = ltp
#                 # if symbol in self.subscribers:
#                 #     for websocket in self.subscribers[symbol]:
#                 #         try:
#                 #             websocket.send_json(message)
#                 #         except:
#                 #             pass  # WebSocket client disconnected
#         except Exception as e:
#             print(f"❗ Error processing message: {e}")

#     def get_latest_price(self, symbol):
#         return self.latest_prices.get(symbol)
    
#     async def get_latest_stock_price(self, symbol):
#         return symbol, self.latest_prices.get(symbol)

#     def subscribe(self, symbols, websocket):
#         with self.token_lock:
#             newly_added = []
#             for symbol in symbols:
#                 if symbol not in self.subscribers:
#                     self.subscribers[symbol] = set()
#                     newly_added.append(symbol)
#                 self.subscribers[symbol].add(websocket)

#             if newly_added:
#                 self.fyers.subscribe(symbols=newly_added, data_type="SymbolUpdate")

#     def unsubscribe(self, websocket):
#         with self.token_lock:
#             to_remove = []
#             for symbol in list(self.subscribers):
#                 if websocket in self.subscribers[symbol]:
#                     self.subscribers[symbol].remove(websocket)
#                     if not self.subscribers[symbol]:
#                         to_remove.append(symbol)
#                         del self.subscribers[symbol]
#             if to_remove:
#                 self.fyers.unsubscribe(symbols=to_remove)


from fyers_apiv3.FyersWebsocket import data_ws
from data_fetchers.fyers.fyers_session import fyers_access_token_handler
from threading import Lock
import threading

class FyersTickerManager:
    def __init__(self):
        self.access_token = fyers_access_token_handler().get_access_token()  # APP_ID:ACCESS_TOKEN

        self.subscribers = {}          # symbol -> set(websocket)
        self.latest_prices = {}         # symbol -> ltp
        self.token_lock = Lock()        # protects subscribe/unsubscribe sets
        self.price_lock = Lock()        # protects latest_prices

        self.fyers = data_ws.FyersDataSocket(
            access_token=self.access_token,
            log_path="logs/",
            litemode=True,              # only LTP; avoids extra fields
            write_to_file=False,
            reconnect=True,
            on_connect=self._on_open,
            on_close=self._on_close,
            on_error=self._on_error,
            on_message=self._on_message
        )

        # Start the WebSocket in a separate thread
        t = threading.Thread(target=self._run_socket, daemon=True)
        t.start()

    def _run_socket(self):
        self.fyers.connect()
        # If your version requires it, call keep_running() ONCE here (not in on_connect)
        # self.fyers.keep_running()  # <- uncomment if needed by your env

    # --- Callbacks ------------------------------------------------------------
    def _on_open(self):
        logger.info("🟢 Connected to Fyers WebSocket")
        with self.token_lock:
            symbols = list(self.subscribers.keys())
        if symbols:
            self.fyers.subscribe(symbols=symbols, data_type="SymbolUpdate")

    def _on_close(self, message):
        logger.info(f"🔴 WebSocket closed: {message}")

    def _on_error(self, message):
        logger.info(f"❌ WebSocket error: {message}")

    def _on_message(self, message):
        """
        Handles both single-tick dicts and batched payloads like:
        { "type": "symbolUpdate", "d": [{ "symbol": "NSE:SBIN-EQ", "ltp": 782.05 }, ...] }
        """
        try:
            # Normalize payload into a list of updates
            if isinstance(message, dict):
                updates = message.get("d") if isinstance(message.get("d"), list) else [message]
            elif isinstance(message, list):
                updates = message
            else:
                return  # Unknown shape
            logger.debug(f"Received {len(updates)} updates")
            with self.price_lock:
                for u in updates:   
                    sym = u.get("symbol")
                    ltp = u.get("ltp")
                    if sym and ltp is not None:
                        # normalize exactly as you subscribe/query (upper & strip spaces)
                        key = sym.strip().upper()
                        self.latest_prices[key] = ltp

                        # If you forward to subscribers, do it outside the lock if heavy
                        # for ws in self.subscribers.get(key, []): ws.send_json(u)

        except Exception as e:
            logger.info(f"❗ Error processing message: {e}")

    # --- Public API -----------------------------------------------------------
    def get_latest_price(self, symbol: str):
        key = symbol.strip().upper()
        with self.price_lock:
            return self.latest_prices.get(key)

    async def get_latest_stock_price(self, symbol: str):
        key = symbol.strip().upper()
        with self.price_lock:
            return symbol, self.latest_prices.get(key)

    def get_stock_price_sync(self, symbol: str):
        key = symbol.strip().upper()
        with self.price_lock:
            return symbol, self.latest_prices.get(key)

    def subscribe(self, symbols, websocket):
        # Expect full Fyers symbols like "NSE:SBIN-EQ"
        normalized = [s.strip().upper() for s in symbols if s]
        newly_added = []
        with self.token_lock:
            for sym in normalized:
                if sym not in self.subscribers:
                    self.subscribers[sym] = set()
                    newly_added.append(sym)
                # self.subscribers[sym].add(websocket)
        if newly_added:
            self.fyers.subscribe(symbols=newly_added, data_type="SymbolUpdate")

    def unsubscribe(self, websocket):
        to_remove = []
        with self.token_lock:
            for sym in list(self.subscribers.keys()):
                if websocket in self.subscribers[sym]:
                    self.subscribers[sym].remove(websocket)
                    if not self.subscribers[sym]:
                        to_remove.append(sym)
                        del self.subscribers[sym]
        if to_remove:
            self.fyers.unsubscribe(symbols=to_remove)
