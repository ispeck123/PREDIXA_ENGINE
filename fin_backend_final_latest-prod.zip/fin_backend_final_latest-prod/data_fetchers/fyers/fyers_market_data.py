from fyers_apiv3.FyersWebsocket import data_ws
from data_fetchers.fyers.fyers_session import fyers_access_token_handler
from threading import Lock
import threading
import time

class FyersMarketData:

    def __init__(self):
        
        self.access_token = fyers_access_token_handler().get_access_token()  # Must be in format APP_ID:ACCESS_TOKEN
        self.symbols = []
        self.stock_latest_price = {}
        self.token_lock = Lock()

        self.fyers = data_ws.FyersDataSocket(
            access_token=self.access_token,       # Access token in the format "appid:accesstoken"
            log_path="",                     # Path to save logs. Leave empty to auto-create logs in the current directory.
            litemode=False,                  # Lite mode disabled. Set to True if you want a lite response.
            write_to_file=False,              # Save response in a log file instead of printing it.
            reconnect=True,                  # Enable auto-reconnection to WebSocket on disconnection.
            on_connect=self.onopen,               # Callback function to subscribe to data upon connection.
            on_close=self.onclose,                # Callback function to handle WebSocket connection close events.
            on_error=self.onerror,                # Callback function to handle WebSocket errors.
            on_message=self.onmessage             # Callback function to handle incoming messages from the WebSocket.
        )

        # Start the WebSocket in a separate thread
        threading.Thread(target=self.fyers.connect, daemon=True).start()
        # self.fyers.connect()


    def onmessage(self, message):
        """
        Callback function to handle incoming messages from the FyersDataSocket WebSocket.

        Parameters:
            message (dict): The received message from the WebSocket.

        """
        #print(message)
        symbol = message.get("symbol")
        ltp = message.get("ltp")
        if symbol and ltp is not None:
            self.stock_latest_price[symbol] = message
        # print(symbol, self.stock_latest_price[symbol])


    def onerror(self, message):
        """
        Callback function to handle WebSocket errors.

        Parameters:
            message (dict): The error message received from the WebSocket.


        """
        print("Market Data WebSocket Error:", message)


    def onclose(self, message):
        """
        Callback function to handle WebSocket connection close events.
        """
        print("Market Data WebSocket connection closed:", message)


    def onopen(self):
        """
        Callback function to subscribe to data type and symbols upon WebSocket connection.

        """
        # Specify the data type and symbols you want to subscribe to
        data_type = "SymbolUpdate"
        with self.token_lock:
            if self.symbols:
                # Subscribe to the specified symbols and data type
                self.fyers.subscribe(symbols=self.symbols, data_type=data_type)
                # Keep the socket running to receive real-time data
                self.fyers.keep_running()

                print("Connected to Market Data WebSocket")


    def add_symbols(self, symbols):
        with self.token_lock:
            add_symbols = []
            for symbol in symbols:
                if symbol not in self.symbols:
                    add_symbols.append(symbol)
            self.fyers.subscribe(symbols=add_symbols, data_type="SymbolUpdate")
            self.symbols.extend(add_symbols)
    
    def remove_symbols(self, symbols):
        with self.token_lock:            
            self.fyers.unsubscribe(symbols=symbols, data_type="SymbolUpdate")
            for symbol in symbols:
                if symbol in self.symbols:
                    self.symbols.remove(symbol)
    
    def get_latest_price(self, symbol):
        return self.stock_latest_price.get(symbol)
    
    def disconnect_websocket(self):
        self.fyers.close_connection()



# fyers = FyersMarketData()
# time.sleep(5)
# fyers.add_symbols(['NSE:RELIANCE-EQ', 'NSE:TCS-EQ'])
# time.sleep(5)
# fyers.remove_symbols(['NSE:RELIANCE-EQ'])