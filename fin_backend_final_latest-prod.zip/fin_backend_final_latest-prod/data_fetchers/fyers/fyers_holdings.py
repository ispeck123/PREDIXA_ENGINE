import os, sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "/home/ispeck/STOCK_PROJECT/STP_LATEST")))

from fyers_apiv3 import fyersModel
from data_fetchers.fyers.fyers_session import fyers_access_token_handler
import logging


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class FyersHoldings:

    def __init__(self):
        fyers_access_token = fyers_access_token_handler().get_access_token()
        self.client_id = fyers_access_token.split(':')[0]
        self.access_token = fyers_access_token.split(':')[1]
        self.fyers = fyersModel.FyersModel(client_id=self.client_id, token=self.access_token, is_async=False, log_path="")

    def get_holdings(self):
        try:
            response = self.fyers.holdings()
            if response.get("code") == 200 and response.get("s") == "ok":
                return response
            else:
                logger.error(f"Error fetching holdings: {response}")
                return {}
        except Exception as e:
            logger.error(f"Exception while fetching holdings: {e}")
            return {}

# if __name__ == "__main__":
#     # print("Fetching holdings from Fyers...")
#     holdings_fetcher = FyersHoldings()
#     holdings = holdings_fetcher.get_holdings()
#     print(holdings)