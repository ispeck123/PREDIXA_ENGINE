import os
from scripts.stock_logic import proc_delta_stock_items
from shared.db.dbconn import DBConnection
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor
import pandas as pd
import yfinance as yf
import csv
from pathlib import Path
import logging
from sqlalchemy import text
from shared.config.settings import stock_data_dir_config

logger = logging.getLogger()

class US_STOCK_DATA_UPDATER:
    def __init__(self):
        self.download_time_frames = ['1mo', '1wk', '1d', '60m', '15m']
        self.frame_name_dict = {
                            '1mo': 'monthly',
                            '1wk': 'weekly',
                            '1d': 'daily',
                            '60m': 'sixty',
                            '15m': 'fifteen'
                        }

    def chunked(self, iterable, n):
        for i in range(0, len(iterable), n):
            yield iterable[i:i + n]

    def return_now_and_previous_date(self, frame: str):
        now_date = datetime.now()
        if frame == '1mo' or frame == '1wk' or frame == '1d':
            start_date = '2020-01-01'
        elif frame == '60m':
            start_date = now_date - timedelta(days=729)
        elif frame == '15m':
            start_date = now_date - timedelta(days=59)
        return now_date, start_date

    def dump_csv(self, header, csv_file, data):
        print("creating_csv", csv_file)
        csv_dump_path = os.path.join(stock_data_dir_config.us_data_dir, 'latest_data_csv', csv_file)
        with open(csv_dump_path, 'w', newline='') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=header)
            writer.writeheader()
            writer.writerows(data)
        print(f'CSV file "{csv_file}" created.')

    def create_75munite_from_15munite(self, file_name: str):
        txt_dir = os.path.join(stock_data_dir_config.us_data_dir, 'latest_data_csv')
        file_path = os.path.join(txt_dir, file_name)
        print("Reading:", file_path)

        df = pd.read_csv(file_path)[['open', 'high', 'low', 'close', 'qty', 'tradeTime', 'tradeDate']]

        chunk_size = 5
        output = []

        # Define operation map
        agg_map = {
            'open': lambda chunk: chunk.iloc[0]['open'],
            'high': lambda chunk: chunk['high'].max(),
            'low': lambda chunk: chunk['low'].min(),
            'close': lambda chunk: chunk.iloc[-1]['close'],
            'qty': lambda chunk: chunk['qty'].sum(),
            'tradeTime': lambda chunk: chunk.iloc[0]['tradeTime'],
            'tradeDate': lambda chunk: chunk.iloc[0]['tradeDate']
        }

        for i in range(0, len(df), chunk_size):
            chunk = df.iloc[i:i + chunk_size]
            if len(chunk) < chunk_size:
                break  # Skip incomplete chunk

            new_row = {col: func(chunk) for col, func in agg_map.items()}
            output.append(new_row)

        if output:
            headers = output[0].keys()
            csv_file_name = file_name.replace("fifteen", "seventy_five")
            self.dump_csv(headers, csv_file_name, output)
            print("Saved as:", csv_file_name)
        else:
            print("No complete 75-minute chunks to save.")

    def get_stock_details(self):
        nn_stock_list = []
        nn_y_fin_stock_list = []
        dbc = DBConnection()
        res = dbc.raw_query(text("select * from us_stock_master where is_active=1;"))
        dbc.close_engine()
        for stock_details in res:
            nn_stock_list.append(stock_details.get('stock_tick'))
            nn_y_fin_stock_list.append(stock_details.get('y_finance'))
        return nn_stock_list, nn_y_fin_stock_list

    def get_stock_data(self, ticker, start_date, end_date, interval='1d'):
        """
        Fetch stock data from Yahoo Finance.

        Parameters:
        ticker (str): Stock symbol (e.g., 'AAPL' for Apple).
        start_date (str): Start date in the format 'YYYY-MM-DD'.
        end_date (str): End date in the format 'YYYY-MM-DD'.
        interval (str): Data frequency (valid intervals: '1m', '2m', '5m', '15m', '30m', '60m', '90m', '1d', '5d', '1wk', '1mo', '3mo').

        Returns:
        DataFrame: Stock data.
        """
        stock = yf.download(ticker, start=start_date, end=end_date, interval=interval)
        # print(stock.tail(5))
        print("/////////////////////////////////////////")
        selected_columns = ['Open', 'High', 'Low', 'Close', 'Volume']
        df_selected = stock.loc[:, (selected_columns, ticker)]
        df_selected.columns = df_selected.columns.droplevel(1)
        print(df_selected.tail(5))
        return df_selected

    def format_and_store_delta_stock_data(self, stock_data: pd.DataFrame, tick: str, interval: str):
        # Check if necessary columns exist
        required_columns = ['Open', 'High', 'Low', 'Close', 'Volume']
        for col in required_columns:
            if col not in stock_data.columns:
                raise ValueError(f"Missing required column: {col}")

        # Rename columns
        df = stock_data.rename(columns={
            'Open': 'open',
            'High': 'high',
            'Low': 'low',
            'Close': 'close',
            'Volume': 'qty',
            #'Adj Close': 'tradeTime'  # Temporary column name
        })

        # Convert index to datetime
        df.index = pd.to_datetime(stock_data.index)
        df['tradeTime'] = df.index.strftime('%H:%M:%S')
        df['tradeDate'] = df.index.strftime('%d/%m/%Y %H:%M:%S')

        # Reorder columns
        df = df.reset_index(drop=True)[['open', 'high', 'low', 'close', 'qty', 'tradeTime', 'tradeDate']]
        df['tradeDate'] = pd.to_datetime(df['tradeDate'], format='%d/%m/%Y %H:%M:%S', errors='coerce')
        # print(df.tail())
        # print("33333333333333333333333333333333333333333333333333333333333333333333")
        # Define output file path
        output_dir = Path(os.path.join(stock_data_dir_config.us_data_dir, 'latest_data_csv'))
        output_dir.mkdir(parents=True, exist_ok=True)
        out_file_name = output_dir / f"{tick}_{self.frame_name_dict[interval]}.csv"

        # Check if the file already exists
        if out_file_name.exists():
            # Load existing data
            existing_data = pd.read_csv(out_file_name)
            # Ensure consistency in date format
            existing_data['tradeDate'] = pd.to_datetime(existing_data['tradeDate'], format='%d/%m/%Y %H:%M:%S')
            existing_data = existing_data.drop(existing_data.index[-1])
            last_stamp_existing_data = existing_data.iloc[-1].get('tradeDate')
            existing_data['tradeDate'] = existing_data['tradeDate'].dt.strftime('%d/%m/%Y %H:%M:%S')
            # Append only new rows
            new_data = df[df['tradeDate'] > last_stamp_existing_data]
            new_data['tradeDate'] = new_data['tradeDate'].dt.strftime('%d/%m/%Y %H:%M:%S')
            if not new_data.empty:
                combined_data = pd.concat([existing_data, new_data]).drop_duplicates(subset=['tradeDate']).reset_index(drop=True)
                print(combined_data.tail())
                combined_data.to_csv(out_file_name, index=False)

                print(f"Successfully updated {out_file_name} with {len(new_data)} new rows.")
            else:
                print(f"No new data to update for {out_file_name}.")
        else:
            df['tradeDate'] = df['tradeDate'].dt.strftime('%d/%m/%Y %H:%M:%S')
            #Save the entire DataFrame if the file doesn't exist
            df.to_csv(out_file_name, index=False)
            print(f"Successfully created {out_file_name} with all data.")

    
    def all_downloader_yfinance(self):
        try:
            nn_stock, nn_y_fin = self.get_stock_details()
            ticker_map = dict(zip(nn_y_fin, nn_stock))

            for interval in self.download_time_frames:
                end_date, start_date = self.return_now_and_previous_date(interval)

                for ticker_chunk in self.chunked(nn_y_fin, 20):  # Process 20 at a time
                    tickers_str = " ".join(ticker_chunk)
                    print(f"Downloading: {tickers_str} | Interval: {interval}")

                    data = yf.download(
                        tickers=tickers_str,
                        start=start_date,
                        end=end_date,
                        interval=interval,
                        group_by="ticker",
                        threads=False,
                        progress=False,
                    )

                    for ticker in ticker_chunk:
                        try:
                            if isinstance(data.columns, pd.MultiIndex):
                                ticker_data = data[ticker]
                            else:
                                ticker_data = data
                            if ticker_data.empty:
                                continue
                            tick_name = ticker_map[ticker]
                            self.format_and_store_delta_stock_data(ticker_data, tick_name, interval)
                        except Exception as ex:
                            logger.error(f"{ticker} ({interval}): {ex}")

            # 75-minute conversion
            for file in os.listdir(os.path.join(stock_data_dir_config.us_data_dir, 'latest_data_csv')):
                if 'fifteen' in file:
                    self.create_75munite_from_15munite(file)

        except Exception as ex:
            logger.exception(ex, stack_info=True)
            raise StopIteration


    def process_all(self):
        try:
            input_dir = os.path.join(stock_data_dir_config.us_data_dir, 'latest_data_csv')
            output_dir = os.path.join(stock_data_dir_config.us_data_dir, 'processed_data_files')
            self.all_downloader_yfinance()
            with ThreadPoolExecutor(max_workers=10) as executor:
                for stock_item in os.listdir(input_dir):
                    executor.submit(proc_delta_stock_items, stock_item, input_dir, output_dir)
                    # proc_delta_stock_items(stock_item, input_dir, output_dir)

        except Exception as ex:
            logger.error(ex)

        print("US stock update process complete ...........................")