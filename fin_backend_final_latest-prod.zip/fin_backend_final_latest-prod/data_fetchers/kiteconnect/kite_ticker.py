from kiteconnect import KiteTicker
from threading import Lock
import threading
import time
from shared.config.settings import kite_config as kcfg
from data_fetchers.kiteconnect.kite_session import load_access_token

API_KEY = kcfg.api_key
ACCESS_TOKEN = load_access_token().get('access_token')

class KiteTickerManager:
    def __init__(self):
        self.kws = KiteTicker(API_KEY, ACCESS_TOKEN)
        self.subscribers = {}  # token: set of websocket clients
        self.latest_prices = {}
        self.token_lock = Lock()

        self.kws.on_ticks = self.on_ticks
        self.kws.on_connect = self.on_connect
        self.kws.on_close = self.on_close
        self.start()

    def start(self):
        self.kws.connect(threaded=True)

    def on_connect(self, ws, response):
        print("🟢 Connected to Zerodha WebSocket")

    def on_close(self, ws, code, reason):
        print(f"🔴 WebSocket closed: {reason}")

    def on_ticks(self, ws, ticks):
        for tick in ticks:
            token = tick['instrument_token']
            last_price = tick.get('last_price')
            if last_price is not None:
                self.latest_prices[token] = last_price
            if token in self.subscribers:
                for websocket in self.subscribers[token]:
                    try:
                        websocket.send_json(tick)
                    except:
                        pass  # Disconnected clients
    
    def get_latest_price(self, token):
        return self.latest_prices.get(token)

    def subscribe(self, tokens, websocket):
        with self.token_lock:
            for token in tokens:
                token = int(token)
                if token not in self.subscribers:
                    self.subscribers[token] = set()
                    self.kws.subscribe([token])
                    self.kws.set_mode(self.kws.MODE_FULL, [token])
                self.subscribers[token].add(websocket)

    def unsubscribe(self, websocket):
        with self.token_lock:
            for token in list(self.subscribers):
                if websocket in self.subscribers[token]:
                    self.subscribers[token].remove(websocket)
                    if not self.subscribers[token]:
                        self.kws.unsubscribe([token])
                        del self.subscribers[token]

# Singleton instance
# kite_ws_manager = KiteTickerManager()