import json
import os
from kiteconnect import KiteConnect, KiteTicker
from shared.config.settings import kite_config as kcfg
from datetime import datetime

TOKEN_FILE = "./access_token.json"

kite = KiteConnect(api_key=kcfg.api_key)

user_data = {
    'user_type': 'individual/res_no_nn',
    'email': 'saptarshisil7@gmail.com',
    'user_name': 'Saptarshi Sil',
    'user_shortname': 'Saptarshi',
    'broker': 'ZERODHA',
    'exchanges': ['MF', 'NFO', 'NCO', 'BSE', 'NSE', 'BFO', 'BCD', 'MCX'],
    'products': ['CNC', 'NRML', 'MIS', 'BO', 'CO'],
    'order_types': ['MARKET', 'LIMIT', 'SL', 'SL-M'],
    'avatar_url': None,
    'user_id': 'UW8299',
    'api_key': 'hfvcn8vtn5f6z4t5',
    'access_token': 'cPTsbhazEzos60bmcwsx0lyHBjv4CiQD',
    'public_token': 'V5YGYIXsrqgC9To84mKqxzzZUCL31S5w',
    'refresh_token': '',
    'enctoken': 'wEzC1CziuL/5KIagfQqULs4auqdOhCghFSuVt1fXoxtzJtgFasEv7BRb8lfYQ9XRc6mo6EA7b6qOF+VcU4DbQhhlJOJVf4gfTQyn7dCp3GeFWE2uHcnPBvfEmJnpJ/k=',
    'login_time': datetime(2025, 5, 15, 9, 23, 8),  # datetime object
    'meta': {'demat_consent': 'consent'}
}


def get_instrument_token(symbol_name: str, exchange: str = "NSE") -> int:
    try:
        instruments = kite.instruments(exchange.upper())
        for instrument in instruments:
            if instrument["tradingsymbol"].lower() == symbol_name.lower():
                return instrument["instrument_token"]
        print(f"Symbol '{symbol_name}' not found on {exchange}")
        return None
    except Exception as e:
        print(f"Error fetching instrument token: {e}")
        return None



def save_access_token(token_data):
    with open(TOKEN_FILE, "w") as f:
        user_data['access_token'] = token_data['access_token']
        json.dump(user_data, f, indent=2, default=str)



def load_access_token():
    if os.path.exists(TOKEN_FILE):
        with open(TOKEN_FILE, "r") as f:
            return json.load(f)
    return None


def is_token_valid(token):
    try:
        kite.set_access_token(token)
        kite.profile()  # A lightweight call to validate
        return True
    except Exception as e:
        print("Invalid access token:", e)
        return False


def request_token_flow():
    print("Open this URL in browser and login:")
    print(kite.login_url())

    request_token = input("Paste the request_token from the redirect URL: ")
    try:
        data = kite.generate_session(request_token, api_secret=kcfg.api_secret)
        print(data)
        save_access_token(data)
        print("Access token saved and session is ready.")
    except Exception as e:
        print("Failed to generate session:", e)


def ensure_valid_session():

    saved_data = load_access_token()
    print(saved_data.get("access_token"))
    if saved_data and is_token_valid(saved_data.get("access_token")):
        print("✅ Existing access token is valid. You’re good to go.")
        return True
    else:
        print("🔄 Need to re-authenticate.")
        request_token_flow()



# --- Main Execution ---
if __name__ == "__main__":
    ensure_valid_session()

    # Example: Call a simple API after validation
    profile = kite.profile()
    print(f"\nLogged in as: {profile['user_name']} ({profile['user_id']})")