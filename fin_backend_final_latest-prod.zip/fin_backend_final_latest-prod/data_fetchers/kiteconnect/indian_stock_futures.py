from kiteconnect import KiteConnect
import pandas as pd
from datetime import datetime
from shared.config.settings import kite_config as kcfg
from shared.config.settings import stock_data_dir_config
from data_fetchers.kiteconnect.kite_session import load_access_token
from dateutil.relativedelta import relativedelta
from calendar import monthrange, THURSDAY
from datetime import timedelta, datetime
from nselib.derivatives import expiry_dates_future
from shared.db.db_model import FuturesMaster
from sqlalchemy import distinct
from shared.db.dbconn import DBConnection
from concurrent.futures import ThreadPoolExecutor, as_completed
from scripts.stock_logic import proc_delta_stock_items
import re, os, csv, time
import threading
import logging

logger = logging.getLogger()

class Indian_future_data_handler:
    def __init__(self):
        self.kite = KiteConnect(api_key=kcfg.api_key)
        acc_token = load_access_token().get("access_token")
        self.kite.set_access_token(acc_token)
        self.time_format = "%d-%m-%Y"
        self.download_path = os.path.join(stock_data_dir_config.indian_stock_future_data_dir, 'latest_data_csv')
        self.name_interval_dict = {
            "day" : "daily", 
            "60minute": "sixty", 
            "15minute" : "fifteen"
        }
        self.historical_lock = threading.Lock()
        self.last_historical_time = [0]

    def re_initialize_kite(self):
        self.kite = KiteConnect(api_key=kcfg.api_key)
        acc_token = load_access_token().get("access_token")
        self.kite.set_access_token(acc_token)

    def return_now_and_previous_date(self, frame: str):
        now_date = datetime.now()
        if frame == 'day' or frame == 'month' or frame == 'week':
            start_date = now_date - timedelta(days=1900)
        elif frame == '60minute':
            start_date = now_date - timedelta(days=400)
        elif frame == '15minute':
            start_date = now_date - timedelta(days=200)
        return now_date, start_date

    def join_numbers_from_string(self, input_string):
        # Find all digits using regex
        numbers = re.findall(r'\d+', input_string)
        # Join all found numbers into one string
        result = ''.join(numbers)
        return result

    def get_all_stock_symbols(self):
        dbc = DBConnection()
        session = dbc.get_session()
        symbols = session.query(distinct(FuturesMaster.symbol)).all()
        sym_list = [s[0] for s in symbols]
        dbc.close_engine()
        return sym_list
    
    def get_futures_token(self, symbol, expiry_date_str):
        instruments = self.kite.instruments("NFO")  # NSE F&O segment
        expiry_date = datetime.strptime(expiry_date_str, "%d-%m-%Y").date()
        for inst in instruments:
            if (inst['name'] == symbol and
                inst['segment'] == 'NFO-FUT' and
                inst['expiry'] == expiry_date):
                return inst['instrument_token']
        return None

    def fetch_future_candles(self, instrument_token, from_date, to_date, interval='day'):
        with self.historical_lock:
            now = time.time()
            elapsed = now - self.last_historical_time[0]
            wait_time = max(0, 1/3 - elapsed)  # 3 requests/sec
            if wait_time > 0:
                time.sleep(wait_time)
            self.last_historical_time[0] = time.time()
            cont = True if interval == 'day' else False
            data = self.kite.historical_data(
                instrument_token=instrument_token,
                from_date=from_date,
                to_date=to_date,
                interval=interval,
                continuous=cont
            )
            df = pd.DataFrame(data)
            df['date'] = pd.to_datetime(df['date'])
            df['date'] = df['date'].dt.tz_convert('Asia/Kolkata')
            df['date'] = df['date'].dt.tz_localize(None).dt.strftime('%d/%m/%Y %H:%M:%S')
            df.rename(columns={'date': 'tradeDate', 'volume': 'qty'}, inplace=True)
            return df
    
    def get_contract_start_date(self, expiry_date_str: str):
        """
        Given an expiry date, finds the estimated contract start date
        based on 3-month rolling futures rule and NSE expiry logic.

        Parameters:
        - expiry_date_str (str): Expiry date in 'dd-mm-yyyy' format

        Returns:
        - start_date (datetime.date): Estimated start date when contract started trading
        """
        # Parse the expiry date
        expiry_date = datetime.strptime(expiry_date_str, "%d-%m-%Y").date()
        # Step 1: Go 3 months back from expiry
        three_months_back = expiry_date - relativedelta(months=3)
        # Step 2: Find the previous month's expiry (last Thursday)
        previous_month = three_months_back.month
        previous_year = three_months_back.year
        def last_thursday(year, month):
            last_day = monthrange(year, month)[1]
            for day in range(last_day, 0, -1):
                if datetime(year, month, day).weekday() == THURSDAY:
                    return datetime(year, month, day).date()
        previous_expiry = last_thursday(previous_year, previous_month)
        # Step 3: Assume trading starts the next day (Friday)
        potential_start = previous_expiry + timedelta(days=1)
        # Step 4: If Friday is weekend, move to Monday
        if potential_start.weekday() == 5:  # Saturday
            potential_start += timedelta(days=2)
        elif potential_start.weekday() == 6:  # Sunday
            potential_start += timedelta(days=1)
        return potential_start.strftime('%d-%m-%Y')
    
    def get_upcoming_expiry_list(self):
        return expiry_dates_future()
    
    def get_future_ohlc(self, symbol, expiry_date_str, start_date_str, end_date, file_name):
        token = self.get_futures_token(symbol, expiry_date_str)
        if token:
            # start_date = datetime.strptime(start_date_str, self.time_format)
            # end_date = datetime.strptime(end_date_str, self.time_format)
            for interval in ['day', '60minute', '15minute']:
                end_date, start_date = self.return_now_and_previous_date(interval)
                df = self.fetch_future_candles(token, start_date, end_date, interval)
                df.to_csv(f"{self.download_path}/{file_name.replace('.csv', f'_{self.name_interval_dict[interval]}.csv')}", index=False)

    def download_symbol_expiry_pair(self, symbol, expiry_date_str):
        try:
            contract_start_date = self.get_contract_start_date(expiry_date_str)
            format_idt = self.join_numbers_from_string(expiry_date_str)
            file_name = f"{symbol}_{format_idt}.csv"
            self.get_future_ohlc(symbol, expiry_date_str, contract_start_date, datetime.now(), file_name)
            print(f"✅ {symbol} | {expiry_date_str} | Done")
        except Exception as e:
            print(f"❌ Error for {symbol} | {expiry_date_str}: {e}")
            logger.exception(f"❌ Error for {symbol} | {expiry_date_str}: {e}", stack_info=True, exc_info=1)
    
    def dump_csv(self, header, csv_file, data):
        print("creating_csv", csv_file)
        csv_dump_path = os.path.join(stock_data_dir_config.indian_stock_future_data_dir,'latest_data_csv', csv_file)
        with open(csv_dump_path, 'w', newline='') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=header)
            writer.writeheader()
            writer.writerows(data)
        print(f'CSV file "{csv_file}" created.') 

    
    
    # def process(self, max_workers=10):
    #     all_symbols = self.get_all_stock_symbols()
    #     exp_list = self.get_upcoming_expiry_list()
    #     converted_list = [datetime.strptime(date_str, "%d-%b-%Y").strftime(self.time_format) for date_str in exp_list]
    #     for syms in all_symbols:
    #         for exp_dates in converted_list:
    #             contract_start_date = self.get_contract_start_date(exp_dates)
    #             format_idt = self.join_numbers_from_string(exp_dates)
    #             file_name = f"{syms}_{format_idt}.csv"
    #             self.get_future_ohlc(syms, exp_dates, contract_start_date, datetime.now(), file_name)
    #             print(syms, contract_start_date, exp_dates, file_name)
    def process(self, max_workers=10, batch_size=200, delay_between_batches=10):
        all_symbols = self.get_all_stock_symbols()
        expiry_str_list = [
            datetime.strptime(date_str, "%d-%b-%Y").strftime(self.time_format)
            for date_str in self.get_upcoming_expiry_list()
        ]

        # Prepare all (symbol, expiry) combinations
        tasks = [(sym, exp) for sym in all_symbols for exp in expiry_str_list]
        for i in range(0, len(tasks), batch_size):
            current_batch = tasks[i:i + batch_size]
            print(f"🔁 Processing batch {i // batch_size + 1} with {len(current_batch)} tasks...")
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = {
                    executor.submit(self.download_symbol_expiry_pair, sym, exp): (sym, exp)
                    for sym, exp in current_batch
                }
                for future in as_completed(futures):
                    sym, exp = futures[future]
                    try:
                        future.result()
                    except Exception as e:
                        print(f"❌ Exception in task {sym}-{exp}: {e}")
                        logger.exception(f"❌ Exception in task {sym}-{exp}: {e}", stack_info=True, exc_info=1)
                    
            # for symkgf, exp in current_batch:
            #     self.download_symbol_expiry_pair(symkgf, exp)
            



            print(f"✅ Batch {i // batch_size + 1} complete. Sleeping for {delay_between_batches} sec...")
            time.sleep(delay_between_batches)  # prevent API ban   
            self.re_initialize_kite()

        

class future_data_processer:
    def __init__(self):
        self.ifdh = Indian_future_data_handler()
        self.input_dir = os.path.join(stock_data_dir_config.indian_stock_future_data_dir, 'latest_data_csv')
        self.output_dir = os.path.join(stock_data_dir_config.indian_stock_future_data_dir, 'processed_data_files')
        self.time_format = "%d-%m-%Y"

    def dump_csv(self, header, csv_file, data):
        print("creating_csv", csv_file)
        csv_dump_path = os.path.join(stock_data_dir_config.indian_stock_future_data_dir,'latest_data_csv', csv_file)
        with open(csv_dump_path, 'w', newline='') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=header)
            writer.writeheader()
            writer.writerows(data)
        print(f'CSV file "{csv_file}" created.') 

    def create_75munite_from_15munite(self, file_name: str):
        txt_dir = os.path.join(stock_data_dir_config.indian_stock_future_data_dir, 'latest_data_csv') 
        file_path = os.path.join(txt_dir, file_name)
        print("Reading:", file_path)
        df = pd.read_csv(file_path)[['open', 'high', 'low', 'close', 'qty', 'tradeDate']] # create_75munite_from_15munite
        chunk_size = 5
        output = []
        # Define operation map
        agg_map = {
            'open': lambda chunk: chunk.iloc[0]['open'],
            'high': lambda chunk: chunk['high'].max(),
            'low': lambda chunk: chunk['low'].min(),
            'close': lambda chunk: chunk.iloc[-1]['close'],
            'qty': lambda chunk: chunk['qty'].sum(),
            # 'tradeTime': lambda chunk: chunk.iloc[0]['tradeTime'],
            'tradeDate': lambda chunk: chunk.iloc[0]['tradeDate']
        }
        for i in range(0, len(df), chunk_size):
            chunk = df.iloc[i:i + chunk_size]
            if len(chunk) < chunk_size:
                break  # Skip incomplete chunk

            new_row = {col: func(chunk) for col, func in agg_map.items()}
            output.append(new_row)

        if output:
            headers = output[0].keys()
            csv_file_name = file_name.replace("fifteen", "seventy_five")
            self.dump_csv(headers, csv_file_name, output)
            print("Saved as:", csv_file_name)
        else:
            print("No complete 75-minute chunks to save.")

    def create_monthly_and_weekly_from_daily(self, file_name: str, sample: str):
        txt_dir = os.path.join(stock_data_dir_config.indian_stock_future_data_dir, 'latest_data_csv') 
        file_path = os.path.join(txt_dir, file_name)
        df = pd.read_csv(file_path)[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]
        df['timstamp'] = pd.to_datetime(df['tradeDate'], dayfirst=True)
        df.set_index('timstamp', inplace=True)
        # df = df.sort_values(by='tradeDate', ascending=True)
        # Resample to weekly frequency
        re_sample = 'W-FRI' if sample == 'W' else sample
        grouped = df.groupby(pd.Grouper(freq=re_sample))
        records = []
        for _, group in grouped:
            if group.empty:
                continue
            first_date = group.index[0]
            open_ = group['open'].iloc[0]
            high_ = group['high'].max()
            low_ = group['low'].min()
            close_ = group['close'].iloc[-1]
            qty_ = group['qty'].sum()

            records.append({
                "tradeDate": first_date,
                "open": open_,
                "high": high_,
                "low": low_,
                "close": close_,
                "qty": qty_
            })
        # print(records)
        result_df = pd.DataFrame(records)
        print(result_df.columns, "#####################################", file_name)
        result_df['tradeDate'] = result_df['tradeDate'].dt.strftime("%d/%m/%Y %H:%M:%S")
        result_df = result_df[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]
        mon_val = 'weekly' if sample == 'W' else 'monthly'
        out_file_name = os.path.join(txt_dir, file_name.replace('daily', mon_val))
        result_df.to_csv(out_file_name)
    # def get_all_stock_files(self):
    #     all_files_list = []
    #     stock_syms = self.ifdh.get_all_stock_symbols()
    #     expiry_str_list = [
    #         datetime.strptime(date_str, "%d-%b-%Y").strftime(self.time_format)
    #         for date_str in self.ifdh.get_upcoming_expiry_list()
    #     ]
    #     conv_exp_list = [self.ifdh.join_numbers_from_string(items) for items in expiry_str_list]
    #     for syms in stock_syms:
    #         for exp_lst in conv_exp_list:
    #             for time_frames in ['daily', 'seventy_five', 'sixty', 'fifteen']:
    #                 file_names = f"{syms}_{exp_lst}_{time_frames}.csv"
    #                 all_files_list.append(file_names)
    #     return all_files_list
    
    # def remove_old_files(self, keep_files):
    #     """
    #     Deletes all files in 'directory' except those in 'keep_files'.

    #     Args:
    #     - directory (str): The directory to scan.
    #     - keep_files (list): List of filenames to keep (with extension).
    #     """
    #     existing_files = set(os.listdir(self.input_dir))
    #     keep_files_set = set(keep_files)

    #     # Files to delete = all files - keep_files
    #     files_to_delete = existing_files - keep_files_set
    #     print(files_to_delete)
    #     if files_to_delete:
    #         for file in files_to_delete:
    #             file_path = os.path.join(self.input_dir, file)
    #             try:
    #                 if os.path.isfile(file_path):
    #                     os.remove(file_path)
    #                     print(f"Deleted: {file}")
    #             except Exception as e:
    #                 print(f"Error deleting {file}: {e}")
    #     else:
    #         print("No files to delete")


    def process_all_files(self):
        all_file_list = os.listdir(self.input_dir)
        for items in all_file_list:
            if str(items).__contains__("fifteen"):
                self.create_75munite_from_15munite(items)
            if str(items).__contains__("daily"):
                self.create_monthly_and_weekly_from_daily(items, 'W')
                self.create_monthly_and_weekly_from_daily(items, 'ME')
        # all_files_to_process = self.get_all_stock_files()
        # self.remove_old_files(all_files_to_process)
        # with ThreadPoolExecutor(max_workers=10) as executor:
        #     for stock_item in os.listdir(self.input_dir):
        #         executor.submit(proc_delta_stock_items, stock_item, self.input_dir, self.output_dir)
        print("all_stock_process_complete...................")



