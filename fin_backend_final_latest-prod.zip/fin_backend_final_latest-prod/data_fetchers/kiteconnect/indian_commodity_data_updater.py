from kiteconnect import KiteConnect
import pandas as pd
from datetime import datetime
from shared.config.settings import kite_config as kcfg
from shared.config.settings import stock_data_dir_config as sddcfg
from data_fetchers.kiteconnect.kite_session import load_access_token
from shared.db.dbconn import DBConnection
from shared.db.db_model import CommoditiesMaster
from sqlitedict import SqliteDict
from concurrent.futures import ThreadPoolExecutor
from scripts.stock_logic import proc_delta_stock_items
import os, re, csv
from datetime import datetime, timedelta
from data_fetchers.fyers.fyers_session import fyers_access_token_handler

class MCXFutureDataHandler:
    def __init__(self):
        self.kite = KiteConnect(api_key=kcfg.api_key)
        self.kite.set_access_token(load_access_token().get("access_token"))
        self.download_path = os.path.join(sddcfg.indian_commodity_data, 'latest_data_csv')
        self.output_path = os.path.join(sddcfg.indian_commodity_data, 'processed_data_files')
        self.commodities = self.get_commodity_symbols()
        self.instrument_df = self.load_instrument_tokens()
        self.lite_db = SqliteDict('finprod.sqlite')
        self.name_interval_dict = {
            "day" : "daily", 
            "60minute": "sixty", 
            "15minute" : "fifteen"
        }
        self.update_latest_3_expiries_mcx()
    
    def get_commodity_symbols(self):
        dbc = DBConnection()
        session = dbc.get_session()
        symbols = session.query(CommoditiesMaster.symbol).all()
        sym_list = [s[0] for s in symbols]
        dbc.close_engine()
        return sym_list

    def create_monthly_and_weekly_from_daily(self, file_name: str, sample: str):
        txt_dir = os.path.join(sddcfg.indian_commodity_data, 'latest_data_csv') 
        file_path = os.path.join(txt_dir, file_name)
        df = pd.read_csv(file_path)[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]
        df['timstamp'] = pd.to_datetime(df['tradeDate'], dayfirst=True)
        df.set_index('timstamp', inplace=True)
        # df = df.sort_values(by='tradeDate', ascending=True)
        # Resample to weekly frequency
        re_sample = 'W-FRI' if sample == 'W' else sample
        grouped = df.groupby(pd.Grouper(freq=re_sample))
        records = []
        for _, group in grouped:
            if group.empty:
                continue
            first_date = group.index[0]
            open_ = group['open'].iloc[0]
            high_ = group['high'].max()
            low_ = group['low'].min()
            close_ = group['close'].iloc[-1]
            qty_ = group['qty'].sum()

            records.append({
                "tradeDate": first_date,
                "open": open_,
                "high": high_,
                "low": low_,
                "close": close_,
                "qty": qty_
            })
        # print(records)
        result_df = pd.DataFrame(records)
        print(result_df.columns, "#####################################", file_name)
        result_df['tradeDate'] = result_df['tradeDate'].dt.strftime("%d/%m/%Y %H:%M:%S")
        result_df = result_df[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]
        mon_val = 'weekly' if sample == 'W' else 'monthly'
        out_file_name = os.path.join(txt_dir, file_name.replace('daily', mon_val))
        result_df.to_csv(out_file_name)
    
    def return_now_and_previous_date(self, frame: str):
        now_date = datetime.now()
        if frame == 'day' or frame == 'month' or frame == 'week':
            start_date = now_date - timedelta(days=1900)
        elif frame == '60minute':
            start_date = now_date - timedelta(days=400)
        elif frame == '15minute':
            start_date = now_date - timedelta(days=200)
        return now_date, start_date

    def create_75munite_from_15munite(self, file_name: str):
        txt_dir = os.path.join(sddcfg.indian_commodity_data, 'latest_data_csv') 
        file_path = os.path.join(txt_dir, file_name)
        print("Reading:", file_path)
        df = pd.read_csv(file_path)[['open', 'high', 'low', 'close', 'qty', 'tradeDate']] # create_75munite_from_15munite
        chunk_size = 5
        output = []
        # Define operation map
        agg_map = {
            'open': lambda chunk: chunk.iloc[0]['open'],
            'high': lambda chunk: chunk['high'].max(),
            'low': lambda chunk: chunk['low'].min(),
            'close': lambda chunk: chunk.iloc[-1]['close'],
            'qty': lambda chunk: chunk['qty'].sum(),
            # 'tradeTime': lambda chunk: chunk.iloc[0]['tradeTime'],
            'tradeDate': lambda chunk: chunk.iloc[0]['tradeDate']
        }
        for i in range(0, len(df), chunk_size):
            chunk = df.iloc[i:i + chunk_size]
            if len(chunk) < chunk_size:
                break  # Skip incomplete chunk

            new_row = {col: func(chunk) for col, func in agg_map.items()}
            output.append(new_row)

        if output:
            headers = output[0].keys()
            csv_file_name = file_name.replace("fifteen", "seventy_five")
            self.dump_csv(headers, csv_file_name, output)
            print("Saved as:", csv_file_name)
        else:
            print("No complete 75-minute chunks to save.")

    def load_instrument_tokens(self):
        all_instruments = self.kite.instruments("MCX")
        df = pd.DataFrame(all_instruments)
        df = df[df['segment'] == 'MCX-FUT']
        df = df[df['name'].isin(self.commodities)]
        df['expiry'] = pd.to_datetime(df['expiry'])
        return df
    
    def get_commodity_token(self, symbol, expiry_date_str):
        instruments = self.kite.instruments("MCX")  # NSE F&O segment
        expiry_date = datetime.strptime(expiry_date_str, "%d-%m-%Y").date()
        for inst in instruments:
            if (inst['name'] == symbol and
                inst['segment'] == 'MCX-FUT' and
                inst['expiry'] == expiry_date):
                return inst['instrument_token']
        return None
    
    def dump_csv(self, header, csv_file, data):
        print("creating_csv", csv_file)
        csv_dump_path = os.path.join(sddcfg.indian_commodity_data,'latest_data_csv', csv_file)
        with open(csv_dump_path, 'w', newline='') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=header)
            writer.writeheader()
            writer.writerows(data)
        print(f'CSV file "{csv_file}" created.')


    def get_near_next_far_expiries(self, symbol):
        df = self.instrument_df[self.instrument_df['name'] == symbol].sort_values(by='expiry')
        return df.head(3)  # near, next, far
    
    def update_latest_3_expiries_mcx(self):
        instruments = self.kite.instruments("MCX")
        enm_dict = {}
        for syms in self.commodities:
            expiry_dates = set()
            for inst in instruments:
                if inst['name'] == syms and inst['segment'] == 'MCX-FUT':
                    expiry_dates.add(inst['expiry']) # .strftime('%d-%m-%Y')
            sorted_expiries = sorted(list(expiry_dates), reverse=False)
            enm_dict[syms] = sorted_expiries[:3]
        self.lite_db['indian_commodity_expiries'] = enm_dict
        self.lite_db.commit()
        self.lite_db.close()

    def fetch_candle_data(self, token, from_date, to_date, interval):
        try:
            cont = True if interval == 'day' else False
            data = self.kite.historical_data(
                instrument_token=token,
                from_date=from_date,
                to_date=to_date,
                interval=interval,
                continuous=cont
            )
            df = pd.DataFrame(data)
            df['date'] = pd.to_datetime(df['date']).dt.tz_convert('Asia/Kolkata').dt.tz_localize(None).dt.strftime('%d/%m/%Y %H:%M:%S')
            df.rename(columns={'date': 'tradeDate', 'volume': 'qty'}, inplace=True)
            return df
        except Exception as e:
            print(f"Error fetching for token {token}: {e}")
            return pd.DataFrame()

    def download_all(self, intervals=['day', '60minute', '15minute']):
        today = datetime.now()
        from_date = today.replace(month=today.month - 1)

        for symbol in self.commodities:
            contracts = self.get_near_next_far_expiries(symbol)
            # exp_dt = self.get_latest_3_expiries_mcx(symbol)

            for _, row in contracts.iterrows():
                token = row['instrument_token']
                expiry = row['expiry'].strftime('%d-%m-%Y')
                numbers = re.findall(r'\d+', expiry)
                # Join all found numbers into one string
                exp_num = ''.join(numbers)
                for interval in intervals:
                    end_dt, start_dt = self.return_now_and_previous_date(interval)
                    df = self.fetch_candle_data(token, start_dt, end_dt, interval)
                    if not df.empty:
                        fname = f"{symbol}_{exp_num}_{self.name_interval_dict[interval]}.csv"
                        df.to_csv(os.path.join(self.download_path, fname), index=False)
                        print(f"Saved: {fname}")

        all_file_list = os.listdir(self.download_path)
        for items in all_file_list:
            if str(items).__contains__("fifteen"):
                self.create_75munite_from_15munite(items)
            elif str(items).__contains__("daily"):
                self.create_monthly_and_weekly_from_daily(items, 'W')
                self.create_monthly_and_weekly_from_daily(items, 'ME')
    
    def process_all(self):
        with ThreadPoolExecutor(max_workers=10) as executor:
            for stock_item in os.listdir(self.download_path):
                executor.submit(proc_delta_stock_items, stock_item, self.download_path, self.output_path)
        print("all_stock_process_complete...................")




