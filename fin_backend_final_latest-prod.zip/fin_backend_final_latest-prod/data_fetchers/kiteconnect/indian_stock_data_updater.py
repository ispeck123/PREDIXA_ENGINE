import os
from scripts.stock_logic import proc_delta_stock_items
from shared.db.dbconn import DBConnection 
from kiteconnect import KiteConnect
from data_fetchers.kiteconnect.kite_session import load_access_token
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor, as_completed
from sqlalchemy import text
import pandas as pd
import yfinance as yf
import csv
from pathlib import Path
from shared.config.settings import kite_config as kcfg
from shared.config.settings import stock_data_dir_config
from shared.utils.logger import logger

class INDIAN_STOCK_DATA_UPDATER:
    def __init__(self):
        self.download_time_frames = ['day', '60minute', '15minute']
        self.frame_name_dict = {
            'day': 'daily',
            '60minute': 'sixty',
            '15minute': 'fifteen'
        }
        saved_data = load_access_token()
        self.kite = KiteConnect(api_key=kcfg.api_key)
        print(saved_data.get("access_token"))
        self.kite.set_access_token(saved_data.get("access_token"))

    def chunked(self, iterable, n):
        for i in range(0, len(iterable), n):
            yield iterable[i:i + n]

    def return_now_and_previous_date(self, frame: str):
        now_date = datetime.now()
        if frame == 'day' or frame == 'month' or frame == 'week':
            start_date = now_date - timedelta(days=1900)
        elif frame == '60minute':
            start_date = now_date - timedelta(days=400)
        elif frame == '15minute':
            start_date = now_date - timedelta(days=200)
        return now_date, start_date

    def dump_csv(self, header, csv_file, data):
        print("creating_csv", csv_file)
        csv_dump_path = os.path.join(stock_data_dir_config.indian_stock_data_dir,'latest_data_csv', csv_file)
        with open(csv_dump_path, 'w', newline='') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=header)
            writer.writeheader()
            writer.writerows(data)
        print(f'CSV file "{csv_file}" created.')

    def create_monthly_and_weekly_from_daily(self, file_name: str, sample: str):
        txt_dir = os.path.join(stock_data_dir_config.indian_stock_data_dir, 'latest_data_csv') 
        file_path = os.path.join(txt_dir, file_name)
        df = pd.read_csv(file_path)[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]
        df['timstamp'] = pd.to_datetime(df['tradeDate'], dayfirst=True)
        df.set_index('timstamp', inplace=True)
        # df = df.sort_values(by='tradeDate', ascending=True)
        # Resample to weekly frequency
        re_sample = 'W-FRI' if sample == 'W' else sample
        grouped = df.groupby(pd.Grouper(freq=re_sample))
        records = []
        for _, group in grouped:
            if group.empty:
                continue
            first_date = group.index[0]
            open_ = group['open'].iloc[0]
            high_ = group['high'].max()
            low_ = group['low'].min()
            close_ = group['close'].iloc[-1]
            qty_ = group['qty'].sum()

            records.append({
                "tradeDate": first_date,
                "open": open_,
                "high": high_,
                "low": low_,
                "close": close_,
                "qty": qty_
            })
        # print(records)
        result_df = pd.DataFrame(records)
        print(result_df.columns, "#####################################", file_name)
        result_df['tradeDate'] = result_df['tradeDate'].dt.strftime("%d/%m/%Y %H:%M:%S")
        result_df = result_df[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]
        mon_val = 'weekly' if sample == 'W' else 'monthly'
        out_file_name = os.path.join(txt_dir, file_name.replace('daily', mon_val))
        result_df.to_csv(out_file_name)


    def create_75munite_from_15munite(self, file_name: str):
        txt_dir = os.path.join(stock_data_dir_config.indian_stock_data_dir, 'latest_data_csv') 
        file_path = os.path.join(txt_dir, file_name)
        print("Reading:", file_path)
        df = pd.read_csv(file_path)[['open', 'high', 'low', 'close', 'qty', 'tradeDate']] # create_75munite_from_15munite
        chunk_size = 5
        output = []
        # Define operation map
        agg_map = {
            'open': lambda chunk: chunk.iloc[0]['open'],
            'high': lambda chunk: chunk['high'].max(),
            'low': lambda chunk: chunk['low'].min(),
            'close': lambda chunk: chunk.iloc[-1]['close'],
            'qty': lambda chunk: chunk['qty'].sum(),
            # 'tradeTime': lambda chunk: chunk.iloc[0]['tradeTime'],
            'tradeDate': lambda chunk: chunk.iloc[0]['tradeDate']
        }
        for i in range(0, len(df), chunk_size):
            chunk = df.iloc[i:i + chunk_size]
            if len(chunk) < chunk_size:
                break  # Skip incomplete chunk

            new_row = {col: func(chunk) for col, func in agg_map.items()}
            output.append(new_row)

        if output:
            headers = output[0].keys()
            csv_file_name = file_name.replace("fifteen", "seventy_five")
            self.dump_csv(headers, csv_file_name, output)
            print("Saved as:", csv_file_name)
        else:
            print("No complete 75-minute chunks to save.")

    def get_stock_details(self):
        stock_list = []
        token_list = []
        dbc = DBConnection()
        res = dbc.raw_query(text("select stock_tick, kite_symbol, kite_token from ind_stock_master where is_active=1 and kite_symbol IS NOT NULL and kite_token IS NOT NULL;"))
        dbc.close_engine()
        for stock in res:
            stock_list.append(stock.get('stock_tick'))
            token_list.append(stock.get('kite_token'))  # or store instrument_token if you have it
        return stock_list, token_list

    def get_stock_data(self, instrument_token, start_date, end_date, interval='day'):
        try:
            # print(instrument_token, "**********************")
            data = self.kite.historical_data(
                instrument_token=instrument_token,
                from_date=start_date,
                to_date=end_date,
                interval=interval,
                continuous=False
            )
            # print(data)
            return pd.DataFrame(data)
        except Exception as e:
            print(f"Error fetching data for token {instrument_token}: {e}")
            return pd.DataFrame()

    def format_and_store_delta_stock_data(self, stock_data: pd.DataFrame, tick: str, interval: str):
        required_columns = ['date', 'open', 'high', 'low', 'close', 'volume']
        for col in required_columns:
            if col not in stock_data.columns:
                raise ValueError(f"Missing required column: {col}")

        df = stock_data.rename(columns={
            'open': 'open',
            'high': 'high',
            'low': 'low',
            'close': 'close',
            'volume': 'qty',
            'date': 'tradeDate'
        })

        # df['tradeDate'] = pd.to_datetime(df['tradeDate'])  # keep as datetime
        df['tradeDate'] = pd.to_datetime(df['tradeDate']).dt.tz_localize(None)
        df = df.sort_values('tradeDate')
        # df['tradeTime'] = df['tradeDate'].dt.strftime('%H:%M:%S')

        output_dir = Path(os.path.join(stock_data_dir_config.indian_stock_data_dir, 'latest_data_csv'))
        output_dir.mkdir(parents=True, exist_ok=True)
        out_file_name = output_dir / f"{tick}_{self.frame_name_dict[interval]}.csv"

        if out_file_name.exists():
            existing_data = pd.read_csv(out_file_name)
            existing_data['tradeDate'] = pd.to_datetime(existing_data['tradeDate'], format='%d/%m/%Y %H:%M:%S')
            existing_data = existing_data.drop(existing_data.index[-1])  # Drop possibly incomplete row
            last_stamp = existing_data.iloc[-1]['tradeDate']

            # Only keep new rows
            df_filtered = df[df['tradeDate'] > last_stamp].copy()
        else:
            df_filtered = df

        # Format before saving to CSV
        df_filtered['tradeDate'] = df_filtered['tradeDate'].dt.strftime('%d/%m/%Y %H:%M:%S')
        df_filtered = df_filtered[['open', 'high', 'low', 'close', 'qty', 'tradeDate']] # create_75munite_from_15munite

        if not df_filtered.empty:
            if out_file_name.exists():
                existing_data['tradeDate'] = existing_data['tradeDate'].dt.strftime('%d/%m/%Y %H:%M:%S')
                combined_data = pd.concat([existing_data, df_filtered]).drop_duplicates(subset=['tradeDate']).reset_index(drop=True)
                combined_data.to_csv(out_file_name, index=False)
                print(f"✅ Updated {out_file_name} with {len(df_filtered)} new rows.")
            else:
                df_filtered.to_csv(out_file_name, index=False)
                print(f"✅ Created {out_file_name} with {len(df_filtered)} rows.")
        else:
            print(f"No new data to update for {tick}")


    def all_downloader_kite(self):
        try:
            stock_names, kite_tokens = self.get_stock_details()
            token_map = dict(zip(kite_tokens, stock_names))

            for interval in self.download_time_frames:
                end_date, start_date = self.return_now_and_previous_date(interval)

                for token in kite_tokens:
                    try:
                        stock_data = self.get_stock_data(token, start_date, end_date, interval)
                        if not stock_data.empty:
                            tick_name = token_map[token]
                            self.format_and_store_delta_stock_data(stock_data, tick_name, interval)
                        else:
                            print(f"No data for token {token}")
                    except Exception as ex:
                        logger.error(f"Error fetching/storing {tick_name} {token}: {ex}")

        except Exception as ex:
            logger.exception(ex, stack_info=True)
            raise StopIteration

    def process_all(self):
        try:
            input_dir = os.path.join(stock_data_dir_config.indian_stock_data_dir, 'latest_data_csv')
            output_dir = os.path.join(stock_data_dir_config.indian_stock_data_dir, 'processed_data_files')
            self.all_downloader_kite()
            all_file_path = os.path.join(stock_data_dir_config.indian_stock_data_dir, 'latest_data_csv')
            for file in os.listdir(all_file_path):
                if 'daily' in file:
                    self.create_monthly_and_weekly_from_daily(file, 'W')
                    self.create_monthly_and_weekly_from_daily(file, 'ME')
                if 'fifteen' in file:
                    self.create_75munite_from_15munite(file)
            # with ThreadPoolExecutor(max_workers=10) as executor:
            #     for stock_item in os.listdir(input_dir):
            #         executor.submit(proc_delta_stock_items, stock_item, input_dir, output_dir)
            print("Indian stock update process complete.")
        except Exception as ex:
            logger.error(ex, stack_info=True)

        print("Indian stock update process complete ...........................")

