import dagster as dg
from apps.pipelines.stock_operations import operations_run_trades_on_daily_cash, operations_run_trades_on_sixty_cash, operations_run_trades_on_fifteen_cash
from apps.pipelines.stock_operations import operation_run_sixty_trades_futures, operation_run_fifteen_trades_futures
from apps.pipelines.stock_operations import operation_run_sixty_trades_commodity, operation_run_fifteen_trades_commodity
from apps.pipelines.stock_operations import pull_india_stock_data, pull_indian_commodity_data, pull_future_data_india, pull_us_stock_data
from apps.pipelines.stock_operations import operation_entry_alert_engine_in_market_hours, operation_setup_alert_engine_in_market_hours
from datetime import datetime, time
################################################### CASH TRADE JOBS ##########################################

@dg.job
def daily_trades_job_india_cash():
    operations_run_trades_on_daily_cash()

@dg.job
def sixty_trades_job_india_cash():
    operations_run_trades_on_sixty_cash()

@dg.job
def fifteen_trades_job_india_cash():
    operations_run_trades_on_fifteen_cash()

##########################################################################################################
################################################### Future TRADE JOBS ##########################################

@dg.job
def sixty_trades_job_futures():
    operation_run_sixty_trades_futures()


@dg.job
def fifteen_trades_job_futures():
    operation_run_fifteen_trades_futures()

#############################################################################################################
################################################### Commodity TRADE JOBS ##########################################

@dg.job
def sixty_trades_job_commodity():
    operation_run_sixty_trades_commodity()

@dg.job
def fifteen_trades_job_commodity():
    operation_run_fifteen_trades_commodity()

##############################################################################################################
################################################### DATA PULL JOBS ###########################################

@dg.job
def update_indian_stock_data_job():
    # Define the Indian trading hours (from 9:15 AM to 3:15 PM)
    start_time = time(9, 14)  # 9:15 AM
    end_time = time(15, 36)   # 3:30 PM
    current_time = datetime.now().time()
    # Schedule task every 15 mins during trading hours if current time is within trading hours
    if (start_time <= current_time <= end_time):
        print("Updating Indian Stocks data..............")
        pull_india_stock_data()

# @dg.job
# def accumulate_daily_trades_job_us():
#     accumulate_daily_trades()

# @dg.job
# def accumulate_sixty_trades_job_us():
#     start_time = time(18, 59)  # 7:00 PM
#     end_time = time(1, 36)   # 1:30 AM
#     current_time = datetime.now().time()
#     # Schedule task every hour during trading hours if current time is within trading hours
#     if (start_time <= current_time <= end_time):
#         accumulate_sixty_trades()

# @dg.job
# def accumulate_fifteen_trades_job_us():
#     start_time = time(18, 59)  # 7:00 PM
#     end_time = time(1, 36)   # 1:30 AM
#     current_time = datetime.now().time()
#     # Schedule task every 15 mins during trading hours if current time is within trading hours
#     if (start_time <= current_time <= end_time):
#         accumulate_fifteen_trades()



@dg.job
def update_us_stock_data_job():
    start_time = time(18, 59)  # 7:00 PM
    end_time = time(1, 36)   # 1:30 AM
    current_time = datetime.now().time()
    # Schedule task every 15 mins during trading hours if current time is within trading hours
    if (start_time <= current_time <= end_time):
        print("Updating US Stocks data..............")
        pull_us_stock_data()

@dg.job
def future_data_india_job():
    day = datetime.now().strftime('%A')
    if day != 'Saturday' and day != 'Sunday':
        print("Updating Future data for India..............")
        pull_future_data_india()

@dg.job
def update_indian_commodity_job():
    pull_indian_commodity_data()

##############################################################################################################
################################################### Alert Engine JOBS ########################################

@dg.job
def market_controlled_setup_alert_job():
    operation_setup_alert_engine_in_market_hours()

@dg.job
def market_controlled_entry_alert_job():
    operation_entry_alert_engine_in_market_hours()

##############################################################################################################