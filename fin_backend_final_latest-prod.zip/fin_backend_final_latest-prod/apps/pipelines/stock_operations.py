import dagster as dg
from apps.pipelines.trade_accumulator_cash import daily_trades_accumulate, sixty_trades_accumulate, fifteen_trades_accumulate
from apps.pipelines.trade_accumulator_future_commodity import sixty_trades_accumulate_futures_and_commodity, fifteen_trades_accumulate_futures_and_commodity
from data_fetchers.kiteconnect.indian_stock_data_updater import INDIAN_STOCK_DATA_UPDATER
from data_fetchers.kiteconnect.indian_commodity_data_updater import MCXFutureDataHandler
from data_fetchers.kiteconnect.indian_stock_futures import Indian_future_data_handler, future_data_processer
from data_fetchers.yfinance.us_stock_data_updater import US_STOCK_DATA_UPDATER
from alert_engine.alert import setup_alert_engine, start_entry_alert_engine
from datetime import datetime
import time

########################################### Cash Operations ############################################

@dg.op(config_schema={"country": str})
def operations_run_trades_on_daily_cash(context):
    country = context.op_config["country"]
    print(country, "country")
    daily_trades_accumulate(country)

@dg.op(config_schema={"country": str})
def operations_run_trades_on_sixty_cash(context):
    country = context.op_config["country"]
    print(country, "country")
    sixty_trades_accumulate(country)

@dg.op(config_schema={"country": str})
def operations_run_trades_on_fifteen_cash(context):
    country = context.op_config["country"]
    print(country, "country")
    fifteen_trades_accumulate(country)

########################################### ###########################################
########################################### Future Operations ############################################

@dg.op
def operation_run_sixty_trades_futures(context):
    sixty_trades_accumulate_futures_and_commodity('futures')

@dg.op
def operation_run_fifteen_trades_futures(context):
    fifteen_trades_accumulate_futures_and_commodity('futures')

########################################### ###########################################
########################################### Commodity Operations ############################################

@dg.op
def operation_run_sixty_trades_commodity(context):
    sixty_trades_accumulate_futures_and_commodity('commodity')

@dg.op
def operation_run_fifteen_trades_commodity(context):
    fifteen_trades_accumulate_futures_and_commodity('commodity')

########################################### ###########################################
########################################### DATA PULL Operations ############################################

@dg.op
def pull_us_stock_data(context):
    ussdu = US_STOCK_DATA_UPDATER()
    ussdu.process_all()

@dg.op
def pull_india_stock_data(context):
    isdu = INDIAN_STOCK_DATA_UPDATER()
    isdu.process_all()

@dg.op
def pull_future_data_india(context):
    ifdh = Indian_future_data_handler()
    fdp = future_data_processer()
    ifdh.process()
    fdp.process_all_files()

@dg.op
def pull_indian_commodity_data(context):
    mcx_handler = MCXFutureDataHandler()
    mcx_handler.download_all()
    mcx_handler.process_all()

########################################### ###########################################
########################################### Alert Engine Operations ############################################

@dg.op
def operation_setup_alert_engine_in_market_hours():
    # Define market hours (IST)
    start_time = time(9, 15)
    end_time = time(15, 30)

    # Check current time
    now = datetime.now().time()

    if not (start_time <= now <= end_time):
        print("⏹️ Outside market hours, exiting early.")
        return

    print("✅ Inside market hours, starting engine...")
    setup_alert_engine()

    # Run until market closes
    while True:
        now = datetime.now().time()
        if now >= end_time:
            print("🔚 Market closed. Stopping engine.")
            break
        time.sleep(30)  # Check every 30 seconds

@dg.op
def operation_entry_alert_engine_in_market_hours():
    # Define market hours (IST)
    start_time = time(9, 15)
    end_time = time(15, 30)

    # Check current time
    now = datetime.now().time()

    if not (start_time <= now <= end_time):
        print("⏹️ Outside market hours, exiting early.")
        return

    print("✅ Inside market hours, starting engine...")
    start_entry_alert_engine()

    # Run until market closes
    while True:
        now = datetime.now().time()
        if now >= end_time:
            print("🔚 Market closed. Stopping engine.")
            break
        time.sleep(30)  # Check every 30 seconds

########################################### ###########################################