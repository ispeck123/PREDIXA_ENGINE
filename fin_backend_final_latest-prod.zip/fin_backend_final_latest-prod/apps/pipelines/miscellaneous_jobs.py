import sys, os
sys.path.insert(0, os.path.abspath("/home/ispeck/STOCK_PROJECT/STP_LATEST"))


from shared.db.dbconn import DBConnection
from shared.db.db_model import TradeSignal, FuturesMaster, Order, UserAlert, Ind_StockMaster, Future_Order, Commodity_Order, CustomDashboard, OMSOrderBucket, OMSOrderBucketCommodity, OMSOrderBucketFuture
import ast
import logging
from apps.finprod_backend.modules.order_update import check_entry_hit, check_entry_hit_fc, evaluate_order_status, evaluate_order_status_fc
from datetime import datetime, timedelta
from sqlalchemy import text, distinct, or_
from shared.config.settings import Config as cfg
from shared.config.settings import DB_Config
import pandas as pd
# from nselib import derivatives
from apps.backend.services.update_futures_category import refresh_futures_master_and_update_categories
import requests
import re
from io import StringIO
# from data_fetchers.fyers.get_stock_prices import StockPriceFetcher
# from data_fetchers.fyers.get_future_prices import FuturePriceFetcher
# from data_fetchers.fyers.get_commodity_prices import CommodityPriceFetcher
import time
import json
from shared.db.db_utils import push_trades_to_order, push_future_commodity_order
from concurrent.futures import ThreadPoolExecutor
from shared.config.settings import stock_data_dir_config as sdc
from apps.backend.api.bucket_orders import reject_bucket_order


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

db = DBConnection()

def delete_duplicate_trade_signals():
    try:
        session = db.get_session()
        trade_signals = session.query(TradeSignal.stock_name, 
                                    TradeSignal.time_fr, 
                                    TradeSignal.exchange_id).distinct().all()
        #print(trade_signals)
        for trade in trade_signals:
            print(trade)
            rows = session.query(TradeSignal).filter(
                TradeSignal.stock_name == trade.stock_name,
                TradeSignal.time_fr == trade.time_fr,
                TradeSignal.exchange_id == trade.exchange_id
            ).order_by(TradeSignal.stock_name.asc()).all()
            
            for row in rows:
                all_signals = session.query(TradeSignal).filter(
                    TradeSignal.stock_name == row.stock_name,
                    TradeSignal.time_fr == row.time_fr,
                    TradeSignal.exchange_id == row.exchange_id
                ).order_by(TradeSignal.created_at.asc()).all()

                distinct_trade_data = []

                for signal in all_signals:
                    try:
                        #trade_data = ast.literal_eval(signal.trade_data)
                        trade_data = {
                                        "stop_loss": int(signal.trade_data["stop_loss"]),
                                        "entry_price": int(signal.trade_data["entry_price"]),
                                        "target_price": int(signal.trade_data["target_price"])
                                    }
                        if trade_data in distinct_trade_data:
                            if signal.exchange_id == 8:
                                oms_order = session.query(OMSOrderBucket).filter(OMSOrderBucket.trade_signal_id == signal.id).first()
                                order = session.query(Order).filter(Order.trade_signal_id == signal.id).all()
                            elif signal.exchange_id == 10:
                                oms_order = session.query(OMSOrderBucketCommodity).filter(OMSOrderBucketCommodity.trade_signal_id == signal.id).first()
                                order = session.query(Commodity_Order).filter(Commodity_Order.trade_signal_id == signal.id).all()
                            elif signal.exchange_id == 11:
                                oms_order = session.query(OMSOrderBucketFuture).filter(OMSOrderBucketFuture.trade_signal_id == signal.id).first()
                                order = session.query(Future_Order).filter(Future_Order.trade_signal_id == signal.id).all()
                            if oms_order and oms_order.is_trade_started == 0:
                                # remove row
                                if reject_bucket_order(oms_order.bucket_id):
                                    session.delete(signal)
                                    logger.info(f"duplicate row removed: id {signal.id} {trade_data}")                                
                                    if len(order) > 0:
                                        session.delete(order[0])
                                    alert = session.query(UserAlert).filter(UserAlert.trade_signal_id == signal.id).all()
                                    if len(alert) > 0:
                                        session.delete(alert[0])
                                    session.delete(oms_order)
                        else:
                            duplicate = [
                                            trd for trd in distinct_trade_data
                                            if (
                                                (trd["stop_loss"] == trade_data["stop_loss"] and trd["entry_price"] == trade_data["entry_price"]) or 
                                                (trd["stop_loss"] == trade_data["stop_loss"] and trd["target_price"] == trade_data["target_price"]) or 
                                                (trd["entry_price"] == trade_data["entry_price"] and trd["target_price"] == trade_data["target_price"])
                                            )
                                        ]
                            if len(duplicate) > 0:
                                if signal.exchange_id == 8:
                                    oms_order = session.query(OMSOrderBucket).filter(OMSOrderBucket.trade_signal_id == signal.id).first()
                                    order = session.query(Order).filter(Order.trade_signal_id == signal.id).all()
                                elif signal.exchange_id == 10:
                                    oms_order = session.query(OMSOrderBucketCommodity).filter(OMSOrderBucketCommodity.trade_signal_id == signal.id).first()
                                    order = session.query(Commodity_Order).filter(Commodity_Order.trade_signal_id == signal.id).all()
                                elif signal.exchange_id == 11:
                                    oms_order = session.query(OMSOrderBucketFuture).filter(OMSOrderBucketFuture.trade_signal_id == signal.id).first()
                                    order = session.query(Future_Order).filter(Future_Order.trade_signal_id == signal.id).all()
                                if oms_order and oms_order.is_trade_started == 0:
                                    # remove row
                                    if reject_bucket_order(oms_order.bucket_id):
                                        session.delete(signal)  
                                        logger.info(f"duplicate row removed: id {signal.id} {trade_data}")
                                        if len(order) > 0:
                                            session.delete(order[0])
                                        alert = session.query(UserAlert).filter(UserAlert.trade_signal_id == signal.id).all()
                                        if len(alert) > 0:
                                            session.delete(alert[0])
                                        session.delete(oms_order)
                            else:
                                distinct_trade_data.append(trade_data)
                                #print(f"row kept: id {signal.id} {trade_data}")
                    except Exception as ex:
                        logger.exception(f"Error in delete_duplicate_trade_signals: {ex}")

        session.commit()
        session.close()
        db.close_engine()
    except Exception as e:
        logger.exception(f"Error in delete_duplicate_trade_signals: {e}")
        db.close_engine()

def delete_completed_trade_signals():
    try:
        session = db.get_session()

        #************************************************ For Cash Segment ***************************************************
        trade_signals = session.query(TradeSignal).filter(TradeSignal.exchange_id == 8).all()
        for trade in trade_signals:
            try:
                #print(trade.trade_data['entry_price'])
                trade.created_at = datetime.strftime(trade.created_at, "%Y-%m-%dT%H:%M")
                # print(trade.exp_date)
                #print(trade.time_fr)
                if trade.exp_date is None:  
                    status, timestamp = check_entry_hit(trade.stock_name,
                                                        trade.trade_data['entry_price'],
                                                        str(trade.created_at),
                                                        trade.time_fr)
                    # print(trade, status, timestamp)
                    if status == True:
                        trade.is_active = 0
                        result = evaluate_order_status(
                            stock_name = trade.stock_name,
                            entry_price = trade.trade_data['entry_price'],
                            created_on = str(trade.created_at),
                            stop_loss = trade.trade_data['stop_loss'],
                            target_price = trade.trade_data['target_price'],
                            quantity = 10,
                            order_type = trade.trade_type.capitalize(),
                            time_frame = trade.time_fr
                        )
                        if result["status"] == "success" or result["status"] == "failed":
                            session.delete(trade)
                            logger.info(f"Completed trade signal deleted: id {trade.id}")
            except Exception as e:
                logger.exception(f"Error in loop iteration of delete_completed_trade_signals: {e}", exc_info=1, stack_info=True)
        session.commit()

        
        #************************************************ For Future Segment ***************************************************
        trade_signals = session.query(TradeSignal).filter(TradeSignal.exchange_id == 11).all()
        for trade in trade_signals:
            try:
                #print(trade.trade_data['entry_price'])
                trade.created_at = datetime.strftime(trade.created_at, "%Y-%m-%dT%H:%M")
                # print(trade.exp_date)
                #print(trade.time_fr)
                status, timestamp = check_entry_hit_fc(trade.stock_name,
                                                    trade.exp_date,
                                                    trade.trade_data['entry_price'],
                                                    str(trade.created_at),
                                                    trade.time_fr,
                                                    True)
                # print(trade, status, timestamp)
                if status == True:
                    trade.is_active = 0
                    result = evaluate_order_status_fc(
                        stock_name = trade.stock_name,
                        entry_price = trade.trade_data['entry_price'],
                        created_on = str(trade.created_at),
                        stop_loss = trade.trade_data['stop_loss'],
                        target_price = trade.trade_data['target_price'],
                        quantity = 10,
                        order_type = trade.trade_type.capitalize(),
                        time_frame = trade.time_fr,
                        exp_num = trade.exp_date,
                        is_future = True
                    )
                    if result["status"] == "success" or result["status"] == "failed":
                        session.delete(trade)
                        logger.info(f"Completed trade signal deleted: id {trade.id}")
            except Exception as e:
                logger.exception(f"Error in loop iteration of delete_completed_trade_signals: {e}", exc_info=1, stack_info=True)
        session.commit()


        #************************************************ For Commodity Segment ***************************************************
        trade_signals = session.query(TradeSignal).filter(TradeSignal.exchange_id == 10).all()
        for trade in trade_signals:
            try:
                #print(trade.trade_data['entry_price'])
                trade.created_at = datetime.strftime(trade.created_at, "%Y-%m-%dT%H:%M")
                # print(trade.exp_date)
                #print(trade.time_fr)
                status, timestamp = check_entry_hit_fc(trade.stock_name,
                                                    trade.exp_date,
                                                    trade.trade_data['entry_price'],
                                                    str(trade.created_at),
                                                    trade.time_fr,
                                                    False)
                # print(trade, status, timestamp)
                if status == True:
                    trade.is_active = 0
                    result = evaluate_order_status_fc(
                        stock_name = trade.stock_name,
                        entry_price = trade.trade_data['entry_price'],
                        created_on = str(trade.created_at),
                        stop_loss = trade.trade_data['stop_loss'],
                        target_price = trade.trade_data['target_price'],
                        quantity = 10,
                        order_type = trade.trade_type.capitalize(),
                        time_frame = trade.time_fr,
                        exp_num = trade.exp_date,
                        is_future = False
                    )
                    if result["status"] == "success" or result["status"] == "failed":
                        session.delete(trade)
                        logger.info(f"Completed trade signal deleted: id {trade.id}")
            except Exception as e:
                logger.exception(f"Error in loop iteration of delete_completed_trade_signals: {e}", exc_info=1, stack_info=True)
        session.commit()


        session.close()
        db.close_engine()
    except Exception as e:
        logger.exception(f"Error in delete_completed_trade_signals: {e}", exc_info=1, stack_info=True)
        db.close_engine()


def update_order_entry_stats():
    try:
        # trades = db.raw_query(text("select * from trade_signals where is_active = 1"))
        # for trade in trades:
        #     try:
        #         buy_price = json.loads(trade["trade_data"])["entry_price"]
        #         if trade["exchange_id"] == 8:
        #             stat, entry_timestamp = check_entry_hit(trade["stock_name"], buy_price, str(trade["created_at"]), trade["time_fr"])
        #         elif trade["exchange_id"] == 11:
        #             stat, entry_timestamp = check_entry_hit_fc(trade["stock_name"], trade["exp_date"], buy_price, str(trade["created_at"]), trade["time_fr"], is_future=True)
        #         elif trade["exchange_id"] == 10:
        #             stat, entry_timestamp = check_entry_hit_fc(trade["stock_name"], trade["exp_date"], buy_price, str(trade["created_at"]), trade["time_fr"], is_future=False)
        #         else:
        #             stat = False
        #         #print(trade["id"], stat, entry_timestamp)
        #     except Exception as e:
        #         logger.exception(e, stack_info=True, exc_info=1)
        #         stat = False
        #     if stat:
        #         trade_to_add = {
        #             "TRADE_TYPE" : trade["trade_type"],
        #             "STOCK_NAME" : trade["stock_name"],
        #             "PREDICTION" : trade["prediction"],
        #             "PROBABILITY" : trade["probability"],
        #             trade["trade_type"] : json.loads(trade["trade_data"]),
        #             "trade_id" : trade["id"],
        #             "created_at" : trade["created_at"],   
        #             "EXP_NUM" : trade["exp_date"]              
        #         }
        #         #print(trade_to_add)
        #         logger.info(trade_to_add)
        #         if trade["exchange_id"] == 8:
        #             push_trades_to_order(time_fr = trade["time_fr"], country = "india", avl_trades = [trade_to_add])
        #         elif trade["exchange_id"] == 11:
        #             push_future_commodity_order(time_fr = trade["time_fr"], country = "india", avl_trades = [trade_to_add], segment = "future")
        #         elif trade["exchange_id"] == 10:
        #             push_future_commodity_order(time_fr = trade["time_fr"], country = "india", avl_trades = [trade_to_add], segment = "commodity")


        
        #  ----------------------------- For Cash Segment -----------------------------
        ords = db.raw_query(text("select * from order_master where is_trade_started=0"))
        rc = db.raw_connection()
        for orders in ords:
            try:
                order_id = orders.get('order_id')
                stock_tick = orders.get('stock_tick')
                buy_price = orders.get('entry_price')
                time_frame = orders.get('time_frame')
                purchased_on = orders.get('purchased_cmp_date')
                # print(purchased_on, type(purchased_on))
                try:
                    stat, entry_timestamp = check_entry_hit(stock_tick, buy_price, purchased_on, time_frame)
                except Exception as ex:
                    logger.exception(ex, stack_info=True, exc_info=1)
                    stat = False
                # print(entry_timestamp, type(entry_timestamp))
                if stat:
                    # entry_timestamp = datetime.strptime(entry_timestamp, "%d/%m/%Y %H:%M:%S")
                    up_query = f"""update order_master set is_trade_started=1, entry_timestamp='{entry_timestamp}' where order_id={order_id}"""
                    
                    rc.execute(text(up_query))
                    rc.commit()
                    
                    logger.info(f"Order entry updated successfully: {order_id}")
            except Exception as er:
                logger.exception(f"Error in update_order_entry_stats: Order Id {order_id}\n", er)
        
    

        #  ----------------------------- For Future Segment -----------------------------
        ords = db.raw_query(text("select * from future_order_master where is_trade_started=0"))
        for orders in ords:
            try:
                exp_date = datetime.strptime(orders.get('expiry_date'), "%d-%m-%Y").date()
                # print(exp_date)
                # print(datetime.now().date())
                if exp_date >= datetime.now().date():
                    order_id = orders.get('order_id')
                    stock_tick = orders.get('stock_tick')
                    buy_price = orders.get('entry_price')
                    time_frame = orders.get('time_frame')
                    purchased_on = orders.get('purchased_cmp_date')
                    exp_num = orders.get('expiry_date').replace("-", "")
                    # print(purchased_on, type(purchased_on))
                    try:
                        stat, entry_timestamp = check_entry_hit_fc(stock_tick, exp_num, buy_price, purchased_on, time_frame, True)
                    except Exception as ex:
                        logger.exception(ex, stack_info=True, exc_info=1)
                        stat = False
                    # print(entry_timestamp, type(entry_timestamp))
                    if stat:
                        # entry_timestamp = datetime.strptime(entry_timestamp, "%d/%m/%Y %H:%M:%S")
                        up_query = f"""update future_order_master set is_trade_started=1, entry_timestamp='{entry_timestamp}' where order_id={order_id}"""
                        
                        rc.execute(text(up_query))
                        rc.commit()
                        
                        logger.info(f"Future Order entry updated successfully: {order_id}")
            except Exception as er:
                logger.exception(f"Error in future update_order_entry_stats: Order Id {order_id}\n", er)
        
        

        #  ----------------------------- For Commodity Segment -----------------------------
        ords = db.raw_query(text("select * from commodity_order_master where is_trade_started=0"))
        for orders in ords:
            try:
                exp_date = datetime.strptime(orders.get('expiry_date'), "%d-%m-%Y").date()
                # print(exp_date)
                # print(datetime.now().date())
                if exp_date >= datetime.now().date():
                    order_id = orders.get('order_id')
                    stock_tick = orders.get('stock_tick')
                    buy_price = orders.get('entry_price')
                    time_frame = orders.get('time_frame')
                    purchased_on = orders.get('purchased_cmp_date')
                    exp_num = orders.get('expiry_date').replace("-", "")
                    # print(purchased_on, type(purchased_on))
                    try:
                        stat, entry_timestamp = check_entry_hit_fc(stock_tick, exp_num, buy_price, purchased_on, time_frame, False)
                    except Exception as ex:
                        logger.exception(ex, stack_info=True, exc_info=1)
                        stat = False
                    # print(entry_timestamp, type(entry_timestamp))
                    if stat:
                        # entry_timestamp = datetime.strptime(entry_timestamp, "%d/%m/%Y %H:%M:%S")
                        up_query = f"""update commodity_order_master set is_trade_started=1, entry_timestamp='{entry_timestamp}' where order_id={order_id}"""
                        
                        rc.execute(text(up_query))
                        rc.commit()
                        
                        logger.info(f"Commodity Order entry updated successfully: {order_id}")
            except Exception as er:
                logger.exception(f"Error in commodity update_order_entry_stats: Order Id {order_id}\n", er)
        


        rc.close()
    except Exception as ex:
        logger.error(ex, stack_info=True, exc_info=1)
        logger.exception("Error in update_order_entry_stats: ", ex)



def update_order_status():
    try:
        #  ----------------------------- For Cash Segment -----------------------------
        ords = db.raw_query(text("select * from order_master where is_evaluated=0 and is_trade_started=1")) # order_master
        rc = db.raw_connection()
        for orders in ords:
            try:
                order_id = orders.get('order_id')
                stock_tick = orders.get('stock_tick')
                buy_price = orders.get('entry_price')
                stop_loss = orders.get('stoploss_price')
                target_price = orders.get('target_price')
                stock_quantity = orders.get('stock_quantity')
                time_frame = orders.get('time_frame')
                # purchased_on = orders.get('purchased_cmp_date')
                entry_timestamp = orders.get('entry_timestamp')
                ord_type = orders.get('order_type')

                logger.info(entry_timestamp)
                try:
                    entry_dt = datetime.fromisoformat(entry_timestamp)
                except Exception:
                    entry_dt = datetime.strptime(entry_timestamp, "%Y-%m-%d %H:%M:%S")

                result = evaluate_order_status(
                    stock_name=stock_tick,
                    entry_price=buy_price,
                    created_on=entry_dt.strftime("%Y-%m-%dT%H:%M"),
                    stop_loss=stop_loss,
                    target_price=target_price,
                    quantity=stock_quantity,
                    order_type=ord_type,
                    time_frame=time_frame
                )
                update_sql = f"""
                    UPDATE order_master
                    SET order_status = :order_status,
                        is_evaluated = :is_eval,
                        completed_on = :completed_on
                    WHERE order_id = :order_id
                """
                exec_result = result.copy()
                exec_result.pop('completed_on', None)
                
                rc.execute(
                    text(update_sql),
                    {
                        "order_status": str(exec_result),
                        "is_eval": 1 if result.get("status") in ["success", "failed"] else 0,
                        "completed_on": result.get("completed_on").strftime("%Y-%m-%d %H:%M:%S") if result.get("completed_on") else None,
                        "order_id": order_id
                    }
                )
                # date_object = datetime.strptime(entry_timestamp, "%Y-%m-%dT%H:%M:%S.%f") #"%Y-%m-%dT%H:%M"
                # cal_res, stat, completed_on = calculate_and_update(stock_tick, buy_price, date_object, stop_loss, target_price, stock_quantity, ord_type, time_frame)
                # if completed_on != None:
                    # up_query = f"""update order_master set order_status="{cal_res}", is_evaluated={int(stat)}, completed_on="{completed_on}" where order_id={order_id};"""
                # else:
                    # up_query = f"""update order_master set order_status="{cal_res}", is_evaluated={int(stat)} where order_id={order_id};"""
                # print(up_query)
                # rc.execute(text(up_query))
                rc.commit()
                
                logger.info(f"Order Updated Successfully: Order Id {order_id}")
                # print(cal_res)
            except Exception as er:
                logger.error(f"Error in update_order_status: Order Id {order_id}\n")
                logger.exception(er)
        

        #  ----------------------------- For Future Segment -----------------------------
        ords = db.raw_query(text("select * from future_order_master where is_evaluated=0 and is_trade_started=1")) # order_master
        for orders in ords:
            try:
                exp_date = datetime.strptime(orders.get('expiry_date'), "%d-%m-%Y").date()
                if exp_date >= datetime.now().date():
                    order_id = orders.get('order_id')
                    stock_tick = orders.get('stock_tick')
                    buy_price = orders.get('entry_price')
                    stop_loss = orders.get('stoploss_price')
                    target_price = orders.get('target_price')
                    stock_quantity = orders.get('stock_quantity')
                    time_frame = orders.get('time_frame')
                    # purchased_on = orders.get('purchased_cmp_date')
                    entry_timestamp = orders.get('entry_timestamp')
                    ord_type = orders.get('order_type')
                    exp_num = orders.get('expiry_date').replace("-", "")

                    try:
                        entry_dt = datetime.fromisoformat(entry_timestamp)
                    except Exception:
                        entry_dt = datetime.strptime(entry_timestamp, "%Y-%m-%d %H:%M:%S")

                    result = evaluate_order_status_fc(
                        stock_name=stock_tick,
                        entry_price=buy_price,
                        created_on=entry_dt.strftime("%Y-%m-%dT%H:%M"),
                        stop_loss=stop_loss,
                        target_price=target_price,
                        quantity=stock_quantity,
                        order_type=ord_type,
                        time_frame=time_frame,
                        exp_num=exp_num,
                        is_future=True
                    )
                    update_sql = f"""
                        UPDATE future_order_master
                        SET order_status = :order_status,
                            is_evaluated = :is_eval,
                            completed_on = :completed_on
                        WHERE order_id = :order_id
                    """
                    exec_result = result.copy()
                    exec_result.pop('completed_on', None)
                    
                    rc.execute(
                        text(update_sql),
                        {
                            "order_status": str(exec_result),
                            "is_eval": 1 if result.get("status") in ["success", "failed"] else 0,
                            "completed_on": result.get("completed_on").strftime("%Y-%m-%d %H:%M:%S") if result.get("completed_on") else None,
                            "order_id": order_id
                        }
                    )
                    # date_object = datetime.strptime(entry_timestamp, "%Y-%m-%dT%H:%M:%S.%f") #"%Y-%m-%dT%H:%M"
                    # cal_res, stat, completed_on = calculate_and_update(stock_tick, buy_price, date_object, stop_loss, target_price, stock_quantity, ord_type, time_frame)
                    # if completed_on != None:
                        # up_query = f"""update order_master set order_status="{cal_res}", is_evaluated={int(stat)}, completed_on="{completed_on}" where order_id={order_id};"""
                    # else:
                        # up_query = f"""update order_master set order_status="{cal_res}", is_evaluated={int(stat)} where order_id={order_id};"""
                    # print(up_query)
                    # rc.execute(text(up_query))
                    rc.commit()
                    
                    logger.info(f"Future Order Updated Successfully: Order Id {order_id}")
                    # print(cal_res)
            except Exception as er:
                logger.exception(f"Error in future update_order_status: Order Id {order_id}\n", er)

        

        #  ----------------------------- For Commodity Segment -----------------------------
        ords = db.raw_query(text("select * from commodity_order_master where is_evaluated=0 and is_trade_started=1")) # order_master
        for orders in ords:
            try:
                exp_date = datetime.strptime(orders.get('expiry_date'), "%d-%m-%Y").date()
                if exp_date >= datetime.now().date():
                    order_id = orders.get('order_id')
                    stock_tick = orders.get('stock_tick')
                    buy_price = orders.get('entry_price')
                    stop_loss = orders.get('stoploss_price')
                    target_price = orders.get('target_price')
                    stock_quantity = orders.get('stock_quantity')
                    time_frame = orders.get('time_frame')
                    # purchased_on = orders.get('purchased_cmp_date')
                    entry_timestamp = orders.get('entry_timestamp')
                    ord_type = orders.get('order_type')
                    exp_num = orders.get('expiry_date').replace("-", "")

                    try:
                        entry_dt = datetime.fromisoformat(entry_timestamp)
                    except Exception:
                        entry_dt = datetime.strptime(entry_timestamp, "%Y-%m-%d %H:%M:%S")

                    result = evaluate_order_status_fc(
                        stock_name=stock_tick,
                        entry_price=buy_price,
                        created_on=entry_dt.strftime("%Y-%m-%dT%H:%M"),
                        stop_loss=stop_loss,
                        target_price=target_price,
                        quantity=stock_quantity,
                        order_type=ord_type,
                        time_frame=time_frame,
                        exp_num=exp_num,
                        is_future=False
                    )
                    update_sql = f"""
                        UPDATE commodity_order_master
                        SET order_status = :order_status,
                            is_evaluated = :is_eval,
                            completed_on = :completed_on
                        WHERE order_id = :order_id
                    """
                    exec_result = result.copy()
                    exec_result.pop('completed_on', None)
                    
                    rc.execute(
                        text(update_sql),
                        {
                            "order_status": str(exec_result),
                            "is_eval": 1 if result.get("status") in ["success", "failed"] else 0,
                            "completed_on": result.get("completed_on").strftime("%Y-%m-%d %H:%M:%S") if result.get("completed_on") else None,
                            "order_id": order_id
                        }
                    )
                    # date_object = datetime.strptime(entry_timestamp, "%Y-%m-%dT%H:%M:%S.%f") #"%Y-%m-%dT%H:%M"
                    # cal_res, stat, completed_on = calculate_and_update(stock_tick, buy_price, date_object, stop_loss, target_price, stock_quantity, ord_type, time_frame)
                    # if completed_on != None:
                        # up_query = f"""update order_master set order_status="{cal_res}", is_evaluated={int(stat)}, completed_on="{completed_on}" where order_id={order_id};"""
                    # else:
                        # up_query = f"""update order_master set order_status="{cal_res}", is_evaluated={int(stat)} where order_id={order_id};"""
                    # print(up_query)
                    # rc.execute(text(up_query))
                    rc.commit()
                    
                    logger.info(f"Commodity Order Updated Successfully: Order Id {order_id}")
                    # print(cal_res)
            except Exception as er:
                logger.exception(f"Error in commodity update_order_status: Order Id {order_id}\n", er)
        


        rc.close()
    except Exception as ex:
        logger.error(ex, stack_info=True, exc_info=1)
        logger.exception("Error in update_order_status: ", ex)

def update_order_status_functions():
    update_order_entry_stats()
    update_order_status()
    delete_completed_trade_signals()
    #delete_duplicate_trade_signals()
    #delete_invalid_trade_signals()
    delete_expired_trade_signals()

def update_futures_expiry():
    try:
        map_dict = {}
        session = db.get_session()
        symbols = session.query(distinct(FuturesMaster.symbol)).all()
        sym_list = [s[0] for s in symbols]
        # exp_list = derivatives.expiry_dates_future()
        exp_list = get_fyers_monthly_fut_expiries_top3('TCS')
        # converted_list = [
        #                     datetime.strptime(date_str, "%d-%b-%Y").strftime("%Y-%m-%d")
        #                     for date_str in exp_list
        #                     ]
        for items in sym_list:
            map_dict[items] = exp_list
        print(exp_list)
        refresh_futures_master_and_update_categories(DB_Config.db_config, map_dict)
        try:
            expiry = session.query(distinct(FuturesMaster.expiry_date)).order_by(FuturesMaster.expiry_date.asc()).all()
            print(expiry)
            if expiry and len(expiry) > 0:
                print(expiry[0][0])
                dashboard_data = session.query(CustomDashboard).filter(CustomDashboard.future_symbol != None, CustomDashboard.expiry_date != None).all()
                for i in range(len(dashboard_data)):
                    dashboard_data[i].expiry_date = expiry[0][0]
                    session.add(dashboard_data[i])
            session.commit()
        except:
            pass
        session.close()
    except Exception as ex:
        logger.exception(ex, stack_info=True)


def extract_date(entry):
    match = re.search(r'\b(\d{2})\s([A-Za-z]{3})\s(\d{2})\b', entry)
    if match:
        # year, month, day = match.groups()
        day, month, year = match.groups()
        full_date_str = f"20{year} {month} {day}"
        return datetime.strptime(full_date_str, "%Y %b %d")
    return None


def get_fyers_monthly_fut_expiries_top3(product: str):
    """
    Returns the top 3 monthly FUT expiries (near/next/far) for a stock future.

    Output example:
    [
      {"expiry": "30-01-2026"},
      {"expiry": "27-02-2026"},
      {"expiry": "27-03-2026"}
    ]
    """
    try:
        url = "https://public.fyers.in/sym_details/NSE_FO.csv"
        response = requests.get(url, timeout=30)
        response.raise_for_status()

        df = pd.read_csv(StringIO(response.text), header=None)
        print(df.columns)
        # Stock FUT rows (example: "NSE:RELIANCE26JANFUT")
        # sym_col =  # column containing "NSE:XXXX..." in your file
        sym_col = 9

        df = df[df[sym_col].astype(str).str.contains(f"NSE:{product}", na=False)]
        df = df[df[sym_col].astype(str).str.contains("FUT", na=False)]

        # Parse expiry using your existing extractor
        df["parsed_date"] = df[1].apply(extract_date)
        df = df.dropna(subset=["parsed_date"]).sort_values(by="parsed_date")

        # Get unique expiries in ascending order (near -> far)
        expiries = (
            df["parsed_date"]
            .drop_duplicates()
            .sort_values()
            .head(3)
        )

        # Format
        out = [d.strftime("%Y-%m-%d") for d in expiries.tolist()]
        return out

    except Exception as e:
        logger.exception(e)
        print(f"Error fetching FUT expiries: {product}  {e}")
        return None


# def delete_pending_trades_entryNotHit_targetHit():
#     try:
#         time_frames = {
#             8: {1: "daily", 2: "sixty", 3: "fifteen", 25: "seventy_five"},
#             10: {1: "daily", 2: "two_forty", 3: "one_twenty", 4: "sixty"},
#             11: {1: "daily", 2: "sixty", 3: "fifteen", 25: "seventy_five"}
#         }
#         session = db.get_session()
#         trade_signals = session.query(TradeSignal).filter(TradeSignal.is_active == 1).all()
#         for trade in trade_signals:
#             try:
#                 #print(trade.trade_data['entry_price'])
#                 created_at = datetime.strftime(trade.created_at, "%Y-%m-%dT%H:%M")
#                 # print(trade.exp_date)
#                 #print(trade.time_fr)
#                 if trade.exp_date is None:  
#                     status, timestamp = check_entry_hit(trade.stock_name,
#                                                         trade.trade_data['entry_price'],
#                                                         str(created_at),
#                                                         trade.time_fr)
#                     # print(trade, status, timestamp)
#                     if status != True:
#                         target_price = trade.trade_data['target_price']
#                         time_fr = time_frames.get(trade.exchange_id, None)
#                         if time_fr:
#                             time_fr = time_fr.get(trade.time_fr, None)
#                         if time_fr:
#                             if trade.exchange_id == 8:
#                                 file_path = os.path.join(cfg.india_data_dir, "latest_data_csv", f"{trade.stock_name}_{time_fr}.csv")
#                             elif trade.exchange_id == 10:
#                                 exp_date
#                                 file_path = os.path.join(cfg.commodity_data_dir, "latest_data_csv", f"{trade.stock_name}_{exp_date}_{time_fr}.csv")
#                             elif trade.exchange_id == 11:
#                                 exp_date
#                                 file_path = os.path.join(cfg.commodity_data_dir, "latest_data_csv", f"{trade.stock_name}_{exp_date}_{time_fr}.csv")
#                             else:
#                                 file_path = None
#                             if file_path:
#                                 if os.path.exists(file_path):
#                                     df = pd.read_csv(file_path)
#                                     df['tradeDate'] = pd.to_datetime(df['tradeDate'], format='%d/%m/%Y %H:%M:%S')
#                                     trade.created_at = datetime.strptime(trade)
#                                     trade.created_at = datetime.strftime(trade.created_at, "%d/%m/%Y %H:%M:%S")
#                                     trade.created_at = datetime.strptime(trade.created_at, "%d/%m/%Y %H:%M:%S")
#                                     data = df[df['tradeDate'] >= trade.created_at]
#                                     high = df['high'].max()
#                                     if high >= target_price:
#                                         session.delete(trade)
#                                         logger.info(f"Pending trade signal deleted: id {trade.id}")
#                                 else:
#                                     logger.error(f"File not found: {file_path}")
#                             else:
#                                 logger.error(f"Exchange Id not found: {trade.exchange_id}")
#                         else:
#                             logger.error(f"Time frame not found: time frame {trade.time_fr}")
#             except Exception as er:
#                 logger.exception(f"Error in delete_pending_trades_entryNotHit_targetHit (Trade Id :{trade.id}): {er}", exc_info=1, stack_info=True)        
#         session.commit()
#         session.close()
#         db.close_engine()
#     except Exception as ex:
#         logger.exception(f"Error in delete_pending_trades_entryNotHit_targetHit: {ex}", exc_info=1, stack_info=True)



def delete_invalid_trade_signals():
    try:
        #****************************************** Cash Segment ************************************************
        spf = StockPriceFetcher()
        time.sleep(2)
        session = db.get_session()
        ###########-----------------------BUY TRADES------------------------------###########
        buy_trade_signals = db.raw_query(text("""select ts.id, ts.stock_name, ts.trade_data, ts.created_at, ts.time_fr, ts.exp_date, ism.fyers_symbol from 
                                              trade_signals as ts
                                              inner join ind_stock_master as ism on ts.stock_name = ism.stock_tick
                                              where ts.trade_type in ("BUY", "buy", "Buy") and ts.exchange_id = 8 
                                              and ism.is_active = 1"""))

        # print(buy_trade_signals)
        for trade in buy_trade_signals:
            try:
                trade["created_at"] = datetime.strptime(trade["created_at"], "%Y-%m-%dT%H:%M:%S.%f")
                trade_created_at = trade["created_at"]
                current_time = datetime.now()
                
                trade["created_at"] = datetime.strftime(trade["created_at"], "%Y-%m-%dT%H:%M")
                if trade["exp_date"] is None:
                    trade["trade_data"] = json.loads(trade["trade_data"])
                    status, timestamp = check_entry_hit(trade["stock_name"],
                                                        trade["trade_data"]['entry_price'],
                                                        str(trade["created_at"]),
                                                        trade["time_fr"])
                    if status == False:
                        ltp = spf.fyers_data.get_latest_price(trade["fyers_symbol"])
                        if ltp:
                            ltp = ltp.get("ltp", None)
                            if (ltp < trade["trade_data"]['entry_price']) or (ltp >= trade["trade_data"]["target_price"] and (current_time - trade_created_at) > timedelta(days=7)):
                                # print(trade)
                                trade_to_delete = session.query(TradeSignal).filter(TradeSignal.id == trade["id"]).all()
                                if len(trade_to_delete) > 0:
                                    # print(trade_to_delete[0].__dict__)
                                    session.delete(trade_to_delete[0])
                                    logger.info(f"Invalid trade signal deleted: id {trade_to_delete[0].id}")
                                order_to_delete = session.query(Order).filter(Order.trade_signal_id == trade["id"]).all()
                                if len(order_to_delete) > 0:
                                    print()
                                    # print(order_to_delete[0].__dict__)
                                    session.delete(order_to_delete[0])
                                alert_to_delete = session.query(UserAlert).filter(UserAlert.trade_signal_id == trade["id"]).all()
                                if len(alert_to_delete) > 0:
                                    print()
                                    # print(alert_to_delete[0].__dict__)
                                    session.delete(alert_to_delete[0])
                        else:
                            logger.error(f"Error in delete_invalid_trade_signals trade id {trade["id"]}: LTP not found for symbol: {trade["fyers_symbol"]}")
                session.commit()
            except Exception as ex:
                logger.exception(f"Error in delete_invalid_trade_signals trade id {trade["id"]}: {ex}")
        # session.close()


        ###########-----------------------SELL TRADES------------------------------###########
        sell_trade_signals = db.raw_query(text("""select ts.id, ts.stock_name, ts.trade_data, ts.created_at, ts.time_fr, ts.exp_date, ism.fyers_symbol from 
                                              trade_signals as ts
                                              inner join ind_stock_master as ism on ts.stock_name = ism.stock_tick
                                              where ts.trade_type in ("SELL", "sell", "Sell") and ts.exchange_id = 8 
                                              and ism.is_active = 1"""))

        # print(sell_trade_signals)
        for trade in sell_trade_signals:
            try:
                trade["created_at"] = datetime.strptime(trade["created_at"], "%Y-%m-%dT%H:%M:%S.%f")
                trade_created_at = trade["created_at"]
                current_time = datetime.now()

                trade["created_at"] = datetime.strftime(trade["created_at"], "%Y-%m-%dT%H:%M")
                if trade["exp_date"] is None:
                    trade["trade_data"] = json.loads(trade["trade_data"])
                    status, timestamp = check_entry_hit(trade["stock_name"],
                                                        trade["trade_data"]['entry_price'],
                                                        str(trade["created_at"]),
                                                        trade["time_fr"])
                    if status == False:
                        ltp = spf.fyers_data.get_latest_price(trade["fyers_symbol"])
                        if ltp:
                            ltp = ltp.get("ltp", None)
                            if (ltp > trade["trade_data"]['entry_price']) or (ltp <= trade["trade_data"]["target_price"] and (current_time - trade_created_at) > timedelta(days=7)):
                                # print(trade)
                                trade_to_delete = session.query(TradeSignal).filter(TradeSignal.id == trade["id"]).all()
                                if len(trade_to_delete) > 0:
                                    # print(trade_to_delete[0].__dict__)
                                    session.delete(trade_to_delete[0])
                                    logger.info(f"Invalid trade signal deleted: id {trade_to_delete[0].id}")
                                order_to_delete = session.query(Order).filter(Order.trade_signal_id == trade["id"]).all()
                                if len(order_to_delete) > 0:
                                    print()
                                    # print(order_to_delete[0].__dict__)
                                    session.delete(order_to_delete[0])
                                alert_to_delete = session.query(UserAlert).filter(UserAlert.trade_signal_id == trade["id"]).all()
                                if len(alert_to_delete) > 0:
                                    print()
                                    # print(alert_to_delete[0].__dict__)
                                    session.delete(alert_to_delete[0])
                        else:
                            logger.error(f"Error in delete_invalid_trade_signals trade id {trade["id"]}: LTP not found for symbol: {trade["fyers_symbol"]}")
                session.commit()
            except Exception as ex:
                logger.exception(f"Error in delete_invalid_trade_signals trade id {trade["id"]}: {ex}")
        session.close()
        db.close_engine()
        spf.fyers_data.disconnect_websocket()
        #return True


        #****************************************** Future Segment ************************************************
        fpf = FuturePriceFetcher()
        time.sleep(2)
        session = db.get_session()
        ###########-----------------------BUY TRADES------------------------------###########
        buy_trade_signals = db.raw_query(text("""select ts.id, ts.stock_name, ts.trade_data, ts.created_at, ts.time_fr, ts.exp_date from 
                                              trade_signals as ts
                                              where ts.trade_type in ("BUY", "buy", "Buy") and ts.exchange_id = 11"""))

        # print(buy_trade_signals)
        for trade in buy_trade_signals:
            try:
                trade["created_at"] = datetime.strptime(trade["created_at"], "%Y-%m-%dT%H:%M:%S.%f")
                trade_created_at = trade["created_at"]
                current_time = datetime.now()
                
                trade["created_at"] = datetime.strftime(trade["created_at"], "%Y-%m-%dT%H:%M")
                
                trade["trade_data"] = json.loads(trade["trade_data"])
                status, timestamp = check_entry_hit_fc(trade["stock_name"],
                                                    trade["exp_date"],
                                                    trade["trade_data"]['entry_price'],
                                                    str(trade["created_at"]),
                                                    trade["time_fr"],
                                                    True)
                if status == False:
                    exp = datetime.strptime(trade["exp_date"], "%d%m%Y")
                    fyers_symbol = f"NSE:{trade["stock_name"].upper()}{datetime.strftime(exp, '%y%b').upper()}FUT"
                    #print(fyers_symbol)
                    ltp = fpf.fyers_data.get_latest_price(fyers_symbol)
                    if ltp:
                        ltp = ltp.get("ltp", None)
                        if (ltp < trade["trade_data"]['entry_price']) or (ltp >= trade["trade_data"]["target_price"] and (current_time - trade_created_at) > timedelta(days=7)):
                            # print(trade)
                            trade_to_delete = session.query(TradeSignal).filter(TradeSignal.id == trade["id"]).all()
                            if len(trade_to_delete) > 0:
                                # print(trade_to_delete[0].__dict__)
                                session.delete(trade_to_delete[0])
                                logger.info(f"Invalid trade signal deleted: id {trade_to_delete[0].id}")
                            order_to_delete = session.query(Future_Order).filter(Future_Order.trade_signal_id == trade["id"]).all()
                            if len(order_to_delete) > 0:
                                print()
                                # print(order_to_delete[0].__dict__)
                                session.delete(order_to_delete[0])
                            alert_to_delete = session.query(UserAlert).filter(UserAlert.trade_signal_id == trade["id"]).all()
                            if len(alert_to_delete) > 0:
                                print()
                                # print(alert_to_delete[0].__dict__)
                                session.delete(alert_to_delete[0])
                    else:
                        logger.error(f"Error in delete_invalid_trade_signals trade id {trade["id"]}: LTP not found for symbol: {fyers_symbol}")
                session.commit()
            except Exception as ex:
                logger.exception(f"Error in delete_invalid_trade_signals trade id {trade["id"]}: {ex}")
        # session.close()


        ###########-----------------------SELL TRADES------------------------------###########
        sell_trade_signals = db.raw_query(text("""select ts.id, ts.stock_name, ts.trade_data, ts.created_at, ts.time_fr, ts.exp_date from 
                                              trade_signals as ts
                                              where ts.trade_type in ("SELL", "sell", "Sell") and ts.exchange_id = 11"""))

        # print(sell_trade_signals)
        for trade in sell_trade_signals:
            try:
                trade["created_at"] = datetime.strptime(trade["created_at"], "%Y-%m-%dT%H:%M:%S.%f")
                trade_created_at = trade["created_at"]
                current_time = datetime.now()

                trade["created_at"] = datetime.strftime(trade["created_at"], "%Y-%m-%dT%H:%M")
                
                trade["trade_data"] = json.loads(trade["trade_data"])
                status, timestamp = check_entry_hit_fc(trade["stock_name"],
                                                    trade["exp_date"],
                                                    trade["trade_data"]['entry_price'],
                                                    str(trade["created_at"]),
                                                    trade["time_fr"],
                                                    True)
                if status == False:
                    exp = datetime.strptime(trade["exp_date"], "%d%m%Y")
                    fyers_symbol = f"NSE:{trade["stock_name"].upper()}{datetime.strftime(exp, '%y%b').upper()}FUT"
                    #print(fyers_symbol)
                    ltp = fpf.fyers_data.get_latest_price(fyers_symbol)
                    if ltp:
                        ltp = ltp.get("ltp", None)
                        if (ltp > trade["trade_data"]['entry_price']) or (ltp <= trade["trade_data"]["target_price"] and (current_time - trade_created_at) > timedelta(days=7)):
                            # print(trade)
                            trade_to_delete = session.query(TradeSignal).filter(TradeSignal.id == trade["id"]).all()
                            if len(trade_to_delete) > 0:
                                # print(trade_to_delete[0].__dict__)
                                session.delete(trade_to_delete[0])
                                logger.info(f"Invalid trade signal deleted: id {trade_to_delete[0].id}")
                            order_to_delete = session.query(Future_Order).filter(Future_Order.trade_signal_id == trade["id"]).all()
                            if len(order_to_delete) > 0:
                                print()
                                # print(order_to_delete[0].__dict__)
                                session.delete(order_to_delete[0])
                            alert_to_delete = session.query(UserAlert).filter(UserAlert.trade_signal_id == trade["id"]).all()
                            if len(alert_to_delete) > 0:
                                print()
                                # print(alert_to_delete[0].__dict__)
                                session.delete(alert_to_delete[0])
                    else:
                        logger.error(f"Error in delete_invalid_trade_signals trade id {trade["id"]}: LTP not found for symbol: {fyers_symbol}")
                session.commit()
            except Exception as ex:
                logger.exception(f"Error in delete_invalid_trade_signals trade id {trade["id"]}: {ex}")
        session.close()
        db.close_engine()
        fpf.fyers_data.disconnect_websocket()
        #return True


        #****************************************** Commodity Segment ************************************************
        cpf = CommodityPriceFetcher()
        time.sleep(2)
        session = db.get_session()
        ###########-----------------------BUY TRADES------------------------------###########
        buy_trade_signals = db.raw_query(text("""select ts.id, ts.stock_name, ts.trade_data, ts.created_at, ts.time_fr, ts.exp_date from 
                                              trade_signals as ts
                                              where ts.trade_type in ("BUY", "buy", "Buy") and ts.exchange_id = 10"""))

        # print(buy_trade_signals)
        for trade in buy_trade_signals:
            try:
                trade["created_at"] = datetime.strptime(trade["created_at"], "%Y-%m-%dT%H:%M:%S.%f")
                trade_created_at = trade["created_at"]
                current_time = datetime.now()
                
                trade["created_at"] = datetime.strftime(trade["created_at"], "%Y-%m-%dT%H:%M")
                
                trade["trade_data"] = json.loads(trade["trade_data"])
                status, timestamp = check_entry_hit_fc(trade["stock_name"],
                                                    trade["exp_date"],
                                                    trade["trade_data"]['entry_price'],
                                                    str(trade["created_at"]),
                                                    trade["time_fr"],
                                                    False)
                if status == False:
                    exp = datetime.strptime(trade["exp_date"], "%d%m%Y")
                    fyers_symbol = f"MCX:{trade["stock_name"].upper()}{datetime.strftime(exp, '%y%b').upper()}FUT"
                    #print(fyers_symbol)
                    ltp = cpf.fyers_data.get_latest_price(fyers_symbol)
                    if ltp:
                        ltp = ltp.get("ltp", None)
                        if (ltp < trade["trade_data"]['entry_price']) or (ltp >= trade["trade_data"]["target_price"] and (current_time - trade_created_at) > timedelta(days=7)):
                            # print(trade)
                            trade_to_delete = session.query(TradeSignal).filter(TradeSignal.id == trade["id"]).all()
                            if len(trade_to_delete) > 0:
                                # print(trade_to_delete[0].__dict__)
                                session.delete(trade_to_delete[0])
                                logger.info(f"Invalid trade signal deleted: id {trade_to_delete[0].id}")
                            order_to_delete = session.query(Commodity_Order).filter(Commodity_Order.trade_signal_id == trade["id"]).all()
                            if len(order_to_delete) > 0:
                                print()
                                # print(order_to_delete[0].__dict__)
                                session.delete(order_to_delete[0])
                            alert_to_delete = session.query(UserAlert).filter(UserAlert.trade_signal_id == trade["id"]).all()
                            if len(alert_to_delete) > 0:
                                print()
                                # print(alert_to_delete[0].__dict__)
                                session.delete(alert_to_delete[0])
                    else:
                        logger.error(f"Error in delete_invalid_trade_signals trade id {trade["id"]}: LTP not found for symbol: {fyers_symbol}")
                session.commit()
            except Exception as ex:
                logger.exception(f"Error in delete_invalid_trade_signals trade id {trade["id"]}: {ex}")
        # session.close()


        ###########-----------------------SELL TRADES------------------------------###########
        sell_trade_signals = db.raw_query(text("""select ts.id, ts.stock_name, ts.trade_data, ts.created_at, ts.time_fr, ts.exp_date from 
                                              trade_signals as ts
                                              where ts.trade_type in ("SELL", "sell", "Sell") and ts.exchange_id = 10"""))

        # print(sell_trade_signals)
        for trade in sell_trade_signals:
            try:
                trade["created_at"] = datetime.strptime(trade["created_at"], "%Y-%m-%dT%H:%M:%S.%f")
                trade_created_at = trade["created_at"]
                current_time = datetime.now()

                trade["created_at"] = datetime.strftime(trade["created_at"], "%Y-%m-%dT%H:%M")
                
                trade["trade_data"] = json.loads(trade["trade_data"])
                status, timestamp = check_entry_hit_fc(trade["stock_name"],
                                                    trade["exp_date"],
                                                    trade["trade_data"]['entry_price'],
                                                    str(trade["created_at"]),
                                                    trade["time_fr"],
                                                    False)
                if status == False:
                    exp = datetime.strptime(trade["exp_date"], "%d%m%Y")
                    fyers_symbol = f"MCX:{trade["stock_name"].upper()}{datetime.strftime(exp, '%y%b').upper()}FUT"
                    #print(fyers_symbol)
                    ltp = cpf.fyers_data.get_latest_price(fyers_symbol)
                    if ltp:
                        ltp = ltp.get("ltp", None)
                        if (ltp > trade["trade_data"]['entry_price']) or (ltp <= trade["trade_data"]["target_price"] and (current_time - trade_created_at) > timedelta(days=7)):
                            # print(trade)
                            trade_to_delete = session.query(TradeSignal).filter(TradeSignal.id == trade["id"]).all()
                            if len(trade_to_delete) > 0:
                                # print(trade_to_delete[0].__dict__)
                                session.delete(trade_to_delete[0])
                                logger.info(f"Invalid trade signal deleted: id {trade_to_delete[0].id}")
                            order_to_delete = session.query(Commodity_Order).filter(Commodity_Order.trade_signal_id == trade["id"]).all()
                            if len(order_to_delete) > 0:
                                print()
                                # print(order_to_delete[0].__dict__)
                                session.delete(order_to_delete[0])
                            alert_to_delete = session.query(UserAlert).filter(UserAlert.trade_signal_id == trade["id"]).all()
                            if len(alert_to_delete) > 0:
                                print()
                                # print(alert_to_delete[0].__dict__)
                                session.delete(alert_to_delete[0])
                    else:
                        logger.error(f"Error in delete_invalid_trade_signals trade id {trade["id"]}: LTP not found for symbol: {fyers_symbol}")
                session.commit()
            except Exception as ex:
                logger.exception(f"Error in delete_invalid_trade_signals trade id {trade["id"]}: {ex}")
        session.close()
        db.close_engine()
        cpf.fyers_data.disconnect_websocket()
        #return True


    except Exception as e:
        session.close()
        logger.exception(f"Error in delete_invalid_trade_signals: {e}")
        db.close_engine()
        spf.fyers_data.disconnect_websocket()
        return True
    
def delete_expired_trade_signals():
    try:
        session = db.get_session()
        today = datetime.now().date()
        #print(today, type(today))
        future_commodity_trades = session.query(TradeSignal).filter(
            TradeSignal.exp_date != None,
            TradeSignal.is_active == 1,
            or_(TradeSignal.exchange_id == 10, TradeSignal.exchange_id == 11)
        ).all()
        for trade in future_commodity_trades:
            exp_date = datetime.strptime(trade.exp_date, "%d%m%Y").date()
            if (exp_date < today) or ((exp_date - timedelta(days=5)) < today):
                #print(exp_date, type(exp_date), trade.id)
                #print(trade.__dict__)
                try:
                    session.delete(trade)
                    logger.info(f"Expired trade signal deleted: id {trade.id}")
                except Exception as ex:
                    logger.exception(f"Error in delete_expired_trade_signals trade id {trade.id}: {ex}")
        session.commit()
        session.close()
        db.close_engine()
    except Exception as e:
        session.close()
        logger.exception(f"Error in delete_expired_trade_signals: {e}")
        db.close_engine()


def delete_expired_futures_commodity_data():
    try:

        def delete_file(file_path, file):
            try:
                # Assuming filename format: STOCKNAME_EXPIRY_TIMEFRAME.csv
                parts = file.split("_")
                if len(parts) >= 3:
                    exp_part = parts[1]  # Get the second last part as expiry
                    try:
                        exp_date = datetime.strptime(exp_part, "%d%m%Y").date()
                        if exp_date < datetime.now().date():
                            os.remove(file_path)
                            logger.info(f"Deleted expired data file: {file_path}")
                    except ValueError:
                        print(f"Filename does not contain a valid expiry date: {file}")
            except Exception as e:
                print(f"Error deleting {file_path}: {e}")
        
        data_directories = [
                            os.path.join(sdc.indian_stock_future_data_dir, "latest_data_csv"),
                            os.path.join(sdc.indian_stock_future_data_dir, "processed_data_files"),
                            os.path.join(sdc.indian_commodity_data, "latest_data_csv"),
                            os.path.join(sdc.indian_commodity_data, "processed_data_files")
                            ]
        for dir in data_directories:
            if os.path.exists(dir):
                file_list = os.listdir(dir)
                filepath_list = [os.path.join(dir, file) for file in file_list if os.path.isfile(os.path.join(dir, file))]                
                with ThreadPoolExecutor(max_workers=10) as executor:
                    executor.map(delete_file, filepath_list, file_list)
            else:
                logger.warning(f"Directory does not exist: {dir}")
    except Exception as ex:
        logger.exception(f"Error in delete_expired_futures_commodity_data: {ex}")



if __name__ == "__main__":
    update_order_status()