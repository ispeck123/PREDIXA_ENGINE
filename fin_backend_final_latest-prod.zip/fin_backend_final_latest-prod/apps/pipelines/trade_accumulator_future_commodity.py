from scripts.calculate_setup_future import Calculate_setup_execute_futures
from shared.db.dbconn import DBConnection
from sqlalchemy import text
from datetime import datetime
from sqlitedict import SqliteDict
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor, as_completed
from stock_model.model_predictor import Indian_model_predictor, US_model_predictor
from shared.db.db_utils import insert_trade_signals, push_future_commodity_order, check_and_insert_automated_alert
from shared.utils.logger import logger 
from shared.config.settings import stock_data_dir_config
from nselib.derivatives import expiry_dates_future
import re

TABLE_NAME = {"futures": "futures_master", "commodity": "commodities_master"}

DATA_DIR = {"futures": stock_data_dir_config.indian_stock_future_data_dir, 'commodity': stock_data_dir_config.indian_commodity_data}

db = SqliteDict("finprod.sqlite")
dbc = DBConnection()
 # Assuming logger.py is in place
country_id_dict = {"india" : 1, "us" : 3}

segment_exchange_id = {"futures": 11, "commodity": 10}


# def get_converted_expiry_list(symbol=None):
#     # Define fixed expiry dates for stock futures (NSEFO)
    
#     # Define expiry mappings for commodity symbols
#     commodity_expiry_map = db['indian_commodity_expiries']
#     # Determine expiry list
#     if symbol is None:
#         stock_future_expiries = [
#             datetime.strptime(date_str, "%d-%b-%Y").strftime("%d-%m-%Y")
#             for date_str in expiry_dates_future()
#         ]
#         expiry_dates = stock_future_expiries
#     else:
#         expiry_dates = commodity_expiry_map.get(symbol.upper(), [])
#         expiry_dates = [dt.strftime("%d-%m-%Y") for dt in expiry_dates]
#     # Convert date strings to YYYYMMDD numeric format
#     return [''.join(re.findall(r'\d+', dt)) for dt in expiry_dates]

def get_converted_expiry_list(symbol=None):
    # Define expiry mappings for commodity symbols
    commodity_expiry_map = db['indian_commodity_expiries']
    print(commodity_expiry_map)
    # Get expiry dates
    if symbol is None:
        today = datetime.today()
        stock_future_expiries = [
            datetime.strptime(date_str, "%d-%b-%Y")
            for date_str in expiry_dates_future()
        ]
        expiry_dates = sorted(stock_future_expiries)
    else:
        today = datetime.today().date()
        # expiry_dates = next(item["expiry"] for item in commodity_expiry_map if item["symbol"] == symbol)
        # expiry_dates = sorted(commodity_expiry_map.get(symbol.upper(), []))
        expiry_dates = [
            datetime.strptime(date_str, "%d-%m-%Y").date()
            for date_str in next(item["expiry"] for item in commodity_expiry_map if item["symbol"] == symbol)
        ]

    # Filter out past expiry dates
    expiry_dates = [dt for dt in expiry_dates if dt >= today]

    if not expiry_dates:
        return []

    # Default to only nearest expiry
    result = [expiry_dates[0]]

    # If it's 5 days or less away, include the next expiry too
    if (expiry_dates[0] - today).days <= 5 and len(expiry_dates) > 1:
        result.append(expiry_dates[1])

    # Convert to 'YYYYMMDD' format
    formatted = [dt.strftime("%d%m%Y") for dt in result]
    return formatted


def run_calculation_process(stock_name, country, time_fr, exp_num, segment):
    try:
        cse = Calculate_setup_execute_futures(
            stock_name=stock_name,
            time_frame=time_fr,
            last_dt=datetime.now(),
            exp_num=exp_num,
            data_dir=country,
            segment=segment
                )
        return cse.calculate()
    except Exception as e:
        logger.error({"STOCK_NAME": stock_name, "error": str(e)}, stack_info=True, exc_info=1)



def daily_trades_accumulate_futures_and_commodity(segment):
    logger.info(f"Starting trade accumulation for {segment}")
    dbc = DBConnection()
    # data = db.get(country, {})
    avl_trades = []
    C_dir = DATA_DIR[segment]

    try:
        if segment == 'futures':
            res = dbc.raw_query(text(f"SELECT DISTINCT symbol FROM {TABLE_NAME[segment]};"))
        else:
            res = dbc.raw_query(text(f"SELECT DISTINCT symbol FROM {TABLE_NAME[segment]} WHERE is_active = 1;"))
    finally:
        dbc.close_engine()
    # for item in res:
    #     for expiry in get_converted_expiry_list(item['symbol']):
    #         run_calculation_process(item['symbol'], C_dir, 1, expiry)
    #         break
            # print(expiry, item['symbol'])
    # 2. Process trades in parallel (CPU-bound)
    with ProcessPoolExecutor() as p_pool:
        if segment == 'futures':
            future_to_stock = {
                p_pool.submit(run_calculation_process, item['symbol'], C_dir, 1, expiry, segment): (item['symbol'], expiry)
                for item in res
                for expiry in get_converted_expiry_list()
            }
        else:
            future_to_stock = {
                p_pool.submit(run_calculation_process, item['symbol'], C_dir, 1, expiry, segment): (item['symbol'], expiry)
                for item in res
                for expiry in get_converted_expiry_list(item['symbol'])
            }

        for fut in as_completed(future_to_stock):
            st_name = future_to_stock[fut]
            try:
                result = fut.result()
                if result is None:
                    continue
                # Shared function to evaluate each side
                def evaluate_trade(trade_type: str):
                    side_key = trade_type.upper()
                    rrr_key = f"{side_key}_RRR"
                    trade_data = result.get(side_key)

                    if result and result.get(rrr_key, 0) >= 2.1 and trade_data:
                        trade_result = {
                            "STOCK_NAME": result["STOCK_NAME"],
                            "TIME_FR": 1,
                            "PRICE_CMP": result.get("PRICE_CMP"),
                            "TRADE_TYPE": side_key,
                            rrr_key: result[rrr_key],
                            f"{side_key}_TIMESTAMPS": result.get(f"{side_key}_TIMESTAMPS"),
                            trade_type.upper(): trade_data,
                            "TIMESTAMP": datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"),
                            "EXP_NUM" : result['EXP_NUM']
                        }
                        # try:
                        #     if str(country).lower().__contains__('us'):
                        #         model_stat = US_model_predictor(result["STOCK_NAME"], 1).fetch_model_stats(
                        #             trade_data["entry_price"],
                        #             trade_data["target_price"],
                        #             trade_data["stop_loss"]
                        #         )
                        #     else:
                        #         model_stat = Indian_model_predictor(result["STOCK_NAME"], 1).fetch_model_stats(
                        #             trade_data["entry_price"],
                        #             trade_data["target_price"],
                        #             trade_data["stop_loss"]
                        #         )
                        #     trade_result["PREDICTION"] = model_stat[0]
                        #     trade_result["PROBABILITY"] = model_stat[1]
                        # except Exception as ex:
                        #     logger.error(f"Error from model predictor for {st_name} ({trade_type}): {ex}")
                        trade_result["PREDICTION"] = "NA"
                        trade_result["PROBABILITY"] = 0.0

                        insres, trade_id = insert_trade_signals(trade_result, country_id_dict['india'], segment_exchange_id[segment], 1)
                        if insres:
                            trade_result["trade_id"] = trade_id
                            check_and_insert_automated_alert(trade_result, segment_exchange_id[segment], country_id_dict['india'], 1)
                            avl_trades.append(trade_result)
                        logger.info(f"Committed [daily] {side_key} trade for {st_name} to DB")

                # Evaluate BUY
                if result.get("BUY_RRR", 0) >= 2.1:
                    evaluate_trade("BUY")

                # Evaluate SELL
                if result.get("SELL_RRR", 0) >= 2.1:
                    evaluate_trade("SELL")

            except Exception as e:
                logger.error(f"Calculation for {st_name} failed: {e}")

    # 3. Push trades in parallel (I/O-bound)
    if avl_trades:
        with ThreadPoolExecutor(max_workers=5) as t_pool:
            futures = [
                t_pool.submit(push_future_commodity_order, time_fr=1, country='india', avl_trades=[trade], segment=segment)
                for trade in avl_trades
            ]
            for fut in as_completed(futures):
                try:
                    fut.result()
                except Exception as e:
                    logger.error(f"Error pushing trade to order: {e}", stack_info=True)
    else:
        logger.info("No trades qualified to push to order.")


def sixty_trades_accumulate_futures_and_commodity(segment):
    if segment == "futures":
        time_frame = 2
    elif segment == "commodity":
        time_frame = 4
    
    logger.info(f"[60-min] Starting trade accumulation for {segment}")
    avl_trades = []
    C_dir = DATA_DIR[segment]

    try:
        if segment == 'futures':
            res = dbc.raw_query(text(f"SELECT DISTINCT symbol FROM {TABLE_NAME[segment]};"))
        else:
            res = dbc.raw_query(text(f"SELECT DISTINCT symbol FROM {TABLE_NAME[segment]} WHERE is_active = 1;"))
    finally:
        dbc.close_engine()

    with ProcessPoolExecutor() as p_pool:
        if segment == 'futures':
            future_to_stock = {
                p_pool.submit(run_calculation_process, item['symbol'], C_dir, time_frame, expiry, segment): (item['symbol'], expiry)
                for item in res
                for expiry in get_converted_expiry_list()
            }
        else:
            future_to_stock = {
                p_pool.submit(run_calculation_process, item['symbol'], C_dir, time_frame, expiry, segment): (item['symbol'], expiry)
                for item in res
                for expiry in get_converted_expiry_list(item['symbol'])
            }

        for fut in as_completed(future_to_stock):
            st_name = future_to_stock[fut]
            try:
                result = fut.result()

                print(result)

                if result is None:
                    continue

                def evaluate_trade(trade_type: str, rrr_threshold: float = 1.15):
                    side_key = trade_type.upper()
                    rrr_key = f"{side_key}_RRR"
                    trade_data = result.get(side_key)

                    if result and result.get(rrr_key, 0) >= rrr_threshold and trade_data:
                        trade_result = {
                            "STOCK_NAME": result["STOCK_NAME"],
                            "TIME_FR": time_frame,
                            "PRICE_CMP": result.get("PRICE_CMP"),
                            "TRADE_TYPE": side_key,
                            rrr_key: result[rrr_key],
                            f"{side_key}_TIMESTAMPS": result.get(f"{side_key}_TIMESTAMPS"),
                            trade_type.upper(): trade_data,
                            "TIMESTAMP": datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"),
                            "EXP_NUM" : result['EXP_NUM']
                        }
                        # try:
                        #     model_stat = Indian_model_predictor(result["STOCK_NAME"], time_frame, side_key, datetime.now()).fetch_model_stats_future_and_commodity(
                        #         trade_data["entry_price"],
                        #         trade_data["target_price"],
                        #         trade_data["stop_loss"],
                        #         result['EXP_NUM'],
                        #         segment
                        #     )
                        #     trade_result["PREDICTION"] = model_stat[0]
                        #     trade_result["PROBABILITY"] = model_stat[1]
                        # except Exception as ex:
                        #     logger.error(f"[60-min] Model predictor error for {st_name} ({side_key}): {ex}")
                        trade_result["PREDICTION"] = "NA" #None
                        trade_result["PROBABILITY"] = 0.0 #None


                        # if trade_result["PREDICTION"] == "success":
                        
                        insres, trade_id = insert_trade_signals(trade_result, country_id_dict['india'], segment_exchange_id[segment], time_frame)
                        if insres:
                            trade_result["trade_id"] = trade_id
                            check_and_insert_automated_alert(trade_result, segment_exchange_id[segment], country_id_dict['india'], time_frame)
                            avl_trades.append(trade_result)

                        logger.info(f"[60-min] {side_key} trade for {st_name} committed to DB")

                # Evaluate both BUY and SELL sides
                if result.get("BUY_RRR", 0) >= 2.1:
                    evaluate_trade("BUY", 2.1)
                if result.get("SELL_RRR", 0) >= 2.1:
                    evaluate_trade("SELL", 2.1)

            except Exception as e:
                logger.error(f"[60-min] Error in processing {st_name}: {e}", stack_info=True)
    print("Pushing orders to DB......................##################")
    if avl_trades:
        with ThreadPoolExecutor(max_workers=5) as t_pool:
            futures = [
                t_pool.submit(push_future_commodity_order, time_fr=time_frame, country='india', avl_trades=[trade], segment=segment)
                for trade in avl_trades
            ]
            for fut in as_completed(futures, timeout=30):
                try:
                    fut.result()
                except Exception as e:
                    logger.error(f"[60-min] Error pushing trade to order: {e}", stack_info=True)
    else:
        logger.info("[60-min] No qualifying trades to push to order.")



def fifteen_trades_accumulate_futures_and_commodity(segment):
    logger.info(f"[15-min] Starting trade accumulation for {segment}")
    avl_trades = []
    C_dir = DATA_DIR[segment]

    try:
        if segment == 'futures':
            res = dbc.raw_query(text(f"SELECT DISTINCT symbol FROM {TABLE_NAME[segment]};"))
        else:
            res = dbc.raw_query(text(f"SELECT DISTINCT symbol FROM {TABLE_NAME[segment]} WHERE is_active = 1;"))
    finally:
        dbc.close_engine()

    with ProcessPoolExecutor() as p_pool:
        if segment == 'futures':
            future_to_stock = {
                p_pool.submit(run_calculation_process, item['symbol'], C_dir, 3, expiry, segment): (item['symbol'], expiry)
                for item in res
                for expiry in get_converted_expiry_list()
            }
        else:
            future_to_stock = {
                p_pool.submit(run_calculation_process, item['symbol'], C_dir, 3, expiry, segment): (item['symbol'], expiry)
                for item in res
                for expiry in get_converted_expiry_list(item['symbol'])
            }

        for fut in as_completed(future_to_stock):
            st_name = future_to_stock[fut]
            try:
                result = fut.result()
                logger.debug(f"[15-min] Result for {st_name}: {result}")

                if result is None:
                    continue

                def evaluate_trade(trade_type: str, rrr_threshold: float = 1.0):
                    side_key = trade_type.upper()
                    rrr_key = f"{side_key}_RRR"
                    trade_data = result.get(side_key)

                    if result and result.get(rrr_key, 0) >= rrr_threshold and trade_data:
                        trade_result = {
                            "STOCK_NAME": result["STOCK_NAME"],
                            "TIME_FR": 3,
                            "PRICE_CMP": result.get("PRICE_CMP"),
                            "TRADE_TYPE": side_key,
                            rrr_key: result[rrr_key],
                            f"{side_key}_TIMESTAMPS": result.get(f"{side_key}_TIMESTAMPS"),
                            trade_type.upper(): trade_data,
                            "TIMESTAMP": datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"),
                            "EXP_NUM" : result['EXP_NUM']
                        }
                        # try:
                        #     model_stat = Indian_model_predictor(result["STOCK_NAME"], 3, side_key, datetime.now()).fetch_model_stats_future_and_commodity(
                        #         trade_data["entry_price"],
                        #         trade_data["target_price"],
                        #         trade_data["stop_loss"],
                        #         result['EXP_NUM'],
                        #         segment
                        #     )
                        #     trade_result["PREDICTION"] = model_stat[0]
                        #     trade_result["PROBABILITY"] = model_stat[1]
                        # except Exception as ex:
                        #     logger.error(f"[15-min] Model predictor error for {st_name} ({side_key}): {ex}")
                        trade_result["PREDICTION"] = "NA" #None
                        trade_result["PROBABILITY"] = 0.0 #None

                        # if trade_result["PREDICTION"] == "success":
                        ins_res, trade_id = insert_trade_signals(trade_result, country_id_dict['india'], segment_exchange_id[segment], 3)
                        if ins_res: 
                            trade_result["trade_id"] = trade_id
                            check_and_insert_automated_alert(trade_result, segment_exchange_id[segment], country_id_dict['india'], 3)
                            avl_trades.append(trade_result)
                        logger.info(f"[15-min] {side_key} trade for {st_name} committed to DB")

                # Evaluate both BUY and SELL
                if result.get("BUY_RRR", 0) >= 2.1:
                    evaluate_trade("BUY", 2.1)
                if result.get("SELL_RRR", 0) >= 2.1:
                    evaluate_trade("SELL", 2.1)

            except Exception as e:
                logger.error(f"[15-min] Error in processing {st_name}: {e}", stack_info=True, exc_info=1)

    if len(avl_trades) > 0:
        pass
        # with ThreadPoolExecutor(max_workers=5) as t_pool:
        #     futures = [
        #         t_pool.submit(push_trades_to_order, time_fr=3, country='india', avl_trades=[trade])
        #         for trade in avl_trades
        #     ]
        #     for fut in as_completed(futures):
        #         try:
        #             fut.result()
        #         except Exception as e:
        #             logger.error(f"[15-min] Error pushing trade to order: {e}", stack_info=True)
    else:
        logger.info("[15-min] No qualifying trades to push to order.")


def one_twenty_trades_accumulate_futures_and_commodity(segment):
    logger.info(f"[120-min] Starting trade accumulation for {segment}")
    avl_trades = []
    C_dir = DATA_DIR[segment]

    try:
        if segment == 'futures':
            res = dbc.raw_query(text(f"SELECT DISTINCT symbol FROM {TABLE_NAME[segment]};"))
        else:
            res = dbc.raw_query(text(f"SELECT DISTINCT symbol FROM {TABLE_NAME[segment]} WHERE is_active = 1;"))
    finally:
        dbc.close_engine()

    with ProcessPoolExecutor() as p_pool:
        if segment == 'futures':
            future_to_stock = {
                p_pool.submit(run_calculation_process, item['symbol'], C_dir, 3, expiry, segment): (item['symbol'], expiry)
                for item in res
                for expiry in get_converted_expiry_list()
            }
        else:
            future_to_stock = {
                p_pool.submit(run_calculation_process, item['symbol'], C_dir, 3, expiry, segment): (item['symbol'], expiry)
                for item in res
                for expiry in get_converted_expiry_list(item['symbol'])
            }

        for fut in as_completed(future_to_stock):
            st_name = future_to_stock[fut]
            try:
                result = fut.result()

                print(result)

                if result is None:
                    continue

                def evaluate_trade(trade_type: str, rrr_threshold: float = 1.15):
                    side_key = trade_type.upper()
                    rrr_key = f"{side_key}_RRR"
                    trade_data = result.get(side_key)

                    if result and result.get(rrr_key, 0) >= rrr_threshold and trade_data:
                        trade_result = {
                            "STOCK_NAME": result["STOCK_NAME"],
                            "TIME_FR": 3,
                            "PRICE_CMP": result.get("PRICE_CMP"),
                            "TRADE_TYPE": side_key,
                            rrr_key: result[rrr_key],
                            f"{side_key}_TIMESTAMPS": result.get(f"{side_key}_TIMESTAMPS"),
                            trade_type.upper(): trade_data,
                            "TIMESTAMP": datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"),
                            "EXP_NUM" : result['EXP_NUM']
                        }
                        # try:
                        #     model_stat = Indian_model_predictor(result["STOCK_NAME"], 3, side_key, datetime.now()).fetch_model_stats_future_and_commodity(
                        #         trade_data["entry_price"],
                        #         trade_data["target_price"],
                        #         trade_data["stop_loss"],
                        #         result['EXP_NUM'],
                        #         segment
                        #     )
                        #     trade_result["PREDICTION"] = model_stat[0]
                        #     trade_result["PROBABILITY"] = model_stat[1]
                        # except Exception as ex:
                        #     logger.error(f"[120-min] Model predictor error for {st_name} ({side_key}): {ex}")
                        trade_result["PREDICTION"] = "NA" #None
                        trade_result["PROBABILITY"] = 0.0 #None


                        # if trade_result["PREDICTION"] == "success":
                        
                        insres, trade_id = insert_trade_signals(trade_result, country_id_dict['india'], segment_exchange_id[segment], 3)
                        if insres:
                            trade_result["trade_id"] = trade_id
                            check_and_insert_automated_alert(trade_result, segment_exchange_id[segment], country_id_dict['india'], 3)
                            avl_trades.append(trade_result)

                        logger.info(f"[120-min] {side_key} trade for {st_name} committed to DB")

                # Evaluate both BUY and SELL sides
                if result.get("BUY_RRR", 0) >= 2.1:
                    evaluate_trade("BUY", 2.1)
                if result.get("SELL_RRR", 0) >= 2.1:
                    evaluate_trade("SELL", 2.1)

            except Exception as e:
                logger.error(f"[120-min] Error in processing {st_name}: {e}", stack_info=True)
    print("Pushing orders to DB......................##################")
    if avl_trades:
        with ThreadPoolExecutor(max_workers=5) as t_pool:
            futures = [
                t_pool.submit(push_future_commodity_order, time_fr=3, country='india', avl_trades=[trade], segment=segment)
                for trade in avl_trades
            ]
            for fut in as_completed(futures, timeout=30):
                try:
                    fut.result()
                except Exception as e:
                    logger.error(f"[120-min] Error pushing trade to order: {e}", stack_info=True)
    else:
        logger.info("[120-min] No qualifying trades to push to order.")


def two_forty_trades_accumulate_futures_and_commodity(segment):
    logger.info(f"[240-min] Starting trade accumulation for {segment}")
    avl_trades = []
    C_dir = DATA_DIR[segment]

    try:
        if segment == 'futures':
            res = dbc.raw_query(text(f"SELECT DISTINCT symbol FROM {TABLE_NAME[segment]};"))
        else:
            res = dbc.raw_query(text(f"SELECT DISTINCT symbol FROM {TABLE_NAME[segment]} WHERE is_active = 1;"))
    finally:
        dbc.close_engine()

    with ProcessPoolExecutor() as p_pool:
        if segment == 'futures':
            future_to_stock = {
                p_pool.submit(run_calculation_process, item['symbol'], C_dir, 2, expiry, segment): (item['symbol'], expiry)
                for item in res
                for expiry in get_converted_expiry_list()
            }
        else:
            future_to_stock = {
                p_pool.submit(run_calculation_process, item['symbol'], C_dir, 2, expiry, segment): (item['symbol'], expiry)
                for item in res
                for expiry in get_converted_expiry_list(item['symbol'])
            }

        for fut in as_completed(future_to_stock):
            st_name = future_to_stock[fut]
            try:
                result = fut.result()

                print(result)

                if result is None:
                    continue

                def evaluate_trade(trade_type: str, rrr_threshold: float = 1.15):
                    side_key = trade_type.upper()
                    rrr_key = f"{side_key}_RRR"
                    trade_data = result.get(side_key)

                    if result and result.get(rrr_key, 0) >= rrr_threshold and trade_data:
                        trade_result = {
                            "STOCK_NAME": result["STOCK_NAME"],
                            "TIME_FR": 2,
                            "PRICE_CMP": result.get("PRICE_CMP"),
                            "TRADE_TYPE": side_key,
                            rrr_key: result[rrr_key],
                            f"{side_key}_TIMESTAMPS": result.get(f"{side_key}_TIMESTAMPS"),
                            trade_type.upper(): trade_data,
                            "TIMESTAMP": datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"),
                            "EXP_NUM" : result['EXP_NUM']
                        }
                        # try:
                        #     model_stat = Indian_model_predictor(result["STOCK_NAME"], 2, side_key, datetime.now()).fetch_model_stats_future_and_commodity(
                        #         trade_data["entry_price"],
                        #         trade_data["target_price"],
                        #         trade_data["stop_loss"],
                        #         result['EXP_NUM'],
                        #         segment
                        #     )
                        #     trade_result["PREDICTION"] = model_stat[0]
                        #     trade_result["PROBABILITY"] = model_stat[1]
                        # except Exception as ex:
                        #     logger.error(f"[240-min] Model predictor error for {st_name} ({side_key}): {ex}")
                        trade_result["PREDICTION"] = "NA" #None
                        trade_result["PROBABILITY"] = 0.0 #None


                        # if trade_result["PREDICTION"] == "success":
                            
                        insres, trade_id = insert_trade_signals(trade_result, country_id_dict['india'], segment_exchange_id[segment], 2)
                        if insres:
                            trade_result["trade_id"] = trade_id
                            check_and_insert_automated_alert(trade_result, segment_exchange_id[segment], country_id_dict['india'], 2)
                            avl_trades.append(trade_result)

                        logger.info(f"[240-min] {side_key} trade for {st_name} committed to DB")

                # Evaluate both BUY and SELL sides
                if result.get("BUY_RRR", 0) >= 2.1:
                    evaluate_trade("BUY", 2.1)
                if result.get("SELL_RRR", 0) >= 2.1:
                    evaluate_trade("SELL", 2.1)

            except Exception as e:
                logger.error(f"[240-min] Error in processing {st_name}: {e}", stack_info=True)
    print("Pushing orders to DB......................##################")
    if avl_trades:
        with ThreadPoolExecutor(max_workers=5) as t_pool:
            futures = [
                t_pool.submit(push_future_commodity_order, time_fr=2, country='india', avl_trades=[trade], segment=segment)
                for trade in avl_trades
            ]
            for fut in as_completed(futures, timeout=30):
                try:
                    fut.result()
                except Exception as e:
                    logger.error(f"[240-min] Error pushing trade to order: {e}", stack_info=True)
    else:
        logger.info("[240-min] No qualifying trades to push to order.")