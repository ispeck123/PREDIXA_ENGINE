from shared.db.db_model import Ind_StockMaster
from shared.db.dbconn import DBConnection
import yfinance as yf
from datetime import date
from dateutil.relativedelta import relativedelta
from apps.finprod_backend.modules.stock_handler import download_single_stock_data, proc_single_tick_item
from shared.config.settings import stock_data_dir_config
import logging
from data_fetchers.fyers.candle_data import CandleDateFetcher
from data_fetchers.fyers.indian_stock_data_updater import INDIAN_STOCK_DATA_UPDATER
from shared.config.settings import Config as cfg

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class STOCK_SPLIT_CHECKER:
    def __init__(self):
        self.db = DBConnection()
        self.since = date.today() - relativedelta(months=1)
    

    def get_all_active_symbols(self):
        session = self.db.get_session()
        res = session.query(Ind_StockMaster).filter(Ind_StockMaster.is_active == True).all()
        session.close()
        return [{"y_finance": r.y_finance, "stock_tick": r.stock_tick, "fyers_symbol": r.fyers_symbol} for r in res]
    

    def check_split_status(self, symbol):
        try:
            splits = yf.Ticker(symbol).splits
            if splits is not None and not splits.empty:
                recent = splits[splits.index.date >= self.since]
                if not recent.empty:
                    logger.info(f"{symbol} has splits: {recent}")
                    return True
                return False
            return False
        except Exception as e:
            logger.error(f"Error checking split status for {symbol}")
            logger.exception(e)
            return False
            

    def calculate(self):
        symbols = self.get_all_active_symbols()
        for symbol in symbols:
            if self.check_split_status(symbol['y_finance']):
                print(f"{symbol['y_finance']} has split")
                self.reprocess_split_stock(symbol)

    def reprocess_split_stock(self, symbol):
        try:
            y_fin_stock_name = symbol['y_finance']
            stock_tick_nn = symbol['stock_tick']
            country_dir = getattr(cfg, 'india_data_dir')

            # download_single_stock_data(stock_tick_nn, y_fin_stock_name, stock_data_dir_config.indian_stock_data_dir)
            # proc_single_tick_item(stock_tick_nn, stock_data_dir_config.indian_stock_data_dir)

            cls = CandleDateFetcher()
            #symbol = y_fin_stock_name.split('.')[0]
            symbol = symbol['fyers_symbol']
            logger.info(f"Processing stock: {stock_tick_nn} Daily")
            cls.fetch_candle_data_custom_resolution(stock_tick=stock_tick_nn, 
                                                    symbol=symbol, 
                                                    start_date="2020-01-01", 
                                                    resolution="1D")
            logger.info(f"Processing stock: {stock_tick_nn} 60")
            cls.fetch_candle_data_custom_resolution(stock_tick=stock_tick_nn, 
                                                    symbol=symbol, 
                                                    start_date="2020-01-01", 
                                                    resolution="60")
            logger.info(f"Processing stock: {stock_tick_nn} 15")
            cls.fetch_candle_data_custom_resolution(stock_tick=stock_tick_nn, 
                                                    symbol=symbol, 
                                                    start_date="2020-01-01", 
                                                    resolution="15")
            logger.info(f"Processing stock: {stock_tick_nn} 5")
            cls.fetch_candle_data_custom_resolution(stock_tick=stock_tick_nn, 
                                                    symbol=symbol, 
                                                    start_date="2020-01-01", 
                                                    resolution="5")
            obj = INDIAN_STOCK_DATA_UPDATER()
            obj.create_75munite_from_15munite(f"{stock_tick_nn}_fifteen.csv")
            obj.create_monthly_and_weekly_from_daily(f"{stock_tick_nn}_daily.csv", 'W')
            obj.create_monthly_and_weekly_from_daily(f"{stock_tick_nn}_daily.csv", 'ME')
            obj.create_25munite_from_5munite(f"{stock_tick_nn}_five.csv")
            obj.create_125munite_from_5munite(f"{stock_tick_nn}_five.csv")

            logger.info(f"Download complete starting process")
            # proc_single_tick_item(stock_tick_nn, country_dir)
            
            print("success")
            logger.info(f"Successfully reprocessed stock data for splited stock: {y_fin_stock_name}")
        except Exception as ex:
            logger.error(f"Error reprocessing stock data for {symbol}")
            logger.exception(ex)




# if __name__ == "__main__":
#     checker = STOCK_SPLIT_CHECKER()
#     checker.calculate()
        