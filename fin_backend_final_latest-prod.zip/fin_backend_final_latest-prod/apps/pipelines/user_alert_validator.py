from shared.db.dbconn import DBConnection
from shared.db.db_model import UserAlert, Ind_StockMaster
import pandas as pd
from shared.config.settings import stock_data_dir_config
import os, logging

logger = logging.getLogger(__name__)

class UserAlertValidator:
    def __init__(self):
        self.db = DBConnection()

    def get_time_frame_name(self, time_frame: int) -> str:
        return {
            1: 'daily',
            2: 'sixty',
            3: 'fifteen',
            25: 'seventy_five'
        }.get(time_frame, str(time_frame))
    
    def validate_user_alerts(self):
        session = self.db.get_session()
        try:
            alerts = session.query(UserAlert).filter(UserAlert.is_active == 0).all()
            for alert in alerts:
                self.validate_alert(alert)
        finally:
            session.close()
    
    def check_alert_position(self, alert):
        try:
            session = self.db.get_session()
            stock = session.query(Ind_StockMaster).filter(Ind_StockMaster.kite_symbol == alert.stock_name).first()
            stock_file_name = f"{stock.stock_tick}_{self.get_time_frame_name(alert.time_frame)}.csv"
            df = pd.read_csv(os.path.join(stock_data_dir_config.indian_stock_data_dir, 'latest_data_csv', stock_file_name))
            df['tradeDate'] = pd.to_datetime(df['tradeDate'], dayfirst=True)
            df.sort_values('tradeDate', inplace=True)
            df = df[df['tradeDate'] >= alert.created_at]
            df.reset_index(drop=True, inplace=True)

            if df.empty:
                return
            min_low = df['low'].min()
            max_high = df['high'].max()
            if alert.trade_type == 'BUY':
                if alert.trigger_price < min_low:
                    alert.is_active = 1
                    alert.save()
            elif alert.trade_type == 'SELL':
                if alert.trigger_price > max_high:
                    alert.is_active = 1
                    alert.save()            
            
        except Exception as e:
            logger.error(e, exc_info=1, stack_info=True)

    