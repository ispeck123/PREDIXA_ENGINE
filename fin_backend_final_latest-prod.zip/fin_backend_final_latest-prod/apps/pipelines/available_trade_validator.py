import os
from shared.config.settings import stock_data_dir_config
from shared.db.dbconn import DBConnection
from shared.db.db_model import TradeSignal, Ind_StockMaster, Us_StockMaster
from datetime import datetime
from scripts.calculate_setup import Calculate_setup_execute
from alert_engine.trade_validation_alerts import TradeValidationAlerts
import logging

dbc = DBConnection()
logger = logging.getLogger(__name__)

class AvailableTradeValidator:
    def __init__(self):
        self.indian_stock_data_dir = stock_data_dir_config.indian_stock_data_dir
        self.future_to_stock = stock_data_dir_config.indian_stock_future_data_dir
        self.commodity_data_dir = stock_data_dir_config.indian_commodity_data
        self.us_data_dir = stock_data_dir_config.us_data_dir
        self.trade_validation_alerts = TradeValidationAlerts()

    def get_time_frame_name(self, time_frame: int) -> str:
        return {
            1: 'Daily',
            2: 'Sixty',
            3: 'Fifteen',
            25: 'SeventyFive'
        }.get(time_frame, str(time_frame))

    def create_invalidate_msg(self, trade: TradeSignal) -> str:
        time_frame_name = self.get_time_frame_name(trade.time_fr)
        return (
            f"Trade of {trade.stock_name} for {time_frame_name} timeframe on "
            f"{trade.created_at.strftime('%d-%m-%Y')} is no longer valid. "
            f"Setup not found with required R:R or a new adverse zone formed."
        )

    # ✅ New: clear update message with old/new targets and RR
    def create_update_msg(self, trade: TradeSignal, old_target: float, new_target: float, new_rr: float) -> str:
        time_frame_name = self.get_time_frame_name(trade.time_fr)
        return (
            f"Updated target for {trade.stock_name} ({time_frame_name}) from {old_target} to {new_target}. "
            f"Current setup R:R = {new_rr:.2f}. Entry unchanged; setup still meets threshold."
        )

    def get_available_trades_cash(self):
        session = dbc.get_session()
        try:
            return session.query(TradeSignal).filter(
                TradeSignal.is_active == 1,
                TradeSignal.exchange_id == 8
            ).all()
        finally:
            session.close()

    # ✅ Keep only one invalidate method and always notify
    def invalidate_cash_trade(self, trade: TradeSignal):
        session = dbc.get_session()
        session.delete(trade)
        session.commit()
        session.close()
        # self.trade_validation_alerts.send_msg(self.create_invalidate_msg(trade))

    def get_available_trades_futures(self):
        session = dbc.get_session()
        try:
            return session.query(TradeSignal).filter(
                TradeSignal.is_active == 1,
                TradeSignal.exchange_id == 11
            ).all()
        finally:
            session.close()

    def get_available_trades_commodity(self):
        session = dbc.get_session()
        try:
            return session.query(TradeSignal).filter(
                TradeSignal.is_active == 1,
                TradeSignal.exchange_id == 10
            ).all()
        finally:
            session.close()

    def validate_trades_cash(self, trades):
        for trade in trades:
            try:
                trade_type = trade.trade_type  # "BUY" or "SELL"
                pcd = trade.created_at
                cse = Calculate_setup_execute(
                    stock_name=trade.stock_name,
                    time_frame=trade.time_fr,
                    last_dt=pcd,
                    country_dir=self.indian_stock_data_dir
                )
                res = cse.calculate()
                if not res or trade_type not in res:
                    # setup disappeared entirely
                    self.invalidate_cash_trade(trade)
                    print("Trade invalid: setup not found", )
                    continue

                current_setup_data = res[trade_type]
                prev = trade.trade_data or {}

                # Defensive reads
                prev_entry = prev.get('entry_price')
                prev_target = prev.get('target_price')
                prev_stop = prev.get('stop_loss')

                new_entry = current_setup_data.get('entry_price')
                new_target = current_setup_data.get('target_price')
                new_stop = current_setup_data.get('stop_loss')

                is_same_entry = prev_entry == new_entry
                is_same_target = prev_target == new_target
                is_same_stop = prev_stop == new_stop

                # ✅ thresholds
                rr_key = f'{trade_type}_RRR'
                new_rr = float(current_setup_data.get(rr_key, 0))
                rr_threshold = 2.1 if trade_type == "BUY" else 1.6

                # Case 1: all values unchanged -> still valid
                if is_same_entry and is_same_target and is_same_stop:
                    print("Trade valid: no change")
                else:
                    print("Trade invalid: change", trade.id)
                    self.invalidate_cash_trade(trade)
            #     # ✅ Case 2: Entry unchanged but Target changed
            #     # If RR still good, update target; else invalidate
            #     if is_same_entry and not is_same_target:
            #         if new_rr >= rr_threshold:
            #             # Update only the target as requested
            #             updated = dict(prev)  # shallow copy
            #             updated['target_price'] = new_target
            #             trade.trade_data = updated
            #             trade.is_send = 0  # optional: mark to notify downstream pipeline again
            #             trade.save()
            #             # notify user about target update
            #             self.trade_validation_alerts.send_msg(
            #                 self.create_update_msg(trade, old_target=prev_target, new_target=new_target, new_rr=new_rr)
            #             )
            #             print("Trade updated: target changed and RR OK")
            #             continue
            #         else:
            #             self.invalidate_cash_trade(trade)
            #             print("Trade invalid: target changed and RR below threshold")
            #             continue

            #     # Optional: handle only-stop changes (entry+target same, stop changed)
            #     # If you want to treat this as valid, just pass; otherwise apply your policy.
            #     if is_same_entry and is_same_target and not is_same_stop:
            #         # Treat as valid (stop moved) OR add your own logic here.
            #         print("Trade valid: stop changed only")
            #         continue

            #     # Any other change (entry changed, or multiple changed) -> invalidate
            #     self.invalidate_cash_trade(trade)
            #     print("Trade invalid: entry changed or other adverse change")

            except Exception as e:
                logger.exception(f"Error in validate_trades_cash: {e}", exc_info=1, stack_info=True)

    def process_all_trades_cash(self):
        trades = self.get_available_trades_cash()
        self.validate_trades_cash(trades)
