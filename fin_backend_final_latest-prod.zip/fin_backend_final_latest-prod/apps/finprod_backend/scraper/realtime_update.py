
import requests
import time
import pandas as pd
from bs4 import BeautifulSoup
from datetime import datetime, timedelta
from random import randint
from shared.config.settings import Config as cfg
import numpy as np
import pytz
from shared.db.dbconn import DBConnection
from data_fetchers.fyers.fyers_session import fyers_access_token_handler
from fyers_apiv3 import fyersModel
import logging
from datetime import datetime, timezone, timedelta
from datetime import time as dt_time
from zoneinfo import ZoneInfo
from typing import Optional, Dict, Any
import os

logger = logging.getLogger()
IST = ZoneInfo("Asia/Kolkata")
local_time = pytz.timezone('Asia/Kolkata')

ohlc_data_candles = {}

ohlc_data = {}

SESSION_START_IST = dt_time(9, 15)

TF_MINUTES_MAP = {
    1: 24 * 60,   # Daily
    25: 75,
    2: 60,        # 60-minute
    3: 15,        # 15-minute
}

def get_y_fin_stock_name(stock : str):
    db = DBConnection()
    f_res = db.raw_query(f"select * from stock_master where stock_tick='{stock}';")
    return f_res[0].get('y_finance')

def get_last_data_from_files(stock_name: str, time_fr: int):
    global ohlc_data
    exe_frame = getattr(cfg, f'TIME_FRAMES_{time_fr}')[-1]
    #stock_file = f"/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/processed_data_files/{stock_name}_{exe_frame}.csv"
    stock_file = os.path.join(os.getcwd(), "apps", "finprod_backend", "processed_data_files", f"{stock_name}_{exe_frame}.csv")
    dff = pd.read_csv(stock_file)
    dff['timestamp'] = pd.to_datetime(dff['timestamp'], dayfirst = True)
    dff['timestamp'] = dff['timestamp'].astype(np.int64) // 10**9
    last_row = dff.iloc[-1]
    ohlc_data[stock_name] = {
        'time': int(last_row['timestamp']),
        'open': last_row['open'],
        'high': last_row['high'],
        'low': last_row['low'],
        'close': last_row['close']
    }
    print("get_last_data_from_files", ohlc_data)



# def get_current_candle_timestamp(time_frame : int):
#     today = datetime.now().strftime("%Y-%m-%d")
#     if time_frame == 1:
#         t_stamp_today = datetime.strptime(today, "%Y-%m-%d") + timedelta(hours=5, minutes=30)
#         gmt_stamp = t_stamp_today.timestamp()
#         # print(gmt_stamp)
#         return gmt_stamp
    
#     elif time_frame == 2:
#         current_min = datetime.now(tz=local_time).minute
#         if 0 <= current_min <= 14: 
#             current_hour = datetime.now(tz=local_time).hour - 1
#         else:
#             current_hour = datetime.now(tz=local_time).hour
#         t_stamp = datetime.strptime(today, "%Y-%m-%d").replace(hour=current_hour, minute=15, second=0) + timedelta(hours=5, minutes=30)
#         # print(t_stamp)
#         return t_stamp.timestamp()
    
#     elif time_frame == 3:
#         current_hour = datetime.now(tz=local_time).hour
#         current_min = datetime.now(tz=local_time).minute
#         if 0 <= current_min <= 14:
#                 cal_min = 0
#         elif 15 <= current_min <= 29:
#                 cal_min = 15
#         elif 30 <= current_min <= 44:
#                 cal_min = 30
#         elif 45 <= current_min <= 59:
#                 cal_min = 45
#         t_stamp = datetime.strptime(today, "%Y-%m-%d").replace(hour=current_hour, minute=cal_min, second=0) + timedelta(hours=5, minutes=30)
#         # print(t_stamp)
#         return t_stamp.timestamp()


def get_current_candle_timestamp(time_frame: int) -> int:
    """
    Returns the candle *start* timestamp (epoch seconds, UTC) for the ongoing bucket.
    time_frame: 1 = 1D, 2 = 60m, 3 = 15m
    """
    tf_min = TF_MINUTES_MAP.get(time_frame)
    if not tf_min:
        raise ValueError(f"Unsupported time_frame: {time_frame}")

    now_ist = datetime.now(IST)

    if time_frame == 1:
        # Daily candle starts at 00:00 IST of 'today'
        day_start_ist = datetime(now_ist.year, now_ist.month, now_ist.day, 17, 30, 0, tzinfo=IST)
        return int(day_start_ist.astimezone(timezone.utc).timestamp())
    elif time_frame == 2:
        current_min = datetime.now(tz=IST).minute
        if 0 <= current_min <= 14: 
            current_hour = datetime.now(tz=IST).hour - 1
        else:
            current_hour = datetime.now(tz=IST).hour
        t_stamp = datetime(now_ist.year, now_ist.month, now_ist.day, current_hour, 15, 0, tzinfo=IST)
        # datetime.strptime(today, "%Y-%m-%d").replace(hour=current_hour, minute=15, second=0)
        # print(t_stamp)
        return t_stamp.timestamp()

    # intraday (e.g. 60, 15) aligned to session start 09:15 IST
    session_start_ist = datetime.combine(now_ist.date(), SESSION_START_IST, tzinfo=IST)

    # If before session, use today's 09:15 anyway (front-of-day bucket)
    if now_ist < session_start_ist:
        bucket_start_ist = session_start_ist
    else:
        # minutes since 09:15
        delta_min = int((now_ist - session_start_ist).total_seconds() // 60)
        # floor to timeframe
        buckets_since_open = max(0, delta_min // tf_min)
        bucket_start_ist = session_start_ist + timedelta(minutes=buckets_since_open * tf_min)

    return int(bucket_start_ist.astimezone(timezone.utc).timestamp())



# def get_latest_stock_price(stock_tick: str):
#     try:
#         y_fin_stock_name = str(get_y_fin_stock_name(stock_tick)).rsplit(".")[0]
#         # cfg.y_fin_stock_list.__getitem__(cfg.stock_list.index(stock_tick)).rsplit(".")[0]
#         url = f'https://www.google.com/finance/quote/{y_fin_stock_name}:NSE'
#         responce = requests.get(url)
#         soup = BeautifulSoup(responce.text, 'html.parser')
#         class1 = 'YMlKec fxKbKc'
#         price = float(soup.find(class_=class1).text.strip()[1:].replace(",", ""))
#         # new_price = price + randint(0, 20)
#         return price
#     except Exception as ex:
#         return None

def get_latest_stock_price(symbol: str):
    try:
        #print("within get_latest_stock_price")
        client_id = fyers_access_token_handler().get_access_token().split(':')[0]
        access_token = fyers_access_token_handler().get_access_token().split(':')[1]
        fyers = fyersModel.FyersModel(client_id=client_id, token=access_token, is_async=False, log_path="")
        quote_data = fyers.quotes({"symbols": symbol})

        if 'd' in quote_data:
            for data in quote_data['d']:
                if data.get('s') == 'ok' and 'v' in data:
                    if data['v']['symbol'] == symbol:
                        return data['v']['lp']
                    else:
                        print(quote_data)
                        return None
                else:
                    print(quote_data)
                    return None
        else:
            print(quote_data)
            return None
    except Exception as ex:
        logger.exception(ex)
        return None
    
def update_ohlc(stock_tick: str, price: float, time_fr : int):
    global ohlc_data_candles
    cal_timestamp = get_current_candle_timestamp(time_fr)
    if stock_tick not in ohlc_data_candles or ohlc_data_candles[stock_tick]['time'] != int(cal_timestamp):
        ohlc_data_candles[stock_tick] = {
            'time': int(cal_timestamp),
            'open': price,
            'high': price,
            'low': price,
            'close': price
        }
    else:
        if stock_tick not in ohlc_data_candles.keys():
            ohlc_data_candles[stock_tick] = {
                'time': int(cal_timestamp),
                'open': price,
                'high': price,
                'low': price,
                'close': price
            }
        else:
            ohlc_data_candles[stock_tick]['high'] = max(ohlc_data_candles[stock_tick]['high'], price)
            ohlc_data_candles[stock_tick]['low'] = min(ohlc_data_candles[stock_tick]['low'], price)
            ohlc_data_candles[stock_tick]['close'] = price
    

    return {
        'time': int(cal_timestamp),
        'open': ohlc_data_candles[stock_tick]['open'],
        'high': ohlc_data_candles[stock_tick]['high'],
        'low': ohlc_data_candles[stock_tick]['low'],
        'close': ohlc_data_candles[stock_tick]['close']
    }


class CandleBuilder:
    """
    Per-symbol, per-timeframe, *current bucket only* aggregator.
    Call .update(ltp, tick_time_ms, time_frame) for each incoming tick.
    If bucket changes, it resets and starts a new one automatically.
    """
    def __init__(self, symbol: str):
        self.symbol = symbol
        self.bucket_start_s = None
        self.o = self.h = self.l = self.c = None
        self.count = 0

    def _reset_for_bucket(self, new_bucket_start_s: int):
        self.bucket_start_s = new_bucket_start_s
        self.o = self.h = self.l = self.c = None
        self.count = 0

    def update(
        self,
        ltp: float,
        tick_time_ms: int,
        ohlc_values: dict
    ):
        # bucket_start_s = get_current_candle_timestamp(time_frame)
        # if self.bucket_start_s != bucket_start_s:
        #     self._reset_for_bucket(bucket_start_s)

        price = float(ltp)

        # === DAILY: use feed's day-wise OHLC as-is, close from LTP ===
        # if time_frame == 1:
            # fall back to ltp if any field missing
        self.bucket_start_s = ohlc_values['time']
        self.o = float(ohlc_values['open']) if ohlc_values['open'] is not None else (self.o if self.o is not None else price)
        self.h = float(ohlc_values['high']) if ohlc_values['high'] is not None else (self.h if self.h is not None else price)
        self.l = float(ohlc_values['low'])  if ohlc_values['low']  is not None else (self.l if self.l  is not None else price)
        self.c = price
        self.count += 1
        return

        # # === INTRADAY: build from ticks ===
        # if self.count == 0:
        #     self.o = self.h = self.l = self.c = price
        # else:
        #     self.h = max(self.h, price)
        #     self.l = min(self.l, price)
        #     self.c = price
        # self.count += 1

    def snapshot(self) -> Optional[Dict[str, Any]]:
        if self.bucket_start_s is None or self.count == 0:
            return None
        return {
            "symbol": self.symbol,
            "t_open": self.bucket_start_s,  # epoch seconds (UTC)
            "o": self.o,
            "h": self.h,
            "l": self.l,
            "c": self.c,
            "count": self.count,
            "status": "open",
        }
