import requests
from bs4 import BeautifulSoup
import concurrent.futures
from shared.db.dbconn import DBConnection
import re

response = {}
response_ = {}
price_response = {}

dbc = DBConnection()

def extract_currency_symbol(s):
    match = re.search(r'[^\d.,\s]+', s)
    return match.group() if match else ''


def wrapper(tick, yfin, sid):
    try:
        result = scrape_stock_price_by_stock_index_map(tick, yfin, sid)
        return tick, result
    except Exception as e:
        print(f"Error in thread for {tick}: {e}")
        return tick, None

# def index_price():
#     try:
#         stock_name = {
#             "NIFTY 50": "NIFTY_50:INDEXNSE",
#             "NIFTY NEXT 50": "NIFTY_NEXT_50:INDEXNSE",
#             "NASDAQ": ".IXIC:INDEXNASDAQ",
#             "BANKNIFTY": "NIFTY_BANK:INDEXNSE",
#             "SENSEX": "SENSEX:INDEXBOM",
#             "FINNIFTY": "NIFTY_FIN_SERVICE:INDEXNSE",
#             "INDIA VIX": "INDIA_VIX:INDEXNSE"
#             #"GOLDM"
#             #"CRUDE OIL M"
#         }
#         response = {}
#         for name in stock_name:
#             url = f'https://www.google.com/finance/quote/{stock_name[name]}'
#             responce = requests.get(url)
#             soup = BeautifulSoup(responce.text, 'html.parser')
#             price_class = 'YMlKec fxKbKc'
#             #price = float(soup.find(class_=price_class).text.strip()[1:].replace(",", ""))
#             price = float((soup.find(class_= price_class).text).replace(',',''))
#             #print(price)
#             #day_change_percentage_class = 'JwB6zf'
#             #percentage = soup.find(class_= day_change_percentage_class).text
#             #print(percentage)
#             prev_price_class = 'P6K39c'
#             prev_price = float((soup.find(class_= prev_price_class).text).replace(',',''))
#             #print(prev_price)
#             day_change = price - prev_price
#             percentage = f"{round(((day_change / prev_price) * 100), 2)}%"
#             if day_change >= 0:
#                 day_change = f"+{round(day_change, 2)} Today"
#             else:
#                 day_change = f"{round(day_change, 2)} Today"
#             #print(day_change)
#             response[name] = {"price": price, "day_change_percentage": percentage, "day_change": day_change}  
#         return response
#     except Exception as ex:
#         return None


def scrape_index_price(name, tag, index_id):
    try:
        #print(name, tag)
        global response
        url = f'https://www.google.com/finance/quote/{tag}'
        responce = requests.get(url)
        soup = BeautifulSoup(responce.text, 'html.parser')
        price_class = 'YMlKec fxKbKc'
        #price = float(soup.find(class_=price_class).text.strip()[1:].replace(",", ""))
        try:
            price = float((soup.find(class_= price_class).text).replace(',',''))
        except:
            price = None
        #print(price)
        #day_change_percentage_class = 'JwB6zf'
        #percentage = soup.find(class_= day_change_percentage_class).text
        #print(percentage)
        prev_price_class = 'P6K39c'
        try:
            prev_price = float((soup.find(class_= prev_price_class).text).replace(',',''))
        except:
            prev_price = None
        #print(prev_price)
        if price and prev_price:
            day_change = price - prev_price
            percentage = f"{round(((day_change / prev_price) * 100), 2)}%"
            if day_change >= 0:
                day_change = f"+{round(day_change, 2)} Today"
            else:
                day_change = f"{round(day_change, 2)} Today"
            #print(day_change)
            response[name] = {"price": price, "day_change_percentage": percentage, "day_change": day_change, "index_id": index_id}
        else:
            response.pop(name)
    except Exception as ex:
        pass
        # print("Exception:", ex)


def index_price(country_id):
    try:
        global response
        res = dbc.raw_query(f"select * from index_master where is_active = 1 and country_id = {country_id};")
        stock_name = {}
        index_id = []
        for row in res:
            stock_name[row['index_name'].upper()] = row['y_finance']
            index_id.append(row['index_id'])
        # stock_name = {
        #     "NIFTY 50": "NIFTY_50:INDEXNSE",
        #     "NIFTY NEXT 50": "NIFTY_NEXT_50:INDEXNSE",
        #     "NASDAQ": ".IXIC:INDEXNASDAQ",
        #     "BANKNIFTY": "NIFTY_BANK:INDEXNSE",
        #     "SENSEX": "SENSEX:INDEXBOM",
        #     "FINNIFTY": "NIFTY_FIN_SERVICE:INDEXNSE",
        #     "INDIA VIX": "INDIA_VIX:INDEXNSE"
        #     #"GOLDM"
        #     #"CRUDE OIL M"
        # }
        response = stock_name
        pool = concurrent.futures.ThreadPoolExecutor(max_workers = len(stock_name))
        results = pool.map(scrape_index_price, stock_name.keys(), stock_name.values(), index_id)
        pool.shutdown(wait=True)
        return response
    except Exception as ex:
        return None
    

def scrape_stock_price(name, tag, stock_id):
    try:
        #print(name, tag)
        global response_
        url = f'https://www.google.com/finance/quote/{tag}'
        #print(url)
        responce = requests.get(url)
        soup = BeautifulSoup(responce.text, 'html.parser')
        price_class = 'YMlKec fxKbKc'
        try:
            price_text = soup.find(class_= price_class).text
            currency = extract_currency_symbol(price_text)
            price = float(price_text.replace(',', '').replace(currency, ''))
        except:
            price = None
        #print("price", price)
        #day_change_percentage_class = 'JwB6zf'
        #percentage = soup.find(class_= day_change_percentage_class).text
        #print(percentage)
        prev_price_class = 'P6K39c'
        try:
            price_text = soup.find(class_= prev_price_class).text
            currency = extract_currency_symbol(price_text)
            prev_price = float(price_text.replace(',', '').replace(currency, ''))
        except:
            prev_price = None
        #print("prev_price", prev_price)
        if price and prev_price:
            day_change = price - prev_price
            percentage = f"{round(((day_change / prev_price) * 100), 2)}%"
            if day_change >= 0:
                day_change = f"+{round(day_change, 2)} Today"
            else:
                day_change = f"{round(day_change, 2)} Today"
            #print(day_change)
            response_[name] = {"price": price, "day_change_percentage": percentage, "day_change": day_change, "stock_id": stock_id, "currency": currency}
        else:
            response_.pop(name)
    except Exception as ex:
        pass
        # print("Exception:", ex)


def stock_price(index_id):
    try:
        global response_
        if index_id == '' or None:
            res = dbc.raw_query("""select sm.id, sm.stock_tick, sm.y_finance, sm.is_active, sm.index_id, cm.country_name from stock_master as sm 
                                inner join index_master as im on sm.index_id = im.index_id
                                inner join county_master as cm on im.country_id = cm.country_id
                                where sm.is_active = 1 order by sm.id asc;""")
        else:
            res = dbc.raw_query("""select sm.id, sm.stock_tick, sm.y_finance, sm.is_active, sm.index_id, cm.country_name from stock_master as sm 
                                inner join index_master as im on sm.index_id = im.index_id
                                inner join county_master as cm on im.country_id = cm.country_id
                                where sm.is_active = 1 and sm.index_id = '{}' order by sm.id asc;""".format(index_id))
        #print(res)
        dbc.close_engine()
        #print(res)
        stock_name = {} 
        stock_id = []
        for row in res:
            if row["country_name"] == "India":
                stock_name[row['stock_tick'].upper()] = row['y_finance'].split('.')[0] + ":NSE"
            elif row["country_name"] == "US":
                stock_name[row['stock_tick'].upper()] = row['y_finance'] + ":NASDAQ"
            else:
                stock_name[row['stock_tick'].upper()] = row['y_finance'].split('.')[0] + ":NSE"
            stock_id.append(row['id'])
        #print(stock_name)
        # stock_name = {
        #     "HDFCBANK": "HDFCBANK:NSE",
        #     "HINDUNILVR": "HINDUNILVR:NSE",
        #     "ICICIBANK": "ICICIBANK:NSE",
        #     "INFY": "INFY:NSE",
        #     "ITC": "ITC:NSE",
        #     "SUN_PHARMA": "SUNPHARMA:NSE",
        #     "TATAMOTORS": "TATAMOTORS:NSE",
        #     "TATAPOWER": "TATAPOWER:NSE",
        #     "RELIANCE": "RELIANCE:NSE",
        #     "TCS": "TCS:NSE",
        #     "BERGEPAINT": "BERGEPAINT:NSE",
        #     "SBICARD": "SBICARD:NSE",
        #     "DMART": "DMART:NSE",
        #     "INDUSINDBK": "INDUSINDBK:NSE",
        #     "BHARTIARTL": "BHARTIARTL:NSE",
        #     "INDRAMEDCO": "INDRAMEDCO:NSE",
        #     "VBL": "VBL:NSE",
        #     "NHPC": "NHPC:NSE",
        #     "SJS_ENTERPRISE": "SJS:NSE",
        #     "TRENT": "TRENT:NSE",
        #     "BSE_LIMITED": "BSE:NSE",
        #     "SHARDA_CORP_CHEM": "SHARDACROP:NSE",
        #     "TIPS_MUSIC": "TIPSMUSIC:NSE",
        #     "KARUR_VYSYA_BANK": "KARURVYSYA:NSE",
        #     "KPIT_TECHNOLOGIES": "KPITTECH:NSE",
        #     "MANAPPURAM_FINANCE": "MANAPPURAM:NSE",
        #     "RVNL": "RVNL:NSE",
        #     "INNOVACAP": "INNOVACAP:NSE",
        #     "FEDERALBANK": "FEDERALBNK:NSE",
        #     "INDIAN_ENERGY_EXCHANGE": "IEX:NSE",
        #     "IREDA": "IREDA:NSE",
        #     "IRFC": "IRFC:NSE",
        #     "NTPC": "NTPC:NSE",
        #     "BEL": "BEL:NSE",
        #     "BPCL": "BPCL:NSE",
        #     "JIOFIN": "JIOFIN:NSE",
        #     "JSW_STEEL": "JSWSTEEL:NSE",
        #     "ADANI_POWER": "ADANIPOWER:NSE",
        #     "ONGC": "ONGC:NSE",
        #     "COAL_INDIA": "COALINDIA:NSE",
        #     "ZOMATO": "ZOMATO:NSE",
        #     "UJJIVANSFB": "UJJIVANSFB:NSE",
        #     "NIFTY": "NIFTY_50:INDEXNSE",
        #     "MOTHERSON": "MOTHERSON:NSE",
        #     "GAIL": "GAIL:NSE",
        #     "IFCI": "IFCI:NSE",
        #     "HINDZINC": "HINDZINC:NSE",
        #     "PNB": "PNB:NSE",
        #     "EASEMYTRIP": "EASEMYTRIP:NSE",
        #     "CDSL": "CDSL:NSE"
        # }
        response_ = stock_name
        pool = concurrent.futures.ThreadPoolExecutor(max_workers = len(stock_name))
        results = pool.map(scrape_stock_price, stock_name.keys(), stock_name.values(), stock_id)
        pool.shutdown(wait=True)
        return response_
    except Exception as ex:
        return None


def scrape_stock_price_by_stock_index_map(name, tag, stock_id):
    try:
        #print(name, tag)
        global price_response
        url = f'https://www.google.com/finance/quote/{tag}'
        #print(url)
        responce = requests.get(url)
        soup = BeautifulSoup(responce.text, 'html.parser')
        price_class = 'YMlKec fxKbKc'
        try:
            price_text = soup.find(class_= price_class).text
            currency = extract_currency_symbol(price_text)
            price = float(price_text.replace(',', '').replace(currency, ''))
        except:
            price = None
        #print("price", price)
        #day_change_percentage_class = 'JwB6zf'
        #percentage = soup.find(class_= day_change_percentage_class).text
        #print(percentage)
        prev_price_class = 'P6K39c'
        try:
            price_text = soup.find(class_= prev_price_class).text
            currency = extract_currency_symbol(price_text)
            prev_price = float(price_text.replace(',', '').replace(currency, ''))
        except:
            prev_price = None
        #print("prev_price", prev_price)
        if price and prev_price:
            day_change = price - prev_price
            percentage = f"{round(((day_change / prev_price) * 100), 2)}%"
            if day_change >= 0:
                day_change = f"+{round(day_change, 2)} Today"
            else:
                day_change = f"{round(day_change, 2)} Today"
            #print(day_change)
            price_response[name] = {"price": price, "day_change_percentage": percentage, "day_change": day_change, "stock_id": stock_id, "currency": currency}
        else:
            price_response.pop(name)
    except Exception as ex:
        pass
        # print("Exception:", ex)


def stock_price_by_stock_index_map(index_id, page=1, limit=50, country = 'India'):
    try:
        global price_response
        offset = (page - 1) * limit
        # if index_id == '' or None:
        #     res = dbc.raw_query("""select sm.id, sm.stock_tick, sm.y_finance, sm.is_active, sm.index_id, cm.country_name 
        #                         from stock_index_map as sim
        #                         inner join stock_master as sm on sim.stock_id = sm.id 
        #                         inner join index_master as im on sim.index_id = im.index_id
        #                         inner join county_master as cm on im.country_id = cm.country_id
        #                         where sm.is_active = 1 and im.is_active = 1 order by sm.id asc;""")
        # else:
        #     res = dbc.raw_query("""select sm.id, sm.stock_tick, sm.y_finance, sm.is_active, sm.index_id, cm.country_name 
        #                         from stock_index_map as sim
        #                         inner join stock_master as sm on sim.stock_id = sm.id 
        #                         inner join index_master as im on sim.index_id = im.index_id
        #                         inner join county_master as cm on im.country_id = cm.country_id
        #                         where sm.is_active = 1 and im.is_active = 1 and sim.index_id = '{}' order by sm.id asc;""".format(index_id))
        #print(res)
        table_name = {
            "india": {
                "stock_table": "ind_stock_master",
                "mapping_table": "ind_stock_index_map"
            },
            "us": {
                "stock_table": "us_stock_master",
                "mapping_table": "us_stock_index_map"
            }
        }
        query = f"""
            select sm.id, sm.stock_tick, sm.y_finance, sm.is_active, sm.index_id, cm.country_name 
            from {table_name[country.lower()]["mapping_table"]} as sim
            inner join {table_name[country.lower()]["stock_table"]} as sm on sim.stock_id = sm.id 
            inner join index_master as im on sim.index_id = im.index_id
            inner join county_master as cm on im.country_id = cm.country_id
            where sm.is_active = 1 and im.is_active = 1
        """
        if index_id and index_id.strip():
            query += f" and sim.index_id = '{index_id}'"
        
        total_count = len(dbc.raw_query(query))

        base_query = query + f" order by sm.id asc limit {limit} offset {offset};"
        res = dbc.raw_query(base_query)
        # print(len(res))
        stock_map = []
        # stock_name = {} 
        # stock_id = []
        # for row in res:
        #     if row["country_name"] == "India":
        #         stock_name[row['stock_tick'].upper()] = row['y_finance'].split('.')[0] + ":NSE"
        #     elif row["country_name"] == "US":
        #         stock_name[row['stock_tick'].upper()] = row['y_finance'] + ":NASDAQ"
        #     else:
        #         stock_name[row['stock_tick'].upper()] = row['y_finance'].split('.')[0] + ":NSE"
        #     stock_id.append(row['id'])
        stock_name = {}
        for row in res:
            stock_tick = row['stock_tick'].upper()
            if row["country_name"] == "India":
                yfinance_code = row['y_finance'].split('.')[0] + ":NSE"
            elif row["country_name"] == "US":
                yfinance_code = row['y_finance'] + ":NASDAQ"
            else:
                yfinance_code = row['y_finance'].split('.')[0] + ":NSE"
            stock_map.append((stock_tick, yfinance_code, row['id']))

            stock_name[stock_tick] = row['y_finance']

        price_response = stock_name
        #print(stock_name)
        # price_response = stock_name
        # pool = concurrent.futures.ThreadPoolExecutor(max_workers = len(stock_name))
        # results = pool.map(scrape_stock_price_by_stock_index_map, stock_name.keys(), stock_name.values(), stock_id)
        # pool.shutdown(wait=True)
        with concurrent.futures.ThreadPoolExecutor(max_workers=min(len(stock_map), 10)) as pool:
            futures = [pool.submit(wrapper, tick, yfin, sid) for tick, yfin, sid in stock_map]
            for future in concurrent.futures.as_completed(futures):
                tick, result = future.result()
                if result is not None:
                    price_response[tick] = result
        return {"total_count": total_count, "price_response": price_response}
    except Exception as ex:
        # print(f"Main error occurred: {ex}")
        return None

# if __name__ == "__main__":
#    print(stock_price())

# from bs4 import BeautifulSoup

# 
# # Find the span with the specific attribute
# span_tag = soup.find('span', {'data-test': 'instrument-price-change'})
# print(span_tag)
# # Extract the text
# if span_tag:
#     value = span_tag.get_text(strip=True)  # Extract and clean text
#     print(value)  # Expected Output: +0.71
# else:
#     print("Value not found")


# from requests_html import HTMLSession

# # Start an HTML session
# session = HTMLSession()

# # URL to scrape
# url = "https://in.investing.com/commodities/crude-oil"

# # Fetch the page and render JavaScript
# response = session.get(url)
# response.html.render(timeout=10, reload=True)  # Wait for JavaScript to execute

# # Extract price
# #price_element = response.html.find('div[data-test="instrument-price-last"]')#, first=True)
# #price_element = response.html.find('div[class="text-5xl/9 font-bold text-[#232526] md:text-[42px] md:leading-[60px]", data-test="instrument-price-last"]', first=True)
# price_element = response.html.find('<span data-test="instrument-price-change"><!-- -->+0.18</span>', first=True)

# if price_element:
#     print("Latest Crude Oil Price:", price_element.text)
# else:
#     print("Price not found.")
