import ccxt
import pandas as pd

def get_gold_data(time_fr: str):
    # Use Binance Futures
    exchange = ccxt.oanda({
        'enableRateLimit': True,
        'options': {'defaultType': 'future'}
    })
    symbol = 'XAU/USDT'
    timeframe = time_fr  # 1-minute candles
    limit = 1000      # Max records to fetch
    # Fetch OHLCV data
    ohlcv = exchange.fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)
    # Convert to DataFrame
    df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
    df = df.rename(columns={
        'volume': 'Volume',
    })
    df.index = pd.to_datetime(df['timestamp'], unit='ms')
    return df


print(get_gold_data('5m'))