from modules.analyze_trend import Trend_Analyzer
from datetime import datetime



if __name__ == '__main__':
    at = Trend_Analyzer('hdfcbank', 1, datetime(year=2025, month=1, day=11))
    at.get_eva_ana_frames()
    at.get_nifty_position()
    