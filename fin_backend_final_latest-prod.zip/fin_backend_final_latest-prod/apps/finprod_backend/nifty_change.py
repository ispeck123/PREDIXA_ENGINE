import pandas as pd

df = pd.read_csv("./latest_data_csv/nifty_daily.csv")

df['Percentage_Change'] = df['close'].pct_change() * 100

df.to_csv("nifty_daily.csv", index=False)