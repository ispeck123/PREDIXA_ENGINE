from fastapi import APIRouter, Request
from shared.db.api_responce import APIResponse
from apps.finprod_backend.modules.decrypt_token import decrypt_and_encrypt, get_access_token
from SharekhanApi.sharekhanConnect import SharekhanConnect
from sqlitedict import SqliteDict
from shared.config.settings import Config as cfg
import logging


db = SqliteDict(cfg.SQLITE_DB)

router = APIRouter()
logger = logging.getLogger()
api_key = "I8tuLzqZWRwXxmwCkfNqPWDVbPIjUMl4"

@router.get("/submit_request_token_and_generate_access", tags=['Token'])
async def submit_request_token_and_generate_access(request_token: str, state: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        res_token = decrypt_and_encrypt(r_token=request_token)
        access_tok_json = get_access_token(api_key, res_token, 12345, None, 1006)
        print(access_tok_json)
        if access_tok_json.get('status') == 200:
            apiresponce.setMsg("success")
            db['access_json'] = access_tok_json
            db.commit()
        else:
            apiresponce.setMsg("failed")
        apiresponce.setResponse(access_tok_json)
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/validate_generated_access_token", tags=['Token'])
async def validate_generated_access_token(request: Request):
    apiresponce = APIResponse(request)
    try:
        access_token = db['access_json'].get('data').get('token')
        sharekhan = SharekhanConnect(api_key, access_token=access_token)
        apiresponce.setMsg("success")
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce

@router.get("/download_and_parse_latest_data", tags=['Token'])
async def download_and_parse_latest_data(request: Request):
    apiresponce = APIResponse(request)
    try:
        access_token = db['access_json'].get('data').get('token')
        sharekhan = SharekhanConnect(api_key, access_token=access_token)
        for idx, stock_items in enumerate(cfg.stock_list):
            s_code = cfg.SCRIPT_CODES[idx]
            for d_intervals in cfg.DOWNLOAD_TIMEFRAMES:
                file_name = f"{stock_items}_{d_intervals}.txt"
                order=sharekhan.historicaldata("NC", s_code, d_intervals)
                with open(f"./apps/finprod_backend/latest_data/{file_name}", mode='w') as f:
                    f.writelines("{}".format(order))

        apiresponce.setMsg("success")
        apiresponce.setResponse("Successfully downloaded latest data")
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce

