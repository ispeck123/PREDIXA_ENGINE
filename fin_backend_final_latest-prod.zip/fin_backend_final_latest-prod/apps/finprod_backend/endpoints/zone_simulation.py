from fastapi import APIRouter, Request, Response
from apps.finprod_backend.modules.cal_z import DemandZoneCalculator, SupplyZoneCalculator, ZoneAnalyzer
from shared.db.api_responce import APIResponse
from datetime import datetime
from shared.config.settings import Config as cfg

import logging
import os

router = APIRouter()
logger = logging.getLogger()

@router.get("/get_simulation_zones", tags=['ZONE SIMULATION'])
async def get_simulation_zones(request: Request, country_name: str, tick: str, time_frame: int, last_d_time: str):
    apiresponce = APIResponse(request)
    try:
        BB = {}
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        country_dir = getattr(cfg, f'{country_name.lower()}_data_dir')
        exe_frame = getattr(cfg, f'TIME_FRAMES_{time_frame}')[-1]
        p_file_path = os.path.join(country_dir, 'processed_data_files', f'{tick}_{exe_frame}.csv')
        dz_cal = DemandZoneCalculator(p_file_path, tick, last_d_time, True) #.calculate_zones()
        sz_cal = SupplyZoneCalculator(p_file_path, tick, last_d_time, True) #.calculate_zones()
        z_ana = ZoneAnalyzer(dz_cal, sz_cal).get_qualified_alterated_zones(True)
        BB['BUY'] = z_ana['Buy'] #dz_cal
        BB['SELL'] = z_ana['Sell'] #sz_cal 
        apiresponce.setMsg('success')
        apiresponce.setResponse(BB)
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce

@router.get("/get_normal_simulation_zones", tags=['ZONE SIMULATION'])
async def get_normal_simulation_zones(request: Request, country_name: str, tick: str, time_frame: int, last_d_time: str):
    apiresponce = APIResponse(request)
    try:
        BB = {}
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        country_dir = getattr(cfg, f'{country_name.lower()}_data_dir')
        exe_frame = getattr(cfg, f'TIME_FRAMES_{time_frame}')[-1]
        p_file_path = os.path.join(country_dir, 'processed_data_files', f'{tick}_{exe_frame}.csv')
        dz_cal = DemandZoneCalculator(p_file_path, tick, last_d_time, True).calculate_zones()
        sz_cal = SupplyZoneCalculator(p_file_path, tick, last_d_time, True).calculate_zones()
        BB['BUY'] = dz_cal
        BB['SELL'] = sz_cal 
        apiresponce.setMsg('success')
        apiresponce.setResponse(BB)
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce