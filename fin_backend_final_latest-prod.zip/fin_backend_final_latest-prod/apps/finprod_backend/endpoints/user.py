from fastapi import APIRouter, Request, HTTPException, status
from shared.db.dbconn import DBConnection
from shared.db.db_model import User, Index, Watchlist, UserCountryAccess, ExchangeMaster, IndexExchangeMap, Ind_StockMaster, Us_StockMaster
from shared.db.req_model import user_cred, WatchlistCreate, user_create
from shared.db.api_responce import APIResponse
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import joinedload
import logging
import uuid
import bcrypt
from datetime import datetime


logger = logging.getLogger()
db = DBConnection()
router = APIRouter()


@router.get("/get_all_user", tags=['User'])
async def get_all_user(request: Request):
    apiresponce = APIResponse(request)
    try:
        session = db.get_session()
        users = session.query(User).filter(User.is_active == 1).all()
        session.close()
        apiresponce.setMsg("success")
        apiresponce.setResponse(users)
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.post("/create_user", tags=['User'])
async def create_user(request: Request, model: user_create):
    apiresponce = APIResponse(request)
    try:
        session = db.get_session()
        existing_user = session.query(User).filter(User.user_name == model.user_name).all()
        if existing_user != None and len(existing_user) > 0:
            apiresponce.setMsg("failed")
            apiresponce.setResponse("Username already exists")
            return apiresponce
        else:
            existing_user = session.query(User).filter(User.email == model.email).all()
            if existing_user != None and len(existing_user) > 0:
                apiresponce.setMsg("failed")
                apiresponce.setResponse("Email already exists")
                return apiresponce
        hashed_pw = bcrypt.hashpw(model.password.encode('utf-8'), bcrypt.gensalt())
        new_user = User(user_name = model.user_name, 
                        email = model.email, 
                        password = hashed_pw, 
                        token = uuid.uuid4().hex,
                        created_at = datetime.now())
        print(new_user)
        session.add(new_user)
        session.commit()
        apiresponce.setResponse({"user_id": new_user.id})
        session.close()
        apiresponce.setMsg("success")
        #apiresponce.setResponse({"user_id": new_user.id})
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.post("/login_user", tags=['User'])
async def login_user(request: Request, model: user_cred):
    apiresponce = APIResponse(request)
    try:
        session = db.get_session()
        user = session.query(User).filter(User.user_name == model.user_name).first()
        if user:
            model.password = model.password.encode('utf-8')
            hashed_pw = user.password.encode('utf-8')
            check_pw = bcrypt.checkpw(model.password, hashed_pw)
            if check_pw:
                apiresponce.setMsg("success")
                apiresponce.setResponse({"user_id": user.id, "user_name": user.user_name, "user_role": user.user_role, "token": user.token})
            else:
                apiresponce.setMsg("failed")
                apiresponce.setResponse("Invalid Password")
                #raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
        else:
            apiresponce.setMsg("failed")
            apiresponce.setResponse("Invalid Username")
            #raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
        session.close()
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.delete("/delete_user", tags=['User'])
async def delete_user(request: Request, user_id: str):
    apiresponce = APIResponse(request)
    try:
        session = db.get_session()
        user = session.query(User).filter(User.id == user_id, User.is_active == 1).all()
        if user and len(user) > 0:
            if user[0].user_role == "admin" or user[0].user_role == "super_admin":
                apiresponce.setMsg("failed")
                apiresponce.setResponse("OOPS! This user cannot be deleted.")
            else:
                user[0].is_active = 0
                session.add(user[0])
                session.commit()
                apiresponce.setMsg("success")
                apiresponce.setResponse("User deleted successfully")
        else:            
            apiresponce.setMsg("failed")
            apiresponce.setResponse("User not found")
        session.close()
    except Exception as ex:
        logger.exception(ex)
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/get_user_watchlist", tags=['Watchlist'])
async def get_user_watchlist(user_id : str, country_id: int, request: Request):
    apiresponce = APIResponse(request)
    try:
        user_id = int(user_id)
        session = db.get_session()
        user = session.query(User).filter(User.id == user_id).first()
        if not user:
            apiresponce.setMsg("failed")
            apiresponce.setResponse("User not found")
            return apiresponce
        session.expire_all()
        if country_id == 3:
            watchlist_data = (
                session.query(
                    Watchlist.id.label('watchlist_id'),
                    Us_StockMaster.id.label("st_master_id"),
                    Us_StockMaster.stock_tick,
                    Us_StockMaster.y_finance.label("stock_y_finance"),
                )
                .join(Watchlist, Watchlist.us_stock_id == Us_StockMaster.id)
                .filter(Watchlist.user_id == user_id, Us_StockMaster.is_active == 1)
                .all()
            )
            watchlist = [
            {   
                "watchlist_id" : w.watchlist_id,
                "stock_id" : w.st_master_id,
                "stock_tick": w.stock_tick,
                "stock_y_finance": w.stock_y_finance,
            }
            for w in watchlist_data]
        else:
            watchlist_data = (
                session.query(
                    Watchlist.id.label('watchlist_id'),
                    Ind_StockMaster.id.label("st_master_id"),
                    Ind_StockMaster.stock_tick,
                    Ind_StockMaster.y_finance.label("stock_y_finance"),
                )
                .join(Watchlist, Watchlist.ind_stock_id == Ind_StockMaster.id)
                .filter(Watchlist.user_id == user_id, Ind_StockMaster.is_active == 1)
                .all()
            )
            watchlist = [
            {   
                "watchlist_id" : w.watchlist_id,
                "stock_id" : w.st_master_id,
                "stock_tick": w.stock_tick,
                "stock_y_finance": w.stock_y_finance,
            }
            for w in watchlist_data]
        # print(watchlist_data)
        
        apiresponce.setMsg("success")
        apiresponce.setResponse({
            "user_id": user.id,
            "user_name": user.user_name,
            "user_role": user.user_role,
            "watchlist": watchlist
        })
        session.close()
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.post("/add_to_watchlist", tags=["Watchlist"])
def add_to_watchlist(data: WatchlistCreate, request: Request):
    apiresponce = APIResponse(request)
    try:
        session = db.get_session()
        user = session.query(User).filter(User.id == data.user_id).first()
        if data.country == 3:
            stock = session.query(Us_StockMaster).filter(Us_StockMaster.id == data.stock_id, Us_StockMaster.is_active == 1).first()
            existing = session.query(Watchlist).filter_by(user_id=data.user_id, us_stock_id=data.stock_id, country_id=data.country).first()
        else:
            stock = session.query(Ind_StockMaster).filter(Ind_StockMaster.id == data.stock_id, Ind_StockMaster.is_active == 1).first()
            existing = session.query(Watchlist).filter_by(user_id=data.user_id, ind_stock_id=data.stock_id, country_id=data.country).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        if not stock:
            raise HTTPException(status_code=404, detail="Stock not found or inactive")
        
        if existing:
            apiresponce.setMsg("failed")
            apiresponce.setResponse("Stock already in watchlist")
            return apiresponce
        if data.country == 3:
            watchlist_entry = Watchlist(user_id=data.user_id, us_stock_id=data.stock_id, country_id=data.country)
        else:
            watchlist_entry = Watchlist(user_id=data.user_id, ind_stock_id=data.stock_id, country_id=data.country)
        session.add(watchlist_entry)
        session.commit()
        apiresponce.setMsg("success")
        apiresponce.setResponse(f"Stock (ID {data.stock_id}) added to user {data.user_id}'s watchlist")
        session.close()
    
    except IntegrityError:
        session.rollback()
        apiresponce.setMsg("failed")
        apiresponce.setResponse("Duplicate entry or integrity error")

    except Exception as ex:
        session.rollback()
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.delete("/watchlist/{watchlist_id}")
def delete_watchlist_item(watchlist_id: int, request: Request):
    apiresponce = APIResponse(request)
    try:
        session = db.get_session()
        watchlist_item = session.query(Watchlist).filter(Watchlist.id == watchlist_id).first()
        if not watchlist_item:
            raise HTTPException(status_code=404, detail="Watchlist item not found")
        session.delete(watchlist_item)
        session.commit()
        apiresponce.setMsg("success")
        apiresponce.setResponse({"message": "Watchlist item deleted successfully"})
    except Exception as ex:
        session.rollback()
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce

