from fastapi import APIRouter, Request
from shared.db.req_model import OrderBase, GetOrder
from shared.db.db_model import Order, Commodity_Order, Future_Order
from shared.db.api_responce import APIResponse
from shared.db.dbconn import DBConnection
from apps.finprod_backend.modules.order_update import check_entry_hit, evaluate_order_status #calculate_and_update, calculate_entry_hit
from apps.finprod_backend.modules.dynamic_target_handler import DYNAMIC_TARGET
from apps.finprod_backend.modules.dynamic_entry_handler import DYNAMIC_ENTRY
from sqlalchemy import text
from typing import Optional
import logging
import json
from shared.config.settings import Config as cfg
from datetime import datetime, timedelta
from apps.finprod_backend.modules.cal_s import Calculate_setup_execute
from concurrent.futures import ThreadPoolExecutor, as_completed
import ast, re
from apps.finprod_backend.modules.order_update import evaluate_order_status
from data_fetchers.fyers.get_stock_prices import StockPriceFetcher


db = DBConnection()
spf = StockPriceFetcher()

def clean_order_status(order_status_str: str):
    # Replace Timestamp('...') with just '...'
    cleaned = re.sub(r"Timestamp\('(.*?)'\)", r"'\1'", order_status_str)
    return ast.literal_eval(cleaned)

def safe_parse_order_status(order_status):
    if not isinstance(order_status, str):
        return order_status  # Already a dict

    if order_status.strip().startswith("{"):
        try:
            # Clean Timestamp if present
            order_status = re.sub(r"Timestamp\('(.*?)'\)", r"'\1'", order_status)
            return ast.literal_eval(order_status)
        except Exception as e:
            logging.error(f"Failed to eval order_status: {order_status} — {e}")
            return {"status": "unknown", "error": str(e)}
    else:
        # It's a simple status string like 'PENDING'
        return {"status": order_status.strip().lower()}



logger = logging.getLogger()

router = APIRouter()

@router.post("/create_order", tags=['Order'])
async def create_order(request: Request, order: OrderBase):
    apiresponce = APIResponse(request)
    try:
        db_order = Order(
                country_id=order.country_id,
                stock_id=order.stock_id,
                stock_tick=order.stock_tick,
                time_frame=order.time_frame,
                order_type=order.order_type,
                entry_price=order.entry_price,
                stoploss_price=order.stoploss_price,
                target_price=order.target_price,
                stock_quantity=order.stock_quantity,
                purchased_cmp_date=order.purchased_cmp_date,
                arima_ab_model_prediction = order.prediction,
                arima_ab_model_prob = order.probability,
                purchased_on=datetime.now(),
                trade_signal_id = order.trade_id)
        
        session = db.get_session()
        session.add(db_order)
        session.commit()
        session.refresh(db_order)
        apiresponce.setMsg("success")
        apiresponce.setResponse({"order_id": db_order.order_id})
        session.close()
    except Exception as ex:
        session.rollback()
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.post("/get_order_count", tags=['Order'])
async def get_order_count(req_model: GetOrder, request: Request):
    apiresponce = APIResponse(request)
    try:
        print(req_model.__dict__)
        if req_model.stock_tick == None or req_model.stock_tick == 'null' or req_model.stock_tick == '':
            req_model.stock_tick = ''
        req_model.stock_tick = '%' + req_model.stock_tick + '%'
        
        if req_model.time_frame == None or req_model.time_frame == 'null' or req_model.time_frame == '':
            req_model.time_frame = '%%'
        
        if req_model.order_type.lower() == "all":
            order_types = ("buy", "sell", "Buy", "Sell", "BUY", "SELL")
        else:
            order_types = (req_model.order_type.lower(), req_model.order_type.upper(), req_model.order_type.capitalize())
        
        if req_model.prediction_type == None or req_model.prediction_type == 'null' or req_model.prediction_type == '':
            req_model.prediction_type = '%%'
        
        res = {"success": 0, "failed": 0, "pending": 0, "in_progress": 0}
        for status in res.keys():
            if status != 'pending' and status != 'in_progress':
                res[status] = len(db.raw_query(text(f"""select * from order_master 
                                            where country_id = {req_model.country_id} 
                                            and stock_tick like '{req_model.stock_tick}' 
                                            and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                            and order_status like '%{status}%'
                                            and time_frame like '{req_model.time_frame}'
                                            and order_type in {order_types}
                                            and arima_ab_model_prediction like '{req_model.prediction_type}'
                                            order by entry_timestamp desc;""")))
            elif status == 'pending':
                res[status] = len(db.raw_query(text(f"""select * from order_master 
                                            where country_id = {req_model.country_id} 
                                            and stock_tick like '{req_model.stock_tick}' 
                                            and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                            and order_status is null
                                            and time_frame like '{req_model.time_frame}'
                                            and order_type in {order_types}
                                            and arima_ab_model_prediction like '{req_model.prediction_type}'
                                            order by purchased_cmp_date desc;""")))
            elif status == 'in_progress':
                res[status] = len(db.raw_query(text(f"""select * from order_master 
                                            where country_id = {req_model.country_id} 
                                            and stock_tick like '{req_model.stock_tick}' 
                                            and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                            and order_status like '%pending%'
                                            and time_frame like '{req_model.time_frame}'
                                            and order_type in {order_types}
                                            and arima_ab_model_prediction like '{req_model.prediction_type}'
                                            order by entry_timestamp desc;""")))
                
        print(res)
        apiresponce.setMsg("success")
        apiresponce.setResponse(res)
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.post("/get_order_list", tags=['Order'])
async def get_order_list_new(req_model: GetOrder, request: Request):
    apiresponce = APIResponse(request)
    try:
        # if req_model.stock_tick == None or req_model.stock_tick == 'null' or req_model.stock_tick == '':
        #     req_model.stock_tick = ''
        # req_model.stock_tick = '%' + req_model.stock_tick + '%'
        try:
            req_model.page_no = int(req_model.page_no)
        except Exception as er:
            print("page_no:", req_model.page_no)
            req_model.page_no = None
        
        try:
            req_model.trade_id = int(req_model.trade_id)
        except Exception as er:
            req_model.trade_id = None

        if req_model.time_frame == None or req_model.time_frame == 'null' or req_model.time_frame == '':
            req_model.time_frame = '%%'
        
        if req_model.order_by_purchased_cmp_date:
            order_by = "purchased_cmp_date desc"
        else:
            order_by = "stock_tick asc"
        
        if req_model.order_type.lower() == "all":
            order_types = ("buy", "sell", "Buy", "Sell", "BUY", "SELL")
        else:
            order_types = (req_model.order_type.lower(), req_model.order_type.upper(), req_model.order_type.capitalize())

        if req_model.prediction_type == None or req_model.prediction_type == 'null' or req_model.prediction_type == '':
            req_model.prediction_type = '%%'

        res = []


        if (req_model.trade_id != None and req_model.trade_id != 'null' and req_model.trade_id != ''): 
            if req_model.status != 'pending' and req_model.status != 'progress':
                total_res = db.raw_query(text(f"""select * from order_master 
                                    where country_id = {req_model.country_id} 
                                    and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                    and order_status like '%{req_model.status}%'
                                    and time_frame like '{req_model.time_frame}' 
                                    and order_type in {order_types}
                                    and arima_ab_model_prediction like '{req_model.prediction_type}'
                                    order by {order_by};"""))
            elif req_model.status == 'pending':
                total_res = db.raw_query(text(f"""select * from order_master 
                                    where country_id = {req_model.country_id} 
                                    and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                    and order_status is null
                                    and time_frame like '{req_model.time_frame}'
                                    and order_type in {order_types}
                                    and arima_ab_model_prediction like '{req_model.prediction_type}'
                                    order by {order_by};"""))
            elif req_model.status == 'progress':
                total_res = db.raw_query(text(f"""select * from order_master 
                                    where country_id = {req_model.country_id} 
                                    and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                    and order_status like '%pending%'
                                    and time_frame like '{req_model.time_frame}'
                                    and order_type in {order_types}
                                    and arima_ab_model_prediction like '{req_model.prediction_type}'
                                    order by {order_by};"""))
            #print("total_res:", total_res)
            found = False
            for i in range(len(total_res)):
                if req_model.trade_id == total_res[i]['trade_signal_id']:
                    found = i+1
                    break
            print("found:", found)
            if found:
                req_model.page_no = ((found - 1) // req_model.limit) + 1
                offset = (req_model.page_no - 1) * req_model.limit
                #print("page_no:", req_model.page_no)
                #print("offset:", offset)
                res = total_res[offset : offset + req_model.limit]
                # if req_model.status != 'pending' and req_model.status != 'progress':
                #     res = db.raw_query(text(f"""select * from order_master 
                #                                     where country_id = {req_model.country_id} 
                #                                     and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                #                                     and order_status like '%{req_model.status}%' 
                #                                     and time_frame like '{req_model.time_frame}'
                #                                     and order_type in {order_types}
                #                                     order by {order_by}
                #                                     limit {req_model.limit} offset {offset};"""))
                # elif req_model.status == 'pending':
                #     res = db.raw_query(text(f"""select * from order_master 
                #                                     where country_id = {req_model.country_id} 
                #                                     and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                #                                     and order_status is null
                #                                     and time_frame like '{req_model.time_frame}'
                #                                     and order_type in {order_types}
                #                                     order by {order_by}
                #                                     limit {req_model.limit} offset {offset};"""))
                # elif req_model.status == 'progress':
                #     res = db.raw_query(text(f"""select * from order_master 
                #                                     where country_id = {req_model.country_id} 
                #                                     and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                #                                     and order_status like '%pending%'
                #                                     and time_frame like '{req_model.time_frame}'
                #                                     and order_type in {order_types}
                #                                     order by {order_by}
                #                                     limit {req_model.limit} offset {offset};"""))
                #print("res", res)
            else:
                pass

        elif (req_model.stock_tick == None or req_model.stock_tick == 'null' or req_model.stock_tick == '') and (req_model.page_no == None or req_model.page_no == 'null' or req_model.page_no == ''):
            req_model.page_no = 1
            offset = (req_model.page_no - 1) * req_model.limit
            if req_model.status != 'pending' and req_model.status != 'progress':
                res = db.raw_query(text(f"""select * from order_master 
                                                where country_id = {req_model.country_id} 
                                                and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and order_status like '%{req_model.status}%'
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types} 
                                                and arima_ab_model_prediction like '{req_model.prediction_type}'
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
            elif req_model.status == 'pending':
                res = db.raw_query(text(f"""select * from order_master 
                                                where country_id = {req_model.country_id} 
                                                and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and order_status is null
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                and arima_ab_model_prediction like '{req_model.prediction_type}'
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
            elif req_model.status == 'progress':
                res = db.raw_query(text(f"""select * from order_master 
                                                where country_id = {req_model.country_id} 
                                                and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and order_status like '%pending%'
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                and arima_ab_model_prediction like '{req_model.prediction_type}'
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
                   
        elif (req_model.stock_tick == None or req_model.stock_tick == 'null' or req_model.stock_tick == '') and (req_model.page_no != None and req_model.page_no != 'null' and req_model.page_no != ''):
            offset = (req_model.page_no - 1) * req_model.limit
            if req_model.status != 'pending' and req_model.status != 'progress':
                res = db.raw_query(text(f"""select * from order_master 
                                                where country_id = {req_model.country_id} 
                                                and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and order_status like '%{req_model.status}%' 
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                and arima_ab_model_prediction like '{req_model.prediction_type}'
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
            elif req_model.status == 'pending':
                res = db.raw_query(text(f"""select * from order_master 
                                                where country_id = {req_model.country_id} 
                                                and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and order_status is null 
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                and arima_ab_model_prediction like '{req_model.prediction_type}'
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
            elif req_model.status == 'progress':
                res = db.raw_query(text(f"""select * from order_master 
                                                where country_id = {req_model.country_id} 
                                                and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and order_status like '%pending%'
                                                and time_frame like '{req_model.time_frame}' 
                                                and order_type in {order_types}
                                                and arima_ab_model_prediction like '{req_model.prediction_type}'
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
        
        elif (req_model.stock_tick != None and req_model.stock_tick != 'null' and req_model.stock_tick != '') and (req_model.page_no == None or req_model.page_no == 'null' or req_model.page_no == ''):            
            if req_model.status != 'pending' and req_model.status != 'progress':
                total_res = db.raw_query(text(f"""select * from order_master 
                                    where country_id = {req_model.country_id} 
                                    and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                    and order_status like '%{req_model.status}%'
                                    and time_frame like '{req_model.time_frame}' 
                                    and order_type in {order_types}
                                    and arima_ab_model_prediction like '{req_model.prediction_type}'
                                    order by {order_by};"""))
            elif req_model.status == 'pending':
                total_res = db.raw_query(text(f"""select * from order_master 
                                    where country_id = {req_model.country_id} 
                                    and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                    and order_status is null
                                    and time_frame like '{req_model.time_frame}'
                                    and order_type in {order_types}
                                    and arima_ab_model_prediction like '{req_model.prediction_type}'
                                    order by {order_by};"""))
            elif req_model.status == 'progress':
                total_res = db.raw_query(text(f"""select * from order_master 
                                    where country_id = {req_model.country_id} 
                                    and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                    and order_status like '%pending%'
                                    and time_frame like '{req_model.time_frame}'
                                    and order_type in {order_types}
                                    and arima_ab_model_prediction like '{req_model.prediction_type}'
                                    order by {order_by};"""))
            found = False
            for i in range(len(total_res)):
                if req_model.stock_tick.lower() in total_res[i]['stock_tick'].lower():
                    found = i+1
                    break
            #print("found:", found)
            if found:
                req_model.page_no = ((found - 1) // req_model.limit) + 1
                offset = (req_model.page_no - 1) * req_model.limit
                #print("offset:", offset)
                res = total_res[offset : offset + req_model.limit]
                # if req_model.status != 'pending' and req_model.status != 'progress':
                #     res = db.raw_query(text(f"""select * from order_master 
                #                                     where country_id = {req_model.country_id} 
                #                                     and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                #                                     and order_status like '%{req_model.status}%' 
                #                                     and time_frame like '{req_model.time_frame}'
                #                                     and order_type in {order_types}
                #                                     order by {order_by}
                #                                     limit {req_model.limit} offset {offset};"""))
                # elif req_model.status == 'pending':
                #     res = db.raw_query(text(f"""select * from order_master 
                #                                     where country_id = {req_model.country_id} 
                #                                     and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                #                                     and order_status is null
                #                                     and time_frame like '{req_model.time_frame}'
                #                                     and order_type in {order_types}
                #                                     order by {order_by}
                #                                     limit {req_model.limit} offset {offset};"""))
                # elif req_model.status == 'progress':
                #     res = db.raw_query(text(f"""select * from order_master 
                #                                     where country_id = {req_model.country_id} 
                #                                     and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                #                                     and order_status like '%pending%'
                #                                     and time_frame like '{req_model.time_frame}'
                #                                     and order_type in {order_types}
                #                                     order by {order_by}
                #                                     limit {req_model.limit} offset {offset};"""))
            else:
                pass
        
        elif (req_model.stock_tick != None and req_model.stock_tick != 'null' and req_model.stock_tick != '') and (req_model.page_no != None and req_model.page_no != 'null' and req_model.page_no != ''):
            offset = (req_model.page_no - 1) * req_model.limit
            if req_model.status != 'pending' and req_model.status != 'progress':
                res = db.raw_query(text(f"""select * from order_master 
                                                where country_id = {req_model.country_id} 
                                                and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and order_status like '%{req_model.status}%' 
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                and arima_ab_model_prediction like '{req_model.prediction_type}'
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
            elif req_model.status == 'pending':
                res = db.raw_query(text(f"""select * from order_master 
                                                where country_id = {req_model.country_id} 
                                                and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and order_status is null 
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                and arima_ab_model_prediction like '{req_model.prediction_type}'
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
            elif req_model.status == 'progress':
                res = db.raw_query(text(f"""select * from order_master 
                                                where country_id = {req_model.country_id} 
                                                and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and order_status like '%pending%' 
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                and arima_ab_model_prediction like '{req_model.prediction_type}'
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
        if res != None:
            for order in res:
                try:                
                    if order['order_status'] == None:
                        order['order_status'] = 'pending'
                    else:
                        # order['order_status'] = clean_order_status(order['order_status'])
                        # print(order['order_status'], type(order['order_status']))
                        # order['order_status'] = ast.literal_eval(order['order_status'].replace("'", '"')) #.
                        order['order_status'] = safe_parse_order_status(order['order_status'])
                        # order['order_status'] = json.loads(order['order_status'])
                        status = order['order_status']
                    
                        if order['order_status']['status'] == 'success':                                            
                            order['order_status'] = 'success'
                            order['reason'] = status.get('reason', None)
                            order['profit_amount'] = status.get('profit_amount', None)
                        
                        elif order['order_status']['status'] == 'failed':                    
                            order['order_status'] = 'failed'
                            order['reason'] = status.get('reason', None)
                            order['loss_amount'] = status.get('loss_amount', None)
                        
                        elif order['order_status']['status'] == 'pending':                    
                            order['order_status'] = 'executed'
                            order['difference'] = status.get('current_difference', None)
                            order['percentage_change'] = status.get('current_pct_change', None)

                            # purchases_on = datetime.strptime(order['purchased_on'], "%Y-%m-%dT%H:%M:%S.%f")
                            # order['evaluated_order_status'] = evaluate_order_status(
                            #     stock_name = order['stock_tick'],
                            #     entry_price = order['entry_price'],
                            #     created_on = datetime.strftime(purchases_on, "%Y-%m-%dT%H:%M"),
                            #     stop_loss = order['stoploss_price'],
                            #     target_price = order['target_price'],
                            #     quantity = order['stock_quantity'],
                            #     order_type = order['order_type'].capitalize(),
                            #     time_frame = order['time_frame']
                            # )
                            # order['evaluated_order_status']['entry_hit'] = str(order['evaluated_order_status']['entry_hit'])
                            # print(order['evaluated_order_status'])

                            if req_model.country_id == 1:
                                stock_row = db.raw_query(text(f"""select * from ind_stock_master where id = '{order["stock_id"]}' and is_active = 1 and fyers_symbol is not null;"""))
                                if stock_row and len(stock_row) > 0:
                                    latest_price = spf.fyers_data.get_latest_price(stock_row[0]['fyers_symbol'])
                                    if latest_price:
                                        profit_loss_amount = (latest_price['ltp'] - order['entry_price']) * order['stock_quantity']
                                        # print("stock", order['stock_tick'])
                                        # print("entry_price:", order['entry_price'])
                                        # print("latest_price:", latest_price['ltp'])
                                        # print("profit_loss_amount:", profit_loss_amount)
                                        if (profit_loss_amount >= 0) and (order['order_type'] in ('buy', 'BUY', 'Buy')):
                                            order['current_status'] = {
                                                "latest_price": latest_price['ltp'],
                                                "status": "profit",
                                                "amount": profit_loss_amount
                                            }
                                        elif (profit_loss_amount < 0) and (order['order_type'] in ('buy', 'BUY', 'Buy')):
                                            order['current_status'] = {
                                                "latest_price": latest_price['ltp'],
                                                "status": "loss",
                                                "amount": profit_loss_amount
                                            }
                                        elif (profit_loss_amount < 0) and (order['order_type'] in ('sell', 'SELL', 'Sell')):
                                            order['current_status'] = {
                                                "latest_price": latest_price['ltp'],
                                                "status": "profit",
                                                "amount": abs(profit_loss_amount)
                                            }
                                        elif (profit_loss_amount >= 0) and (order['order_type'] in ('sell', 'SELL', 'Sell')):
                                            order['current_status'] = {
                                                "latest_price": latest_price['ltp'],
                                                "status": "loss",
                                                "amount": -profit_loss_amount
                                            }
                                        # print("current_status:", order['current_status'])

                except Exception as err:
                    logger.exception(err)
                    print(order['order_status'])
                    order['order_status'] = None 
        
        apiresponce.setMsg("success")
        apiresponce.setResponse({"orders": res, "page_no": req_model.page_no})
    except Exception as ex:
        logger.exception(ex)
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.post("/get_auto_order_count", tags=['Order'])
async def get_auto_order_count(req_model: GetOrder, request: Request):
    apiresponce = APIResponse(request)
    try:
        if req_model.stock_tick == None or req_model.stock_tick == 'null' or req_model.stock_tick == '':
            req_model.stock_tick = ''
        req_model.stock_tick = '%' + req_model.stock_tick + '%'
        
        if req_model.time_frame == None or req_model.time_frame == 'null' or req_model.time_frame == '':
            req_model.time_frame = '%%'
        
        if req_model.order_type.lower() == "all":
            order_types = ("buy", "sell", "Buy", "Sell", "BUY", "SELL")
        else:
            order_types = (req_model.order_type.lower(), req_model.order_type.upper(), req_model.order_type.capitalize())
        
        if req_model.prediction_type == None or req_model.prediction_type == 'null' or req_model.prediction_type == '':
            prediction_type = " "
        else:
            prediction_type = f"and arima_ab_model_prediction like '%{req_model.prediction_type}%'"

        res = {"success": 0, "failed": 0, "pending": 0, "in_progress": 0}
        for status in res.keys():
            if status != 'pending' and status != 'in_progress':
                res[status] = len(db.raw_query(text(f"""select * from auto_order_master 
                                            where country_id = {req_model.country_id} 
                                            and stock_tick like '{req_model.stock_tick}' 
                                            and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                            and order_status like '%{status}%'
                                            and time_frame like '{req_model.time_frame}'
                                            and order_type in {order_types} 
                                            {prediction_type}
                                            order by entry_timestamp desc;""")))
            elif status == 'pending':
                res[status] = len(db.raw_query(text(f"""select * from auto_order_master 
                                            where country_id = {req_model.country_id} 
                                            and stock_tick like '{req_model.stock_tick}' 
                                            and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                            and order_status is null 
                                            and time_frame like '{req_model.time_frame}'
                                            and order_type in {order_types}
                                            {prediction_type}
                                            order by purchased_cmp_date desc;""")))
            elif status == 'in_progress':
                res[status] = len(db.raw_query(text(f"""select * from auto_order_master 
                                            where country_id = {req_model.country_id} 
                                            and stock_tick like '{req_model.stock_tick}' 
                                            and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                            and order_status like '%pending%' 
                                            and time_frame like '{req_model.time_frame}'
                                            and order_type in {order_types}
                                            {prediction_type}
                                            order by entry_timestamp desc;""")))
                
        print(res)
        apiresponce.setMsg("success")
        apiresponce.setResponse(res)
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.post("/get_auto_order_list", tags=['Order'])
async def get_auto_order_list_new(req_model: GetOrder, request: Request):
    apiresponce = APIResponse(request)
    try:
        # if req_model.stock_tick == None or req_model.stock_tick == 'null' or req_model.stock_tick == '':
        #     req_model.stock_tick = ''
        # req_model.stock_tick = '%' + req_model.stock_tick + '%'
        try:
            req_model.page_no = int(req_model.page_no)
        except Exception as er:
            print("page_no:", req_model.page_no)
            req_model.page_no = None
        
        if req_model.time_frame == None or req_model.time_frame == 'null' or req_model.time_frame == '':
            req_model.time_frame = '%%'

        if req_model.order_by_purchased_cmp_date:
            order_by = "purchased_cmp_date desc"
        else:
            order_by = "stock_tick asc"
        
        if req_model.order_type.lower() == "all":
            order_types = ("buy", "sell", "Buy", "Sell", "BUY", "SELL")
        else:
            order_types = (req_model.order_type.lower(), req_model.order_type.upper(), req_model.order_type.capitalize())
        
        if req_model.prediction_type == None or req_model.prediction_type == 'null' or req_model.prediction_type == '':
            prediction_type = " "
        else:
            prediction_type = f"and arima_ab_model_prediction like '%{req_model.prediction_type}%'"
        
        res = []
        if (req_model.stock_tick == None or req_model.stock_tick == 'null' or req_model.stock_tick == '') and (req_model.page_no == None or req_model.page_no == 'null' or req_model.page_no == ''):
            req_model.page_no = 1
            offset = (req_model.page_no - 1) * req_model.limit
            if req_model.status != 'pending' and req_model.status != 'progress':
                res = db.raw_query(text(f"""select * from auto_order_master 
                                                where country_id = {req_model.country_id} 
                                                and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and order_status like '%{req_model.status}%' 
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                {prediction_type}
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
            elif req_model.status == 'pending':
                res = db.raw_query(text(f"""select * from auto_order_master 
                                                where country_id = {req_model.country_id} 
                                                and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and order_status is null
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                {prediction_type}
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
            elif req_model.status == 'progress':
                res = db.raw_query(text(f"""select * from auto_order_master 
                                                where country_id = {req_model.country_id} 
                                                and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and order_status like '%pending%'
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                {prediction_type}
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
                   
        elif (req_model.stock_tick == None or req_model.stock_tick == 'null' or req_model.stock_tick == '') and (req_model.page_no != None and req_model.page_no != 'null' and req_model.page_no != ''):
            offset = (req_model.page_no - 1) * req_model.limit
            if req_model.status != 'pending' and req_model.status != 'progress':
                res = db.raw_query(text(f"""select * from auto_order_master 
                                                where country_id = {req_model.country_id} 
                                                and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and order_status like '%{req_model.status}%'
                                                and time_frame like '{req_model.time_frame}' 
                                                and order_type in {order_types}
                                                {prediction_type}
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
            elif req_model.status == 'pending':
                res = db.raw_query(text(f"""select * from auto_order_master 
                                                where country_id = {req_model.country_id} 
                                                and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and order_status is null 
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                {prediction_type}
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
            elif req_model.status == 'progress':
                res = db.raw_query(text(f"""select * from auto_order_master 
                                                where country_id = {req_model.country_id} 
                                                and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and order_status like '%pending%' 
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                {prediction_type}
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
        
        elif (req_model.stock_tick != None and req_model.stock_tick != 'null' and req_model.stock_tick != '') and (req_model.page_no == None or req_model.page_no == 'null' or req_model.page_no == ''):            
            if req_model.status != 'pending' and req_model.status != 'progress':
                total_res = db.raw_query(text(f"""select * from auto_order_master 
                                    where country_id = {req_model.country_id} 
                                    and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                    and order_status like '%{req_model.status}%'
                                    and time_frame like '{req_model.time_frame}' 
                                    and order_type in {order_types}
                                    {prediction_type}
                                    order by {order_by};"""))
            elif req_model.status == 'pending':
                total_res = db.raw_query(text(f"""select * from auto_order_master 
                                    where country_id = {req_model.country_id} 
                                    and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                    and order_status is null
                                    and time_frame like '{req_model.time_frame}'
                                    and order_type in {order_types}
                                    {prediction_type}
                                    order by {order_by};"""))
            elif req_model.status == 'progress':
                total_res = db.raw_query(text(f"""select * from auto_order_master 
                                    where country_id = {req_model.country_id} 
                                    and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                    and order_status like '%pending%'
                                    and time_frame like '{req_model.time_frame}'
                                    and order_type in {order_types}
                                    {prediction_type}
                                    order by {order_by};"""))
            found = False
            for i in range(len(total_res)):
                if req_model.stock_tick.lower() in total_res[i]['stock_tick'].lower():
                    found = i+1
                    break
            #print("found:", found)
            if found:
                req_model.page_no = ((found - 1) // req_model.limit) + 1
                offset = (req_model.page_no - 1) * req_model.limit
                #print("offset:", offset)
                res = total_res[offset : offset + req_model.limit]
                # if req_model.status != 'pending' and req_model.status != 'progress':
                #     res = db.raw_query(text(f"""select * from auto_order_master 
                #                                     where country_id = {req_model.country_id} 
                #                                     and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                #                                     and order_status like '%{req_model.status}%' 
                #                                     and time_frame like '{req_model.time_frame}'
                #                                     order by {order_by}
                #                                     limit {req_model.limit} offset {offset};"""))
                # elif req_model.status == 'pending':
                #     res = db.raw_query(text(f"""select * from auto_order_master 
                #                                     where country_id = {req_model.country_id} 
                #                                     and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                #                                     and order_status is null
                #                                     and time_frame like '{req_model.time_frame}'
                #                                     order by {order_by}
                #                                     limit {req_model.limit} offset {offset};"""))
                # elif req_model.status == 'progress':
                #     res = db.raw_query(text(f"""select * from auto_order_master 
                #                                     where country_id = {req_model.country_id} 
                #                                     and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                #                                     and order_status like '%pending%'
                #                                     and time_frame like '{req_model.time_frame}'
                #                                     order by {order_by}
                #                                     limit {req_model.limit} offset {offset};"""))
            else:
                pass
        
        elif (req_model.stock_tick != None and req_model.stock_tick != 'null' and req_model.stock_tick != '') and (req_model.page_no != None and req_model.page_no != 'null' and req_model.page_no != ''):
            offset = (req_model.page_no - 1) * req_model.limit
            if req_model.status != 'pending' and req_model.status != 'progress':
                res = db.raw_query(text(f"""select * from auto_order_master 
                                                where country_id = {req_model.country_id} 
                                                and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and order_status like '%{req_model.status}%' 
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                {prediction_type}
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
            elif req_model.status == 'pending':
                res = db.raw_query(text(f"""select * from auto_order_master 
                                                where country_id = {req_model.country_id} 
                                                and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and order_status is null 
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                {prediction_type}
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
            elif req_model.status == 'progress':
                res = db.raw_query(text(f"""select * from auto_order_master 
                                                where country_id = {req_model.country_id} 
                                                and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and order_status like '%pending%'
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                {prediction_type}
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
        
        print(len(res))
        if res != None:
            for order in res:  
                try:              
                    if order['order_status'] == None:
                        order['order_status'] = 'pending'
                    else:
                        # order['order_status'] = clean_order_status(order['order_status']) #.replace("'", '"')
                        #order['order_status'] = json.loads(order['order_status'])
                        # order['order_status'] = ast.literal_eval(order['order_status'])
                        order['order_status'] = safe_parse_order_status(order['order_status'])
                        status = order['order_status']
                    
                        if order['order_status']['status'] == 'success':                                            
                            order['order_status'] = 'success'
                            order['reason'] = status.get('reason', None)
                            order['profit_amount'] = status.get('profit_amount', None)
                        
                        elif order['order_status']['status'] == 'failed':                    
                            order['order_status'] = 'failed'
                            order['reason'] = status.get('reason', None)
                            order['loss_amount'] = status.get('loss_amount', None)
                        
                        elif order['order_status']['status'] == 'pending':                    
                            order['order_status'] = 'executed'
                            order['difference'] = status.get('difference', None)
                            order['percentage_change'] = status.get('percentage_change', None)

                            if req_model.country_id == 1:
                                    stock_row = db.raw_query(text(f"""select * from ind_stock_master where id = '{order["stock_id"]}' and is_active = 1 and fyers_symbol is not null;"""))
                                    if stock_row and len(stock_row) > 0:
                                        latest_price = spf.fyers_data.get_latest_price(stock_row[0]['fyers_symbol'])
                                        if latest_price:
                                            profit_loss_amount = (latest_price['ltp'] - order['entry_price']) * order['stock_quantity']
                                            if profit_loss_amount >= 0:
                                                order['current_status'] = {
                                                    "latest_price": latest_price['ltp'],
                                                    "status": "profit",
                                                    "amount": profit_loss_amount
                                                }
                                            else:
                                                order['current_status'] = {
                                                    "latest_price": latest_price['ltp'],
                                                    "status": "loss",
                                                    "amount": profit_loss_amount
                                                }

                except Exception as err:
                    logger.exception(err)
                    print(order['order_status'])
                    order['order_status'] = None 
        
        apiresponce.setMsg("success")
        apiresponce.setResponse({"orders": res, "page_no": req_model.page_no})
    except Exception as ex:
        #print("order status -----", order['order_status'])
        #print(order['order_id'])
        logger.exception(ex)
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/get_order_list", tags=['Order'])
async def get_order_list(country_id: int, request: Request):
    apiresponce = APIResponse(request)
    try:
        # new_list = []
        res = db.raw_query(text(f"select * from order_master where country_id={country_id} order by purchased_cmp_date desc;"))
        apiresponce.setMsg("success")
        apiresponce.setResponse(res)
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce

@router.get("/get_auto_order_list", tags=['Order'])
async def get_auto_order_list(country_id: int, request: Request):
    apiresponce = APIResponse(request)
    try:
        res = db.raw_query(text(f"select * from auto_order_master where country_id={country_id} LIMIT 50;"))
        apiresponce.setMsg("success")
        apiresponce.setResponse(res)
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce

@router.get("/delete_order", tags=['Order'])
async def delete_order(request: Request, id : int):
    apiresponce = APIResponse(request)
    try:
        rc = db.raw_connection()
        rc.execute(text(f"delete from order_master where order_id={id}"))
        rc.commit()
        rc.close()
        apiresponce.setMsg("success")
        # apiresponce.setResponse()
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce

@router.get("/update_order_entry_stats", tags=['Order'])
async def update_order_entry_stats(request: Request):
    apiresponce = APIResponse(request)
    try:
        ords = db.raw_query(text("select * from order_master where is_trade_started=0"))
        for orders in ords:
            order_id = orders.get('order_id')
            stock_tick = orders.get('stock_tick')
            buy_price = orders.get('entry_price')
            time_frame = orders.get('time_frame')
            purchased_on = orders.get('purchased_cmp_date')
            # print(purchased_on, type(purchased_on))
            try:
                stat, entry_timestamp = check_entry_hit(stock_tick, buy_price, purchased_on, time_frame)
            except Exception as ex:
                logger.exception(ex, stack_info=True, exc_info=1)
                stat = False
            # print(entry_timestamp, type(entry_timestamp))
            if stat:
                # entry_timestamp = datetime.strptime(entry_timestamp, "%d/%m/%Y %H:%M:%S")
                up_query = f"""update order_master set is_trade_started=1, entry_timestamp='{entry_timestamp}' where order_id={order_id}"""
                rc = db.raw_connection()
                rc.execute(text(up_query))
                rc.commit()
                rc.close()
        apiresponce.setMsg("success")
        apiresponce.setResponse("Trade Entries Updated Successfully")
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/update_auto_order_entry_stats", tags=['Order'])
async def update_auto_order_entry_stats(request: Request):
    apiresponce = APIResponse(request)
    try:
        rc = db.raw_connection()
        table_name = 'auto_order_master' # auto_order_master unique_india_order_master
        ords = db.raw_query(text(f"select * from {table_name} where is_trade_started=0;"))
        for orders in ords:
            order_id = orders.get('order_id')
            stock_tick = orders.get('stock_tick')
            buy_price = orders.get('entry_price')
            purchased_on = orders.get('purchased_cmp_date')
            time_frame = orders.get('time_frame')
            # print(purchased_on, type(purchased_on))
            is_started, entry_ts = check_entry_hit(stock_tick, buy_price, purchased_on, time_frame)
            # stat, entry_timestamp = calculate_entry_hit(stock_tick, buy_price, purchased_on, time_frame)
            # print(entry_timestamp, type(entry_timestamp))
            if is_started and entry_ts:
                update_sql = text(f"""
                    UPDATE {table_name}
                    SET is_trade_started = 1, entry_timestamp = :entry_ts
                    WHERE order_id = :order_id
                """)
                rc.execute(update_sql, {"entry_ts": entry_ts.strftime("%Y-%m-%dT%H:%M:%S"), "order_id": order_id})
                rc.commit() 
            print(is_started, entry_ts)
        rc.close()
        apiresponce.setMsg("success")
        apiresponce.setResponse("Auto Trade Entries Updated Successfully")
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/update_order_status", tags=['Order'])
async def update_order_status(request: Request):
    apiresponce = APIResponse(request)
    try:
        ords = db.raw_query(text("select * from order_master where is_evaluated=0 and is_trade_started=1")) # order_master
        for orders in ords:
            order_id = orders.get('order_id')
            stock_tick = orders.get('stock_tick')
            buy_price = orders.get('entry_price')
            stop_loss = orders.get('stoploss_price')
            target_price = orders.get('target_price')
            stock_quantity = orders.get('stock_quantity')
            time_frame = orders.get('time_frame')
            # purchased_on = orders.get('purchased_cmp_date')
            entry_timestamp = orders.get('entry_timestamp')
            ord_type = orders.get('order_type')

            try:
                entry_dt = datetime.fromisoformat(entry_timestamp)
            except Exception:
                entry_dt = datetime.strptime(entry_timestamp, "%Y-%m-%d %H:%M:%S")

            result = evaluate_order_status(
                stock_name=stock_tick,
                entry_price=buy_price,
                created_on=entry_dt.strftime("%Y-%m-%dT%H:%M"),
                stop_loss=stop_loss,
                target_price=target_price,
                quantity=stock_quantity,
                order_type=ord_type,
                time_frame=time_frame
            )
            update_sql = f"""
                UPDATE order_master
                SET order_status = :order_status,
                    is_evaluated = :is_eval,
                    completed_on = :completed_on
                WHERE order_id = :order_id
            """
            exec_result = result.copy()
            exec_result.pop('completed_on', None)
            rc = db.raw_connection()
            rc.execute(
                text(update_sql),
                {
                    "order_status": str(exec_result),
                    "is_eval": 1 if result.get("status") in ["success", "failed"] else 0,
                    "completed_on": result.get("completed_on").strftime("%Y-%m-%d %H:%M:%S") if result.get("completed_on") else None,
                    "order_id": order_id
                }
            )
            # date_object = datetime.strptime(entry_timestamp, "%Y-%m-%dT%H:%M:%S.%f") #"%Y-%m-%dT%H:%M"
            # cal_res, stat, completed_on = calculate_and_update(stock_tick, buy_price, date_object, stop_loss, target_price, stock_quantity, ord_type, time_frame)
            # if completed_on != None:
                # up_query = f"""update order_master set order_status="{cal_res}", is_evaluated={int(stat)}, completed_on="{completed_on}" where order_id={order_id};"""
            # else:
                # up_query = f"""update order_master set order_status="{cal_res}", is_evaluated={int(stat)} where order_id={order_id};"""
            # print(up_query)
            # rc.execute(text(up_query))
            rc.commit()
            rc.close()
            # print(cal_res)
        apiresponce.setMsg("success")
        apiresponce.setResponse("Orders Updated Successfully")
    except Exception as ex:
        logger.error(ex, stack_info=True, exc_info=1)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/update_auto_order_status", tags=['Order'])
async def update_auto_order_status(request: Request):
    apiresponce = APIResponse(request)
    # try:
    table_name = 'auto_order_master' #  unique_india_order_master
    ords = db.raw_query(text(f"select * from {table_name} where is_evaluated=0 and is_trade_started=1"))
    for orders in ords:
        order_id = orders.get('order_id')
        stock_tick = orders.get('stock_tick')
        buy_price = orders.get('entry_price')
        stop_loss = orders.get('stoploss_price')
        target_price = orders.get('target_price')
        stock_quantity = orders.get('stock_quantity')
        time_frame = orders.get('time_frame')
        # purchased_on = orders.get('purchased_cmp_date')
        entry_timestamp = orders.get('entry_timestamp')
        ord_type = orders.get('order_type')
        try:
            entry_dt = datetime.fromisoformat(entry_timestamp)
        except Exception:
            entry_dt = datetime.strptime(entry_timestamp, "%Y-%m-%d %H:%M:%S")

        result = evaluate_order_status(
                stock_name=stock_tick,
                entry_price=buy_price,
                created_on=entry_dt.strftime("%Y-%m-%dT%H:%M"),
                stop_loss=stop_loss,
                target_price=target_price,
                quantity=stock_quantity,
                order_type=ord_type,
                time_frame=time_frame
            )
        update_sql = f"""
                UPDATE {table_name}
                SET order_status = :order_status,
                    is_evaluated = :is_eval,
                    completed_on = :completed_on
                WHERE order_id = :order_id
            """
        rc = db.raw_connection()
        rc.execute(
                text(update_sql),
                {
                    "order_status": str(result),
                    "is_eval": 1 if result.get("status") in ["success", "failed"] else 0,
                    "completed_on": result.get("completed_on").strftime("%Y-%m-%d %H:%M:%S") if result.get("completed_on") else None,
                    "order_id": order_id
                }
            )
        # date_object = datetime.strptime(entry_timestamp, "%Y-%m-%dT%H:%M:%S.%f") #"%Y-%m-%dT%H:%M"
        # print(order_id, date_object)
        # cal_res, stat, completed_on = calculate_and_update(stock_tick, buy_price, date_object, stop_loss, target_price, stock_quantity, ord_type, time_frame)
        # if completed_on != None:
        #     up_query = f"""update {table_name} set order_status="{cal_res}", is_evaluated={int(stat)}, completed_on="{completed_on}" where order_id={order_id};"""
        # else:
        #     up_query = f"""update {table_name} set order_status="{cal_res}", is_evaluated={int(stat)} where order_id={order_id};"""
        # print(up_query)
        # rc = raw_connection()
        # rc.execute(text(up_query))
        rc.commit()
        rc.close()
        # print(cal_res)
    apiresponce.setMsg("success")
    apiresponce.setResponse("Auto Orders Updated Successfully")
    # except Exception as ex:
    #     logger.error(ex, stack_info=True)
    #     apiresponce.setMsg("failed")
    #     apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/get_filtered_orders", tags=['Order'])
async def get_filtered_orders(request: Request, country_id: int, tick: str, start_time: Optional[str] = None, end_time: Optional[str] = None):
    apiresponce = APIResponse(request)
    try:
        filtered_list = []
        now = datetime.now()
        start_dt = datetime.strptime(start_time, "%Y-%m-%d %H:%M:%S") if start_time else datetime(year=2020, month=4, day=1)
        end_dt = datetime.strptime(end_time, "%Y-%m-%d %H:%M:%S") if end_time else now
        if len(tick) == 0:
            res = db.raw_query(text(f"select * from order_master where country_id={country_id};"))
        else:
            res = db.raw_query(text(f"select * from order_master where stock_tick='{tick}' and country_id={country_id};"))
        for orders in res:
            try:
                order_dt = datetime.strptime(orders.get('purchased_cmp_date'), "%Y-%m-%dT%H:%M")
                if start_dt <= order_dt <= end_dt:
                    filtered_list.append(orders)
            except:
                pass
        apiresponce.setMsg("success")
        apiresponce.setResponse(filtered_list)
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/adjust_order_target", tags=['Order'])
async def adjust_order_target(request: Request):
    apiresponce = APIResponse(request)
    try:
        res = db.raw_query(text("select * from auto_order_master where is_trade_started=1 and is_evaluated=0"))
        for items in res:
            try:
                print(items.get('order_id'))
                DYNAMIC_TARGET(items.get('order_id'))
            except Exception as ex:
                pass
        apiresponce.setMsg("success")
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/get_filtered_auto_orders", tags=['Order'])
async def get_filtered_orders(request: Request, country_id: int, tick: str, start_time: Optional[str] = None, end_time: Optional[str] = None):
    apiresponce = APIResponse(request)
    try:
        filtered_list = []
        now = datetime.now()
        start_dt = datetime.strptime(start_time, "%Y-%m-%d %H:%M:%S") if start_time else datetime(year=2020, month=4, day=1)
        end_dt = datetime.strptime(end_time, "%Y-%m-%d %H:%M:%S") if end_time else now
        if len(tick) == 0:
            res = db.raw_query(text("select * from auto_order_master"))
        else:
            res = db.raw_query(text(f"select * from auto_order_master where stock_tick='{tick}' and country_id={country_id};"))
        for orders in res:
            order_dt = datetime.strptime(orders.get('purchased_cmp_date'), "%Y-%m-%dT%H:%M")
            if start_dt <= order_dt <= end_dt:
                filtered_list.append(orders)
        apiresponce.setMsg("success")
        apiresponce.setResponse(filtered_list)
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce

@router.get("/adjust_order_entry")
async def adjust_order_entry(request: Request):
    apiresponce = APIResponse(request)
    try:
        res = db.raw_query(text("select * from auto_order_master where is_trade_started=0"))
        for ords in res:
            DYNAMIC_ENTRY(ords.get('order_id'))
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/add_order_to_bucket")
async def add_order_to_bucket(order_id: int, request: Request):
    apiresponce = APIResponse(request)
    try:
        rc = db.raw_connection()
        query = f"insert into unique_order_master values (select * from auto_order_master where order_id={order_id})"
        rc.execute(text(query))
        rc.commit()
        rc.close()
        apiresponce.setMsg("success")
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/delete_order_from_auto")
async def delete_order_from_auto(order_id: int, request: Request):
    apiresponce = APIResponse(request)
    try:
        rc = db.raw_connection()
        query = f"delete from auto_order_master where order_id={order_id};"
        rc.execute(text(query))
        rc.commit()
        rc.close()
        apiresponce.setMsg("success")
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/get_order_status_from_trade_id", tags=['Order'])
async def get_order_status_from_trade_id(request: Request, trade_id: int, exchange: str):
    apiresponce = APIResponse(request)
    try:
        status = None
        session = db.get_session()
        if exchange == "NSE":
            row = session.query(Order).filter(Order.trade_signal_id == trade_id).first()
        elif exchange == "MCX":
            row = session.query(Commodity_Order).filter(Commodity_Order.trade_signal_id == trade_id).first()
        elif exchange == "NSEFO":
            row = session.query(Future_Order).filter(Future_Order.trade_signal_id == trade_id).first()
        else:
            row = None
        if row:
            order_status = safe_parse_order_status(row.order_status)
            #print(order_status)
            if order_status == None:
                status = "Pending"
            elif order_status.get("status") == "pending":
                status = "Progress"
            else:
                status = order_status.get("status")
            if status:
                status = status.capitalize()
                apiresponce.setMsg("success")
                apiresponce.setResponse({"order_status": status})
            else:
                apiresponce.setMsg("failed")
                apiresponce.setResponse({"order_status": status})
        else:
            apiresponce.setMsg("failed")
            apiresponce.setResponse({"order_status": status})
        session.close()
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce