from fastapi import APIRouter, Request, WebSocket, WebSocketDisconnect
from shared.db.api_responce import APIResponse
from fastapi.responses import HTMLResponse
from apps.finprod_backend.scraper.realtime_update import get_latest_stock_price, update_ohlc, get_last_data_from_files
import asyncio
from datetime import datetime
from apps.finprod_backend.scraper.index_scraper import index_price, stock_price, stock_price_by_stock_index_map
from shared.db.dbconn import DBConnection
from sqlalchemy import text
from shared.db.db_model import Ind_StockMaster
from data_fetchers.fyers.fyers_ticker import FyersTickerManager
import threading
import logging
import time

logger = logging.getLogger()

router = APIRouter()
dbc = DBConnection()
fyers_ticker = FyersTickerManager()

# ohlc_data = {}

# @router.get("/test_websocket")
# async def get():
#     html_content = """
#     <!DOCTYPE html>
#     <html>
#     <head>
#         <title>Stock Price WebSocket</title>
#     </head>
#     <body>
#         <h1>Stock Price WebSocket</h1>
#         <label for="stock_id">Enter Stock Id:</label>
#         <input id="stock_id" type="text" />
#         <label for="time_frame">Enter Time Frame:</label>
#         <input id="time_frame" type="text" />
#         <button onclick="connect()">Connect</button>
#         <button onclick="disconnect()">Disconnect</button>
#         <h3>Stock Price: <span id="stock_price">N/A</span></h3>

#         <script>
#             let websocket;
#             function connect() {
#                 const stockId = document.getElementById("stock_id").value;
#                 const timeFrame = document.getElementById("time_frame").value;
#                 websocket = new WebSocket(`ws://103.13.113.132:2560/ws/${stockId}/${timeFrame}`);

#                 websocket.onmessage = function(event) {
#                     document.getElementById("stock_price").textContent = event.data;
#                 };

#                 websocket.onclose = function() {
#                     console.log("Disconnected from server");
#                 };
#             }

#             function disconnect() {
#                 if (websocket) {
#                     websocket.close();
#                 }
#             }
#         </script>
#     </body>
#     </html>
#     """
#     return HTMLResponse(content=html_content)


# @router.websocket("/ws/{stock_id}/{time_frame}")
# async def websocket_endpoint(websocket: WebSocket, stock_id: int, time_frame : int):
#     await websocket.accept()
#     try:

#         fyers_ticker = FyersTickerManager()
#         session = dbc.get_session()
#         stock = session.query(Ind_StockMaster).filter(Ind_StockMaster.id == stock_id, Ind_StockMaster.is_active == 1).first()
#         session.close()
#         #print(stock)
#         if stock:
#             fyers_ticker.subscribe([stock.fyers_symbol], fyers_ticker.fyers)
#             # res = get_last_data_from_files(stock[0].stock_tick, time_frame)
#             #print(res)
#             while True:
#                 #price = get_latest_stock_price(stock[0].fyers_symbol)
#                 price = await fyers_ticker.get_latest_stock_price(stock.fyers_symbol)
#                 #print(price)
#                 # t_stamp = datetime.strptime(datetime.now().today(), )
#                 if price is not None:
#                     candle_data = update_ohlc(stock.stock_tick, price, time_frame)
#                     candle_data['stock_tick'] = stock.stock_tick
#                     # await websocket.send_json(candle_data)
#                     await websocket.send_json(candle_data)
#                 else:
#                     await websocket.send_text("Error fetching stock price")
#                 await asyncio.sleep(5)  # Adjust the interval as needed
#         else:
#             await websocket.send_text("Error fetching stock price")
#             websocket.close()
#     except WebSocketDisconnect:
#         websocket.close()
#         print(f"Client disconnected: {stock.stock_tick}")
#     except Exception as e:
#         websocket.close()
#         print(f"Error: {e}")
#     finally:
#         fyers_ticker.unsubscribe(fyers_ticker.fyers)
#         websocket.close()


# @router.websocket("/ws/{stock_id}/{time_frame}")
# async def websocket_endpoint(websocket: WebSocket, stock_id: int, time_frame: int):
#     await websocket.accept()

#     session = dbc.get_session()
#     stock = session.query(Ind_StockMaster).filter(
#         Ind_StockMaster.id == stock_id,
#         Ind_StockMaster.is_active == 1
#     ).first()
#     session.close()

#     if not stock:
#         await websocket.send_text("Error: stock not found or inactive.")
#         return

#     stock_tick = stock.stock_tick
#     fyers_symbol = stock.fyers_symbol
#     time_fr = time_frame

#     fyers_ticker.subscribe([fyers_symbol], fyers_ticker.fyers)
#     try:
#         while True:
#             price = fyers_ticker.get_latest_stock_price(fyers_symbol)
#             if price is not None:
#                 candle_data = update_ohlc(stock_tick, price, time_frame)
#                 candle_data['stock_tick'] = stock_tick
#                 await websocket.send_json(candle_data)
#             else:
#                 await websocket.send_text("Error fetching stock price")
#             await asyncio.sleep(5)  # wait for 5 seconds before next fetch
#     except WebSocketDisconnect:
#         print(f"Client disconnected: {stock_tick}")
#         websocket.close()
#     except Exception as e:
#         print(f"WebSocket error: {e}")
#     finally:
#         fyers_ticker.unsubscribe(fyers_ticker.fyers)
#         websocket.close()


# @router.get("/get_index_price/{country_id}")
# async def get_index_price(country_id: str):
#     html_content = f"""
#     <!DOCTYPE html>
#     <html lang="en">
#     <head>
#         <meta charset="UTF-8">
#         <meta name="viewport" content="width=device-width, initial-scale=1.0">
#         <title>Live Index Prices</title>
#         <style>
#             body {{
#                 font-family: Arial, sans-serif;
#                 text-align: center;
#                 margin: 20px;
#             }}
#             table {{
#                 width: 60%;
#                 margin: auto;
#                 border-collapse: collapse;
#             }}
#             th, td {{
#                 border: 1px solid black;
#                 padding: 10px;
#                 text-align: center;
#             }}
#             th {{
#                 background-color: #4CAF50;
#                 color: white;
#             }}
#             .positive {{
#                 color: green;
#                 font-weight: bold;
#             }}
#             .negative {{
#                 color: red;
#                 font-weight: bold;
#             }}
#         </style>
#     </head>
#     <body>
#         <h2>Live Index Prices</h2>
#         <table>
#             <thead>
#                 <tr>
#                     <th>Index</th>
#                     <th>Price</th>
#                     <th>Day Change</th>
#                     <th>Change (%)</th>
#                     <th>Index ID</th>
#                 </tr>
#             </thead>
#             <tbody id="stock-data">
#                 <tr><td colspan="5">Waiting for data...</td></tr>
#             </tbody>
#         </table>

#         <script>
#             const country_id = "{country_id}";
#             const socket = new WebSocket(`ws://103.13.113.132:2560/index_price/{country_id}`);

#             socket.onopen = function(event) {{
#                 console.log("Connected to WebSocket...");
#             }};

#             socket.onmessage = function(event) {{
#                 let data = JSON.parse(event.data);
#                 let tableBody = document.getElementById("stock-data");
#                 tableBody.innerHTML = ""; // Clear previous data

#                 for (let stock in data) {{
#                     let stockInfo = data[stock];
#                     let changeClass = stockInfo.day_change.startsWith("+") ? "positive" : "negative";

#                     let row = `
#                         <tr>
#                             <td><strong>${{stock}}</strong></td>
#                             <td>${{stockInfo.price.toLocaleString()}}</td>
#                             <td class="${{changeClass}}">${{stockInfo.day_change}}</td>
#                             <td class="${{changeClass}}">${{stockInfo.day_change_percentage}}</td>
#                             <td class="${{changeClass}}">${{stockInfo.index_id}}</td>
#                         </tr>
#                     `;
#                     tableBody.innerHTML += row;
#                 }}
#             }};

#             socket.onerror = function(event) {{
#                 console.error("WebSocket Error:", event);
#             }};

#             socket.onclose = function(event) {{
#                 console.log("WebSocket Disconnected");
#             }};
#         </script>
#     </body>
#     </html>
#     """
#     return HTMLResponse(content=html_content)


# @router.websocket("/index_price/{country_id}")
# async def index_price_websocket(websocket: WebSocket, country_id: str):
#     await websocket.accept()
#     try:
#         while True:
#             res = index_price(country_id)
#             if res:
#                 await websocket.send_json(res)
#             else:
#                 await websocket.send_text("Error fetching index price")
#             await asyncio.sleep(5)
#     except WebSocketDisconnect:
#         print(f"Client disconnected !")
#     except Exception as e:
#         print(f"Error: {e}")



# @router.get("/get_stock_price")
# async def get_stock_price(index_id: str = ''):
#     html_content = f"""
#     <!DOCTYPE html>
#     <html lang="en">
#     <head>
#         <meta charset="UTF-8">
#         <meta name="viewport" content="width=device-width, initial-scale=1.0">
#         <title>Live Stock Prices</title>
#         <style>
#             body {{
#                 font-family: Arial, sans-serif;
#                 text-align: center;
#                 margin: 20px;
#             }}
#             table {{
#                 width: 60%;
#                 margin: auto;
#                 border-collapse: collapse;
#             }}
#             th, td {{
#                 border: 1px solid black;
#                 padding: 10px;
#                 text-align: center;
#             }}
#             th {{
#                 background-color: #4CAF50;
#                 color: white;
#             }}
#             .positive {{
#                 color: green;
#                 font-weight: bold;
#             }}
#             .negative {{
#                 color: red;
#                 font-weight: bold;
#             }}
#         </style>
#     </head>
#     <body>
#         <h2>Live Stock Prices</h2>
#         <table>
#             <thead>
#                 <tr>
#                     <th>Stock</th>
#                     <th>Price</th>
#                     <th>Day Change</th>
#                     <th>Change (%)</th>
#                     <th>Stock ID</th>
#                     <th>Currency</th>
#                 </tr>
#             </thead>
#             <tbody id="stock-data">
#                 <tr><td colspan="6">Waiting for data...</td></tr>
#             </tbody>
#         </table>

#         <script>
#             const index_id = "{index_id}";
#             const socket = new WebSocket(`ws://103.13.113.132:2560/stock_price?index_id={index_id}`);

#             socket.onopen = function(event) {{
#                 console.log("Connected to WebSocket...");
#             }};

#             socket.onmessage = function(event) {{
#                 let data = JSON.parse(event.data);
#                 let tableBody = document.getElementById("stock-data");
#                 tableBody.innerHTML = ""; // Clear previous data

#                 for (let stock in data) {{
#                     let stockInfo = data[stock];
#                     let changeClass = stockInfo.day_change.startsWith("+") ? "positive" : "negative";

#                     let row = `
#                         <tr>
#                             <td><strong>${{stock}}</strong></td>
#                             <td>${{stockInfo.price.toLocaleString()}}</td>
#                             <td class="${{changeClass}}">${{stockInfo.day_change}}</td>
#                             <td class="${{changeClass}}">${{stockInfo.day_change_percentage}}</td>
#                             <td class="${{changeClass}}">${{stockInfo.stock_id}}</td>
#                             <td class="${{changeClass}}">${{stockInfo.currency}}</td>
#                         </tr>
#                     `;
#                     tableBody.innerHTML += row;
#                 }}
#             }};

#             socket.onerror = function(event) {{
#                 console.error("WebSocket Error:", event);
#             }};

#             socket.onclose = function(event) {{
#                 console.log("WebSocket Disconnected");
#             }};
#         </script>
#     </body>
#     </html>
#     """
#     return HTMLResponse(content=html_content)


# @router.websocket("/stock_price")
# async def stock_price_websocket(websocket: WebSocket, index_id: str = ''):
#     await websocket.accept()
#     try:
#         while True:
#             res = stock_price(index_id)
#             if res:
#                 await websocket.send_json(res)
#             else:
#                 await websocket.send_text("Error fetching stock price")
#             await asyncio.sleep(5)
#     except WebSocketDisconnect:
#         print(f"Client disconnected !")
#     except Exception as e:
#         print(f"Error: {e}")


@router.get("/get/country/list")
async def get_country_list(request: Request):
    try:
        apiresponce = APIResponse(request)
        
        res = dbc.raw_query(text(f"select * from county_master where status = 1;"))
        apiresponce.setMsg("success")
        apiresponce.setResponse(res)
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce

@router.get("/get/index")
async def get_index(request: Request, index_id: str = None):
    try:
        apiresponce = APIResponse(request)
        if index_id == None or index_id == "all" or index_id == "ALL" or index_id == "All" or index_id == "null":
            res = dbc.raw_query(text(f"select * from index_master where is_active = 1;"))
        else:
            res = dbc.raw_query(text(f"select * from index_master where is_active = 1 and index_id = '{index_id}';"))
        apiresponce.setMsg("success")
        apiresponce.setResponse(res)
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


# @router.get("/get_stock_price_by_stock_index_map")
# async def get_stock_price_by_stock_index_map(index_id: str = '', page_id: int = 1, limit: int = 10, country: str = 'India'):
#     html_content = f"""
#     <!DOCTYPE html>
#     <html lang="en">
#     <head>
#         <meta charset="UTF-8">
#         <meta name="viewport" content="width=device-width, initial-scale=1.0">
#         <title>Live Stock Prices</title>
#         <style>
#             body {{
#                 font-family: Arial, sans-serif;
#                 text-align: center;
#                 margin: 20px;
#             }}
#             table {{
#                 width: 60%;
#                 margin: auto;
#                 border-collapse: collapse;
#             }}
#             th, td {{
#                 border: 1px solid black;
#                 padding: 10px;
#                 text-align: center;
#             }}
#             th {{
#                 background-color: #4CAF50;
#                 color: white;
#             }}
#             .positive {{
#                 color: green;
#                 font-weight: bold;
#             }}
#             .negative {{
#                 color: red;
#                 font-weight: bold;
#             }}
#         </style>
#     </head>
#     <body>
#         <h2>Live Stock Prices</h2>
#         <table>
#             <thead>
#                 <tr>
#                     <td colspan="6" id="total-count" style="font-weight:bold; text-align:center;">Total Count : Loading...</td>
#                 </tr>
#                 <tr>
#                     <th>Stock</th>
#                     <th>Price</th>
#                     <th>Day Change</th>
#                     <th>Change (%)</th>
#                     <th>Stock ID</th>
#                     <th>Currency</th>
#                 </tr>
#             </thead>
#             <tbody id="stock-data">
#                 <tr><td colspan="6">Waiting for data...</td></tr>
#             </tbody>
#         </table>

#         <script>
#             const index_id = "{index_id}";
#             const page_id = {page_id};
#             const limit = {limit};
#             const country = "{country}";
#             const socket = new WebSocket(`ws://103.13.113.132:2560/stock_price_by_stock_index_map?index_id={index_id}&page_id={page_id}&limit={limit}&country={country}`);

#             socket.onopen = function(event) {{
#                 console.log("Connected to WebSocket...");
#             }};

#             socket.onmessage = function(event) {{
#                 let data = JSON.parse(event.data);
#                 let tableBody = document.getElementById("stock-data");
#                 tableBody.innerHTML = ""; // Clear previous data

#                 document.getElementById("total-count").innerHTML = `Total Count: ${{data["total_count"]}}`;

#                 for (let stock in data["price_response"]) {{
#                     let stockInfo = data["price_response"][stock];
#                     let changeClass = stockInfo.day_change.startsWith("+") ? "positive" : "negative";

#                     let row = `
#                         <tr>
#                             <td><strong>${{stock}}</strong></td>
#                             <td>${{stockInfo.price.toLocaleString()}}</td>
#                             <td class="${{changeClass}}">${{stockInfo.day_change}}</td>
#                             <td class="${{changeClass}}">${{stockInfo.day_change_percentage}}</td>
#                             <td class="${{changeClass}}">${{stockInfo.stock_id}}</td>
#                             <td class="${{changeClass}}">${{stockInfo.currency}}</td>
#                         </tr>
#                     `;
#                     tableBody.innerHTML += row;
#                 }}
#             }};

#             socket.onerror = function(event) {{
#                 console.error("WebSocket Error:", event);
#             }};

#             socket.onclose = function(event) {{
#                 console.log("WebSocket Disconnected");
#             }};
#         </script>
#     </body>
#     </html>
#     """
#     return HTMLResponse(content=html_content)


# @router.websocket("/stock_price_by_stock_index_map")
# async def stock_price_by_stock_index_map_websocket(websocket: WebSocket, index_id: str = '', page_id: int = 1, limit: int = 10, country: str = 'India'):
#     await websocket.accept()
#     try:
#         while True:
#             res = stock_price_by_stock_index_map(index_id, page_id, limit, country)
#             # print(res)
#             if res:
#                 await websocket.send_json(res)
#             else:
#                 await websocket.send_text("Error fetching stock price")
#             await asyncio.sleep(5)
#     except WebSocketDisconnect:
#         print(f"Client disconnected !")
#     except Exception as e:
#         print(f"Error: {e}")