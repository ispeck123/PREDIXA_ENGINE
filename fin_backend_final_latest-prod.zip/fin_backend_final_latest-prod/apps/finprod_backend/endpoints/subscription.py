from fastapi import APIRouter, Request, HTTPException, status
from shared.db.api_responce import APIResponse
from shared.db.dbconn import DBConnection
from shared.db.req_model import UserSubscriptionRequest, UserCountryAccessRequest
from shared.db.db_model import SubscriptionPlan, UserSubscription, User, UserCountryAccess, CountryMaster
from datetime import datetime
from sqlalchemy.orm import joinedload

import logging

logger = logging.getLogger()
db = DBConnection()
router = APIRouter()


@router.get("/get_all_subscriptions", tags=['Subscription'])
async def create_user(request: Request):
    apiresponce = APIResponse(request)
    try:
        session = db.get_session()
        res = session.query(SubscriptionPlan).filter(SubscriptionPlan.is_active == True).all()
        session.close()
        apiresponce.setMsg("success")
        apiresponce.setResponse(res)
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/get_all_users_subscriptions", tags=['Subscription'])
async def get_all_users_subscriptions(request: Request):
    apiresponce = APIResponse(request)
    try:
        session = db.get_session()
        # res = session.query(UserSubscription).filter(UserSubscription.is_active == True).all()
        results = session.query(
            UserSubscription.subscription_id,
            UserSubscription.user_id,
            User.user_name,
            UserSubscription.plan_id,
            SubscriptionPlan.plan_name,
            UserSubscription.start_date,
            UserSubscription.end_date,
            UserSubscription.is_active,
            UserSubscription.created_at
        ).join(
            SubscriptionPlan, UserSubscription.plan_id == SubscriptionPlan.plan_id
        ).join(
            User, UserSubscription.user_id == User.id
        ).all()
        session.close()
        data = [
            {
                "subscription_id": r.subscription_id,
                "user_id": r.user_id,
                "user_name": r.user_name,
                "plan_id": r.plan_id,
                "plan_name": r.plan_name,
                "start_date": r.start_date,
                "end_date": r.end_date,
                "is_active": r.is_active,
                "created_at": r.created_at
            }
            for r in results
        ]
        apiresponce.setMsg("success")
        apiresponce.setResponse(data)
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.post("/user-create_user_subscription", tags=['Subscription'])
async def create_user_subscription(request: Request, model: UserSubscriptionRequest):
    apiresponce = APIResponse(request)
    try:
        session = db.get_session()
        chk_subscription = session.query(UserSubscription).filter(UserSubscription.user_id == model.user_id).first()
        if chk_subscription:
            return HTTPException(status_code=404, detail="Subscription already exists")
        user = session.query(User).filter(User.id == model.user_id).first()
        if not user:
            return HTTPException(status_code=404, detail="User not found")
        plan = session.query(SubscriptionPlan).filter(SubscriptionPlan.plan_id == model.plan_id).first()
        if not plan:
            return HTTPException(status_code=404, detail="Subscription plan not found")
        
        new_subscription = UserSubscription(
                                user_id=model.user_id,
                                plan_id=model.plan_id,
                                start_date=model.start_date,
                                end_date=model.end_date,
                                is_active=True,
                                created_at=datetime.utcnow())
        session.add(new_subscription)
        session.commit()
        session.refresh(new_subscription)
        session.close()
        apiresponce.setMsg("success")
        apiresponce.setResponse({"message": "User subscription created successfully", "subscription_id": new_subscription.subscription_id})
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce

@router.get("/check-subscription", tags=['Subscription'])
async def check_active_subscription(user_id: int, request: Request):
    apiresponce = APIResponse(request)
    try:
        session = db.get_session()
        user = session.query(User).filter(User.id == user_id).first()
        if not user:
            return HTTPException(status_code=404, detail="User not found")
        result = session.query(UserSubscription.subscription_id,
                                     UserSubscription.user_id,
                                     UserSubscription.plan_id,
                                     UserSubscription.start_date,
                                     UserSubscription.end_date,
                                     UserSubscription.created_at,
                                     SubscriptionPlan.plan_name).join(
                                        SubscriptionPlan, 
                                        UserSubscription.plan_id == SubscriptionPlan.plan_id).filter(
                                            UserSubscription.user_id == user_id,
                                            UserSubscription.is_active == True,
                                            SubscriptionPlan.is_active == True).order_by(
                                                UserSubscription.created_at.desc()).all()
        
        if not result:
            return HTTPException(status_code=404, detail="No active subscription found")
        
        data =  [
                    {
                        "subscription_id": subscription.subscription_id,
                        "user_id": subscription.user_id,
                        "plan_id": subscription.plan_id,
                        "plan_name": subscription.plan_name,
                        "start_date": subscription.start_date,
                        "end_date": subscription.end_date,
                        "created_at": subscription.created_at
                    }
                    for subscription in result
                ]
        
        apiresponce.setMsg("success")
        apiresponce.setResponse(data)
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce



@router.post("/user_grant_country_access",  tags=['Subscription'])
async def grant_country_access(request: Request, model: UserCountryAccessRequest):
    apiresponce = APIResponse(request)
    try:
        session = db.get_session()
        user = session.query(User).filter(User.id == model.user_id).first()
        if not user:
            return HTTPException(status_code=404, detail="User not found")

        valid_countries = session.query(CountryMaster.country_id).filter(
                                CountryMaster.country_id.in_(model.country_ids),
                                CountryMaster.status == 1  # use 1 instead of True for TINYINT fields
                            ).all()
        valid_country_ids = [c.country_id for c in valid_countries]
        #print(valid_country_ids)     
        # if not valid_country_ids:
        #     return HTTPException(status_code=404, detail="No valid country IDs found")
        new_entries = []
        existing_entries = session.query(UserCountryAccess).filter(UserCountryAccess.user_id == model.user_id).all()
        for entry in existing_entries:
            if entry.country_id not in valid_country_ids:
                session.delete(entry)
                session.commit()
        existing_entries = session.query(UserCountryAccess).filter(UserCountryAccess.user_id == model.user_id).all()
        for cid in valid_country_ids:
            existing_entry = session.query(UserCountryAccess).filter(UserCountryAccess.user_id == model.user_id, 
                                                                     UserCountryAccess.country_id == cid).all()
            if existing_entry != None and len(existing_entry) == 0:
                new_entries.append(UserCountryAccess(
                    user_id=model.user_id,
                    country_id=cid,
                    granted_by=model.granted_by,
                    granted_at=datetime.utcnow()
                ))
        session.bulk_save_objects(new_entries)
        session.commit()
        session.close()
        apiresponce.setMsg("success")
        apiresponce.setResponse({"message": "Access granted successfully", "countries_granted": valid_country_ids})
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce



@router.get("/user-country-access", tags=['Subscription'])
def get_user_country_access(user_id: int, request: Request):
    apiresponce = APIResponse(request)
    try:
        session = db.get_session()
        user = session.query(User).filter(User.id == user_id).first()
        if not user:
            return HTTPException(status_code=404, detail="User not found")
        # Fetch country access records for this user
        country_ids = session.query(UserCountryAccess.country_id).filter(
            UserCountryAccess.user_id == user_id
        ).distinct()
        
        countries = session.query(CountryMaster).filter(
            CountryMaster.country_id.in_(country_ids),
            CountryMaster.status == 1
        ).all()
        if countries:
            apiresponce.setMsg("success")
            apiresponce.setResponse(countries)
        else:
            apiresponce.setMsg("failed")
            apiresponce.setResponse({"message": "No access Countries Found"})
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce
    

@router.get("/update_user_subscription", tags=['Subscription'])
async def update_user_subscription(request: Request, subcription_id: int, is_active: bool):
    apiresponce = APIResponse(request)
    try:
        session = db.get_session()
        res = session.query(UserSubscription).filter(UserSubscription.subscription_id == subcription_id).all()
        if res is not None and len(res) > 0:
            res[0].is_active = is_active
            session.add(res[0])
            session.commit()
            apiresponce.setMsg("success")
            apiresponce.setResponse("Subscription updated successfully")
        else:
            apiresponce.setMsg("failed")
            apiresponce.setResponse("Subscription not found")
        session.close()
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce