from fastapi import APIRouter, Request
from shared.db.req_model import GetAlertNew, CustomAlertCreate, CustomAlertUpdate, CustomAlertGet
from shared.db.api_responce import APIResponse
# from datetime import datetime
from apps.finprod_backend.modules.alert_controller import ALERT_CONTROLLER
from apps.finprod_backend.modules.alert_notifier import ALERT_NOTIFIER
import logging
from shared.db.dbconn import DBConnection
from sqlalchemy import text, or_, and_
from shared.db.db_model import CustomAlert, UserAlert
import pytz
from datetime import datetime
from typing import Any

time_zone = pytz.timezone('Asia/Kolkata')

logger = logging.getLogger()

router = APIRouter()
db = DBConnection()

@router.get("/generate_latest_alerts", tags=['Alerts'])
async def generate_latest_alerts(request: Request):
    apiresponce = APIResponse(request)
    try:
        acl = ALERT_CONTROLLER()
        output = acl.calculate_all_stock_predictions()
        apiresponce.setMsg("success")
        apiresponce.setResponse(output)
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/fetch_tick_wise_alert", tags=['Alerts'])
async def fetch_tick_wise_alert(tick: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        acl = ALERT_CONTROLLER()
        output_ = acl.calculate_stock_setup(tick)
        acl.send_tick_wise_telegram_alert(tick, output_)
        apiresponce.setMsg("success")
        apiresponce.setResponse(output_)
    except Exception as ex:
        logger.exception(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/alert_notifier", tags=['Alerts'])
async def alert_notifier(request: Request):
    apiresponce = APIResponse(request)
    try:
        ALERT_NOTIFIER()
    except Exception as ex:
        logger.exception(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.post("/get_alerts", tags = ["Alerts"])
async def get_alerts(req_model: GetAlertNew, request: Request):
    apiresponce = APIResponse(request)
    try:
        print(req_model.__dict__)
        try:
            req_model.page_no = int(req_model.page_no)
        except Exception as er:
            print("page_no:", req_model.page_no)
            req_model.page_no = None
        total_count = []
        total_count = db.raw_query(text(f"""select * from user_alerts 
                                where country_id = {req_model.country_id} 
                                and user_id = {req_model.user_id} 
                                and is_active = 1
                                and date(created_at) between '{req_model.start_date}' and '{req_model.end_date}'
                                and is_sys = {int(req_model.is_system)}
                                order by created_at desc"""))
        if total_count == None:
            total_count = []
        
        if req_model.country_id == 1:
            join_table = "ind_stock_master"
            join_column = "kite_symbol"
        else:
            join_table = "us_stock_master"
            join_column = "y_finance"
            
        res = []
        if (req_model.stock_tick == None or req_model.stock_tick == 'null' or req_model.stock_tick == ''):
            
            if (req_model.page_no == None or req_model.page_no == 'null' or req_model.page_no == ''):
                req_model.page_no = 1
                #print("case 1")
            else:
                #print("case 2")
                pass
            
            offset = (req_model.page_no - 1) * req_model.limit
            res = db.raw_query(text(f"""select * from user_alerts as ua 
                                inner join {join_table} as sm on ua.stock_symbol = sm.{join_column}
                                where ua.country_id = {req_model.country_id} 
                                and ua.user_id = {req_model.user_id} 
                                and ua.is_active = 1
                                and date(ua.created_at) between '{req_model.start_date}' and '{req_model.end_date}'
                                and ua.is_sys = {int(req_model.is_system)}
                                and sm.is_active = 1
                                order by ua.created_at desc
                                limit {req_model.limit} offset {offset}"""))
        
        elif (req_model.stock_tick != None and req_model.stock_tick != 'null' and req_model.stock_tick != ''):

            if (req_model.page_no != None and req_model.page_no != 'null' and req_model.page_no != ''):
                #print("case 3")
                offset = (req_model.page_no - 1) * req_model.limit
                res = db.raw_query(text(f"""select * from user_alerts as ua
                                    inner join {join_table} as sm on ua.stock_symbol = sm.{join_column}
                                    where ua.country_id = {req_model.country_id} 
                                    and ua.user_id = {req_model.user_id} 
                                    and ua.is_active = 1
                                    and date(ua.created_at) between '{req_model.start_date}' and '{req_model.end_date}'
                                    and ua.is_sys = {int(req_model.is_system)}
                                    and sm.is_active = 1
                                    order by ua.created_at desc
                                    limit {req_model.limit} offset {offset}"""))
            else:
                #print("case 4")
                found = False
                for i in range(len(total_count)):
                    if req_model.stock_tick.lower() in total_count[i]['stock_symbol'].lower():
                        found = i+1
                        break
                #print("found:", found)
                if found:
                    req_model.page_no = ((found - 1) // req_model.limit) + 1
                    offset = (req_model.page_no - 1) * req_model.limit
                    #print("offset:", offset)
                    res = db.raw_query(text(f"""select * from user_alerts as ua
                                    inner join {join_table} as sm on ua.stock_symbol = sm.{join_column}
                                    where ua.country_id = {req_model.country_id} 
                                    and ua.user_id = {req_model.user_id} 
                                    and ua.is_active = 1
                                    and date(ua.created_at) between '{req_model.start_date}' and '{req_model.end_date}'
                                    and ua.is_sys = {int(req_model.is_system)}
                                    and sm.is_active = 1
                                    order by ua.created_at desc
                                    limit {req_model.limit} offset {offset}"""))
                    
                else:
                    pass

        apiresponce.setMsg("success")
        apiresponce.setResponse({"total_count": len(total_count), "alerts": res, "page_no": req_model.page_no})
    except Exception as ex:
        logger.exception(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce

@router.post("/generate_custom_alerts", tags = ["Alerts"])
async def generate_custom_alerts(request: Request, model: CustomAlertCreate):
    apiresponce = APIResponse(request)
    try:
        session = db.get_session()
        row = CustomAlert(
            user_id = model.user_id,
            country_id = model.country_id,
            exchange_id = model.exchange_id,
            stock_symbol = model.stock_symbol,
            threshold = model.threshold,
            condition = model.condition,
            message = model.message,
            created_at = datetime.now(tz=time_zone),
            is_active = True
        )
        session.add(row)
        session.commit()
        session.close()
        apiresponce.setMsg("success")
        apiresponce.setResponse({"custom_alert_id": row.id})
    except Exception as ex:
        logger.exception(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.post("/get_custom_alerts", tags = ["Alerts"])
async def get_custom_alerts(request: Request, model: CustomAlertGet):
    apiresponce = APIResponse(request)
    try:
        print(model.__dict__)
        try:
            model.page_no = int(model.page_no)
        except Exception as er:
            model.page_no = None
        
        if model.country_id == 1:
            join_table = "ind_stock_master"
            join_column = "kite_symbol"
        else:
            join_table = "us_stock_master"
            join_column = "y_finance"

        total_count = []
        total_count = db.raw_query(text(f"""select ca.id, ca.user_id, ca.country_id, ca.exchange_id, ca.stock_symbol,
                                ca.threshold, ca.condition, ca.message, ca.created_at, ca.updated_at, ca.is_active, sm.stock_tick 
                                from custom_alerts as ca
                                inner join {join_table} as sm on ca.stock_symbol = sm.{join_column}
                                where ca.country_id = {model.country_id} 
                                and ca.user_id = {model.user_id} 
                                and ca.is_active = 1
                                and date(ca.created_at) between '{model.start_date}' and '{model.end_date}'
                                and sm.is_active = 1
                                order by ca.created_at desc"""))
        
        if total_count == None:
            total_count = []
        
            
        res = []
        if (model.stock_symbol == None or model.stock_symbol == 'null' or model.stock_symbol == ''):
            
            if (model.page_no == None or model.page_no == 'null' or model.page_no == ''):
                model.page_no = 1
                #print("case 1")
            else:
                #print("case 2")
                pass
            
            offset = (model.page_no - 1) * model.limit
            res = db.raw_query(text(f"""select ca.id, ca.user_id, ca.country_id, ca.exchange_id, ca.stock_symbol,
                                ca.threshold, ca.condition, ca.message, ca.created_at, ca.updated_at, ca.is_active, sm.stock_tick 
                                from custom_alerts as ca
                                inner join {join_table} as sm on ca.stock_symbol = sm.{join_column}
                                where ca.country_id = {model.country_id} 
                                and ca.user_id = {model.user_id} 
                                and ca.is_active = 1
                                and date(ca.created_at) between '{model.start_date}' and '{model.end_date}'
                                and sm.is_active = 1
                                order by ca.created_at desc
                                limit {model.limit} offset {offset}"""))
        
        elif (model.stock_symbol != None and model.stock_symbol != 'null' and model.stock_symbol != ''):

            if (model.page_no != None and model.page_no != 'null' and model.page_no != ''):
                #print("case 3")
                offset = (model.page_no - 1) * model.limit
                res = db.raw_query(text(f"""select ca.id, ca.user_id, ca.country_id, ca.exchange_id, ca.stock_symbol,
                                ca.threshold, ca.condition, ca.message, ca.created_at, ca.updated_at, ca.is_active, sm.stock_tick 
                                from custom_alerts as ca
                                inner join {join_table} as sm on ca.stock_symbol = sm.{join_column}
                                where ca.country_id = {model.country_id} 
                                and ca.user_id = {model.user_id} 
                                and ca.is_active = 1
                                and date(ca.created_at) between '{model.start_date}' and '{model.end_date}'
                                and sm.is_active = 1
                                order by ca.created_at desc
                                limit {model.limit} offset {offset}"""))
            else:
                #print("case 4")
                found = False
                for i in range(len(total_count)):
                    if model.stock_symbol.lower() in total_count[i]['stock_symbol'].lower():
                        found = i+1
                        break
                #print("found:", found)
                if found:
                    model.page_no = ((found - 1) // model.limit) + 1
                    offset = (model.page_no - 1) * model.limit
                    #print("offset:", offset)
                    # res = db.raw_query(text(f"""select ca.id, ca.user_id, ca.country_id, ca.exchange_id, ca.stock_symbol,
                    #             ca.threshold, ca.condition, ca.message, ca.created_at, ca.updated_at, ca.is_active, sm.stock_tick 
                    #             from custom_alerts as ca
                    #             inner join {join_table} as sm on ca.stock_symbol = sm.{join_column}
                    #             where ca.country_id = {model.country_id} 
                    #             and ca.user_id = {model.user_id} 
                    #             and ca.is_active = 1
                    #             and date(ca.created_at) between '{model.start_date}' and '{model.end_date}'
                    #             and sm.is_active = 1
                    #             order by ca.created_at desc
                    #             limit {model.limit} offset {offset}"""))
                    res = total_count[offset : offset + model.limit]
                    
                else:
                    pass

        apiresponce.setMsg("success")
        apiresponce.setResponse({"total_count": len(total_count), "alerts": res, "page_no": model.page_no})
    except Exception as ex:
        logger.exception(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.delete("/delete_custom_alerts", tags = ["Alerts"])
async def delete_custom_alerts(request: Request, alert_id: int):
    apiresponce = APIResponse(request)
    try:
        session = db.get_session()
        rows = session.query(CustomAlert).filter(CustomAlert.id == alert_id, CustomAlert.is_active == 1).all()
        if len(rows) > 0:
            session.delete(rows[0])
            session.commit()        
            apiresponce.setMsg("success")
            apiresponce.setResponse("Alert deleted successfully")
        else:
            apiresponce.setMsg("failed")
            apiresponce.setResponse("Alert not found")
        session.close()
    except Exception as ex:
        logger.exception(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.post("/update_custom_alerts", tags = ["Alerts"])
async def update_custom_alerts(request: Request, model: CustomAlertUpdate):
    apiresponce = APIResponse(request)
    try:
        session = db.get_session()
        rows = session.query(CustomAlert).filter(CustomAlert.id == model.alert_id, CustomAlert.is_active == 1).all()
        if len(rows) > 0:
            rows[0].threshold = model.threshold if model.threshold not in ("null", "", None) else rows[0].threshold
            rows[0].condition = model.condition if model.condition not in ("null", "", None) else rows[0].condition
            rows[0].message = model.message if model.message not in ("null", "", None) else rows[0].message
            rows[0].updated_at = datetime.now(tz=time_zone)
            session.add(rows[0])
            session.commit()        
            apiresponce.setMsg("success")
            apiresponce.setResponse("Alert updated successfully")
        else:
            apiresponce.setMsg("failed")
            apiresponce.setResponse("Alert not found")
        session.close()
    except Exception as ex:
        logger.exception(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/get_custom_alerts_id", tags = ["Alerts"])
async def get_custom_alerts_id(request: Request, alert_id: int):
    apiresponce = APIResponse(request)
    try:
        session = db.get_session()
        rows = session.query(CustomAlert).filter(CustomAlert.id == alert_id, CustomAlert.is_active == 1).all()
        if len(rows) > 0:
            apiresponce.setMsg("success")
            apiresponce.setResponse({"data": rows})
        else:
            apiresponce.setMsg("failed")
            apiresponce.setResponse("Alert not found")
        session.close()
    except Exception as ex:
        logger.exception(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce

@router.get("/seen_custom_alerts", tags = ["Alerts"])
async def seen_custom_alerts(request: Request, alert_id: int):
    apiresponce = APIResponse(request)
    try:
        session = db.get_session()
        rows = session.query(CustomAlert).filter(CustomAlert.id == alert_id, CustomAlert.is_active == 1).all()
        if len(rows) > 0:
            rows[0].notification_seen = True
            rows[0].notification_seen_at = datetime.now(tz=time_zone)
            session.add(rows[0])
            session.commit()        
            apiresponce.setMsg("success")
            apiresponce.setResponse("Alert updated successfully")
        else:
            apiresponce.setMsg("failed")
            apiresponce.setResponse("Alert not found")
        session.close()
    except Exception as ex:
        logger.exception(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/get_custom_alerts_notifications", tags = ["Alerts"])
async def get_custom_alerts_notifications(request: Request, user_id: int, country_id: int):
    apiresponce = APIResponse(request)
    try:
        rows = db.raw_query(f"""select ca.id, ca.user_id, ca.country_id, ca.exchange_id, ca.stock_symbol, 
                            ca.threshold, ca.condition, ca.message, ca.created_at, ca.updated_at, ca.is_active, 
                            ca.notification_sent, ca.notification_sent_at, ca.notification_seen, 
                            ca.notification_seen_at, ism.stock_tick
                            from custom_alerts as ca 
                            inner join ind_stock_master as ism on ca.stock_symbol = ism.kite_symbol 
                            where ca.user_id = {user_id} and ca.country_id = {country_id} and ca.is_active = 1 
                            and ca.notification_sent = 1 and ca.notification_sent_at is not null  
                            and ism.is_active = 1 
                            order by ca.notification_sent_at desc limit 100""")
        if len(rows) > 0:
            apiresponce.setMsg("success")
            apiresponce.setResponse({"data": rows})
        else:
            apiresponce.setMsg("failed")
            apiresponce.setResponse("No Notification")
    except Exception as ex:
        logger.exception(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/get_order_alerts_notifications", tags = ["Alerts"])
async def get_order_alerts_notifications(request: Request, user_id: int, country_id: int):
    apiresponce = APIResponse(request)
    try:
        entry_notifications = db.raw_query(f"""select ua.id, ua.user_id, ua.country_id, ua.stock_symbol, ua.exchange, ua.alert_type, 
                                ua.timeframe, ua.entry_notification_sent, ua.entry_notification_sent_at, ua.entry_notification_seen, ua.entry_notification_seen_at, 
                                'entry_hit' as notification_type, ism.stock_tick, om.order_id, om.stock_id, om.entry_price, om.stoploss_price, om.target_price, om.trade_signal_id, 
                                ua.entry_notification_sent_at as notification_sent_at
                                from user_alerts as ua 
                                inner join ind_stock_master as ism on ua.stock_symbol = ism.kite_symbol 
                                inner join order_master as om on ua.trade_signal_id = om.trade_signal_id
                                where ua.entry_notification_sent = 1 and ua.entry_notification_sent_at is not null  
                                and ua.is_active = 1 and ism.is_active = 1 and ua.user_id = {user_id} and ua.country_id = {country_id}
                                order by ua.entry_notification_sent_at desc limit 100""")
        # for notification in entry_notifications:
        #     notification["notification_type"] = "entry_hit"
        #     notification["notification_sent_at"] = notification["entry_notification_sent_at"]
        
        stoploss_target_notifications = db.raw_query(f"""select ua.id, ua.user_id, ua.country_id, ua.stock_symbol, ua.exchange, ua.alert_type, 
                                ua.timeframe, ua.stoploss_target_notification_sent, ua.stoploss_target_notification_sent_at, ua.stoploss_target_notification_seen, ua.stoploss_target_notification_seen_at, 
                                ua.notification_type, ism.stock_tick, om.order_id, om.stock_id, om.entry_price, om.stoploss_price, om.target_price, om.trade_signal_id, 
                                ua.stoploss_target_notification_sent_at as notification_sent_at
                                from user_alerts as ua 
                                inner join ind_stock_master as ism on ua.stock_symbol = ism.kite_symbol 
                                inner join order_master as om on ua.trade_signal_id = om.trade_signal_id
                                where ua.stoploss_target_notification_sent = 1 and ua.stoploss_target_notification_sent_at is not null  
                                and ua.is_active = 1 and ism.is_active = 1 and ua.user_id = {user_id} and ua.country_id = {country_id}
                                order by ua.stoploss_target_notification_sent_at desc limit 100""")
        # for notification in stoploss_target_notifications:
        #     notification["notification_sent_at"] = notification["stoploss_target_notification_sent_at"]
        
        rows = entry_notifications + stoploss_target_notifications
        rows = sorted(rows, key = lambda t: t["notification_sent_at"], reverse = True)[0:100]
        
        if len(rows) > 0:
            apiresponce.setMsg("success")
            apiresponce.setResponse({"data": rows})
        else:
            apiresponce.setMsg("failed")
            apiresponce.setResponse("No Notification")
    except Exception as ex:
        logger.exception(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/seen_order_alerts", tags = ["Alerts"])
async def seen_order_alerts(request: Request, alert_id: Any, notification_type: str = None):
    apiresponce = APIResponse(request)
    try:
        session = db.get_session()
        if not isinstance(alert_id, int):            
            try:
                alert_id = int(alert_id)
            except:
                alert_id = alert_id.strip().lower()
        if alert_id == "all":
            rows = session.query(UserAlert).filter(UserAlert.is_active == True,
                                                   or_(
                                                       and_(
                                                           UserAlert.entry_notification_sent == True, 
                                                           UserAlert.entry_notification_seen == False
                                                           ),
                                                       and_(
                                                           UserAlert.stoploss_target_notification_sent == True, 
                                                           UserAlert.stoploss_target_notification_seen == False
                                                           )
                                                       )                                                   
                                                   ).all()
            if len(rows) > 0:
                for alert in rows:
                    if alert.entry_notification_sent == True and alert.entry_notification_seen == False:
                        print("entry", alert.id)
                        alert.entry_notification_seen = True
                        alert.entry_notification_seen_at = datetime.now(tz=time_zone)
                        session.add(alert)
                    if alert.stoploss_target_notification_sent == True and alert.stoploss_target_notification_seen == False:
                        print("target/stoploss", alert.id)
                        alert.stoploss_target_notification_seen = True
                        alert.stoploss_target_notification_seen_at = datetime.now(tz=time_zone)
                        session.add(alert)
                session.commit()
                apiresponce.setMsg("success")
                apiresponce.setResponse("Alert updated successfully")
            else:
                apiresponce.setMsg("failed")
                apiresponce.setResponse("Alert not found")



        else:
            rows = session.query(UserAlert).filter(UserAlert.id == alert_id).all()
            if len(rows) > 0:
                if notification_type == "entry_hit":
                    rows[0].entry_notification_seen = True
                    rows[0].entry_notification_seen_at = datetime.now(tz=time_zone)
                    session.add(rows[0])
                    session.commit()        
                    apiresponce.setMsg("success")
                    apiresponce.setResponse("Alert updated successfully")
                elif notification_type == "target_hit" or notification_type == "stoploss_hit":
                    rows[0].stoploss_target_notification_seen = True
                    rows[0].stoploss_target_notification_seen_at = datetime.now(tz=time_zone)
                    session.add(rows[0])
                    session.commit()        
                    apiresponce.setMsg("success")
                    apiresponce.setResponse("Alert updated successfully")
                else:
                    apiresponce.setMsg("failed")
                    apiresponce.setResponse("Invalid notification type")
            else:
                apiresponce.setMsg("failed")
                apiresponce.setResponse("Alert not found")
        
        
        session.close()
    except Exception as ex:
        logger.exception(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce