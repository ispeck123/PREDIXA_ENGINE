from fastapi import APIRouter, Request, HTTPException
from shared.db.api_responce import APIResponse
#from SharekhanApi.sharekhanConnect import SharekhanConnect
from sqlitedict import SqliteDict
#from modules.cal_s import Calculate_setup_execute
#from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from shared.config.settings import Config as cfg
from collections import defaultdict
from apps.finprod_backend.modules.stock_handler import get_all_stock_cmp
import logging, math
import numpy as np


db = SqliteDict(cfg.SQLITE_DB)
router = APIRouter()
logger = logging.getLogger()

# db['us'] = {}
# db['india'] = {}
# db['us']['daily_trades'] = []
# db['india']['daily_trades'] = []
# db['us']['fifteen_trades'] = []
# db['india']['fifteen_trades'] = []
# db['us']['sixty_trades'] = []
# db['india']['sixty_trades'] = []
# db.commit()
# db.close()


# @router.get("/accumulate_daily_trades", tags=['AVAILABLE TRADES'])
# async def accumulate_daily_trades(request: Request):
#     apiresponce = APIResponse(request)
#     try:
#         avl_trades = []
#         fss = []
#         res = raw_query(f"select * from stock_master where is_active=1")
#         with ThreadPoolExecutor(10) as t_pool:
#             # for i in range(1, 4):
#             for items in res:
#                 st_name = items.get('stock_tick')
#                 cse = Calculate_setup_execute(stock_name=st_name, time_frame=1, last_dt=datetime.now())
#                 future_to_input = t_pool.submit(cse.calculate)
#                 fss.append(future_to_input)

#             for futs in fss:
#                 try:
#                     result = futs.result()
#                     if 'BUY_RRR' in result.keys():
#                         avl_trades.append(result)
#                 except Exception as e:
#                     print(f"Task for input generated an exception: {e}")
        
#         db['daily_trades'] = avl_trades
#         db.commit()
#         apiresponce.setMsg("success")
#         apiresponce.setResponse("Successfully accumulated daily trade data")
#     except Exception as ex:
#         logger.error(ex)
#         apiresponce.setMsg("failed")
#         apiresponce.setResponse(str(ex))
#     return apiresponce

# @router.get("/accumulate_sixty_trades", tags=['AVAILABLE TRADES'])
# async def accumulate_sixty_trades(request: Request):
#     apiresponce = APIResponse(request)
#     try:
#         avl_trades = []
#         fss = []
#         res = raw_query(f"select * from stock_master where is_active=1")
#         with ThreadPoolExecutor(10) as t_pool:
#             # for i in range(1, 4):
#             for items in res:
#                 st_name = items.get('stock_tick')
#                 cse = Calculate_setup_execute(stock_name=st_name, time_frame=2, last_dt=datetime.now())
#                 future_to_input = t_pool.submit(cse.calculate)
#                 fss.append(future_to_input)
#             for futs in fss:
#                 try:
#                     result = futs.result()
#                     if 'BUY_RRR' in result.keys():
#                         avl_trades.append(result)
#                 except Exception as e:
#                     print(f"Task for input generated an exception: {e}")
        
#         db['sixty_trades'] = avl_trades
#         db.commit()
#         apiresponce.setMsg("success")
#         apiresponce.setResponse("Successfully accumulated daily trade data")
#     except Exception as ex:
#         logger.error(ex)
#         apiresponce.setMsg("failed")
#         apiresponce.setResponse(str(ex))
#     return apiresponce


# @router.get("/accumulate_fifteen_trades", tags=['AVAILABLE TRADES'])
# async def accumulate_fifteen_trades(request: Request):
#     apiresponce = APIResponse(request)
#     try:
#         avl_trades = []
#         fss = []
#         res = raw_query(f"select * from stock_master where is_active=1")
#         with ThreadPoolExecutor(10) as t_pool:
#             # for i in range(1, 4):
#             for items in res:
#                 st_name = items.get('stock_tick')
#                 cse = Calculate_setup_execute(stock_name=st_name, time_frame=3, last_dt=datetime.now())
#                 future_to_input = t_pool.submit(cse.calculate)
#                 fss.append(future_to_input)
#             for futs in fss:
#                 try:
#                     result = futs.result()
#                     if 'BUY_RRR' in result.keys():
#                         avl_trades.append(result)
#                 except Exception as e:
#                     print(f"Task for input generated an exception: {e}")
        
#         db['fifteen_trades'] = avl_trades
#         db.commit()
#         apiresponce.setMsg("success")
#         apiresponce.setResponse("Successfully accumulated daily trade data")
#     except Exception as ex:
#         logger.error(ex)
#         apiresponce.setMsg("failed")
#         apiresponce.setResponse(str(ex))
#     return apiresponce

def sanitize_json_floats(obj):
    #print(obj)
    #print(type(obj))
    if isinstance(obj, list):
        return [sanitize_json_floats(x) for x in obj]
    elif isinstance(obj, dict):
        return {k: sanitize_json_floats(v) for k, v in obj.items()}
    # elif isinstance(obj, np.float64):
    #     return None
    elif isinstance(obj, float):
        if math.isinf(obj) or math.isnan(obj):
            return None  # or 0.0 or string if you prefer
        return obj
    else:
        return obj


@router.get("/get_available_trades_daily", tags=['AVAILABLE TRADES'])
async def get_available_trades_daily(country_name: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        if country_name.lower().__contains__('us') or country_name.lower().__contains__('india'):
            country_dict = db.get(country_name.lower())
            all_daily_trades = country_dict['daily_trades']
            print(all_daily_trades, "****************************")
            all_daily_trades = sorted(all_daily_trades, key=lambda x: datetime.fromisoformat(x['TIMESTAMP']), reverse=True)
            sanitized_trades = sanitize_json_floats(all_daily_trades)
        else:
            return HTTPException(204, detail='Invalid Country')
        apiresponce.setMsg("success")
        apiresponce.setResponse(sanitized_trades)
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


# @router.get("/get_available_trades_daily_filter", tags=['AVAILABLE TRADES'])
# async def get_available_trades_daily_filter(request: Request, country_name: str, page_no: int = 1, limit: int = 10, search_key: str = None):
#     apiresponce = APIResponse(request)
#     try:
#         if country_name.lower().__contains__('us') or country_name.lower().__contains__('india'):
#             country_dict = db.get(country_name.lower())
#             all_daily_trades = country_dict['daily_trades']
#             total_count = len(all_daily_trades)
#             all_daily_trades = sorted(all_daily_trades, key=lambda x: datetime.fromisoformat(x['TIMESTAMP']), reverse=True)
#             if search_key != None and search_key != 'null' and search_key != '':
#                 all_daily_trades = [trade for trade in all_daily_trades if search_key in trade["STOCK_NAME"]]
#                 total_count = len(all_daily_trades)
#             start = ((page_no - 1) * limit) + 1
#             end = page_no * limit
#             if end > len(all_daily_trades):
#                 end = len(all_daily_trades)
#             trades = []
#             for i in range(start-1, end):
#                 trades.append(all_daily_trades[i])
#         else:
#             return HTTPException(204, detail='Invalid Country')
#         apiresponce.setMsg("success")
#         apiresponce.setResponse({"total_count": total_count, "trades": trades})
#     except Exception as ex:
#         logger.error(ex, stack_info=True)
#         apiresponce.setMsg("failed")
#         apiresponce.setResponse(str(ex))
#     return apiresponce


@router.get("/get_available_trades_daily_filter", tags=['AVAILABLE TRADES'])
async def get_available_trades_daily_filter(request: Request, country_name: str, start_date: str = "2025-01-01", end_date: str = "2025-12-31", page_no: str = None, limit: int = 10, search_key: str = None):
    apiresponce = APIResponse(request)
    try:
        if country_name.lower().__contains__('us') or country_name.lower().__contains__('india'):
            
            country_dict = db.get(country_name.lower())
            if country_dict == None or "daily_trades" not in country_dict:
                apiresponce.setMsg("success")
                apiresponce.setResponse({"total_count": 0, "trades": [], "page_no": None})
                return apiresponce
            all_daily_trades = country_dict['daily_trades']

            start_date = datetime.fromisoformat(start_date).date()
            end_date = datetime.fromisoformat(end_date).date()            
            all_daily_trades = [
                trade for trade in all_daily_trades
                if start_date <= datetime.fromisoformat(trade['TIMESTAMP']).date() <= end_date
            ]

            total_count = len(all_daily_trades)
            all_daily_trades = sorted(all_daily_trades, key=lambda x: x['STOCK_NAME'])            

            #  When search_key is given and page_no is not given 
            if (search_key != None and search_key != 'null' and search_key != '') and (page_no == None or page_no == 'null' or page_no == ''):
                a, b = total_count//limit, total_count%limit
                pg_nos = []
                if a > 0:
                    for i in range(a):
                        pg_nos.append(limit)
                if b > 0:
                    pg_nos.append(b)
                #print(pg_nos)
                start = 0
                data_found = False
                search_pg_no = False
                for i in range(len(pg_nos)):
                    end = start + pg_nos[i]
                    trades = []
                    for j in range(start, end):
                        trades.append(all_daily_trades[j])
                        if search_key.lower() in all_daily_trades[j]["STOCK_NAME"].lower():
                            #print(i)
                            if not data_found:
                                search_pg_no = i+1
                            data_found = True
                    if not data_found:
                        trades = []
                    else:
                        apiresponce.setMsg("success")
                        apiresponce.setResponse({"total_count": total_count, "trades": sanitize_json_floats(trades), "page_no": search_pg_no})
                        return apiresponce
                    start = end        
                if not data_found:
                    apiresponce.setMsg("success")
                    apiresponce.setResponse({"total_count": total_count, "trades": [], "page_no": None})
                    return apiresponce
            
            #  When search_key is not given and page_no is given
            elif (search_key == None or search_key == 'null' or search_key == '') and (page_no != None and page_no != 'null' and page_no != ''):
                page_no = int(page_no)
                start = ((page_no - 1) * limit) + 1
                end = page_no * limit
                if end > len(all_daily_trades):
                    end = len(all_daily_trades)
                trades = []
                for i in range(start-1, end):
                    trades.append(all_daily_trades[i])
                apiresponce.setMsg("success")
                apiresponce.setResponse({"total_count": total_count, "trades": sanitize_json_floats(trades), "page_no": page_no})
                return apiresponce
            
            #  When both search_key and page_no given
            elif (search_key != None and search_key != 'null' and search_key != '') and (page_no != None and page_no != 'null' and page_no != ''):
                print("line 1 .............")
                page_no = int(page_no)
                start = ((page_no - 1) * limit) + 1
                end = page_no * limit
                if end > len(all_daily_trades):
                    end = len(all_daily_trades)
                trades = []
                for i in range(start-1, end):
                    trades.append(all_daily_trades[i])
                apiresponce.setMsg("success")
                print(trades)
                apiresponce.setResponse({"total_count": total_count, "trades": sanitize_json_floats(trades), "page_no": page_no})
                return apiresponce
            
            # When both search_key and page_no not given
            else:
                page_no = 1
                start = ((page_no - 1) * limit) + 1
                end = page_no * limit
                if end > len(all_daily_trades):
                    end = len(all_daily_trades)
                trades = []
                for i in range(start-1, end):
                    trades.append(all_daily_trades[i])
                apiresponce.setMsg("success")
                apiresponce.setResponse({"total_count": total_count, "trades": sanitize_json_floats(trades), "page_no": page_no})
                return apiresponce
        else:
            return HTTPException(204, detail='Invalid Country')
        
    except Exception as ex:
        logger.exception(ex)
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/get_available_trades_sixty", tags=['AVAILABLE TRADES'])
async def get_available_trades_sixty(country_name: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        if country_name.lower().__contains__('us') or country_name.lower().__contains__('india'):
            country_dict = db.get(country_name.lower())
            all_daily_sixty = country_dict['sixty_trades']
            all_daily_sixty = sorted(all_daily_sixty, key=lambda x: datetime.fromisoformat(x['TIMESTAMP']), reverse=True)
        else:
            return HTTPException(204, detail='Invalid Country')
        apiresponce.setMsg("success")
        apiresponce.setResponse(all_daily_sixty)
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/get_available_trades_sixty_filter", tags=['AVAILABLE TRADES'])
async def get_available_trades_sixty_filter(request: Request, country_name: str, start_date: str = "2025-01-01", end_date: str = "2025-12-31", page_no: str = None, limit: int = 10, search_key: str = None):
    apiresponce = APIResponse(request)
    try:
        if country_name.lower().__contains__('us') or country_name.lower().__contains__('india'):
            
            country_dict = db.get(country_name.lower())
            if country_dict == None or "sixty_trades" not in country_dict:
                apiresponce.setMsg("success")
                apiresponce.setResponse({"total_count": 0, "trades": [], "page_no": None})
                return apiresponce
            all_sixty_trades = country_dict['sixty_trades']

            start_date = datetime.fromisoformat(start_date).date()
            end_date = datetime.fromisoformat(end_date).date()            
            all_sixty_trades = [
                trade for trade in all_sixty_trades
                if start_date <= datetime.fromisoformat(trade['TIMESTAMP']).date() <= end_date
            ]

            total_count = len(all_sixty_trades)
            all_sixty_trades = sorted(all_sixty_trades, key=lambda x: x['STOCK_NAME']) 
            
            #  When search_key is given and page_no is not given 
            if (search_key != None and search_key != 'null' and search_key != '') and (page_no == None or page_no == 'null' or page_no == ''):
                a, b = total_count//limit, total_count%limit
                pg_nos = []
                if a > 0:
                    for i in range(a):
                        pg_nos.append(limit)
                if b > 0:
                    pg_nos.append(b)
                #print(pg_nos)
                start = 0
                data_found = False
                search_pg_no = False
                for i in range(len(pg_nos)):
                    end = start + pg_nos[i]
                    trades = []
                    for j in range(start, end):
                        trades.append(all_sixty_trades[j])
                        if search_key.lower() in all_sixty_trades[j]["STOCK_NAME"].lower():
                            #print(i)
                            if not data_found:
                                search_pg_no = i+1
                            data_found = True
                    if not data_found:
                        trades = []
                    else:
                        apiresponce.setMsg("success")
                        apiresponce.setResponse({"total_count": total_count, "trades": sanitize_json_floats(trades), "page_no": search_pg_no})
                        return apiresponce
                    start = end        
                if not data_found:
                    apiresponce.setMsg("success")
                    apiresponce.setResponse({"total_count": total_count, "trades": [], "page_no": None})
                    return apiresponce
            
            #  When search_key is not given and page_no is given
            elif (search_key == None or search_key == 'null' or search_key == '') and (page_no != None and page_no != 'null' and page_no != ''):
                page_no = int(page_no)
                start = ((page_no - 1) * limit) + 1
                end = page_no * limit
                if end > len(all_sixty_trades):
                    end = len(all_sixty_trades)
                trades = []
                for i in range(start-1, end):
                    trades.append(all_sixty_trades[i])
                apiresponce.setMsg("success")
                apiresponce.setResponse({"total_count": total_count, "trades": sanitize_json_floats(trades), "page_no": page_no})
                return apiresponce
            
            #  When both search_key and page_no given
            elif (search_key != None and search_key != 'null' and search_key != '') and (page_no != None and page_no != 'null' and page_no != ''):
                page_no = int(page_no)
                start = ((page_no - 1) * limit) + 1
                end = page_no * limit
                if end > len(all_sixty_trades):
                    end = len(all_sixty_trades)
                trades = []
                for i in range(start-1, end):
                    trades.append(all_sixty_trades[i])
                apiresponce.setMsg("success")
                apiresponce.setResponse({"total_count": total_count, "trades": sanitize_json_floats(trades), "page_no": page_no})
                return apiresponce
            
            # When both search_key and page_no not given
            else:
                page_no = 1
                start = ((page_no - 1) * limit) + 1
                end = page_no * limit
                if end > len(all_sixty_trades):
                    end = len(all_sixty_trades)
                trades = []
                for i in range(start-1, end):
                    trades.append(all_sixty_trades[i])
                apiresponce.setMsg("success")
                apiresponce.setResponse({"total_count": total_count, "trades": sanitize_json_floats(trades), "page_no": page_no})
                return apiresponce
        else:
            return HTTPException(204, detail='Invalid Country')
        
    except Exception as ex:
        logger.exception(ex)
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/get_available_trades_fifteen", tags=['AVAILABLE TRADES'])
async def get_available_trades_fifteen(country_name: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        if country_name.lower().__contains__('us') or country_name.lower().__contains__('india'):
            country_dict = db.get(country_name.lower())
            all_daily_fifteen = country_dict['fifteen_trades']
            all_daily_fifteen = sorted(all_daily_fifteen, key=lambda x: datetime.fromisoformat(x['TIMESTAMP']), reverse=True)
        else:
            return HTTPException(204, detail='Invalid Country')
        apiresponce.setMsg("success")
        apiresponce.setResponse(all_daily_fifteen)
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/get_available_trades_fifteen_filter", tags=['AVAILABLE TRADES'])
async def get_available_trades_fifteen_filter(request: Request, country_name: str, start_date: str = "2025-01-01", end_date: str = "2025-12-31", page_no: str = None, limit: int = 10, search_key: str = None):
    apiresponce = APIResponse(request)
    try:
        if country_name.lower().__contains__('us') or country_name.lower().__contains__('india'):
            
            country_dict = db.get(country_name.lower())
            if country_dict == None or "fifteen_trades" not in country_dict:
                apiresponce.setMsg("success")
                apiresponce.setResponse({"total_count": 0, "trades": [], "page_no": None})
                return apiresponce
            all_fifteen_trades = country_dict['fifteen_trades']

            start_date = datetime.fromisoformat(start_date).date()
            end_date = datetime.fromisoformat(end_date).date()            
            all_fifteen_trades = [
                trade for trade in all_fifteen_trades
                if start_date <= datetime.fromisoformat(trade['TIMESTAMP']).date() <= end_date
            ]

            total_count = len(all_fifteen_trades)
            all_fifteen_trades = sorted(all_fifteen_trades, key=lambda x: x['STOCK_NAME']) 
            
            #  When search_key is given and page_no is not given 
            if (search_key != None and search_key != 'null' and search_key != '') and (page_no == None or page_no == 'null' or page_no == ''):
                a, b = total_count//limit, total_count%limit
                pg_nos = []
                if a > 0:
                    for i in range(a):
                        pg_nos.append(limit)
                if b > 0:
                    pg_nos.append(b)
                #print(pg_nos)
                start = 0
                data_found = False
                search_pg_no = False
                for i in range(len(pg_nos)):
                    end = start + pg_nos[i]
                    trades = []
                    for j in range(start, end):
                        trades.append(all_fifteen_trades[j])
                        if search_key.lower() in all_fifteen_trades[j]["STOCK_NAME"].lower():
                            #print(i)
                            if not data_found:
                                search_pg_no = i+1
                            data_found = True
                    if not data_found:
                        trades = []
                    else:
                        apiresponce.setMsg("success")
                        apiresponce.setResponse({"total_count": total_count, "trades": sanitize_json_floats(trades), "page_no": search_pg_no})
                        return apiresponce
                    start = end        
                if not data_found:
                    apiresponce.setMsg("success")
                    apiresponce.setResponse({"total_count": total_count, "trades": [], "page_no": None})
                    return apiresponce
            
            #  When search_key is not given and page_no is given
            elif (search_key == None or search_key == 'null' or search_key == '') and (page_no != None and page_no != 'null' and page_no != ''):
                page_no = int(page_no)
                start = ((page_no - 1) * limit) + 1
                end = page_no * limit
                if end > len(all_fifteen_trades):
                    end = len(all_fifteen_trades)
                trades = []
                for i in range(start-1, end):
                    trades.append(all_fifteen_trades[i])
                apiresponce.setMsg("success")
                apiresponce.setResponse({"total_count": total_count, "trades": sanitize_json_floats(trades), "page_no": page_no})
                return apiresponce
            
            #  When both search_key and page_no given
            elif (search_key != None and search_key != 'null' and search_key != '') and (page_no != None and page_no != 'null' and page_no != ''):
                page_no = int(page_no)
                start = ((page_no - 1) * limit) + 1
                end = page_no * limit
                if end > len(all_fifteen_trades):
                    end = len(all_fifteen_trades)
                trades = []
                for i in range(start-1, end):
                    trades.append(all_fifteen_trades[i])
                apiresponce.setMsg("success")
                apiresponce.setResponse({"total_count": total_count, "trades": sanitize_json_floats(trades), "page_no": page_no})
                return apiresponce
            
            # When both search_key and page_no not given
            else:
                page_no = 1
                start = ((page_no - 1) * limit) + 1
                end = page_no * limit
                if end > len(all_fifteen_trades):
                    end = len(all_fifteen_trades)
                trades = []
                for i in range(start-1, end):
                    trades.append(all_fifteen_trades[i])
                apiresponce.setMsg("success")
                apiresponce.setResponse({"total_count": total_count, "trades": sanitize_json_floats(trades), "page_no": page_no})
                return apiresponce
        else:
            return HTTPException(204, detail='Invalid Country')
        
    except Exception as ex:
        logger.exception(ex)
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/get_available_trades_by_stock", tags=['AVAILABLE TRADES'])
async def get_available_trades_by_stock(country_name: str, stock_name: str, time_frame: int, request: Request):
    apiresponce = APIResponse(request)
    try:
        avl_trades = []
        country_dict = db.get(country_name.lower())
        if time_frame == 1:
            all_trades = country_dict['daily_trades']
        elif time_frame == 2:
            all_trades = country_dict['sixty_trades']
        elif time_frame == 3:
            all_trades = country_dict['fifteen_trades']
        else:
            return HTTPException(204, detail='Invalid Time Frame')
        for items in all_trades:
            if items['STOCK_NAME'] == stock_name.lower():
                avl_trades.append(items)
                
        if len(avl_trades) > 0:
            apiresponce.setMsg("success")
            apiresponce.setResponse(avl_trades)
        else:
            apiresponce.setMsg("failed")
            apiresponce.setResponse("No trades Available")
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/fetch_filtered_stock_available_trades")
async def fetch_filtered_stock_available_trades(request: Request, time_fr: int, country_name: str):
    apiresponce = APIResponse(request)
    try:
        grouped_setups = defaultdict(list)
        frame = getattr(cfg, f'TIME_FRAMES_{time_fr}')[-1]
        country_dict = db.get(country_name.lower())
        cmp_dict = get_all_stock_cmp(country_name.lower())
        requested_setups = country_dict[f'{frame}_trades']
        print(cmp_dict)
        for setup in requested_setups:
            stock = setup['STOCK_NAME']
            grouped_setups[stock].append(setup)
        
        filtered_setups = []
        for stock, setups_list in grouped_setups.items():
            if stock not in cmp_dict:
                continue  # Skip if CMP not available
            cmp_value = cmp_dict[stock]
            closest_setup = min(
                setups_list,
                key=lambda x: abs(x['BUY']['entry_price'] - cmp_value)
            )
            filtered_setups.append(closest_setup)
        apiresponce.setMsg("success")
        apiresponce.setResponse(filtered_setups)
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce

# avl_trades = []
#         fss = []
#         # res = raw_query(f"select * from stock_master where is_active=1")
#         with ThreadPoolExecutor(10) as t_pool:
#             # for i in range(1, 4):
#             cse = Calculate_setup_execute(stock_name=stock_name, time_frame=time_frame, last_dt=datetime.now())
#             future_to_input = t_pool.submit(cse.calculate)
#             fss.append(future_to_input)
            
#             for futs in fss:
#                 # for future in as_completed(futs):
#                 try:
#                     result = futs.result()
#                     if 'BUY_RRR' in result.keys():
#                         avl_trades.append(result)
#                 except Exception as e:
#                     print(f"Task for input generated an exception: {e}")