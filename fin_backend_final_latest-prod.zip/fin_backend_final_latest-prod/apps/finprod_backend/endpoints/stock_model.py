from fastapi import APIRouter, Request
from shared.db.req_model import Stock_RCM_New
from shared.db.api_responce import APIResponse
from shared.db.dbconn import DBConnection
# from modules.order_update import calculate_and_update, calculate_entry_hit
from apps.finprod_backend.modules.calculate_model import Stock_Model_Loader_Daily, Stock_Model_Loader_Minute, LSTM_RF, ARIMA_AB, ARIMA_AB_BUY, ARIMA_AB_ZONE
from sqlalchemy import text
from shared.config.settings import Config as cfg
import logging
from datetime import datetime
from apps.finprod_backend.modules.stock_utils import AUTO_TRADER_RANDOM
import os

router = APIRouter()
logger = logging.getLogger()
db = DBConnection()

@router.post("/fetch_stock_model_prediction", tags=['Stock Model'])
async def fetch_stock_model_prediction(request: Request, model: Stock_RCM_New):
    apiresponce = APIResponse(request)
    try:
        # out_res = {}
        last_d_time = datetime.strptime(model.last_d_time, "%Y-%m-%d %H:%M:%S")
        # frame = getattr(cfg, f'TIME_FRAMES_{time_frame}')
        # for t_fr in frame:
        bind_data = {
            "order_type" : model.order_type,
            "entry_price" : model.entry_price,
            "target_price" : model.target_price,
            "stoploss_price" : model.stoploss_price
            }
        if model.mod_frame == 'daily':
            #file_name = f"/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/processed_data_files/{model.tick}_daily.csv"
            file_name = os.path.join(os.getcwd(), "apps", "finprod_backend", "processed_data_files", f"{model.tick}_daily.csv")
            stm = Stock_Model_Loader_Daily(file_name, bind_data, last_d_time)
            out_res, prob = stm.run()
        else:
            #file_name = f"/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/processed_data_files/{model.tick}_sixty.csv"
            file_name = os.path.join(os.getcwd(), "apps", "finprod_backend", "processed_data_files", f"{model.tick}_sixty.csv")
            stm = Stock_Model_Loader_Minute(file_name, bind_data, last_d_time)
            out_res, prob = stm.run()
        if out_res == "success":
            prob = round(prob*100, 2)
            apiresponce.setMsg("success")
            apiresponce.setResponse({"probability" : prob})
        else:
            prob = round(abs(1 - prob)*100, 2)
            apiresponce.setMsg("failed")
            apiresponce.setResponse({"probability" : prob})
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.post("/fetch_lstm_rf_prediction", tags=['Stock Model'])
async def fetch_lstm_rf_prediction(request: Request, model: Stock_RCM_New):
    apiresponce = APIResponse(request)
    try:
        last_d_time = datetime.strptime(model.last_d_time, "%Y-%m-%d %H:%M:%S")
        bind_data = {
            "order_type" : model.order_type,
            "entry_price" : model.entry_price,
            "target_price" : model.target_price,
            "stoploss_price" : model.stoploss_price
            }
        # if model.model_frame == 'daily':
        #file_name = f"/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/processed_data_files/{model.tick}_daily.csv"
        file_name = os.path.join(os.getcwd(), "apps", "finprod_backend", "processed_data_files", f"{model.tick}_daily.csv")
        # stm = LSTM_RF(file_name, bind_data, last_d_time)
        stm = ARIMA_AB_BUY(file_name, bind_data, last_d_time, model.tick)
        out_res, prob = stm.run()
        if out_res == "success":
            prob = round(prob*100, 2)
            apiresponce.setMsg("success")
            apiresponce.setResponse({"probability" : prob})
        else:
            prob = round(prob*100, 2)
            apiresponce.setMsg("failed")
            apiresponce.setResponse({"probability" : prob})
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.post("/fetch_arima_ab_prediction", tags=['Stock Model'])
async def fetch_arima_ab_prediction(request: Request, model: Stock_RCM_New):
    apiresponce = APIResponse(request)
    try:
        last_d_time = datetime.strptime(model.last_d_time, "%Y-%m-%d %H:%M:%S")
        bind_data = {
            # "order_type" : model.order_type,
            "entry_price" : model.entry_price,
            "target_price" : model.target_price,
            "stoploss_price" : model.stoploss_price
            }
        # if model.model_frame == 'daily':
        #file_name = f"/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/processed_data_files/{model.tick}_daily.csv"
        file_name = os.path.join(os.getcwd(), "apps", "finprod_backend", "processed_data_files", f"{model.tick}_daily.csv")
        arm_ab = ARIMA_AB_BUY(file_name, bind_data, last_d_time, model.tick)
        out_res, prob = arm_ab.run()
        prob = round(prob*100, 2)
        apiresponce.setMsg(out_res)
        apiresponce.setResponse({"probability" : prob})
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce



@router.post("/update_lstm_rf_stock_model_predictions", tags=['Stock Model'])
async def update_stock_model_predictions(request: Request):
    apiresponce = APIResponse(request)
    try:
        res = db.raw_query(text("select * from order_master"))
        for items in res:
            bind_data = {
                "order_type" : items.get("order_type"),
                "entry_price" : items.get("entry_price"),
                "target_price" : items.get("target_price"),
                "stoploss_price" : items.get("stoploss_price")
            }
            tick = items.get("stock_tick")
            #file_name = f"/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/processed_data_files/{tick}_daily.csv"
            file_name = os.path.join(os.getcwd(), "apps", "finprod_backend", "processed_data_files", f"{tick}_daily.csv")
            last_d_time = datetime.strptime(items.get("purchased_cmp_date"), "%Y-%m-%dT%H:%M")
            stm = LSTM_RF(file_name, bind_data, last_d_time)
            out_res, prob = stm.run()
            query = f"update order_master set lstm_rf_model_prediction='{out_res}', lstm_rf_model_prob={prob} where order_id={items.get('order_id')}"
            rc = db.raw_connection()
            rc.execute(text(query))
            rc.commit()
            rc.close
            # print(out_res, prob)
        apiresponce.setMsg("success")
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.post("/update_arima_ab_stock_model_predictions", tags=['Stock Model'])
async def update_stock_model_predictions(request: Request):
    apiresponce = APIResponse(request)
    try:
        res = db.raw_query(text("select * from order_master;"))
        for items in res:
            bind_data = {
                "order_type" : items.get("order_type"),
                "entry_price" : items.get("entry_price"),
                "target_price" : items.get("target_price"),
                "stoploss_price" : items.get("stoploss_price")
            }
            tick = items.get("stock_tick")
            #file_name = f"/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/processed_data_files/{tick}_daily.csv"
            file_name = os.path.join(os.getcwd(), "apps", "finprod_backend", "processed_data_files", f"{tick}_daily.csv")
            last_d_time = datetime.strptime(items.get("purchased_cmp_date"), "%Y-%m-%dT%H:%M")
            stm = ARIMA_AB_BUY(file_name, bind_data, last_d_time, tick)
            out_res, prob = stm.run()
            query = f"update order_master set arima_ab_model_prediction='{out_res}', arima_ab_model_prob={prob} where order_id={items.get('order_id')}"
            rc = db.raw_connection()
            rc.execute(text(query))
            rc.commit()
            rc.close()
            print(items.get('order_id'))
            # print(out_res, prob)
        apiresponce.setMsg("success")
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce



@router.get("/generate_auto_orders", tags=['Stock Model'])
async def generate_auto_orders(time_frame: int, request: Request):
    apiresponce = APIResponse(request)
    try:
        at = AUTO_TRADER_RANDOM(time_frame)
        at.start()
        apiresponce.setMsg("success")
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce

