from fastapi import APIRouter, Request
from starlette.concurrency import run_in_threadpool
from shared.db.api_responce import APIResponse
import logging
from datetime import datetime, time as dt_time, timezone as dt_timezone
import pandas as pd
from shared.config.settings import Config as cfg
from shared.config.settings import stock_data_dir_config
from shared.config.settings import stock_logic_config
from concurrent.futures import ProcessPoolExecutor
import numpy as np
from scripts.calculate_zones import DemandZoneCalculator, SupplyZoneCalculator, ZoneAnalyzer, ZONE_TIME_FIXATURE, GAPZoneCalculator
from apps.finprod_backend.modules.calculate_zone import Calculate_GAP, Calculate_BUY_SELL_ZONES, Calculate_BAD_ZONES
from scripts.calculate_zones_ext import Calculate_Base_Candles
# from apps.finprod_backend.modules.calculate_setup import Calculate_setup_execute
from scripts.calculate_setup import Calculate_setup_execute
# from modules.cal_s import Calculate_setup_execute
from apps.finprod_backend.modules.utils import utility
from apps.finprod_backend.modules.stock_handler import ohlc_inverter
from pytz import timezone
import numpy as np
from collections.abc import Mapping, Iterable
from scripts.curve_helper import check_price_across_timeframes
from scripts.models import load_preprocess_chart_data, TF
from scripts.trade_engine import processs_all_zones, process_qualified_zones, process_zones
from scripts.trend_engine import MultiTimeframeTrendCalculator
from lakehouse.config import LakehouseConfig
from lakehouse.spark_session import create_spark_session
from lakehouse.timeframes import normalize_timeframe
from scripts.setup_engine_new import SDEnginePipeline
import os, re
import logging
import threading


logger = logging.getLogger()


def pyify(obj):
    if isinstance(obj, np.generic):
        return obj.item()
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, Mapping):
        return {k: pyify(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set)):
        return [pyify(v) for v in obj]
    return obj

router = APIRouter()
logger = logging.getLogger()

def is_during_trading_hours():
    start_time = dt_time(9, 14)  # 9:15 AM
    end_time = dt_time(15, 36)   # 3:30 PM
    current_time = datetime.now().time()
    return start_time <= current_time <= end_time

def is_trading_day():
    current_year = datetime.now().year
    start_date = datetime(year=current_year, month=1, day=1)
    end_date = datetime(year=current_year, month=12, day=31)
    current_date = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0).strftime("%Y-%m-%d")
    trading_days = pd.bdate_range(start=start_date, end=end_date).to_list()
    return pd.Timestamp(current_date) in trading_days

@router.get("/get_candle_chart_data", tags=['Stock Calculation'])
async def get_candle_chart_data(country_name: str, tick: str, time_frame: int, last_d_time: str, request: Request):
    try:
        apiresponce = APIResponse(request)
        data = {}
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        # last_d_time = timezone('Asia/Kolkata').localize(
        #                         datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
                            # )
        aqq_time_frame = getattr(cfg, f'TIME_FRAMES_{time_frame}')
        exe_frame = aqq_time_frame[-1]
        # if time_frame == 1:
        for t_frame in aqq_time_frame:
            try:
                if country_name.lower().__contains__('us'):
                # filepath = f"./latest_data_csv/{tick}_{t_frame}.csv"
                    filepath = f"{cfg.us_data_dir}/latest_data_csv/{tick}_{t_frame}.csv"
                else:
                    filepath = f"{cfg.india_data_dir}/latest_data_csv/{tick.lower()}_{t_frame}.csv"
                print(filepath)
                # df = pd.read_csv(filepath)
                df, violation_df = load_preprocess_chart_data(filepath, last_d_time)
                #print(df)
                # if t_frame == exe_frame and is_during_trading_hours() and is_trading_day():
                #     df = df.drop(df.index[-1])
                # df['tradeDate'] = pd.to_datetime(df['tradeDate'], dayfirst = True)
                # if country_name.__contains__('us'):
                #     pass
                # else:
                # df['tradeDate'] = df['tradeDate'].dt.tz_localize('UTC').dt.tz_convert('Asia/Kolkata')
                #print(df)
                df_1 = df[['tradeDate', 'open', 'high', 'low', 'close']][df.tradeDate <= last_d_time]
                df_1.rename(columns = {'tradeDate': 'time'}, inplace = True)
                df_1['timestamp'] = df_1['time'].copy()
                df_1['time'] = (df_1['time'].astype(np.int64) // 10**9).astype(int)
                # df_1.replace([np.inf, -np.inf], np.nan, inplace=True) 
                # df_1.fillna(0, inplace=True)
                # df_1 = ohlc_inverter(df_1)
                df_sorted = df_1.sort_values(by='time', ascending=True)
                df_sorted = df_sorted.drop_duplicates(subset=['time'])
                df_sorted.replace([np.inf, -np.inf], np.nan, inplace=True)
                df_sorted.fillna(0, inplace=True)
                data[t_frame] = df_sorted.to_dict(orient = 'records')      
            except Exception as edx:
                logger.exception(edx, stack_info=True)
                continue
        apiresponce.setMsg("success")
        apiresponce.setResponse(data)
    except Exception as ex:
        logger.exception(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


_lake_spark = None
_lake_spark_lock = threading.Lock()
_lake_query_lock = threading.Lock()


def _get_lake_spark():
    global _lake_spark
    with _lake_spark_lock:
        if _lake_spark is None:
            _lake_spark = create_spark_session(LakehouseConfig.from_env(), "finprod-candle-lake")
        return _lake_spark


def _lake_chart_data(country_name: str, tick: str, time_frame: int, last_d_time: str):
    if country_name.lower() not in {"india", "in", "nse"}:
        raise ValueError("The lake-backed candle endpoint currently supports NSE Cash only")
    config = LakehouseConfig.from_env()
    legacy_frames = getattr(cfg, f"TIME_FRAMES_{time_frame}")
    cutoff_local = timezone("Asia/Kolkata").localize(datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S"))
    cutoff_utc = cutoff_local.astimezone(timezone("UTC")).replace(tzinfo=None)
    spark = _get_lake_spark()
    from pyspark.sql import functions as F
    result = {}
    with _lake_query_lock:
        for legacy_frame in legacy_frames:
            canonical = normalize_timeframe(legacy_frame)
            source = (spark.table(config.table_name)
                .where((F.col("symbol") == tick.lower()) & (F.col("timeframe") == canonical))
                .where(F.col("timestamp") <= F.lit(cutoff_utc)))
            # Intraday candles must stay inside the NSE session. Daily and
            # calendar aggregates use a session-date marker for chart display.
            local_ts = F.from_utc_timestamp("timestamp", "Asia/Kolkata")
            minutes = F.hour(local_ts) * 60 + F.minute(local_ts)
            intraday = canonical in {"5m", "15m", "25m", "60m", "75m", "125m"}
            if intraday:
                source = source.where((minutes >= 540) & (minutes <= 930))
            rows = (source
                .select(F.col("timestamp").cast("long").alias("timestamp_epoch"), "open", "high", "low", "close")
                .orderBy("timestamp_epoch").collect())
            candles = []
            for row in rows:
                source_epoch = int(row.timestamp_epoch)
                source_utc = datetime.fromtimestamp(source_epoch, tz=dt_timezone.utc)
                # Preserve the broker timestamp; shift only the chart presentation epoch.
                # The chart consumer expects IST wall-clock values.
                display_epoch = source_epoch + 19800
                display_local = source_utc.astimezone(timezone("Asia/Kolkata"))
                candles.append({
                    # Chart compatibility: this epoch is shifted so UTC rendering shows IST.
                    "time": display_epoch,
                    "timestamp": display_local.isoformat(),
                    "timestamp_utc": source_utc.isoformat(),
                    "open": float(row.open), "high": float(row.high),
                    "low": float(row.low), "close": float(row.close),
                })
            result[legacy_frame] = candles
    return result


# @router.get("/get_candle_chart_data", tags=["Stock Calculation"])
# async def get_candle_chart_data_lake(country_name: str, tick: str, time_frame: int, last_d_time: str, request: Request):
#     apiresponce = APIResponse(request)
#     try:
#         data = await run_in_threadpool(_lake_chart_data, country_name, tick, time_frame, last_d_time)
#         apiresponce.setMsg("success")
#         apiresponce.setResponse(data)
#     except Exception as ex:
#         logger.exception("Lakehouse candle chart request failed", exc_info=True)
#         apiresponce.setMsg("failed")
#         apiresponce.setResponse(str(ex))
#     return apiresponce


@router.get("/calculate_base_candles", tags=['Stock Calculation'])
async def calculate_zone(country_name: str, tick: str, time_frame: int, last_d_time: str, request: Request):
    try:
        apiresponce = APIResponse(request)
        data = {}
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        time_list = getattr(cfg, f"TIME_FRAMES_{time_frame}")
        country_dir = getattr(cfg, f'{country_name.lower()}_data_dir')
        # if time_frame == 1:
        for t_frame in time_list:
            file_name = f"{country_dir}/latest_data_csv/{tick}_{t_frame}.csv"
            cbc = Calculate_Base_Candles(csv_path = file_name, tick = tick, last_d_time=last_d_time)
            data[t_frame] = cbc.calculate_zones()
            # is_exe = True if t_frame == time_list[::-1][0] else False
            # cbc = Calculate_BUY_SELL_ZONES(csv_path = file_name, tick = tick, last_d_time=last_d_time, is_execute=is_exe)
            # data[t_frame] = cbc.ca()
        # calc_zone = Calculate_Base_Candles(csv_path = "processed_data_files/hdfc_60minute.csv", tick = tick, time_frame = time_frame)
        apiresponce.setMsg("success")
        apiresponce.setResponse(data)
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


# @router.get("/calculate_zone", tags=['Stock Calculation'])
# async def calculate_zone(request: Request):
#     try:
#         apiresponce = APIResponse(request)
#         calc_zone = Calculate_Base_Candles(csv_path = "processed_data_files/hdfc_sixty.csv", tick = "hdfc", last_d_time=datetime.now())
#         return calc_zone.calculate_zones()
#     except Exception as ex:
#         logger.exception(ex)
#         apiresponce.setMsg("failed")
#         apiresponce.setResponse(str(ex))
#     return apiresponce

@router.get("/get_gaps", tags=['Stock Calculation'])
async def get_gaps(country_name: str, tick: str, time_frame: int, last_d_time: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        out_res = {}
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        frame = getattr(cfg, f'TIME_FRAMES_{time_frame}')
        country_dir = getattr(cfg, f'{country_name.lower()}_data_dir')
        for t_fr in frame:
            file_name = f"{country_dir}/latest_data_csv/{tick}_{t_fr}.csv"
            gzc = GAPZoneCalculator(file_name, tick, last_d_time, True)
            # res = Calculate_GAP(csv_path=file_name, last_d_time=last_d_time)
            out_res[t_fr] = gzc.detect_and_format_gaps()
        apiresponce.setMsg("success")
        apiresponce.setResponse(out_res)
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce

@router.get("/calculate_buy_zone", tags=['Stock Calculation'])
async def calculate_buy_zone(country_name: str, tick: str, time_frame: int, last_d_time: str, request: Request):
    try:
        apiresponce = APIResponse(request)
        data = {}
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        time_list = getattr(cfg, f"TIME_FRAMES_{time_frame}")
        country_dir = getattr(cfg, f'{country_name.lower()}_data_dir')
        for t_frame in time_list:
            is_execute = True if time_list[-1] == t_frame else False
            file_name = f"{country_dir}/processed_data_files/{tick}_{t_frame}.csv"
            # dz_calc = DemandZoneCalculator(file_name, tick, last_d_time, is_execute).calculate_zones()
            dz_calc = DemandZoneCalculator(file_name, tick, last_d_time, is_execute).calculate_zones()
            # cbsz = Calculate_BUY_SELL_ZONES(csv_path=file_name, tick=tick, last_d_time=last_d_time, is_execute=is_execute)
            data[t_frame] = dz_calc # cbsz.calculate_new_buy_zones()
        
        apiresponce.setMsg("success")
        apiresponce.setResponse(data)
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce

@router.get("/calculate_opt_zone", tags=['Stock Calculation'])
async def calculate_opt_zone(country_name: str, tick: str, time_frame: int, last_d_time: str, request: Request):
    try:
        apiresponce = APIResponse(request)
        data = {}
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        time_list = getattr(stock_logic_config, f"TIME_FRAMES_{time_frame}")
        country_dir = stock_data_dir_config.indian_stock_data_dir
        # with ProcessPoolExecutor(max_workers=4) as executor:
        for t_frame in time_list:
            try:
                file_name = f"{country_dir}/latest_data_csv/{tick}_{t_frame}.csv"

                if t_frame == time_list[0]:
                    tf = TF.E
                elif t_frame == time_list[1]:
                    tf = TF.A
                else:
                    tf = TF.X
                resp = process_zones(file_name, tf, last_d_time)
                data[t_frame] = resp
                
            except Exception as ex:
                logger.exception(ex, stack_info=True, exc_info=True)
        
        apiresponce.setMsg("success")
        apiresponce.setResponse(data)
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce

@router.get("/calculate_sell_zone", tags=['Stock Calculation'])
async def calculate_sell_zone(country_name: str, tick: str, time_frame: int, last_d_time: str, request: Request):
    try:
        apiresponce = APIResponse(request)
        data = {}
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        time_list = getattr(cfg, f"TIME_FRAMES_{time_frame}")
        country_dir = getattr(cfg, f'{country_name.lower()}_data_dir')
        # if time_frame == 2:
        #     time_list = getattr(cfg, f'TIME_FRAME_EXE_{time_frame}')
        for t_frame in time_list:
            file_name = f"{country_dir}/latest_data_csv/{tick}_{t_frame}.csv"
            is_execute = True if time_list[-1] == t_frame else False
            sz_calc = SupplyZoneCalculator(file_name, tick, last_d_time, is_execute).calculate_zones()
            # cbsz = Calculate_BUY_SELL_ZONES(csv_path=file_name, tick=tick, last_d_time=last_d_time, is_execute=is_execute)
            data[t_frame] = sz_calc # cbsz.calculate_new_sell_zones()
        
        apiresponce.setMsg("success")
        apiresponce.setResponse(data)
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce

@router.get("/calculate_all_zones")
async def calculate_all_zones(country_name: str, tick: str, time_frame: int, last_d_time: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        data = {}
        buy_data = {}
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        time_list = getattr(cfg, f"TIME_FRAMES_{time_frame}")
        country_dir = getattr(cfg, f'{country_name.lower()}_data_dir')
        # if time_frame == 2:
        #     time_list = getattr(cfg, f'TIME_FRAME_EXE_{time_frame}')
        # with ProcessPoolExecutor(max_workers=4) as executor:
        for t_frame in time_list:
            file_name = f"{country_dir}/latest_data_csv/{tick}_{t_frame}.csv"
            # is_execute = True if time_list[-1] == t_frame else False
            # cbsz = Calculate_BUY_SELL_ZONES(csv_path=file_name, tick=tick, last_d_time=last_d_time, is_execute=is_execute)
            # dz_cal_f = executor.submit(DemandZoneCalculator, file_name, tick, last_d_time, is_execute)
            # sz_cal_f = executor.submit(SupplyZoneCalculator, file_name, tick, last_d_time, is_execute)
            # dz_cal = dz_cal_f.result()
            # sz_cal = sz_cal_f.result()
            # z_ana = ZoneAnalyzer(dz_cal, sz_cal)
            # b_arr, s_arr = z_ana.calculate_seperate_zones(True)
            # print(type(b_arr), type(s_arr))
            # print("____________________________________________________________")
            # buy_data = b_arr #b_arr # dz_cal.calculate_all_zones(True)
            # sell_data = s_arr # [] 
            # # sz_cal.calculate_all_zones(True)
            # data[t_frame] =  {
            #     'Buy' : buy_data,
            #     'Sell' : sell_data
            # }
            if t_frame == time_list[0]:
                tf = TF.E
            elif t_frame == time_list[1]:
                tf = TF.A
            else:
                tf = TF.X
            resp = processs_all_zones(file_name, tf, last_d_time)
            data[t_frame] = resp
                # print(t_frame, sell_data)
                # data[t_frame]['Sell'] = 
        
        apiresponce.setMsg("success")
        apiresponce.setResponse(data)
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce

@router.get("/get_qualified_zones", tags=['Stock Calculation'])
async def get_qualified_zones(country_name: str, tick: str, time_frame: int, last_d_time: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        country_dir = getattr(cfg, f'{country_name.lower()}_data_dir')
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        if time_frame == 25:
            time_list = getattr(cfg, f"TIME_FRAMES_{time_frame}")
            file_name = f"{country_dir}/latest_data_csv/{tick}_seventy_five.csv"
        else:
            time_list = getattr(cfg, f"TIME_FRAMES_{time_frame}")
            file_name = f"{country_dir}/latest_data_csv/{tick}_{time_list[::-1][0]}.csv"
        print(file_name, "*********************************")
        data = process_qualified_zones(file_name, TF.X, last_d_time, time_list, tick)
        # with ProcessPoolExecutor(max_workers=4) as executor:
        #     dz_cal = executor.submit(DemandZoneCalculator, file_name, tick, last_d_time, True)
        #     sz_cal = executor.submit(SupplyZoneCalculator, file_name, tick, last_d_time, True)
        
        # dz_cal = dz_cal.result()
        # sz_cal = sz_cal.result()
        # zone_cal = ZoneAnalyzer(dz_cal, sz_cal)
        # cse = Calculate_setup_execute(tick, time_frame, last_d_time)
        # trend = cse.get_stock_trend()
        # data = zone_cal.get_qualified_alterated_zones(True)
        # bb_data = {
        #     'Buy' : data['Buy'][:3],
        #     'Sell' : data['Sell'][:3]
        # }
        apiresponce.setMsg("success")
        apiresponce.setResponse(data)
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce

# @router.get("/calculate_setup", tags=['Stock Calculation'])
# async def calculate_setup(country_name: str, tick: str, time_frame: int, last_d_time: str, request: Request):
#     apiresponce = APIResponse(request)
#     try:
#         setup_data = {}
#         country_dir = getattr(cfg, f'{country_name.lower()}_data_dir')
#         last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
#         # if time_frame == 1:
#         # file_name = f"./processed_data_files/{tick}_{exe_frame}.csv"
#         cse = Calculate_setup_execute(tick, time_frame, last_d_time, country_dir)
#         setup_data = cse.calculate()
#         print(setup_data)
        
#         if setup_data is not None:
#             apiresponce.setMsg("success")
#             apiresponce.setResponse(setup_data)
#         else:
#             apiresponce.setMsg("failed")
#             apiresponce.setResponse("Not Enough Data available")
            
#     except Exception as ex:
#         logger.exception(ex)
#         apiresponce.setMsg("failed")
#         apiresponce.setResponse(str(ex))
#     return apiresponce

@router.get("/bad_zone_records", tags=['Stock Calculation'])
async def calculate_bad_zones(country_name: str, tick: str, time_frame: int, last_d_time: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        out_res = {}
        country_dir = getattr(cfg, f'{country_name.lower()}_data_dir')
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        frame = getattr(cfg, f'TIME_FRAMES_{time_frame}')
        for t_fr in frame:
            file_name = f"{country_dir}/latest_data_csv/{tick}_{t_fr}.csv"
            cbz = Calculate_BAD_ZONES(csv_path=file_name, last_d_time=last_d_time)
            out_res[t_fr] = cbz.get_bad_zones_data()

        apiresponce.setMsg("success")
        apiresponce.setResponse(out_res)
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/get_fixed_time_eae_zones", tags=['Stock Calculation'])
async def get_fixed_time_eae_zones(country_name: str, tick: str, time_frame: int, last_d_time: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        out_res = {}
        country_dir = stock_data_dir_config.indian_stock_data_dir
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        ztf = ZONE_TIME_FIXATURE(tick, time_frame, last_d_time, country_dir)
        execute_data = {
            'Buy' : ztf.calculate_and_adjust_dz(),
            'Sell': ztf.calculate_and_adjust_sz()
        }
        analyse_data = ztf.calculate_analyse_eval_overlap()


        # out_res['Buy'] = ztf.calculate_and_adjust_dz()
        # out_res['Sell'] = ztf.calculate_and_adjust_sz()
        out_res['Execute'] = execute_data
        out_res['Analyse'] = analyse_data
        apiresponce.setMsg("success")
        apiresponce.setResponse(out_res)
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce

@router.get("/get_all_time_high_and_previous_high", tags=['Stock Calculation'])
async def get_all_time_high_and_previous_high(country_name: str, tick: str, time_frame: int, last_d_time: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        ut = utility()
        country_dir = getattr(cfg, f'{country_name.lower()}_data_dir')
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        out_res = ut.calculate_all_time_high_previous_high(country_dir, tick, time_frame, last_d_time)
        apiresponce.setMsg("success")
        apiresponce.setResponse(out_res)
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce

@router.get("/get_all_time_high_and_previous_high_future_commodity", tags=['Stock Calculation'])
async def get_all_time_high_and_previous_high_future_commodity(country_name: str, tick: str, exp_str: str, time_frame: int, last_d_time: str, segment: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        ut = utility()
        country_dir = cfg.commodity_data_dir if segment == 'commodity' else cfg.future_data_dir
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        exp_num = exp_str # datetime.strptime(exp_str, "%d-%m-%Y").strftime("%d%m%Y")
        out_res = ut.calculate_all_time_high_previous_high_future_commodity(country_dir, tick, time_frame, exp_num, segment, last_d_time)
        out_res = pyify(out_res)
        apiresponce.setMsg("success")
        apiresponce.setResponse(out_res)
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce



def fill_datetime_gaps(dataframe, time_frame):
    dataframe['time'] = pd.to_datetime(dataframe['time'], dayfirst = True)

    # Generate a DataFrame with all dates between the oldest and newest date in the original DataFrame
    if time_frame == "daily":
        all_dates = pd.DataFrame({
            'time': pd.date_range(start=dataframe['time'].min(), end=dataframe['time'].max(), freq='1D')}
        )
    elif time_frame == "weekly":
        all_dates = pd.DataFrame({
            'time': pd.date_range(start=dataframe['time'].min(), end=dataframe['time'].max(), freq='7D')}
        )
    elif time_frame == "monthly":
        all_dates = pd.DataFrame({
            'time': pd.date_range(start=dataframe['time'].min(), end=dataframe['time'].max(), freq='1M')}
        )
    elif time_frame == "75minute":
        all_dates = pd.DataFrame({
            'time': pd.date_range(start=dataframe['time'].min(), end=dataframe['time'].max(), freq='75min')}
        )
    elif time_frame == "60minute":
        all_dates = pd.DataFrame({
            'time': pd.date_range(start=dataframe['time'].min(), end=dataframe['time'].max(), freq='60min')}
        )
    elif time_frame == "15minute":
        all_dates = pd.DataFrame({
            'time': pd.date_range(start=dataframe['time'].min(), end=dataframe['time'].max(), freq='15min')}
        )

    # Merge the generated DataFrame with the original DataFrame
    merged_df = pd.merge(dataframe, all_dates, on='time', how='outer')

    merged_df.fillna({'open':0 , 'high':0, 'low':0, 'close':0}, inplace=True)
    merged_df = merged_df.sort_values(by='time')


    # print(merged_df.head(10))
    return merged_df


@router.get("/check_price_percentage_across_timeframe", tags=['Stock Calculation'])
async def check_price_percentage_across_timeframe(country_name: str, tick: str, time_frame: int, last_d_time: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        time_list = getattr(cfg, f"TIME_FRAMES_{time_frame}")
        mft = MultiTimeframeTrendCalculator()
        mft._set_symbol_and_timeframe(time_list, tick, last_d_time)
        context = mft.calculate_full_context()
        api_json_context = mft.to_api(context)
        # print(api_responce)
        # country_dir = getattr(cfg, f'{country_name.lower()}_data_dir')
        
        # cal = Calculate_setup_execute(stock_name = tick, time_frame = time_frame, last_dt = last_d_time, country_dir = country_dir)
        # file_name = os.path.join(country_dir, "processed_data_files", f"{tick}_{time_list[-1]}.csv")
        # cmp_ex, cmp_t_stamp = cal.get_cmp_price_tstamp(file_name, last_d_time)
        # mtf_zones = cal.get_mtf_zones()
        # last_candle_dict = cal.get_all_frame_last_candle()

        # mtf_for_decision = {
            # "evaluate": {"dz": mtf_zones["evaluate"]["dz"], "sz": mtf_zones["evaluate"]["sz"]},
            # "analyze":  {"dz": mtf_zones["analyze"]["dz"],  "sz": mtf_zones["analyze"]["sz"]},
            # "execute":  {"dz": mtf_zones["execute"]["dz"],  "sz": mtf_zones["execute"]["sz"]},  # or filtered_exe_dz/sz
        # }

        # price_across_timeframe = check_price_across_timeframes(mtf_for_decision, last_candle_dict, cmp_ex)

        apiresponce.setMsg("success")
        apiresponce.setResponse(api_json_context)
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/check_price_percentage_across_timeframe_future_and_commodity", tags=['Stock Calculation'])
async def check_price_percentage_across_timeframe(country_name: str, tick: str, time_frame: int, exp_dt: str, last_d_time: str, is_future: bool, request: Request):
    apiresponce = APIResponse(request)
    try:
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        if is_future:
            time_list = getattr(stock_logic_config, f"FUTURE_TIME_FRAME_{time_frame}")
        else:
            time_list = getattr(stock_logic_config, f"COMMODITY_TIME_FRAME_{time_frame}")
        mft = MultiTimeframeTrendCalculator()
        numbers = re.findall(r'\d+', exp_dt)
        exp_num = ''.join(numbers)
        # mft._set_symbol_and_timeframe(time_list, tick, last_d_time)
        data_dir = stock_data_dir_config.indian_stock_future_data_dir if is_future else stock_data_dir_config.indian_commodity_data
        mft._set_symbol_and_timeframe_future_and_commodity(time_list, tick, last_d_time, exp_num, data_dir)
        context = mft.calculate_full_context()
        api_json_context = mft.to_api(context)
        # print(api_responce)
        # country_dir = getattr(cfg, f'{country_name.lower()}_data_dir')
        
        # cal = Calculate_setup_execute(stock_name = tick, time_frame = time_frame, last_dt = last_d_time, country_dir = country_dir)
        # file_name = os.path.join(country_dir, "processed_data_files", f"{tick}_{time_list[-1]}.csv")
        # cmp_ex, cmp_t_stamp = cal.get_cmp_price_tstamp(file_name, last_d_time)
        # mtf_zones = cal.get_mtf_zones()
        # last_candle_dict = cal.get_all_frame_last_candle()

        # mtf_for_decision = {
            # "evaluate": {"dz": mtf_zones["evaluate"]["dz"], "sz": mtf_zones["evaluate"]["sz"]},
            # "analyze":  {"dz": mtf_zones["analyze"]["dz"],  "sz": mtf_zones["analyze"]["sz"]},
            # "execute":  {"dz": mtf_zones["execute"]["dz"],  "sz": mtf_zones["execute"]["sz"]},  # or filtered_exe_dz/sz
        # }

        # price_across_timeframe = check_price_across_timeframes(mtf_for_decision, last_candle_dict, cmp_ex)
        apiresponce.setMsg("success")
        apiresponce.setResponse(api_json_context)
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce