from fastapi import APIRouter, Request, HTTPException
from shared.db.api_responce import APIResponse
from shared.db.dbconn import DBConnection
from shared.db.db_model import UserCountryAccess, ExchangeMaster, IndexExchangeMap, Index, CommoditiesMaster
from sqlalchemy.orm import joinedload
import logging
from shared.db.req_model import CreateIndexModel

logger = logging.getLogger()
db = DBConnection()
router = APIRouter()

@router.get("/user-exchanges", tags=["Exchange"])
def get_user_exchange_access(user_id: int, country_id: int, request: Request):
    apiresponce = APIResponse(request)
    try:    
        session = db.get_session()
        country_ids = session.query(UserCountryAccess.country_id).filter(
                UserCountryAccess.user_id == user_id
                    ).distinct().all()
        country_ids = [c.country_id for c in country_ids]

        if not country_ids:
            return HTTPException(status_code=404, detail="No country access found for this user.")
        
        exchanges = session.query(ExchangeMaster).options(
                        joinedload(ExchangeMaster.country)
                    ).filter(
                        ExchangeMaster.country_id.in_(country_ids),
                        ExchangeMaster.is_active == True,
                        ExchangeMaster.country_id == country_id
                    ).all()
        data = [
                {
                    "exchange_id": e.exchange_id,
                    "exchange_code": e.exchange_code,
                    "exchange_name": e.exchange_name,
                    "country_id": e.country_id,
                    "country_name": e.country.country_name if e.country else None
                }
                for e in exchanges
            ]
        session.close()
        apiresponce.setMsg("success")
        apiresponce.setResponse(data)
    except Exception as ex:
        session.rollback()
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce
    

@router.get("/exchange-indexes", tags=["Exchange"])
def get_indexes_by_exchange(exchange_id: int, request: Request):
    apiresponce = APIResponse(request)
    try:
        session = db.get_session()
        index_maps = session.query(IndexExchangeMap).join(Index).filter(
            IndexExchangeMap.exchange_id == exchange_id,
            Index.is_active == True
        ).all()

        if not index_maps:
            return HTTPException(status_code=404, detail="No indexes found for this exchange.")

        apiresponce.setMsg("success")
        apiresponce.setResponse(index_maps)
        session.close()
    except Exception as ex:
        session.rollback()
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce



@router.get("/commodity-instruments", tags=["Commodity"])
async def get_commodity_intruments(request: Request):
    apiresponce = APIResponse(request)
    try:
        session = db.get_session()
        res = session.query(CommoditiesMaster).all()
        apiresponce.setMsg("success")
        apiresponce.setResponse(res)
        session.close()
    except Exception as ex:
        session.rollback()
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/get_exchanges", tags=["Exchange"])
async def get_exchanges(request: Request, country_id: str, exchange_id: str = None):
    apiresponce = APIResponse(request)
    try:
        session = db.get_session()
        if exchange_id == None:
            res = session.query(ExchangeMaster).filter(ExchangeMaster.country_id == country_id, ExchangeMaster.is_active == 1).all()
        else:
            res = session.query(ExchangeMaster).filter(ExchangeMaster.country_id == country_id, ExchangeMaster.is_active == 1, ExchangeMaster.exchange_id == exchange_id).all()
        if res and len(res) > 0:
            apiresponce.setMsg("success")
            apiresponce.setResponse(res)
        else:
            apiresponce.setMsg("failed")
            apiresponce.setResponse("Not found !")
        session.close()
    except Exception as ex:
        session.rollback()
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.post("/add_new_index", tags=['Exchange'])
async def add_new_index(request: Request, model: CreateIndexModel):
    apiresponce = APIResponse(request)
    try:
        
        session = db.get_session()
        valid_exchange_ids = session.query(ExchangeMaster.exchange_id).filter(ExchangeMaster.exchange_id.in_(model.exchange_ids)).all()
        valid_exchange_ids = {idx[0] for idx in valid_exchange_ids}  # Extract IDs from tuples

        invalid_ids = set(model.exchange_ids) - valid_exchange_ids
        if invalid_ids:
            apiresponce.setMsg("invalid exchange")
            apiresponce.setResponse({"invalid_ids": list(invalid_ids)})
            session.close()
            return apiresponce

        row = Index(index_name = model.index_name, y_finance = model.symbol, country_id = model.country_id)
        session.add(row)
        session.commit()
        session.refresh(row)

        exchange_ids = model.exchange_ids

        mapping_entries = [
                    IndexExchangeMap(index_id=row.index_id, exchange_id=idx_id)
                    for idx_id in exchange_ids]
            
        session.add_all(mapping_entries)
        session.commit()
        apiresponce.setMsg("success")
        apiresponce.setResponse({"index_id": row.index_id})
        session.close()
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce