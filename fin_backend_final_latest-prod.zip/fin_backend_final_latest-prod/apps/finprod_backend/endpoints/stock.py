from fastapi import APIRouter, Request, Query
from shared.db.api_responce import APIResponse
from shared.db.req_model import CreateStockModel, GetStockModel
from shared.db.db_model import Index, Ind_StockMaster, Ind_StockIndexMap, Us_StockIndexMap, Us_StockMaster
from apps.finprod_backend.modules.analyze_trend import Trend_Analyzer
from apps.finprod_backend.modules.parse_create_csv import run_conversion, remove_old_data
from apps.finprod_backend.modules.stock_handler import download_single_stock_data, proc_single_tick_item, download_and_store_delta_data, all_downloader_yfinance
from apps.finprod_backend.modules.stock_utils import filter_data_with_buffer, filter_post_data_with_buffer
from shared.db.dbconn import DBConnection
# from apps.finprod_backend.modules.btc_updater import proc_btc_data_and_update
from apps.finprod_backend.data_parser.stock_list import *
from apps.finprod_backend.modules.stock_logic import *
import logging, pandas
from threading import Thread
from datetime import datetime
# from apps.finprod_backend.modules.cal_z import DemandZoneCalculator, SupplyZoneCalculator, ZoneAnalyzer
from scripts.calculate_zones import DemandZoneCalculator, SupplyZoneCalculator, ZoneAnalyzer
from shared.config.settings import Config as cfg
from shared.config.settings import stock_logic_config
import re, ast
import json
from sqlalchemy import text
from dateutil import parser
from data_fetchers.fyers.candle_data import CandleDateFetcher
from data_fetchers.fyers.indian_stock_data_updater import INDIAN_STOCK_DATA_UPDATER


logger = logging.getLogger()
db = DBConnection()
router = APIRouter()

def conv_exp_to_num(exp_dt):
    numbers = re.findall(r'\d+', exp_dt)
        # Join all found numbers into one string
    exp_num = ''.join(numbers)
    return exp_num


@router.get("/search", tags=['Stock Process'])
async def search(request: Request, keyword: str):
    apiresponce = APIResponse(request)
    try:
        query_words = keyword.lower()
        data = cfg.stock_list
        results = [stock for stock in data if stock.startswith(query_words)]
        if results:
            apiresponce.setMsg("success")
            apiresponce.setResponse(results)
        else:
            apiresponce.setMsg("failed")
            apiresponce.setResponse("No data found")
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce

@router.post("/add_new_stock", tags=['Stock Process'])
async def add_new_stock(request: Request, model: CreateStockModel):
    apiresponce = APIResponse(request)
    try:
        
        session = db.get_session()
        valid_index_ids = session.query(Index.index_id).filter(Index.index_id.in_(model.index_ids)).all()
        valid_index_ids = {idx[0] for idx in valid_index_ids}  # Extract IDs from tuples

        invalid_ids = set(model.index_ids) - valid_index_ids
        if invalid_ids:
            apiresponce.setMsg("invalid index")
            apiresponce.setResponse({"invalid_ids": list(invalid_ids)})
            return apiresponce

        if model.country.lower().__contains__('us'):
            db_order = Us_StockMaster(stock_tick=model.stock_name, y_finance=model.y_stock_name)
        else:
            db_order = Ind_StockMaster(stock_tick=model.stock_name, y_finance=model.y_stock_name)
        session.add(db_order)
        session.commit()
        session.refresh(db_order)

        index_ids = model.index_ids

        if model.country.lower().__contains__('us'):
            mapping_entries = [
                        Us_StockIndexMap(stock_id=db_order.id, index_id=idx_id)
                        for idx_id in index_ids]
        else:
            mapping_entries = [
                        Ind_StockIndexMap(stock_id=db_order.id, index_id=idx_id)
                        for idx_id in index_ids]
        session.add_all(mapping_entries)
        session.commit()
        apiresponce.setMsg("success")
        apiresponce.setResponse({"stock_id": db_order.id, "country" : model.country})
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce

@router.get("/process_new_stock", tags=['Stock Process'])
async def process_new_stock(country_name: str, stock_id: int, request: Request):
    apiresponce = APIResponse(request)
    try:
        country_dir = getattr(cfg, f'{country_name.lower()}_data_dir')
        if country_name.lower().__contains__('us'):
            stock_res = db.raw_query(text(f"select * from us_stock_master where id={stock_id}"))
        else:
            stock_res = db.raw_query(text(f"select * from ind_stock_master where id={stock_id}"))
        y_fin_stock_name = stock_res[0].get('fyers_symbol')
        stock_tick_nn = str(stock_res[0].get('stock_tick')).lower()

        # download_single_stock_data(stock_tick_nn, y_fin_stock_name, country_dir)
        # proc_single_tick_item(stock_tick_nn, country_dir)

        cls = CandleDateFetcher()
        symbol = y_fin_stock_name
        logger.info(f"Processing stock: {stock_tick_nn} Daily")
        cls.fetch_candle_data_custom_resolution(stock_tick=stock_tick_nn, 
                                                symbol=symbol, 
                                                start_date="2020-01-01", 
                                                resolution="1D")
        logger.info(f"Processing stock: {stock_tick_nn} 60")
        cls.fetch_candle_data_custom_resolution(stock_tick=stock_tick_nn, 
                                                symbol=symbol, 
                                                start_date="2020-01-01", 
                                                resolution="60")
        logger.info(f"Processing stock: {stock_tick_nn} 15")
        cls.fetch_candle_data_custom_resolution(stock_tick=stock_tick_nn, 
                                                symbol=symbol, 
                                                start_date="2020-01-01", 
                                                resolution="15")
        logger.info(f"Processing stock: {stock_tick_nn} 5")
        cls.fetch_candle_data_custom_resolution(stock_tick=stock_tick_nn, 
                                                symbol=symbol, 
                                                start_date="2020-01-01", 
                                                resolution="5")
        obj = INDIAN_STOCK_DATA_UPDATER()
        obj.create_75munite_from_15munite(f"{stock_tick_nn}_fifteen.csv")
        obj.create_monthly_and_weekly_from_daily(f"{stock_tick_nn}_daily.csv", 'W')
        obj.create_monthly_and_weekly_from_daily(f"{stock_tick_nn}_daily.csv", 'ME')
        obj.create_25munite_from_5munite(f"{stock_tick_nn}_five.csv")
        obj.create_125munite_from_5munite(f"{stock_tick_nn}_five.csv")

        logger.info(f"Download complete starting process")
        # proc_single_tick_item(stock_tick_nn, country_dir)
        
        apiresponce.setMsg("success")
    except Exception as ex:
        logger.error(ex, exc_info=1, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce

@router.get("/process_stock_delta_update", tags=['Stock Process'])
async def process_stock_delta_update(stock_id: int, country_name: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        if country_name.lower().__contains__('us'):
            c_name = 'us_stock_master'
        else:
            c_name = 'ind_stock_master'

        stock_res = db.raw_query(text(f"select * from {c_name} where id={stock_id}"))
        country_dir = getattr(cfg, f'{country_name.lower()}_data_dir')
        y_fin_stock_name = stock_res[0].get('y_finance')
        stock_tick_nn = str(stock_res[0].get('stock_tick')).lower()
        # download_single_stock_data(stock_tick_nn, y_fin_stock_name)
        download_and_store_delta_data(stock_tick_nn, y_fin_stock_name, country_dir)
        file_list = os.listdir(f'{country_dir}/latest_data_csv')
        input_dir = os.path.join(country_dir, "latest_data_csv")
        output_dir = os.path.join(country_dir, "processed_data_files")
        for ff in file_list:
            if str(ff).__contains__(stock_tick_nn):
                proc_delta_stock_items(ff, input_dir, output_dir)
        apiresponce.setMsg("success")
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce

@router.get("/get_list_of_stock", tags=['Stock Process'])
async def get_list_of_stock(country_name: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        stock_list = list_of_stocks(country_name)
        apiresponce.setMsg("success")
        apiresponce.setResponse(stock_list)
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce

@router.get("/get_sample_stock_data", tags=['Stock Process'])
async def get_sample_stock_data(request: Request):
    apiresponce = APIResponse(request)
    try:
        df = pandas.read_csv("./apps/finprod_backend/processed_data_files/hdfc_15minute.csv")
        data = df.map(lambda x: None if isinstance(x, float) and (x == float('inf') or x == float('-inf') or x != x) else x)
        data_dict = data.to_dict(orient='records')
        json_str = json.dumps(data_dict)
        json_dict = json.loads(json_str)
        apiresponce.setMsg("success")
        apiresponce.setResponse(json_dict)
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/parse_latest_data_csv", tags=['Stock Process'])
async def parse_latest_data_csv(request: Request):
    apiresponce = APIResponse(request)
    try:
        run_conversion()
        remove_old_data()
        apiresponce.setMsg("success")
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce



@router.get("/process_stock_items", tags=['Stock Process'])
async def process_stock_items(request: Request):
    apiresponce = APIResponse(request)
    try:
        th_list = []
        input_dir = "latest_data_csv"
        output_dir = "processed_data_files"
        for stock_item in os.listdir(input_dir):
            # proc_all_stock_items(stock_item, input_dir, output_dir)
            Th = Thread(target=proc_all_stock_items, args=(stock_item, input_dir, output_dir))
            th_list.append(Th)
            Th.start()
        for threa in th_list:
            threa.join()
        print("process_complete............*********************************")
        apiresponce.setMsg("success")
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce



@router.get("/process_all_delta_stock_items", tags=['Stock Process'])
async def process_delta_stock_items(request: Request):
    apiresponce = APIResponse(request)
    try:
        input_dir = "latest_data_csv"
        output_dir = "processed_data_files"
        all_downloader_yfinance()
        for stock_item in os.listdir(input_dir):
            proc_delta_stock_items(stock_item, input_dir, output_dir)
        apiresponce.setMsg("success")
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce



@router.get("/view_order_candlestick", tags=['Stock Process'])
async def view_order_condlestick(request: Request, order_id : str, country_name: str, exchange_type: str):
    apiresponce = APIResponse(request)
    try:
        if exchange_type.lower() == 'commodity':
            country_dir = cfg.commodity_data_dir
            res = db.raw_query(text(f"select * from commodity_order_master where order_id={order_id}"))
            # print("Null", res[0].get('completed_on'))
            exp_num = res[0].get('expiry_date') #conv_exp_to_num()
            formatted_date = exp_num #datetime.strptime(exp_num, "%d-%m-%Y").strftime("%d%m%Y")
            time_frame = res[0].get('time_frame')
            exe_frame = getattr(stock_logic_config, f"COMMODITY_TIME_FRAME_{time_frame}")
            # file_name = f"{country_dir}/latest_data_csv/{res[0].get('stock_tick')}_{formatted_date}_{exe_frame}.csv"

        elif exchange_type.lower() == 'futures':
            country_dir = cfg.future_data_dir
            res = db.raw_query(text(f"select * from future_order_master where order_id={order_id};"))
            # print("Null", res[0].get('completed_on'))
            print(res)
            exp_num = res[0].get('expiry_date')
            formatted_date = exp_num #datetime.strptime(exp_num, "%d-%m-%Y").strftime("%d%m%Y")
            time_frame = res[0].get('time_frame')
            exe_frame = getattr(stock_logic_config, f"FUTURE_TIME_FRAME_{time_frame}")
            # file_name = f"{country_dir}/latest_data_csv/{res[0].get('stock_tick')}_{formatted_date}_{exe_frame}.csv"
            
        elif exchange_type.lower() == 'cash':
            country_dir = cfg.india_data_dir
            res = db.raw_query(text(f"select * from order_master where order_id={order_id}"))
            print("Null", res[0].get('completed_on'))
            time_frame = res[0].get('time_frame')
            exe_frame = getattr(stock_logic_config, f"TIME_FRAME_EXE_{time_frame}")
            # file_name = f"{country_dir}/latest_data_csv/{res[0].get('stock_tick')}_{exe_frame}.csv"
        else:
            country_dir = cfg.us_data_dir
            res = db.raw_query(text(f"select * from order_master where order_id={order_id}"))
            print("Null", res[0].get('completed_on'))
            time_frame = res[0].get('time_frame')
            exe_frame = getattr(stock_logic_config, f"TIME_FRAME_EXE_{time_frame}")
            # file_name = f"{country_dir}/latest_data_csv/{res[0].get('stock_tick')}_{exe_frame}.csv"
        out_data = {}
        for frames in exe_frame:
            if exchange_type.lower() == "futures" or exchange_type.lower() == "commodity":
                file_name = f"{country_dir}/latest_data_csv/{res[0].get('stock_tick')}_{formatted_date}_{frames}.csv"
            else:
                file_name = f"{country_dir}/latest_data_csv/{res[0].get('stock_tick')}_{frames}.csv"
            start_time = parser.parse(res[0].get("purchased_cmp_date")) 
            #datetime.strptime(res[0].get("purchased_cmp_date"), "%Y-%m-%dT%H:%M") 
            adjustment = 180
            df_res_pre = filter_data_with_buffer(file_name, start_time, start_time, 180, 0)
            if res[0].get('completed_on') is not None:
                end_time = datetime.strptime(res[0].get("completed_on"), '%Y-%m-%dT%H:%M:%S.%f')
                # df_res_post = filter_data_with_buffer(file_name, start_time, end_time, 90, adjustment)
                df_res_post = filter_post_data_with_buffer(file_name, start_time, end_time, 0, adjustment)
            else:
                print("pending.....................")
                end_time = datetime.now()
                # df_res_post = filter_data_with_buffer(file_name, start_time, end_time, 90, adjustment)
                df_res_post = filter_post_data_with_buffer(file_name, start_time, end_time, 0, adjustment)
                # print(df_res_post)
            
            df_data = {
                'PRE' : df_res_pre,
                'POST' : df_res_post
            }
            out_data[frames] = df_data
        apiresponce.setMsg("success")
        apiresponce.setResponse(out_data)    
    except Exception as ex:
        logger.error(ex, stack_info=True, exc_info=1)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce

@router.get("/view_auto_order_candlestick", tags=['Stock Process'])
async def view_auto_order_condlestick(request: Request, order_id : str, country_name: str):
    apiresponce = APIResponse(request)
    try:
        out_res = {}
        country_dir = getattr(cfg, f'{country_name.lower()}_data_dir')
        res = db.raw_query(text(f"select * from auto_order_master where order_id={order_id}"))
        print("Null", res[0].get('completed_on'))
        time_frame = res[0].get('time_frame')
        exe_frame = getattr(cfg, f"TIME_FRAMES_{time_frame}")

        for frames in exe_frame:
            file_name = f"{country_dir}/latest_data_csv/{res[0].get('stock_tick')}_{frames}.csv"
            start_time = datetime.strptime(res[0].get("purchased_cmp_date"), "%Y-%m-%dT%H:%M") 
            adjustment = 180
            df_res_pre = filter_data_with_buffer(file_name, start_time, start_time, 180, 0)
            if res[0].get('completed_on') is not None:
                order_status = re.sub(r"Timestamp\('([^']+)'\)", r"'\1'", res[0].get('order_status')) 
                order_status = ast.literal_eval(order_status)
                # end_time = datetime.strptime(res[0].get("completed_on"), '%Y-%m-%dT%H:%M:%S.%f')
                end_time = datetime.now()
                if order_status['status'] == 'success':
                    df_res_post = filter_post_data_with_buffer(file_name, start_time, end_time, 0, adjustment)
                else:
                    end_time = datetime.now()
                    df_res_post = filter_post_data_with_buffer(file_name, start_time, end_time, 0, adjustment)
            else:
                end_time = datetime.now()
                df_res_post = filter_post_data_with_buffer(file_name, start_time, end_time, 0, adjustment)
            df_data = {
                'PRE' : df_res_pre,
                'POST' : df_res_post
            }
            out_res[frames] = df_data
        apiresponce.setMsg("success")
        apiresponce.setResponse(out_res)
    except Exception as ex:
        logger.error(ex, stack_info=True, exc_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce

@router.get("/get_hh_and_ll", tags=['Stock Process'])
async def get_hh_and_ll(tick: str, time_frame: int, last_d_time: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        at = Trend_Analyzer(stock_tick=tick, time_frame=time_frame, last_dt_time=last_d_time)
        out_put = at.find_higher_high_and_lower_low()
        apiresponce.setMsg("success")
        apiresponce.setResponse(out_put)    
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce

@router.get('/calculate_stock_trend')
async def calculate_stock_trend(country_name: str, tick: str, time_frame: int, last_d_time: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        t_frame = getattr(cfg, f"TIME_FRAMES_{time_frame}")[1]
        country_dir = getattr(cfg, f'{country_name.lower()}_data_dir')
        file_name = f"{country_dir}/processed_data_files/{tick}_{t_frame}.csv"
        dz_cal = DemandZoneCalculator(file_name, tick, last_d_time, is_execute=False)
        sz_cal = SupplyZoneCalculator(file_name, tick, last_d_time, is_execute=False)
        z_ana = ZoneAnalyzer(dz_cal, sz_cal)
        trend = z_ana.calculate_overall_trend()
        apiresponce.setMsg("success")
        apiresponce.setResponse(trend)    
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce



# @router.get('/update_btc_usd_data', tags=['BTC-FUT'])
# async def update_btc_usd_data(request: Request):
#     apiresponce = APIResponse(request)
#     try:
#         proc_btc_data_and_update()
#         apiresponce.setMsg("success")
#     except Exception as ex:
#         logger.error(ex)
#         apiresponce.setMsg("failed")
#         apiresponce.setResponse(str(ex))
#     return apiresponce


@router.get('/get_stock_info', tags=['Stocks-process'])
async def get_stock_info(request: Request, country_name: str, stock_tick: str = None):
    apiresponce = APIResponse(request)
    try:
        ddt = {}
        if country_name.lower().__contains__('us'):
            res = db.raw_query(text('select * from us_stock_master where is_active=1;'))
        else:
            res = db.raw_query(text('select * from ind_stock_master where is_active=1;'))
        if stock_tick:
            for items in res:
                if str(items['stock_tick']).lower() == stock_tick.lower():
                    ddt = items 
                    break
        else:
            ddt = res
        apiresponce.setMsg("success")
        apiresponce.setResponse(ddt)
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.post('/get_stock_list', tags=['Stocks-process'])
async def get_stock_list(request: Request, model: GetStockModel):
    apiresponce = APIResponse(request)
    try:             
        if isinstance(model.index_id, int) == False:
            try:
                model.index_id = int(model.index_id)
            except:
                model.index_id = "all"
        
        if isinstance(model.page_no, int) == False:
            try:
                model.page_no = int(model.page_no)
            except:
                model.page_no = None
            
        if model.country_name.lower() == 'us':
            table_name = 'us_stock_master'
            index_map_table = 'us_stock_index_map'
        else:
            table_name = 'ind_stock_master'
            index_map_table = 'ind_stock_index_map'
        
        if model.index_id == "all":
            total_stocks = db.raw_query(text(f"""select ism.id, ism.stock_tick, ism.y_finance, ism.is_active, ism.is_proc
                                  from {table_name} ism
                                  where ism.is_active = 1 
                                  order by ism.stock_tick"""))
            if total_stocks == None:
                total_stocks = []
            
            stocks = []
            if (model.stock_tick == None or model.stock_tick == 'null' or model.stock_tick == '') and (model.page_no == None or model.page_no == 'null' or model.page_no == ''):
                # print("case 1")
                model.page_no = 1
                offset = (model.page_no - 1) * model.limit
                stocks = db.raw_query(text(f"""select ism.id, ism.stock_tick, ism.y_finance, ism.is_active, ism.is_proc
                                  from {table_name} ism
                                  where ism.is_active = 1 
                                  order by ism.stock_tick limit {model.limit} offset {offset}"""))
                
            elif (model.stock_tick == None or model.stock_tick == 'null' or model.stock_tick == '') and (model.page_no != None and model.page_no != 'null' and model.page_no != ''):
                # print("case 2")
                offset = (model.page_no - 1) * model.limit
                stocks = db.raw_query(text(f"""select ism.id, ism.stock_tick, ism.y_finance, ism.is_active, ism.is_proc
                                  from {table_name} ism
                                  where ism.is_active = 1 
                                  order by ism.stock_tick limit {model.limit} offset {offset}"""))
            
            elif (model.stock_tick != None and model.stock_tick != 'null' and model.stock_tick != '') and (model.page_no == None or model.page_no == 'null' or model.page_no == ''):
                # print("case 3")
                found = False
                for i in range(len(total_stocks)):
                    if model.stock_tick.lower() in total_stocks[i]['stock_tick'].lower():
                        found = i+1
                        break
                #print("found:", found)
                if found:
                    model.page_no = ((found - 1) // model.limit) + 1
                    offset = (model.page_no - 1) * model.limit
                    stocks = total_stocks[offset : offset + model.limit]
                    # stocks = db.raw_query(text(f"""select ism.id, ism.stock_tick, ism.y_finance, ism.is_active, ism.is_proc
                    #               from {table_name} ism
                    #               where ism.is_active = 1 
                    #               order by ism.stock_tick limit {model.limit} offset {offset}"""))
            
            elif (model.stock_tick != None and model.stock_tick != 'null' and model.stock_tick != '') and (model.page_no != None and model.page_no != 'null' and model.page_no != ''):
                # print("case 4")
                offset = (model.page_no - 1) * model.limit
                stocks = db.raw_query(text(f"""select ism.id, ism.stock_tick, ism.y_finance, ism.is_active, ism.is_proc
                                  from {table_name} ism
                                  where ism.is_active = 1 
                                  order by ism.stock_tick limit {model.limit} offset {offset}"""))
                

        else:
            total_stocks = db.raw_query(text(f"""select ism.id, ism.stock_tick, ism.y_finance, ism.is_active, ism.is_proc
                                  from {table_name} ism
                                  inner join {index_map_table} isim on ism.id = isim.stock_id
                                  where ism.is_active = 1 
                                  and isim.index_id = {model.index_id}
                                  order by ism.stock_tick"""))
            if total_stocks == None:
                total_stocks = []

            stocks = []
            if (model.stock_tick == None or model.stock_tick == 'null' or model.stock_tick == '') and (model.page_no == None or model.page_no == 'null' or model.page_no == ''):
                # print("case 5")
                model.page_no = 1
                offset = (model.page_no - 1) * model.limit
                stocks = db.raw_query(text(f"""select ism.id, ism.stock_tick, ism.y_finance, ism.is_active, ism.is_proc
                                  from {table_name} ism
                                  inner join {index_map_table} isim on ism.id = isim.stock_id
                                  where ism.is_active = 1 
                                  and isim.index_id = {model.index_id}
                                  order by ism.stock_tick limit {model.limit} offset {offset}"""))
                
            elif (model.stock_tick == None or model.stock_tick == 'null' or model.stock_tick == '') and (model.page_no != None and model.page_no != 'null' and model.page_no != ''):
                # print("case 6")
                offset = (model.page_no - 1) * model.limit
                stocks = db.raw_query(text(f"""select ism.id, ism.stock_tick, ism.y_finance, ism.is_active, ism.is_proc
                                  from {table_name} ism
                                  inner join {index_map_table} isim on ism.id = isim.stock_id
                                  where ism.is_active = 1 
                                  and isim.index_id = {model.index_id}
                                  order by ism.stock_tick limit {model.limit} offset {offset}"""))
            
            elif (model.stock_tick != None and model.stock_tick != 'null' and model.stock_tick != '') and (model.page_no == None or model.page_no == 'null' or model.page_no == ''):
                # print("case 7")
                found = False
                for i in range(len(total_stocks)):
                    if model.stock_tick.lower() in total_stocks[i]['stock_tick'].lower():
                        found = i+1
                        break
                #print("found:", found)
                if found:
                    model.page_no = ((found - 1) // model.limit) + 1
                    offset = (model.page_no - 1) * model.limit
                    stocks = total_stocks[offset : offset + model.limit]
                    # stocks = db.raw_query(text(f"""select ism.id, ism.stock_tick, ism.y_finance, ism.is_active, ism.is_proc
                    #               from {table_name} ism
                    #               inner join {index_map_table} isim on ism.id = isim.stock_id
                    #               where ism.is_active = 1 
                    #               and isim.index_id = {model.index_id}
                    #               order by ism.stock_tick limit {model.limit} offset {offset}"""))
            
            elif (model.stock_tick != None and model.stock_tick != 'null' and model.stock_tick != '') and (model.page_no != None and model.page_no != 'null' and model.page_no != ''):
                # print("case 8")
                offset = (model.page_no - 1) * model.limit
                stocks = db.raw_query(text(f"""select ism.id, ism.stock_tick, ism.y_finance, ism.is_active, ism.is_proc
                                  from {table_name} ism
                                  inner join {index_map_table} isim on ism.id = isim.stock_id
                                  where ism.is_active = 1 
                                  and isim.index_id = {model.index_id}
                                  order by ism.stock_tick limit {model.limit} offset {offset}"""))
        
        
        if stocks == None:
            stocks = []
        apiresponce.setMsg("success")
        apiresponce.setResponse({"total_stocks": len(total_stocks), "stocks": stocks, "page_no": model.page_no})
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.delete('/delete_stock', tags=['Stocks-process'])
async def delete_stock(request: Request, country_name: str, stock_id: int):
    apiresponce = APIResponse(request)
    try:
        session = db.get_session()
        if country_name.lower() == 'us':
            res1 = session.query(Us_StockIndexMap).filter(Us_StockIndexMap.stock_id == stock_id).all()           
            res2 = session.query(Us_StockMaster).filter(Us_StockMaster.id == stock_id, Us_StockMaster.is_active == 1).all()
        elif country_name.lower() == 'india':
            res1 = session.query(Ind_StockIndexMap).filter(Ind_StockIndexMap.stock_id == stock_id).all()
            res2 = session.query(Ind_StockMaster).filter(Ind_StockMaster.id == stock_id, Ind_StockMaster.is_active == 1).all()
        else:
            res1 = session.query(Ind_StockIndexMap).filter(Ind_StockIndexMap.stock_id == stock_id).all()
            res2 = session.query(Ind_StockMaster).filter(Ind_StockMaster.id == stock_id, Ind_StockMaster.is_active == 1).all()
        
        for item in res1:
            session.delete(item)
            session.commit()
        #res2[0].is_active = 0
        #session.add(res2[0])
        session.delete(res2[0])
        session.commit()
        session.close()        
        apiresponce.setMsg("success")
        apiresponce.setResponse("Stock deleted successfully")
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get('/change_stock_status', tags=['Stocks-process'])
async def change_stock_status(request: Request, country_name: str, stock_id: int, status: bool):
    apiresponce = APIResponse(request)
    try:
        session = db.get_session()
        if country_name.lower() == 'us':
            res = session.query(Us_StockMaster).filter(Us_StockMaster.id == stock_id, Us_StockMaster.is_active == 1).all()
        elif country_name.lower() == 'india':
            res = session.query(Ind_StockMaster).filter(Ind_StockMaster.id == stock_id, Ind_StockMaster.is_active == 1).all()
        else:
            res = session.query(Ind_StockMaster).filter(Ind_StockMaster.id == stock_id, Ind_StockMaster.is_active == 1).all()
        if res and len(res) > 0:
            res[0].is_proc = status
            session.add(res[0])
            session.commit()
            apiresponce.setMsg("success")
            apiresponce.setResponse("Stock status changed successfully")
        else:
            apiresponce.setMsg("failed")
            apiresponce.setResponse("Stock not found")
        session.close()
        db.close_engine()        
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce