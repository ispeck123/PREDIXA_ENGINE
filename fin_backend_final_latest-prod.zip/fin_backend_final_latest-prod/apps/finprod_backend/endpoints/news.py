from fastapi import APIRouter, Request
from shared.db.api_responce import APIResponse
import feedparser
import logging
from sqlitedict import SqliteDict

logger = logging.getLogger()

router = APIRouter()

RSS_FEED_URL = "https://news.google.com/rss/search?q=stock+market+india&hl=en-IN&gl=IN&ceid=IN:en"

PUBLISHER_DOMAIN_MAP = {
    "The Economic Times": "economictimes.indiatimes.com",
    "Mint": "livemint.com",
    "The Times of India": "timesofindia.indiatimes.com",
    "Equitymaster": "equitymaster.com",
    "NDTV Profit": "profit.ndtv.com",
    "The Siasat Daily": "siasat.com",
    "Outlook Business": "business.outlookindia.com",
    "India Today": "indiatoday.in",
    "Business Standard": "business-standard.com",
    "Moneycontrol": "moneycontrol.com",
    "CNBCTV18": "cnbctv18.com",
    "BusinessLine": "thehindubusinessline.com",
    "Reuters": "reuters.com",
    "Reuters India": "in.reuters.com",
    "The Financial Express": "financialexpress.com",
    "MSN": "msn.com",
    "Upstox": "upstox.com",
    "Samco": "samco.in"
}

def get_publisher(entry):
    if hasattr(entry, 'source'):
        publisher = entry.source.title
    elif 'title' in entry and '-' in entry.title:
        # Heuristic: Sometimes the publisher is in the title
        publisher = entry.title.split('-')[-1].strip()
    else:
        publisher = "Unknown"
    # print(publisher)  # fallback logo
    return publisher

def get_publisher_logo(publisher: str) -> str:
    domain = PUBLISHER_DOMAIN_MAP.get(publisher)
    if domain:
        return f"https://www.google.com/s2/favicons?domain={domain}&sz=64"
    else:
        return "https://st2.depositphotos.com/6789684/12262/v/450/depositphotos_122620866-stock-illustration-illustration-of-flat-icon.jpg"


@router.get("/market-news")
def get_market_news(request: Request):
    apiresponce = APIResponse(request)
    try:
        feed = feedparser.parse(RSS_FEED_URL)
        news_items = []
        for entry in feed.entries:
            publisher = get_publisher(entry)
            logo = get_publisher_logo(publisher)
            news_items.append({
                "title": entry.title,
                "link": entry.link,
                "published": entry.published, 
                "publisher": publisher,
                "logo": logo
            })
        apiresponce.setMsg('success')
        apiresponce.setResponse({"news": news_items})
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/short_term_trading_news")
def short_term_trading_news(request: Request):
    apiresponce = APIResponse(request)
    try:
        try:
            db = SqliteDict("finprod.sqlite")
            print(db["short_term_trading_news"])
            print(type(db["short_term_trading_news"]))
            news = db["short_term_trading_news"]
            db.close()
        except:
            news = {}
        if "stocks" in news:
            if len(news["stocks"]) > 0:
                apiresponce.setMsg('success')
                apiresponce.setResponse({"news": news["stocks"]})
            else:
                apiresponce.setMsg("failed")
                apiresponce.setResponse("Not found")
        elif len(news) > 0:
            apiresponce.setMsg('success')
            apiresponce.setResponse({"news": news})
        else:
            apiresponce.setMsg("failed")
            apiresponce.setResponse("Not found")
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce   