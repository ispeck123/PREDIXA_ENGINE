from Config import Config as cfg
from datetime import datetime, timedelta
from modules.parse_create_csv import dump_csv
from modules.dbhandler import DBConnection
# from modules.dbconn import raw_query
from modules.parse_create_csv import create_75munite_from_15munite
from pathlib import Path
import pandas as pd
import yfinance as yf
import logging
import os, time


logger = logging.getLogger()

download_time_frames = ['1mo', '1wk', '1d', '60m', '15m']
frame_name_dict = {
    '1mo': 'monthly', 
    '1wk': 'weekly', 
    '1d': 'daily',
    '60m': 'sixty', 
    '15m': 'fifteen'
}

time_vals = ['9:15:00', '10:30:00', '11:45:00', '13:00:00', '14:15:00']


def return_now_and_previous_date(frame: str):
    now_date = datetime.now()
    if frame == '1mo' or frame == '1wk' or frame == '1d':
        start_date = '2020-01-01'
    elif frame == '60m':
        start_date = now_date - timedelta(days=729)
    elif frame == '15m':
        start_date = now_date - timedelta(days=59)
    return now_date, start_date

def proc_all_75():
    ll = os.listdir('latest_data_csv')
    for items in ll:
        if items.__contains__('fifteen'):
            # full_path = os.path.join('latest_data_csv', items)
            create_75munite_from_15munite(items)

def get_stock_details():
    nn_stock_list = []
    nn_y_fin_stock_list = []
    dbc = DBConnection()
    res = dbc.raw_query("select * from ind_stock_master where is_active=1;")
    dbc.close_engine()
    for stock_details in res:
        nn_stock_list.append(stock_details.get('stock_tick'))
        nn_y_fin_stock_list.append(stock_details.get('y_finance'))
    return nn_stock_list, nn_y_fin_stock_list

def create_custom_candles(df):
    results = []
    start_index = 0
    while start_index < len(df):
        # Create a sub-DataFrame for the next 5 rows (75 minutes)
        end_index = min(start_index + 5, len(df))  # Ensure not to go out of bounds
        sub_df = df.iloc[start_index:end_index]
        first_time = sub_df.index[0]
        new_row = {
            'tradeDate': first_time,
            'open': sub_df['open'].iloc[0],  # First open in the interval
            'high': sub_df['high'].max(),     # Maximum high in the interval
            'low': sub_df['low'].min(),       # Minimum low in the interval
            'close': sub_df['close'].iloc[-1],# Last close in the interval
            'qty': sub_df['qty'].sum()        # Sum of quantity traded in the interval
        }
        results.append(new_row)
        start_index += 5
    df_resampled = pd.DataFrame(results)
    df_resampled['timestamp'] = df['tradeDate']
    df_resampled.set_index('timestamp', inplace=True)
    
    return df_resampled


def get_stock_data(ticker, start_date, end_date, interval='1d'):
    """
    Fetch stock data from Yahoo Finance.

    Parameters:
    ticker (str): Stock symbol (e.g., 'AAPL' for Apple).
    start_date (str): Start date in the format 'YYYY-MM-DD'.
    end_date (str): End date in the format 'YYYY-MM-DD'.
    interval (str): Data frequency (valid intervals: '1m', '2m', '5m', '15m', '30m', '60m', '90m', '1d', '5d', '1wk', '1mo', '3mo').

    Returns:
    DataFrame: Stock data.
    """
    # print(ticker)
    stock = yf.download(ticker, start=start_date, end=end_date, interval=interval)
    # print(stock.tail(5))
    print("/////////////////////////////////////////")
    selected_columns = ['Open', 'High', 'Low', 'Close', 'Volume']
    df_selected = stock.loc[:, (selected_columns, ticker)]
    df_selected.columns = df_selected.columns.droplevel(1)
    print(df_selected.tail(5))
    return df_selected

def format_stock_data(stock_data: pd.DataFrame, tick: str, interval: str):
    df = stock_data.rename(columns={
            'Open': 'open',
            'High': 'high',
            'Low': 'low',
            'Close': 'close',
            'Volume': 'qty',  # Temporarily renaming to tradeTime, will replace with actual times in step 2
            #'Adj Close': 'tradeTime'
        })
    df.index = pd.to_datetime(stock_data.index)
    df.index = df.index.tz_convert('Asia/Kolkata')
    df['tradeTime'] = df.index.strftime('%H:%M:%S')
    df['tradeDate'] = df.index.strftime('%d/%m/%Y %H:%M:%S')
    df = df.reset_index(drop=True)[['open', 'high', 'low', 'close', 'qty', 'tradeTime', 'tradeDate']]
    # print(df.head())
    df['tradeDate'] = pd.to_datetime(df['tradeDate'], dayfirst = True)
    out_file_name = f"./latest_data_csv/{tick}_{frame_name_dict[interval]}.csv"
    prev_df = pd.read_csv(out_file_name)
    last_avl_stamp = pd.to_datetime(prev_df.iloc[-1]['tradeDate'], dayfirst=True)
    update_df = df[df['tradeDate'] > last_avl_stamp]
    # update_df['tradeDate'] = update_df['tradeDate'].dt.strftime('%d/%m/%Y %H:%M:%S')
    # update_df.loc[:, 'tradeDate'] = update_df['tradeDate'].dt.strftime('%d/%m/%Y %H:%M:%S')
    # dataframe[dataframe['tradeDate'] > date_obj]
    update_df = update_df.reset_index(drop=True)[['open', 'high', 'low', 'close', 'qty', 'tradeTime', 'tradeDate']]
    comb_df = pd.concat([prev_df, update_df], ignore_index=True)
    comb_df = prev_df.reset_index(drop=True)[['open', 'high', 'low', 'close', 'qty', 'tradeTime', 'tradeDate']]
    comb_df["tradeDate"] = pd.to_datetime(comb_df["tradeDate"], dayfirst=True).dt.strftime("%d/%m/%Y %H:%M:%S")
    # prev_df['tradeDate'] = pd.to_datetime(prev_df['tradeDate'], errors='coerce')
    # prev_df['tradeDate'] = prev_df['tradeDate'].dt.strftime('%d/%m/%Y %H:%M:%S') 
    comb_df.to_csv(out_file_name)
    print("successfully created {}".format(out_file_name))

def format_all_stock_data(stock_data: pd.DataFrame, tick: str, interval: str):
    # Rename columns for standardization
    df = stock_data.rename(columns={
        'Open': 'open',
        'High': 'high',
        'Low': 'low',
        'Close': 'close',
        'Volume': 'qty',
        #'Adj Close': 'tradeTime'
    })
    
    # Ensure the index is a proper datetime format
    try:
        df.index = pd.to_datetime(stock_data.index, errors='coerce')
    except Exception as e:
        raise ValueError("Error converting index to datetime.") from e
    
    # Convert and format datetime explicitly
    df['tradeTime'] = df.index.strftime('%H:%M:%S')  # Extract time in HH:MM:SS
    df['tradeDate'] = df.index.strftime('%d/%m/%Y %H:%M:%S')  # Extract date in desired format

    # Verify and enforce the tradeDate format
    df['tradeDate'] = pd.to_datetime(df['tradeDate'], format='%d/%m/%Y %H:%M:%S', errors='coerce')
    if df['tradeDate'].isnull().any():
        raise ValueError("Invalid datetime values detected in 'tradeDate'.")
    
    # Convert tradeDate back to string in the required format
    df['tradeDate'] = df['tradeDate'].dt.strftime('%d/%m/%Y %H:%M:%S')

    # Reorganize the DataFrame
    df = df.reset_index(drop=True)[['open', 'high', 'low', 'close', 'qty', 'tradeTime', 'tradeDate']]
    
    # Save to CSV
    out_file_name = f"./latest_data_csv/{tick}_{frame_name_dict[interval]}.csv"
    df.to_csv(out_file_name, index=False)
    print(f"Successfully created {out_file_name}")


def format_and_store_delta_stock_data(stock_data: pd.DataFrame, tick: str, interval: str):
    # Check if necessary columns exist
    required_columns = ['Open', 'High', 'Low', 'Close', 'Volume']
    for col in required_columns:
        if col not in stock_data.columns:
            raise ValueError(f"Missing required column: {col}")
    
    # Rename columns
    df = stock_data.rename(columns={
        'Open': 'open',
        'High': 'high',
        'Low': 'low',
        'Close': 'close',
        'Volume': 'qty',  
        #'Adj Close': 'tradeTime'  # Temporary column name
    })
    
    # Convert index to datetime
    df.index = pd.to_datetime(stock_data.index)
    df['tradeTime'] = df.index.strftime('%H:%M:%S')
    df['tradeDate'] = df.index.strftime('%d/%m/%Y %H:%M:%S')
    
    # Reorder columns
    df = df.reset_index(drop=True)[['open', 'high', 'low', 'close', 'qty', 'tradeTime', 'tradeDate']]
    df['tradeDate'] = pd.to_datetime(df['tradeDate'], format='%d/%m/%Y %H:%M:%S', errors='coerce')
    # print(df.tail())
    # print("33333333333333333333333333333333333333333333333333333333333333333333")
    # Define output file path
    output_dir = Path("./latest_data_csv")
    output_dir.mkdir(parents=True, exist_ok=True)
    out_file_name = output_dir / f"{tick}_{frame_name_dict[interval]}.csv"
    
    # Check if the file already exists
    if out_file_name.exists():
        # Load existing data
        existing_data = pd.read_csv(out_file_name)
        # Ensure consistency in date format
        if not(existing_data.empty):
            existing_data['tradeDate'] = pd.to_datetime(existing_data['tradeDate'], format='%d/%m/%Y %H:%M:%S')
            existing_data = existing_data.drop(existing_data.index[-1])
            last_stamp_existing_data = existing_data.iloc[-1].get('tradeDate')
            existing_data['tradeDate'] = existing_data['tradeDate'].dt.strftime('%d/%m/%Y %H:%M:%S')
            # Append only new rows
            new_data = df[df['tradeDate'] > last_stamp_existing_data]
            new_data['tradeDate'] = new_data['tradeDate'].dt.strftime('%d/%m/%Y %H:%M:%S')
            if not new_data.empty:
                combined_data = pd.concat([existing_data, new_data]).drop_duplicates(subset=['tradeDate']).reset_index(drop=True)
                print(combined_data.tail())
                combined_data.to_csv(out_file_name, index=False)

                print(f"Successfully updated {out_file_name} with {len(new_data)} new rows.")
            else:
                print(f"No new data to update for {out_file_name}.")
        # print("##################################################")
        df['tradeDate'] = df['tradeDate'].dt.strftime('%d/%m/%Y %H:%M:%S')
         #Save the entire DataFrame if the file doesn't exist
        df.to_csv(out_file_name, index=False)
        print(f"Successfully created {out_file_name} with all data.")

    else:
        df['tradeDate'] = df['tradeDate'].dt.strftime('%d/%m/%Y %H:%M:%S')
         #Save the entire DataFrame if the file doesn't exist
        df.to_csv(out_file_name, index=False)
        print(f"Successfully created {out_file_name} with all data.")


def auto_downloader_yfinance():
    try:
        nn_stock, nn_y_fin = get_stock_details()
        for idx, stock_names in enumerate(nn_y_fin):
            print(stock_names)
            for items in download_time_frames:
                end_date, start_date = return_now_and_previous_date(items)
                tick_name = nn_stock[idx]
                obt_sd = get_stock_data(stock_names, start_date, end_date, items)
                format_and_store_delta_stock_data(obt_sd, tick_name, items)
        file_list = os.listdir('latest_data_csv')
        for files in file_list:
            if str(files).__contains__('fifteen'):
                create_75munite_from_15munite(files)
    except Exception as ex:
        print(stock_names)
        logger.exception(ex, stack_info=True)
        # raise StopIteration
    

def manual_downloader_yfinance():
    try:
        nn_stock, nn_y_fin = get_stock_details()
        for idx, stock_names in enumerate(nn_y_fin):
            print(stock_names)
            for items in download_time_frames:
                end_date, start_date = return_now_and_previous_date(items)
                tick_name = nn_stock[idx]
                obt_sd = get_stock_data(stock_names, start_date, end_date, items)
                format_all_stock_data(obt_sd, tick_name, items)
        file_list = os.listdir('latest_data_csv')
        for files in file_list:
            if str(files).__contains__('fifteen'):
                create_75munite_from_15munite(files)
    except Exception as ex:
        logger.exception(ex, stack_info=True)
        raise StopIteration


def proc_all_75():
    file_list = os.listdir('latest_data_csv')
    for files in file_list:
        if str(files).__contains__('fifteen'):
            create_75munite_from_15munite(files)
# now_date = datetime.now().date()
# before = now_date - timedelta(days=730)
# stock_data = get_stock_data('HDFCBANK.NS', '2022-10-20', datetime.now().date() , interval='15m')
# print(stock_data)
# format_stock_data(stock_data)

# print(before)
# def get_crude_oil_data():
# auto_downloader_yfinance()
# # download_single_stock_data()
if __name__ == '__main__':
    proc_all_75()
    # download_single_stock_data('zomato')
    # auto_downloader_yfinance()
    # manual_downloader_yfinance()