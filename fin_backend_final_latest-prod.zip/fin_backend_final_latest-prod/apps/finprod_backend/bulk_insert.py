from modules.dbconn import get_session, raw_query
from models.reqmodel import Us_StockMaster, Ind_StockMaster, Ind_StockIndexMap, Us_StockIndexMap
from modules.stock_handler import proc_single_tick_item, download_single_stock_data
import pandas as pd

stock_id_list = []


def insert_new_stock(stock_name: str, y_stock_name: str, index_id: list):
    global stock_id_list
    session = get_session()
    # db_order = Ind_StockMaster(stock_tick=stock_name, y_finance=y_stock_name)
    # session.add(db_order)
    # session.commit()
    # session.refresh(db_order)
    ind_stock_id = session.query(Us_StockMaster).filter(Us_StockMaster.y_finance == y_stock_name).first()
    print(ind_stock_id.id, type(ind_stock_id.id))
    # if len(ind_stock_id) > 0:
        # print(ind_stock_id.id)
    index_ids = index_id
    mapping_entries = [
                Us_StockIndexMap(stock_id=ind_stock_id.id, index_id=idx_id)
                for idx_id in index_ids]
    session.add_all(mapping_entries)
    session.commit()
    stock_id_list.append(ind_stock_id.id)
    

def process_stocks_from_csv():
    df = pd.read_csv('sp500_sample_stocks_modified.csv')
    print(len(df))
    for i in range(len(df)):
        try:
            row = df.iloc[i]
            y_name = row['y_stock_name']
            s_name = str(row['stock_name']).lower()
            i_id = list(map(int, str(row['index_ids']).split(',')))
            # print(row, i_id)
            insert_new_stock(s_name, y_name, i_id)
        except Exception as ex:
            pass
    print(stock_id_list)

def proc_stock_data():
    all_stock_id = [624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 636, 637, 638, 639, 640, 641, 642, 643, 644, 647, 649, 651, 652, 653, 654, 655, 656, 658, 659, 660, 661, 662, 663, 665, 666, 667, 668, 669, 670, 671, 673, 674, 675, 676, 677, 678, 679, 681, 683, 684, 685, 686, 688, 689, 691, 692, 694, 696, 697, 698, 699, 700, 701, 702, 703, 704, 705, 706, 707, 708, 709, 711, 712, 714, 715, 716, 717, 718, 719, 720, 722, 724, 725, 726, 727, 728, 729, 730, 732, 733, 735, 736, 738, 739, 740, 741, 742, 744, 745, 746, 747, 748, 750, 751, 752, 753]
    for items in all_stock_id:
        stock_res = raw_query(f"select * from stock_master where id={items}")
        y_fin_stock_name = stock_res[0].get('y_finance')
        stock_tick_nn = stock_res[0].get('stock_tick')
        download_single_stock_data(stock_tick_nn, y_fin_stock_name)
        proc_single_tick_item(stock_tick_nn)

if __name__ == '__main__':
    process_stocks_from_csv()
    # proc_stock_data()