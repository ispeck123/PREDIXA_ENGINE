import os
from modules.parse_create_csv import create_75munite_from_15munite
from modules.stock_logic import proc_all_stock_items
from alert_schedular import trading_task, process_latest_stock_data


def proc_all_75():
    ll = os.listdir('latest_data_csv')
    for items in ll:
        if items.__contains__('fifteen'):
            full_path = os.path.join('latest_data_csv', items)
            create_75munite_from_15munite(items)

def process_75_stock_data():
    try:
        ctr = 0
        th_list = []
        input_dir = "latest_data_csv"
        output_dir = "./processed_data_files"
        for stock_item in os.listdir(input_dir):
            if stock_item.__contains__("weekly"):
                proc_all_stock_items(stock_item, input_dir, output_dir)
            # proc_delta_stock_items(stock_item, input_dir, output_dir)
            # ctr += 1
            # if ctr > 5:
            #     break
            # Th = Thread(target=proc_all_stock_items, args=(stock_item, input_dir, output_dir))
            # Th = Thread(target=proc_delta_stock_items, args=(stock_item, input_dir, output_dir))
            # th_list.append(Th)
            # Th.start()
        # for threa in th_list:
            # threa.join()
        print("process_complete............*********************************")
    except Exception as ex:
        print(ex)
        raise StopIteration


if __name__ == '__main__':
    # proc_all_75()
    process_75_stock_data()
    # trading_task()
    # process_latest_stock_data()