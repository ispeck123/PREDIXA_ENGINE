# # Import the required module from the fyers_apiv3 package
# from fyers_apiv3 import fyersModel

# # Replace these values with your actual API credentials
# client_id = "9OG15PCU6X-100"
# secret_key = "O5ISJX0OIN"
# redirect_uri = "https://trade.fyers.in/api-login/redirect-uri/index.html"
# response_type = "code"  
# state = "sample_state"

# # Create a session model with the provided credentials
# session = fyersModel.SessionModel(
#     client_id=client_id,
#     secret_key=secret_key,
#     redirect_uri=redirect_uri,
#     response_type=response_type
# )

# # Generate the auth code using the session model
# response = session.generate_authcode()

# # Print the auth code received in the response
# print(response)

#---------------------------------------------------------------------------

# Import the required module from the fyers_apiv3 package
# from fyers_apiv3 import fyersModel

# # Define your Fyers API credentials
# client_id = "9OG15PCU6X-100"  # Replace with your client ID
# secret_key = "O5ISJX0OIN"  # Replace with your secret key
# redirect_uri = "https://trade.fyers.in/api-login/redirect-uri/index.html"  # Replace with your redirect URI
# response_type = "code" 
# grant_type = "authorization_code"  

# # The authorization code received from Fyers after the user grants access
# auth_code = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhcHBfaWQiOiI5T0cxNVBDVTZYIiwidXVpZCI6ImNiN2I3NTRhOThkNjQyY2M4ODE3MjUxOWU3ZWM1NjkwIiwiaXBBZGRyIjoiIiwibm9uY2UiOiIiLCJzY29wZSI6IiIsImRpc3BsYXlfbmFtZSI6IkNBMDAyODciLCJvbXMiOiJLMSIsImhzbV9rZXkiOiI5NjY4ZmQ0MzhiOGU0Njk0ZDgyYjg5NDI3MWI4YjFmMTU3ZWUyZmIzNTQyOGNiMGQ4YWNlMjIzYiIsImlzRGRwaUVuYWJsZWQiOiJOIiwiaXNNdGZFbmFibGVkIjoiTiIsImF1ZCI6IltcImQ6MVwiLFwiZDoyXCIsXCJ4OjBcIixcIng6MVwiLFwieDoyXCJdIiwiZXhwIjoxNzUyMTc4NDQxLCJpYXQiOjE3NTIxNDg0NDEsImlzcyI6ImFwaS5sb2dpbi5meWVycy5pbiIsIm5iZiI6MTc1MjE0ODQ0MSwic3ViIjoiYXV0aF9jb2RlIn0.hWTJg63IjhG3vA3kVam1vdLPTbhTTL8uzRafD2WX_tU"

# # Create a session object to handle the Fyers API authentication and token generation
# session = fyersModel.SessionModel(
#     client_id=client_id,
#     secret_key=secret_key, 
#     redirect_uri=redirect_uri, 
#     response_type=response_type, 
#     grant_type=grant_type
# )

# # Set the authorization code in the session object
# session.set_token(auth_code)

# # Generate the access token using the authorization code
# response = session.generate_token()

# # Print the response, which should contain the access token and other details
# print(response)

#--------------------------------------------------------------------------------------
      
from fyers_apiv3 import fyersModel

fyers = fyersModel.FyersModel(client_id="9OG15PCU6X-100", token="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOlsiZDoxIiwiZDoyIiwieDowIiwieDoxIiwieDoyIl0sImF0X2hhc2giOiJnQUFBQUFCb2RmenJGNmlhaFZRek1uYUNuVDh6SGhQMHdwNFdGeTFmVDdtYVVtZVJpMWcwYW1HdVBvMkdSc3dWSmxKMXM3dzN4SEc5THJ2N2E4VnotRDdHNUdzMkU3MUg5TmFhQUNRUUxrTFBVSnc0V29sOHMxdz0iLCJkaXNwbGF5X25hbWUiOiIiLCJvbXMiOiJLMSIsImhzbV9rZXkiOiI5NjY4ZmQ0MzhiOGU0Njk0ZDgyYjg5NDI3MWI4YjFmMTU3ZWUyZmIzNTQyOGNiMGQ4YWNlMjIzYiIsImlzRGRwaUVuYWJsZWQiOiJZIiwiaXNNdGZFbmFibGVkIjoiTiIsImZ5X2lkIjoiQ0EwMDI4NyIsImFwcFR5cGUiOjEwMCwiZXhwIjoxNzUyNjI1ODAwLCJpYXQiOjE3NTI1NjI5MjMsImlzcyI6ImFwaS5meWVycy5pbiIsIm5iZiI6MTc1MjU2MjkyMywic3ViIjoiYWNjZXNzX3Rva2VuIn0.1RZgtupoSdhsDK_ML7OBYBzP1HjaWq64noLJwRvWFCM", is_async=False, log_path="")
symbols = ["NSE:RELIANCE-EQ", "NSE:TCS-EQ"]

quote_data = fyers.quotes(data = {"symbols": ",".join(symbols)})
print(quote_data)



#----------------------------------------------------------------------------------------------

# from fyers_apiv3.FyersWebsocket import data_ws

# def custom_message(msg):
#     print("Live Data:", msg)

# def on_connect(ws):
#     print("Connected")
#     ws.subscribe(symbols=["NSE:RELIANCE-EQ"], data_type = "SymbolUpdate")
#     ws.set_mode(ws_mode="FULL", symbols=["NSE:RELIANCE-EQ"])

# socket = data_ws.FyersDataSocket(
#     access_token="9OG15PCU6X-100:eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOlsiZDoxIiwiZDoyIiwieDowIiwieDoxIiwieDoyIl0sImF0X2hhc2giOiJnQUFBQUFCb2RmenJGNmlhaFZRek1uYUNuVDh6SGhQMHdwNFdGeTFmVDdtYVVtZVJpMWcwYW1HdVBvMkdSc3dWSmxKMXM3dzN4SEc5THJ2N2E4VnotRDdHNUdzMkU3MUg5TmFhQUNRUUxrTFBVSnc0V29sOHMxdz0iLCJkaXNwbGF5X25hbWUiOiIiLCJvbXMiOiJLMSIsImhzbV9rZXkiOiI5NjY4ZmQ0MzhiOGU0Njk0ZDgyYjg5NDI3MWI4YjFmMTU3ZWUyZmIzNTQyOGNiMGQ4YWNlMjIzYiIsImlzRGRwaUVuYWJsZWQiOiJZIiwiaXNNdGZFbmFibGVkIjoiTiIsImZ5X2lkIjoiQ0EwMDI4NyIsImFwcFR5cGUiOjEwMCwiZXhwIjoxNzUyNjI1ODAwLCJpYXQiOjE3NTI1NjI5MjMsImlzcyI6ImFwaS5meWVycy5pbiIsIm5iZiI6MTc1MjU2MjkyMywic3ViIjoiYWNjZXNzX3Rva2VuIn0.1RZgtupoSdhsDK_ML7OBYBzP1HjaWq64noLJwRvWFCM",  # Format: client_id:access_token
#     log_path="",
#     litemode=False,                  # Lite mode disabled. Set to True if you want a lite response.
#     write_to_file=False,              # Save response in a log file instead of printing it.
#     reconnect=True
# )

# socket.on_connect = on_connect
# socket.on_message = custom_message
# socket.connect()

# ---------------------------------------------------------------------------------------

# from fyers_apiv3 import fyersModel

# client_id = "9OG15PCU6X-100"
# access_token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOlsiZDoxIiwiZDoyIiwieDowIiwieDoxIiwieDoyIl0sImF0X2hhc2giOiJnQUFBQUFCb2RmZFNUc3RfdnIwN2JaeVNiWGl5U0lrdWlsbm85dFNDbkZndHV5SjJDdURoalNmLU81Mmx3VWFWSHFQekllaEhOVG5weEhId0l2R2J4eUdWR1lBNWJGSWo2aHNicW9xdDdZSjROTGVmOTBLamlQdz0iLCJkaXNwbGF5X25hbWUiOiIiLCJvbXMiOiJLMSIsImhzbV9rZXkiOiI5NjY4ZmQ0MzhiOGU0Njk0ZDgyYjg5NDI3MWI4YjFmMTU3ZWUyZmIzNTQyOGNiMGQ4YWNlMjIzYiIsImlzRGRwaUVuYWJsZWQiOiJZIiwiaXNNdGZFbmFibGVkIjoiTiIsImZ5X2lkIjoiQ0EwMDI4NyIsImFwcFR5cGUiOjEwMCwiZXhwIjoxNzUyNjI1ODAwLCJpYXQiOjE3NTI1NjE0OTAsImlzcyI6ImFwaS5meWVycy5pbiIsIm5iZiI6MTc1MjU2MTQ5MCwic3ViIjoiYWNjZXNzX3Rva2VuIn0.3sE0TDKt-3469kRz6OdNB-hRRT313CLdcK5ovh8GHFA"

# # Initialize the FyersModel instance with your client_id, access_token, and enable async mode
# fyers = fyersModel.FyersModel(client_id=client_id, is_async=False, token=access_token, log_path="")

# data = {
#     "symbol":"NSE:SBIN-EQ",
#     "resolution":"5",
#     "date_format":"0",
#     "range_from":"1690895316",
#     "range_to":"1691068173",
#     "cont_flag":"1"
# }

# response = fyers.history(data=data)
# print(response)

# ------------------------------------------------------------------------------------------


# from fyers_apiv3.FyersWebsocket import data_ws
# def onmessage(message):
#     """
#     Callback function to handle incoming messages from the FyersDataSocket WebSocket.

#     Parameters:
#         message (dict): The received message from the WebSocket.

#     """
#     print("Response:", message)


# def onerror(message):
#     """
#     Callback function to handle WebSocket errors.

#     Parameters:
#         message (dict): The error message received from the WebSocket.


#     """
#     print("Error:", message)


# def onclose(message):
#     """
#     Callback function to handle WebSocket connection close events.
#     """
#     print("Connection closed:", message)


# def onopen():
#     """
#     Callback function to subscribe to data type and symbols upon WebSocket connection.

#     """
#     # Specify the data type and symbols you want to subscribe to
#     data_type = "SymbolUpdate"
#     # data_type = "DepthUpdate"


#     # Subscribe to the specified symbols and data type
#     symbols = ['NSE:SBIN-EQ', 'NSE:ADANIENT-EQ']
#     fyers.subscribe(symbols=symbols, data_type=data_type)

#     # Keep the socket running to receive real-time data
#     fyers.keep_running()


# # Replace the sample access token with your actual access token obtained from Fyers
# access_token = "9OG15PCU6X-100:eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOlsiZDoxIiwiZDoyIiwieDowIiwieDoxIiwieDoyIl0sImF0X2hhc2giOiJnQUFBQUFCb2RmenJGNmlhaFZRek1uYUNuVDh6SGhQMHdwNFdGeTFmVDdtYVVtZVJpMWcwYW1HdVBvMkdSc3dWSmxKMXM3dzN4SEc5THJ2N2E4VnotRDdHNUdzMkU3MUg5TmFhQUNRUUxrTFBVSnc0V29sOHMxdz0iLCJkaXNwbGF5X25hbWUiOiIiLCJvbXMiOiJLMSIsImhzbV9rZXkiOiI5NjY4ZmQ0MzhiOGU0Njk0ZDgyYjg5NDI3MWI4YjFmMTU3ZWUyZmIzNTQyOGNiMGQ4YWNlMjIzYiIsImlzRGRwaUVuYWJsZWQiOiJZIiwiaXNNdGZFbmFibGVkIjoiTiIsImZ5X2lkIjoiQ0EwMDI4NyIsImFwcFR5cGUiOjEwMCwiZXhwIjoxNzUyNjI1ODAwLCJpYXQiOjE3NTI1NjI5MjMsImlzcyI6ImFwaS5meWVycy5pbiIsIm5iZiI6MTc1MjU2MjkyMywic3ViIjoiYWNjZXNzX3Rva2VuIn0.1RZgtupoSdhsDK_ML7OBYBzP1HjaWq64noLJwRvWFCM"

# # Create a FyersDataSocket instance with the provided parameters
# fyers = data_ws.FyersDataSocket(
#     access_token=access_token,       # Access token in the format "appid:accesstoken"
#     log_path="",                     # Path to save logs. Leave empty to auto-create logs in the current directory.
#     litemode=False,                  # Lite mode disabled. Set to True if you want a lite response.
#     write_to_file=False,              # Save response in a log file instead of printing it.
#     reconnect=True,                  # Enable auto-reconnection to WebSocket on disconnection.
#     on_connect=onopen,               # Callback function to subscribe to data upon connection.
#     on_close=onclose,                # Callback function to handle WebSocket connection close events.
#     on_error=onerror,                # Callback function to handle WebSocket errors.
#     on_message=onmessage             # Callback function to handle incoming messages from the WebSocket.
# )

# # Establish a connection to the Fyers WebSocket
# fyers.connect()