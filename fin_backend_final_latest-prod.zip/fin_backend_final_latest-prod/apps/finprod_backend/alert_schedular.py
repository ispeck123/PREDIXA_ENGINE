import schedule
import time
import pandas as pd
from datetime import datetime, time as dt_time
from y_finance import auto_downloader_yfinance
from apps.finprod_backend.modules.stock_logic import proc_delta_stock_items, proc_all_stock_items
# from modules.dbconn import raw_query
from apps.finprod_backend.modules.alert_notifier import ALERT_NOTIFIER
from threading import Thread
import os, shutil

def trading_task():
    # Define the task you want to execute
    print("Executing trading task at", datetime.now())
    auto_downloader_yfinance()
    time.sleep(2)
    process_latest_stock_data()
    time.sleep(2)
    copy_all_files("./apps/finprod_backend/backup_files/processed_data_files", 
                   "./apps/finprod_backend/processed_data_files")
    # ALERT_NOTIFIER()

def is_trading_day():
    current_date = datetime.now().date()
    date = pd.Timestamp(current_date)
    current_year = date.year
    holidays = [
        f"{current_year}-01-26",  # Republic Day
        f"{current_year}-03-29",  # Holi (date may vary each year)
        f"{current_year}-08-15",  # Independence Day
        f"{current_year}-10-02",  # Gandhi Jayanti
        f"{current_year}-10-24",  # Diwali (date may vary each year)
        f"{current_year}-12-25"   # Christmas
    ]
    trading_days = pd.bdate_range(start=f"{current_year}-01-01", end=f"{current_year}-12-31", freq='C', holidays=holidays)
    return date in trading_days


def copy_all_files(src_dir, dest_dir):
    if not os.path.exists(dest_dir):
        os.makedirs(dest_dir)
    for filename in os.listdir(src_dir):
        src_file = os.path.join(src_dir, filename)
        dest_file = os.path.join(dest_dir, filename)
        if os.path.isfile(src_file):
            shutil.copy(src_file, dest_file)
            print(f"Copied {filename} to {dest_dir}")

def process_latest_stock_data():
    try:
        ctr = 0
        th_list = []
        input_dir = "./apps/finprod_backend/latest_data_csv"
        output_dir = "./apps/finprod_backend/backup_files/processed_data_files"
        for stock_item in os.listdir(input_dir):
            # if stock_item.__contains__('seventy_five'):
            #     continue
            # else:
            proc_delta_stock_items(stock_item, input_dir, output_dir)
            # ctr += 1
            # if ctr > 5:
            #     break
            # Th = Thread(target=proc_all_stock_items, args=(stock_item, input_dir, output_dir))
            # Th = Thread(target=proc_delta_stock_items, args=(stock_item, input_dir, output_dir))
            # th_list.append(Th)
            # Th.start()
        # for threa in th_list:
            # threa.join()
        print("process_complete............*********************************")
    except Exception as ex:
        print(ex)
        raise StopIteration


def schedule_hourly_during_trading_hours():
    # Define the Indian trading hours (from 9:15 AM to 3:15 PM every hour)
    start_time = dt_time(9, 14)  # 9:15 AM
    end_time = dt_time(15, 36)   # 3:30 PM

    # Get current time
    current_time = datetime.now().time()

    # Schedule task every hour during trading hours if current time is within trading hours
    if (start_time <= current_time <= end_time) and is_trading_day():
        trading_task()
        # schedule.every().hour.at(":30").do()  # Run at 15 minutes past every hour
        print("Scheduled to run every hour at :30 past the hour during trading hours.")
    else:
        print("Outside trading hours, task not scheduled.")

# schedule.every(15).minutes.do(schedule_hourly_during_trading_hours)

if __name__ == '__main__':
    schedule.every(15).minutes.do(schedule_hourly_during_trading_hours)
    print("Starting Schedular...........................")
    # trading_task()
    while True:
        schedule.run_pending()
        time.sleep(1)
    # process_latest_stock_data()
    # time.sleep(2)
    # copy_all_files("./backup_files/processed_data_files", "./processed_data_files")