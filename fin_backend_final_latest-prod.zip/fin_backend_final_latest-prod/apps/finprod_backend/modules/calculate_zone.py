import pandas as pd
from datetime import datetime, timedelta, timezone
from concurrent.futures import ThreadPoolExecutor
from dateutil import parser
from shared.config.settings import Config as cfg
import numpy as np
import os

class Calculate_Base_Candles:
    def __init__(self, csv_path, tick, last_d_time) -> None:
        self.csv_path = csv_path
        self.tick = tick
        self.last_d_time = last_d_time
        self.valid_dz_indx = []
        self.valid_sz_indx = []
    def time_to_local(self, original_time):
        d = datetime.utcfromtimestamp(original_time)
        return datetime(d.year, d.month, d.day, d.hour, d.minute, d.second, d.microsecond).timestamp()

    def calculate_zones(self):
        out_res = []
        df = pd.read_csv(self.csv_path)
        df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst = True)
        df = df[df.timestamp <= self.last_d_time]
        df['timestamp'] = (df['timestamp'].astype(np.int64) // 10**9).astype(int)
        for i in range(len(df) - 1):
            row_data = df.iloc[i]
            if bool(row_data.get("is_basing")) and i >= 1:
                point = int(row_data.get("timestamp"))
                out_res.append(point)
        return out_res

class Calculate_BAD_ZONES:
    def __init__(self, csv_path, last_d_time) -> None:
        self.csv_path = csv_path
        self.last_d_time = last_d_time

    def find_increasing_indices(self, lst):
        increasing_indices = []
        single_values = []
        for i in range(len(lst) - 1):
            if lst[i+1] - lst[i] == 1:
                if not increasing_indices or (increasing_indices and increasing_indices[-1][-1] != i):
                    increasing_indices.append([i, i+1])
                else:
                    increasing_indices[-1][-1] = i+1
            elif i > 0 and lst[i-1] + 1 != lst[i] and lst[i] + 1 != lst[i+1]:
                single_values.append(i)
        if lst[-1] != lst[-2] + 1:
            single_values.append(len(lst) - 1)
        return increasing_indices, single_values
    
    def get_bad_zones_data(self):
        out_data = {}
        b_z = []
        group_index_list = []
        single_index_list = []
        df = pd.read_csv(self.csv_path)
        df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst = True)
        df = df[df.timestamp <= self.last_d_time]
        df['timestamp'] = (df['timestamp'].astype(np.int64) // 10**9).astype(int)
        for j in range(len(df)):
            bad_row_data = df.iloc[j]
            if str(bad_row_data.get("ideal_zone")).__contains__('BADZONE'):
                b_z.append(j)
        if len(b_z) >= 3:
            con_z, sin_z = self.find_increasing_indices(b_z)
            # print(con_z, sin_z)
            for li in con_z:
                low_li = []
                high_li = []
                # print(len(df) ,b_z[li[1]] + 1)
                prev_t = df.iloc[b_z[li[0]] - 1].get('timestamp')
                if len(df) == (b_z[li[1]] + 1):
                    next_t = df.iloc[b_z[li[1]]].get('timestamp')
                else:
                    next_t = df.iloc[b_z[li[1]] + 1].get('timestamp')
                for k in range(li[0], li[1]+1):
                    low_li.append(abs(df.iloc[b_z[k]].get('low')))
                    high_li.append(abs(df.iloc[b_z[k]].get('high')))
                y1 = max(high_li)
                y2 = min(low_li)
                point1 = {"time": int(prev_t), "price": y2}
                point2 = {"time": int(next_t), "price": y1}
                group_index_list.append([point1,point2])
            for si in sin_z:
                s_row_data = df.iloc[b_z[si]]
                s_low_dat = s_row_data.get("low")
                s_high_dat = s_row_data.get("high")
                # s_exp = s_row_data.get("timestamp")
                p1_time = df.iloc[b_z[si]-1]['timestamp']
                p2_time = df.iloc[b_z[si]+1]['timestamp']
                point_1 = {"time": int(p1_time), "price": s_low_dat}
                point_2 = {"time": int(p2_time), "price": s_high_dat}
                group_index_list.append([point_1, point_2])
        # out_data['multiple_groups'] = group_index_list
        # out_data['single_group'] = single_index_list
        return group_index_list


class Calculate_GAP:
    def __init__(self, csv_path, last_d_time) -> None:
        self.csv_path = csv_path
        self.last_d_time = last_d_time

    def calculate_percentage(self, price1, price2):
        if price1 == 0 or price2 == 0:
            return False
        # Calculate the percentage difference
        if (price1 - price2) > 0:
            percentage_difference = abs(price1 - price2) / (price1) * 100
            # print(percentage_difference)
            return percentage_difference
        else:
            return False

    def calculate_gaps(self):
        gap_dict = {}
        gap_up_list = []
        gap_down_list = []
        df = pd.read_csv(self.csv_path)
        df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst = True)
        df = df[df.timestamp <= self.last_d_time]
        df['timestamp'] = (df['timestamp'].astype(np.int64) // 10**9).astype(int)
        for i in range(len(df) - 1):
            if i == (len(df) - 1):
                continue
            first_row_data = df.iloc[i]
            next_row_data = df.iloc[i+1]
            # GAP UP
            diff_up = self.calculate_percentage(next_row_data['low'], first_row_data['high'])
            # GAP DOWN
            diff_down = self.calculate_percentage(first_row_data['low'], next_row_data['high'])  
            # print(diff_up, diff_down)
            if diff_up > 2:
                p1_time = df.iloc[i]['timestamp']
                p2_time = df.iloc[i+1]['timestamp']
                point1 = {"time": int(p1_time), "price": first_row_data['high']} # strftime("%Y-%m-%d")
                point2 = {"time": int(p2_time), "price": next_row_data['low']}
                gap_up_list.append([point1,point2])
            if diff_down > 2:
                p1_time = df.iloc[i]['timestamp']
                p2_time = df.iloc[i+1]['timestamp']
                point1 = {"time": int(p1_time), "price": first_row_data['low']} # strftime("%Y-%m-%d")
                point2 = {"time": int(p2_time), "price": next_row_data['high']}
                gap_down_list.append([point1,point2])
        gap_dict['GAP_UP'] = gap_up_list
        gap_dict['GAP_DOWN'] = gap_down_list
        return gap_dict


class Calculate_BUY_SELL_ZONES:
    def __init__(self, csv_path, tick, last_d_time, is_execute) -> None:
        self.csv_path = csv_path
        self.tick = tick
        self.last_d_time = last_d_time
        self.is_execute = is_execute
        # print(self.csv_path, "**************************************************************")

    def check_price_range(self, max_val, min_val, bull_bear_list: list, cmp) -> str:
        # zone_type_list: list, bull_bear_list: list
        # SZ = zone_type_list.count('RBD') + zone_type_list.count('DBD') + bull_bear_list.count(0) + zone_type_list.count('DBR')
        # DZ = zone_type_list.count('RBR') + zone_type_list.count('DBR') + bull_bear_list.count(1)
        # return 'SZ' if SZ > DZ else 'DZ'
        if max_val < cmp and min_val < cmp :
            return 'DZ'
        elif max_val > cmp and min_val > cmp:
            return 'SZ'
        else:
            if bull_bear_list.count(1) >= bull_bear_list.count(0):
                avg_val = (max_val+min_val)/2
                if avg_val < cmp:
                    return 'DZ'
                else:
                    return 'SZ'
        
  
    def divide_buy_and_sell_zones(self, all_zone_list, data_frame):
        # print(len(data_frame))
        dz_list = []
        sz_list = []
        dz_val_list = []
        sz_val_list = []
        cmp = data_frame['close'].iloc[-1]
        if len(all_zone_list) >= 2:

            group, single = self.find_increasing_indices(all_zone_list)
            # if str(self.csv_path).__contains__('weekly'):
                # print(group, single)
            for li in group:
                low_li = []
                high_li = []
                buy_sell_zones = []
                bull_bear_list = []
                # prev_t = data_frame.iloc[all_zone_list[li[0]] - 1].get('timestamp')
                # next_t = data_frame.iloc[all_zone_list[li[1]] + 1].get('timestamp')
                for k in range(all_zone_list[li[0]], all_zone_list[li[1]] + 1):
                    # if data_frame.iloc[k].get('low') < cmp:
                    low_li.append(abs(data_frame.iloc[k].get('low')))
                        # if self.is_execute:
                    high_li.append(abs(data_frame.iloc[k].get('high')))
                    buy_sell_zones.append(data_frame.iloc[k].get('buy_sell_zone_type'))
                    bull_bear_list.append(data_frame.iloc[k].get('is_bullish'))
                        # else:
                            # wick_val = 'close' if int(data_frame.iloc[k].get('is_bullish')) == 1 else 'open'
                            # low_li.append(abs(data_frame.iloc[k].get('low')))
                            # high_li.append(abs(data_frame.iloc[k].get(wick_val)))
                    # else:
                    #     low_li.append(abs(data_frame.iloc[k].get('low')))
                    #     if self.is_execute:
                    #         high_li.append(abs(data_frame.iloc[k].get('high')))
                    #     else:
                    #         wick_val = 'open' if int(data_frame.iloc[k].get('is_bullish')) == 1 else 'close'
                    #         low_li.append(abs(data_frame.iloc[k].get('low')))
                    #         high_li.append(abs(data_frame.iloc[k].get(wick_val)))
                # print("**********************************", self.csv_path)

                y1 = max(high_li)
                y2 = min(low_li)
                VAL = self.check_price_range(y1, y2, bull_bear_list, cmp)
                if VAL == 'DZ':
                    dz_list.append(li)
                    dz_val_list.append((y2, y1))
                elif VAL == 'SZ':
                    sz_list.append(li)
                    sz_val_list.append((y2, y1))

            for si in single:
                buy_sell_zones = []
                bull_bear_list = []
                s_row_data = data_frame.iloc[all_zone_list[si]]
                buy_sell_zones.append(s_row_data.get('buy_sell_zone_type'))
                bull_bear_list.append(s_row_data.get('is_bullish'))
                if s_row_data.get('low') < cmp:
                    if self.is_execute:
                        wick_val = 'close' if int(s_row_data.get('is_bullish')) == 1 else 'open'
                    else:
                        wick_val = 'high'
                    VAL = self.check_price_range(s_row_data.get(wick_val), s_row_data.get('low'), bull_bear_list, cmp)
                else:
                    if self.is_execute:
                        wick_val = 'open' if int(s_row_data.get('is_bullish')) == 1 else 'close'
                    else:
                        wick_val = 'low'
                    VAL = self.check_price_range(s_row_data.get('high'), s_row_data.get(wick_val), bull_bear_list, cmp)

                if VAL == 'DZ' and [si] not in dz_list:
                    dz_list.append([si])
                    dz_val_list.append((s_row_data.get('low'), s_row_data.get('high')))
                elif VAL == 'SZ' and [si] not in sz_list:
                    sz_list.append([si])
                    sz_val_list.append((s_row_data.get('low'), s_row_data.get('high')))

                # s_low_dat = s_row_data.get("low")
        elif len(all_zone_list) == 1:
            buy_sell_zones = []
            bull_bear_list = []
            s_row_data = data_frame.iloc[all_zone_list[0]]
            buy_sell_zones.append(s_row_data.get('buy_sell_zone_type'))
            bull_bear_list.append(s_row_data.get('is_bullish'))
            VAL = self.check_price_range(s_row_data.get('high'), s_row_data.get('low'), bull_bear_list, cmp)
            if VAL == 'DZ':
                dz_list.append([all_zone_list[0]])
                dz_val_list.append((s_row_data.get('low'), s_row_data.get('high')))
            elif VAL == 'SZ':
                sz_list.append([all_zone_list[0]])
                sz_val_list.append((s_row_data.get('low'), s_row_data.get('high')))
        # print(len(dz_list), len(dz_val_list), "**********************************************")
        # print(len(sz_list), len(sz_val_list), "**********************************************")
        # print(overlapping_indexes, "########################################")
        # for rng in overlapping_indexes:
        #     # print(dz_val_list[rng], "##############################################")
        #     if 0 <= rng < len(dz_val_list):
        #         dz_list.pop(rng)
        #         dz_val_list.pop(rng)
        return dz_list, sz_list, dz_val_list, sz_val_list


    def check_zone_violation(self, data_frame, check_start_index, zone_price_range, is_demand_or_sell):
        found_leg_out = False
        chk_int = False
        for j in range(check_start_index + 1, len(data_frame) - 1):
            if bool(data_frame.iloc[j]['is_leg_out']) == True and not(found_leg_out):
                continue
            else:
                found_leg_out = True
            w_val = 'low' if is_demand_or_sell else 'high'
            per_intersect = self.ranges_intersect(zone_price_range, data_frame.iloc[j].get(w_val), is_demand_or_sell)
            if per_intersect:
                chk_int = True
                break
        return chk_int
    
    def slice_list_by_time(self, data, prev_t, next_t):
        for idx, stamp in enumerate(data):
            t1 = stamp[0]['time']
            t2 = stamp[1]['time']
            if t1 == prev_t and t2 == next_t:
                return data[0:idx]
        return []
    
    def return_ath_and_pth(self, timestamp):
        filepath = os.path.join(os.getcwd(), "apps", "finprod_backend", "processed_data_files", f"{self.tick}_daily.csv")
        fdf = pd.read_csv(filepath)
        fdf['timestamp'] = pd.to_datetime(fdf['timestamp'], dayfirst = True)
        fdf['timestamp'] = (fdf['timestamp'].astype(np.int64) // 10**9).astype(int)
        fdf = fdf[fdf.timestamp <= timestamp]
        all_time_high = fdf['high'].max()
        previous_high = fdf['high'].iloc[-2]
        previous_low = fdf['low'].iloc[-2]
        # print("ATH & PTH ############################", all_time_high, previous_high)
        return all_time_high, previous_high, previous_low
    
    def get_preceding_zones(self, qual_zone, check_zone_list, is_dz):
        preceding_zones = []
        qual_zone_high = qual_zone[1]['price']
        qual_zone_low = qual_zone[0]['price']
        if is_dz:
            for items in check_zone_list:
                if items[0]['price'] >= qual_zone_high:
                    preceding_zones.append(items)
        else:
            for items in check_zone_list:
                if items[1]['price'] <= qual_zone_low:
                    preceding_zones.append(items)
        # if self.is_execute and not(is_dz) and len(preceding_zones) > 0:
        #     print(qual_zone, preceding_zones[0], "kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk")
        return preceding_zones

    def check_prededing_leg_out_violation(self, leg_out_element, first_pre_zone, isDZ):
        if isDZ:
            leg_out_high = leg_out_element[1]['price']
            return leg_out_high >= first_pre_zone[1]['price']
        else:
            # print(leg_out_element, "33333333333333333333333333333333333333")
            leg_out_low = leg_out_element[0]['price']
            return leg_out_low <= first_pre_zone[0]['price']
        
    def qualified_zones(self, all_leg_out_list: list, all_zones_list: list, valid_ranges_list: list, df : pd.DataFrame, isDZ: bool):
        new_qualified_zone_list = []
        violated_preeceding_zone_list = []
        valid_ranges_list = sorted(valid_ranges_list, key=lambda z: z[0]["time"], reverse=True)
        all_leg_out_list = sorted(all_leg_out_list, key=lambda z: z[0]["time"], reverse=True)
        if self.is_execute:
            print(len(all_leg_out_list), len(valid_ranges_list), "GGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG")
        for idx, elements in enumerate(all_leg_out_list):
            is_qualified_zone = False
            prev_time = elements[0]['time']
            next_time = elements[1]['time']
            time_sliced_list = self.slice_list_by_time(all_zones_list, prev_time, next_time)
            time_sliced_list = sorted(time_sliced_list, key=lambda z: z[0]["time"], reverse=True)
            preceding_zones = self.get_preceding_zones(valid_ranges_list[idx], time_sliced_list, isDZ)
            preceding_zones = sorted(preceding_zones, key=lambda z: z[0]["time"], reverse=True)
            # print("**************************************")
            # print(valid_ranges_list[idx])
            # print(preceding_zones)
            # print("**************************************")
            if len(preceding_zones) > 0:
                # if self.is_execute and not(isDZ):
                #     print("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")
                #     print(elements)
                #     print(valid_ranges_list[idx])
                #     print(preceding_zones[0])
                #     print("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")
                is_qualified_zone = self.check_prededing_leg_out_violation(elements, preceding_zones[0], isDZ)
                if not(is_qualified_zone) and isDZ:
                    ath, pth, ptl = self.return_ath_and_pth(prev_time)
                    is_qualified_zone = True if elements[1]['price'] >= pth else False
                # elif not(is_qualified_zone) and not(isDZ):
                    # ath, pth, ptl = self.return_ath_and_pth(prev_time)
                    # is_qualified_zone = True if elements[0]['price'] <= ptl else False
                if is_qualified_zone: violated_preeceding_zone_list.append(preceding_zones[0])
            else:
                ath, pth, ptl = self.return_ath_and_pth(prev_time)
                if isDZ:
                    is_qualified_zone = True if elements[1]['price'] >= pth else False
                else:
                    is_qualified_zone = True # if elements[1]['price'] <= ptl else False
                    # is_qualified_zone = True if valid_ranges_list[idx][0]['price'] <= pth else False
            if is_qualified_zone:
                new_qualified_zone_list.append(valid_ranges_list[idx])
            

        for idx, elements in enumerate(all_leg_out_list):
            check_element = valid_ranges_list[idx]
            if check_element not in new_qualified_zone_list:
                prev_time = elements[0]['time']
                next_time = elements[1]['time']
                time_sliced_list = self.slice_list_by_time(all_zones_list, prev_time, next_time)
                time_sliced_list = sorted(time_sliced_list, key=lambda z: z[0]["time"], reverse=True)
                preceding_zones = self.get_preceding_zones(valid_ranges_list[idx], time_sliced_list, isDZ)
                preceding_zones = sorted(preceding_zones, key=lambda z: z[0]["time"], reverse=True)
                # print(preceding_zones, "*******************************")
                if len(preceding_zones) > 0:
                    if preceding_zones[0] in violated_preeceding_zone_list:
                        new_qualified_zone_list.append(check_element)

        new_qualified_zone_list = sorted(new_qualified_zone_list, key=lambda z: z[0]["time"], reverse=True)
        return new_qualified_zone_list
    
    def update_new_sell_zones_df(self):
        valid_sz_list = []
        df = pd.read_csv(self.csv_path)
        df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst = True)
        df = df[df.timestamp <= self.last_d_time]
        # df['timestamp'] = df['timestamp'].astype(np.int64) // 10**9
        # for i in range(len(df) - 1):
        # cmp_tstamp = df.iloc[len(df) - 1]['timestamp']
        d_z, s_z, all_base_zone_index, dz_val, sz_val = self.calculate_full_zones()
        # print(all_base_zone_index, "******************************")
        if len(all_base_zone_index) == 1:
            s_row_data = df.iloc[all_base_zone_index[0]]
            s_high_dat = s_row_data.get("high")
            if self.is_execute:
                wick_val = 'open' if int(s_row_data.get('is_bullish')) == 1 else 'close'
                s_low_dat = s_row_data.get(wick_val)
            else:
                s_low_dat = s_row_data.get("low")

            chk_int = self.check_zone_violation(df, all_base_zone_index[0], (s_low_dat, s_high_dat), False)
            if not(chk_int):
                df.loc[all_base_zone_index[0], 'final_zone'] = 'SZ'
                valid_sz_list.append((s_low_dat, s_high_dat))
        else:
            for items in s_z:
                if len(items) == 2:
                    low_li = []
                    high_li = []
                    # prev_t = df.iloc[all_base_zone_index[items[0]] - 1].get('timestamp')
                    # next_t = df.iloc[all_base_zone_index[items[1]] + 1].get('timestamp')
                    for k in range(all_base_zone_index[items[0]], all_base_zone_index[items[1]] + 1):
                        high_li.append(abs(df.iloc[k].get('high')))
                        if self.is_execute:
                            wick_val = 'open' if int(df.iloc[k].get('is_bullish')) == 1 else 'close'
                            low_li.append(abs(df.iloc[k].get(wick_val)))
                        else:
                            low_li.append(abs(df.iloc[k].get('low')))
                            # low_li.append(abs(df.iloc[d_z[k]].get('low')))
                    # print(high_li, low_li)
                    ideal_zone_list = df['ideal_zone'].iloc[all_base_zone_index[items[0]]:all_base_zone_index[items[1]] + 1].to_list()
                    y1 = max(high_li)
                    y2 = min(low_li)
                    chk_int = self.check_zone_violation(df, all_base_zone_index[items[1]], (y2, y1), False)
                    # print(y2, y1, chk_int)
                    if not(chk_int) and any(value != 'BADZONE' for value in ideal_zone_list):
                        for m in range(all_base_zone_index[items[0]], all_base_zone_index[items[1]] + 1):
                            df.loc[m, 'final_zone'] = 'SZ'
                            valid_sz_list.append((y2, y1))

                elif len(items) == 1:
                    s_row_data = df.iloc[all_base_zone_index[items[0]]]
                    s_high_dat = s_row_data.get("high")
                    if self.is_execute:
                        wick_val = 'open' if int(s_row_data.get('is_bullish')) == 1 else 'close'
                        s_low_dat = s_row_data.get(wick_val)
                    else:
                        s_low_dat = s_row_data.get("low")

                    chk_int = self.check_zone_violation(df, all_base_zone_index[items[0]], (s_low_dat, s_high_dat), False)
                    if not(chk_int):
                        df.loc[all_base_zone_index[items[0]], 'final_zone'] = 'SZ'
                        valid_sz_list.append((s_low_dat, s_high_dat))

        return df, valid_sz_list
    
    def calculate_zones_with_leg_out(self, dz_sz, df, all_base_zone_index, isDZ):
        zone_ranges = []
        for items in dz_sz:
            if len(items) == 2:
                low_li = []
                high_li = []
                ex_low_li = []
                ex_high_li = []
                prev_t = df.iloc[all_base_zone_index[items[0]] - 1].get('timestamp')
                next_t = df.iloc[all_base_zone_index[items[1]] + 1].get('timestamp')
                for k in range(all_base_zone_index[items[0]], all_base_zone_index[items[1]] + 1):
                    if isDZ:
                        low_li.append(abs(df.iloc[k].get('low')))
                        if self.is_execute:
                            wick_val = 'close' if int(df.iloc[k].get('is_bullish')) == 1 else 'open'
                            high_li.append(abs(df.iloc[k].get(wick_val)))
                        else:
                            high_li.append(abs(df.iloc[k].get('high')))
                            # low_li.append(abs(df.iloc[d_z[k]].get('low')))
                    else:
                        high_li.append(abs(df.iloc[k].get('high')))
                        if self.is_execute:
                            wick_val = 'open' if int(df.iloc[k].get('is_bullish')) == 1 else 'close'
                            # wick_val = 'close' if int(df.iloc[k].get('is_bullish')) == 1 else 'open'
                            low_li.append(abs(df.iloc[k].get(wick_val)))
                        else:
                            low_li.append(abs(df.iloc[k].get('low')))
                            # low_li.append(abs(df.iloc[d_z[k]].get('low')))
                    
                    if k == all_base_zone_index[items[1]]:
                        while True:
                            if k+1 < len(df):
                                k = k + 1
                                # print(df.iloc[k].to_list())
                                if bool(df.iloc[k].get('is_leg_out')) == True:
                                    ex_low_li.append(abs(df.iloc[k].get('low')))
                                    ex_high_li.append(abs(df.iloc[k].get('high')))
                                else:
                                    break
                            else:
                                break
                        # print("#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*##*")
                ideal_zone_list = df['ideal_zone'].iloc[all_base_zone_index[items[0]]:all_base_zone_index[items[1]] + 1].to_list()
                y1 = max(high_li)
                y2 = min(low_li)
                chk_int = self.check_zone_violation(df, all_base_zone_index[items[1]], (y2, y1), isDZ)
                if not(chk_int) and any(value != 'BADZONE' for value in ideal_zone_list):
                    cm_li = low_li + ex_low_li
                    cm_hi = high_li + ex_high_li  
                    point1 = {"time": int(prev_t), "price": min(cm_li)}
                    point2 = {"time": int(next_t), "price": max(cm_hi)}
                    zone_ranges.append([point1,point2])

            elif len(items) == 1:
                hi_li = []
                lo_li = []
                idx = all_base_zone_index[items[0]]
                s_row_data = df.iloc[idx]
                
                if isDZ:
                    s_low_dat = s_row_data.get("low")
                    if self.is_execute:
                        wick_val = 'close' if int(s_row_data.get('is_bullish')) == 1 else 'open'
                        s_high_dat = s_row_data.get(wick_val)
                    else:
                        s_high_dat = s_row_data.get("high")
                else:
                    s_high_dat = s_row_data.get("high")
                    if self.is_execute:
                        # wick_val = 'close' if int(s_row_data.get('is_bullish')) == 1 else 'open'
                        wick_val = 'open' if int(s_row_data.get('is_bullish')) == 1 else 'close'
                        s_low_dat = s_row_data.get(wick_val)
                    else:
                        s_low_dat = s_row_data.get("low")
                
                hi_li.append(s_high_dat)
                lo_li.append(s_low_dat)

                while True:
                    if idx + 1 < len(df):
                        idx = idx + 1
                        if bool(df.iloc[idx].get('is_leg_out')):
                            hi_li.append(abs(df.iloc[idx].get('high')))
                            lo_li.append(abs(df.iloc[idx].get('low')))
                        else:
                            break
                    else:
                        break

                chk_int = self.check_zone_violation(df, all_base_zone_index[items[0]], (s_low_dat, s_high_dat), isDZ)
                if not(chk_int):
                    # if self.is_execute:
                    #     print(s_low_dat, s_high_dat, isDZ, "11111111111111111111111111111111111111111111111111111")
                    prev_t = df.iloc[all_base_zone_index[items[0]] - 1].get('timestamp')
                    next_t = df.iloc[all_base_zone_index[items[0]] + 1].get('timestamp')
                    point1 = {"time": int(prev_t), "price": min(lo_li)}
                    point2 = {"time": int(next_t), "price": max(hi_li)}
                    zone_ranges.append([point1,point2])
        return zone_ranges
   
    def update_new_buy_zones_df(self):
        valid_dz_list = []
        df = pd.read_csv(self.csv_path)
        df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst = True)
        df = df[df.timestamp <= self.last_d_time]
        # df['timestamp'] = df['timestamp'].astype(np.int64) // 10**9
        # cmp_tstamp = df.iloc[len(df) - 1]['timestamp'] 
        # for i in range(len(df) - 1):
        d_z, s_z, all_base_zone_index, dz_val, sz_val = self.calculate_full_zones()
        # print(all_base_zone_index, d_z, "******************************")
        if len(all_base_zone_index) == 1:
            s_row_data = df.iloc[all_base_zone_index[0]]
            s_low_dat = s_row_data.get("low")
            if self.is_execute:
                wick_val = 'close' if int(s_row_data.get('is_bullish')) == 1 else 'open'
                s_high_dat = s_row_data.get(wick_val)
            else:
                s_high_dat = s_row_data.get("high")

            chk_int = self.check_zone_violation(df, all_base_zone_index[0], (s_low_dat, s_high_dat), True)
            if not(chk_int):
                df.loc[all_base_zone_index[0], 'final_zone'] = 'DZ'
                valid_dz_list.append((s_low_dat, s_high_dat))
        else:
            for items in d_z:

                if len(items) == 2:
                    low_li = []
                    high_li = []
                    # prev_t = df.iloc[all_base_zone_index[items[0]] - 1].get('timestamp')
                    # next_t = df.iloc[all_base_zone_index[items[1]] + 1].get('timestamp')
                    for k in range(all_base_zone_index[items[0]], all_base_zone_index[items[1]] + 1):
                        low_li.append(abs(df.iloc[k].get('low')))
                        if self.is_execute:
                            wick_val = 'close' if int(df.iloc[k].get('is_bullish')) == 1 else 'open'
                            high_li.append(abs(df.iloc[k].get(wick_val)))
                        else:
                            high_li.append(abs(df.iloc[k].get('high')))
                            # low_li.append(abs(df.iloc[d_z[k]].get('low')))
                    ideal_zone_list = df['ideal_zone'].iloc[all_base_zone_index[items[0]]:all_base_zone_index[items[1]] + 1].to_list()
                    y1 = max(high_li)
                    y2 = min(low_li)
                    chk_int = self.check_zone_violation(df, all_base_zone_index[items[1]], (y2, y1), True)
                    if not(chk_int) and any(value != 'BADZONE' for value in ideal_zone_list):
                        for n in range(all_base_zone_index[items[0]], all_base_zone_index[items[1]] + 1):
                            df.loc[n, 'final_zone'] = 'DZ'
                            valid_dz_list.append((y2, y1))

                elif len(items) == 1:
                    # print(items, all_base_zone_index)
                    s_row_data = df.iloc[all_base_zone_index[items[0]]]
                    s_low_dat = s_row_data.get("low")
                    if self.is_execute:
                        wick_val = 'close' if int(s_row_data.get('is_bullish')) == 1 else 'open'
                        s_high_dat = s_row_data.get(wick_val)
                    else:
                        s_high_dat = s_row_data.get("high")

                    chk_int = self.check_zone_violation(df, all_base_zone_index[items[0]], (s_low_dat, s_high_dat), True)
                    if not(chk_int):
                        df.loc[all_base_zone_index[items[0]], 'final_zone'] = 'DZ'
                        valid_dz_list.append((s_low_dat, s_high_dat))

        return df, valid_dz_list

    def filter_valid_dz_list(self, valid_dz_list: list, qualified_list: list):
        # filtered_list = []
        for idx, dz in enumerate(valid_dz_list):
            point1, point2 = dz
            
            price1 = point1["price"]
            price2 = point2["price"]
            if (price1, price2) not in qualified_list:
                valid_dz_list.pop(idx)
        return valid_dz_list
    
    def calculate_all_sell_zones(self):
        valid_sz_list = []
        df = pd.read_csv(self.csv_path)
        df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst = True)
        df = df[df.timestamp <= self.last_d_time]
        df['timestamp'] = (df['timestamp'].astype(np.int64) // 10**9).astype(int)
        # for i in range(len(df) - 1):
        # cmp_tstamp = df.iloc[len(df) - 1]['timestamp']
        d_z, s_z, all_base_zone_index, dz_val, sz_val = self.calculate_full_zones()
        if len(all_base_zone_index) == 1:
            s_leg_out_li = []
            ksz = all_base_zone_index[0]
            s_row_data = df.iloc[all_base_zone_index[0]]
            s_high_dat = s_row_data.get("high")
            if self.is_execute:
                wick_val = 'open' if int(s_row_data.get('is_bullish')) == 1 else 'close'
                s_low_dat = s_row_data.get(wick_val)
            else:
                s_low_dat = s_row_data.get("low")
            
            while True:
                ksz += 1
                if ksz < len(df):
                    if bool(df.iloc[ksz].get('is_leg_out')):
                        s_leg_out_li.append(df.iloc[ksz].get('low'))
                    else:
                        break
                else:
                    break
            
            if min(s_leg_out_li) <= s_high_dat:
                prev_t = df.iloc[all_base_zone_index[0] - 1].get('timestamp')
                next_t = df.iloc[all_base_zone_index[0] + 1].get('timestamp')
                # chk_int = self.check_zone_violation(df, all_base_zone_index[0], (s_low_dat, s_high_dat), False)
                # if not(chk_int):
                df.loc[all_base_zone_index[0], 'final_zone'] = 'SZ'
                point1 = {"time": int(prev_t), "price": s_low_dat}
                point2 = {"time": int(next_t), "price": s_high_dat}
                valid_sz_list.append([point1,point2])
        else:
            for items in s_z:
                if len(items) == 2:
                    low_li = []
                    high_li = []
                    s_leg_out_li = []
                    prev_t = df.iloc[all_base_zone_index[items[0]] - 1].get('timestamp')
                    next_t = df.iloc[all_base_zone_index[items[1]] + 1].get('timestamp')
                    for k in range(all_base_zone_index[items[0]], all_base_zone_index[items[1]] + 1):
                        high_li.append(abs(df.iloc[k].get('high')))
                        if self.is_execute:
                            wick_val = 'open' if int(df.iloc[k].get('is_bullish')) == 1 else 'close'
                            low_li.append(abs(df.iloc[k].get(wick_val)))
                        else:
                            low_li.append(abs(df.iloc[k].get('low')))

                        if k == all_base_zone_index[items[1]]:
                            k += 1
                            if k < len(df):
                                if bool(df.iloc[k].get('is_leg_out')):
                                    s_leg_out_li.append(df.iloc[k].get('low'))
                                else:
                                    break
                            else:
                                break
                            # low_li.append(abs(df.iloc[d_z[k]].get('low')))
                    # print(high_li, low_li)
                    ideal_zone_list = df['ideal_zone'].iloc[all_base_zone_index[items[0]]:all_base_zone_index[items[1]] + 1].to_list()
                    y1 = max(high_li)
                    y2 = min(low_li)
                    # chk_int = self.check_zone_violation(df, all_base_zone_index[items[1]], (y2, y1), False)
                    # print(y2, y1, chk_int)
                    if min(s_leg_out_li) <= y1:
                        if any(value != 'BADZONE' for value in ideal_zone_list):
                            point1 = {"time": int(prev_t), "price": y2}
                            point2 = {"time": int(next_t), "price": y1}
                            valid_sz_list.append([point1,point2])

                elif len(items) == 1:
                    s_leg_out_li = []
                    ksz = all_base_zone_index[items[0]]
                    s_row_data = df.iloc[all_base_zone_index[items[0]]]
                    s_high_dat = s_row_data.get("high")
                    if self.is_execute:
                        wick_val = 'open' if int(s_row_data.get('is_bullish')) == 1 else 'close'
                        s_low_dat = s_row_data.get(wick_val)
                    else:
                        s_low_dat = s_row_data.get("low")

                    while True:
                        ksz += 1
                        if ksz < len(df):
                            if bool(df.iloc[ksz].get('is_leg_out')):
                                s_leg_out_li.append(df.iloc[ksz].get('low'))
                            else:
                                break
                        else:
                            break
                    # chk_int = self.check_zone_violation(df, all_base_zone_index[items[0]], (s_low_dat, s_high_dat), False)
                    # if not(chk_int):
                    if min(s_leg_out_li) <= s_high_dat:
                        prev_t = df.iloc[all_base_zone_index[items[0]] - 1].get('timestamp')
                        next_t = df.iloc[all_base_zone_index[items[0]] + 1].get('timestamp')
                        point1 = {"time": int(prev_t), "price": s_low_dat}
                        point2 = {"time": int(next_t), "price": s_high_dat}
                        valid_sz_list.append([point1,point2])

        return valid_sz_list

    def calculate_new_sell_zones(self):
        valid_sz_list = []
        df = pd.read_csv(self.csv_path)
        df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst = True)
        df = df[df.timestamp <= self.last_d_time]
        df['timestamp'] = (df['timestamp'].astype(np.int64) // 10**9).astype(int)
        # for i in range(len(df) - 1):
        print(len(df), self.last_d_time, self.csv_path, "666666666666666666666666666666666666666")
        cmp_tstamp = df.iloc[-2]['timestamp']
        d_z, s_z, all_base_zone_index, dz_val, sz_val = self.calculate_full_zones()
        if len(all_base_zone_index) == 1:
            s_row_data = df.iloc[all_base_zone_index[0]]
            s_high_dat = s_row_data.get("high")
            if self.is_execute:
                wick_val = 'open' if int(s_row_data.get('is_bullish')) == 1 else 'close'
                s_low_dat = s_row_data.get(wick_val)
            else:
                s_low_dat = s_row_data.get("low")

            chk_int = self.check_zone_violation(df, all_base_zone_index[0], (s_low_dat, s_high_dat), False)
            if not(chk_int):
                df.loc[all_base_zone_index[0], 'final_zone'] = 'SZ'
        else:
            for items in s_z:
                if len(items) == 2:
                    low_li = []
                    high_li = []
                    prev_t = df.iloc[all_base_zone_index[items[0]] - 1].get('timestamp')
                    next_t = df.iloc[all_base_zone_index[items[1]] + 1].get('timestamp')
                    for k in range(all_base_zone_index[items[0]], all_base_zone_index[items[1]] + 1):
                        high_li.append(abs(df.iloc[k].get('high')))
                        if self.is_execute:
                            wick_val = 'open' if int(df.iloc[k].get('is_bullish')) == 1 else 'close'
                            low_li.append(abs(df.iloc[k].get(wick_val)))
                        else:
                            low_li.append(abs(df.iloc[k].get('low')))
                            # low_li.append(abs(df.iloc[d_z[k]].get('low')))
                    # print(high_li, low_li)
                    ideal_zone_list = df['ideal_zone'].iloc[all_base_zone_index[items[0]]:all_base_zone_index[items[1]] + 1].to_list()
                    y1 = max(high_li)
                    y2 = min(low_li)
                    chk_int = self.check_zone_violation(df, all_base_zone_index[items[1]], (y2, y1), False)
                    # print(y2, y1, chk_int)
                    if not(chk_int) and any(value != 'BADZONE' for value in ideal_zone_list):
                        point1 = {"time": int(prev_t), "price": y2}
                        point2 = {"time": int(cmp_tstamp), "price": y1}
                        valid_sz_list.append([point1,point2])

                elif len(items) == 1:
                    s_row_data = df.iloc[all_base_zone_index[items[0]]]
                    s_high_dat = s_row_data.get("high")
                    if self.is_execute:
                        wick_val = 'open' if int(s_row_data.get('is_bullish')) == 1 else 'close'
                        s_low_dat = s_row_data.get(wick_val)
                    else:
                        s_low_dat = s_row_data.get("low")

                    chk_int = self.check_zone_violation(df, all_base_zone_index[items[0]], (s_low_dat, s_high_dat), False)
                    if not(chk_int):
                        prev_t = df.iloc[all_base_zone_index[items[0]] - 1].get('timestamp')
                        next_t = df.iloc[all_base_zone_index[items[0]] + 1].get('timestamp')
                        point1 = {"time": int(prev_t), "price": s_low_dat}
                        point2 = {"time": int(cmp_tstamp), "price": s_high_dat}
                        valid_sz_list.append([point1,point2])
        # if self.is_execute:
        return valid_sz_list
    
    def get_qualified_sell_zones(self):
        df = pd.read_csv(self.csv_path)
        df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst = True)
        df = df[df.timestamp <= self.last_d_time]
        df['timestamp'] = (df['timestamp'].astype(np.int64) // 10**9).astype(int)
        d_z, s_z, all_base_zone_index, dz_val, sz_val = self.calculate_full_zones()
        all_buy_zones = self.calculate_all_buy_zones()
        all_sell_zones = self.calculate_all_sell_zones()
        valid_sz_list = self.calculate_new_sell_zones()
        all_zones_with_lo = self.calculate_zones_with_leg_out(s_z, df, all_base_zone_index, False)
        all_zones_with_lo = sorted(all_zones_with_lo, key=lambda z: z[0]["time"])
        all_zones = all_buy_zones + all_sell_zones
        all_zones = sorted(all_zones, key=lambda z: z[0]["time"])
        new_qual_sz = self.qualified_zones(all_zones_with_lo, all_zones, valid_sz_list, df, False)
        return new_qual_sz
    
    def calculate_all_buy_zones(self):
        valid_dz_list = []
        df = pd.read_csv(self.csv_path)
        df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst = True)
        df = df[df.timestamp <= self.last_d_time]
        df['timestamp'] = (df['timestamp'].astype(np.int64) // 10**9).astype(int)
        # cmp_tstamp = df.iloc[len(df) - 1]['timestamp'] 
        # for i in range(len(df) - 1):
        d_z, s_z, all_base_zone_index, dz_val, sz_val = self.calculate_full_zones()
        if len(all_base_zone_index) == 1:
            kak_index = all_base_zone_index[0]
            s_row_data = df.iloc[all_base_zone_index[0]]
            s_low_dat = s_row_data.get("low")
            if self.is_execute:
                wick_val = 'close' if int(s_row_data.get('is_bullish')) == 1 else 'open'
                s_high_dat = s_row_data.get(wick_val)
            else:
                s_high_dat = s_row_data.get("high")
            prev_t = df.iloc[all_base_zone_index[0] - 1].get('timestamp')
            next_t = df.iloc[all_base_zone_index[0] + 1].get('timestamp')
            z_type = df.iloc[all_base_zone_index[0]].get('buy_sell_zone_type')
            # chk_int = self.check_zone_violation(df, all_base_zone_index[0], (s_low_dat, s_high_dat), True)
            # if not(chk_int):
            # is_actual_dz = False
            leg_out_list = []
            while True:
                kak_index = kak_index + 1
                if kak_index < len(df):
                    if bool(df.iloc[kak_index].get('is_leg_out')):
                        leg_out_list.append(df.iloc[kak_index].get('high'))
                    else:
                        break
                else:
                    break
            if max(leg_out_list) >= s_row_data.get('close'):
                df.loc[all_base_zone_index[0], 'final_zone'] = 'DZ'
                point1 = {"time": int(prev_t), "price": s_low_dat}
                point2 = {"time": int(next_t), "price": s_high_dat}
                valid_dz_list.append([point1,point2])
        else:
            for items in d_z:
                if len(items) == 2:
                    low_li = []
                    high_li = []
                    leg_out_li = []
                    z_type_list = []
                    prev_t = df.iloc[all_base_zone_index[items[0]] - 1].get('timestamp')
                    next_t = df.iloc[all_base_zone_index[items[1]] + 1].get('timestamp')
                    for k in range(all_base_zone_index[items[0]], all_base_zone_index[items[1]] + 1):
                        low_li.append(abs(df.iloc[k].get('low')))
                        if self.is_execute:
                            wick_val = 'close' if int(df.iloc[k].get('is_bullish')) == 1 else 'open'
                            high_li.append(abs(df.iloc[k].get(wick_val)))
                        else:
                            high_li.append(abs(df.iloc[k].get('high')))
                            # low_li.append(abs(df.iloc[d_z[k]].get('low')))
                        z_type_list.append(df.iloc[k].get('buy_sell_zone_type'))
                        if k == all_base_zone_index[items[1]]:
                            while True:
                                k += 1
                                if k < len(df):
                                    if bool(df.iloc[k].get('is_leg_out')):
                                        leg_out_li.append(df.iloc[k].get('high'))
                                    else:
                                        break
                                else:
                                    break
                    
                    ideal_zone_list = df['ideal_zone'].iloc[all_base_zone_index[items[0]]:all_base_zone_index[items[1]] + 1].to_list()
                    y1 = max(high_li)
                    y2 = min(low_li)
                    if max(leg_out_li) >= y1:
                    # chk_int = self.check_zone_violation(df, all_base_zone_index[items[1]], (y2, y1), True)
                        if any(value != 'BADZONE' for value in ideal_zone_list):    
                            point1 = {"time": int(prev_t), "price": y2}
                            point2 = {"time": int(next_t), "price": y1}
                            valid_dz_list.append([point1,point2])

                elif len(items) == 1:
                    leg_out_li = []
                    kak_index = all_base_zone_index[items[0]]
                    s_row_data = df.iloc[all_base_zone_index[items[0]]]
                    s_low_dat = s_row_data.get("low")
                    if self.is_execute:
                        wick_val = 'close' if int(s_row_data.get('is_bullish')) == 1 else 'open'
                        s_high_dat = s_row_data.get(wick_val)
                    else:
                        s_high_dat = s_row_data.get("high")

                    while True:
                        kak_index += 1
                        if kak_index < len(df):
                            if df.iloc[kak_index].get('is_leg_out'):
                                leg_out_li.append(df.iloc[kak_index].get('high'))
                            else:
                                break
                        else:
                            break

                    if max(leg_out_li) >= s_row_data.get('close'):
                    # chk_int = self.check_zone_violation(df, all_base_zone_index[items[0]], (s_low_dat, s_high_dat), True)
                    # if not(chk_int):
                        prev_t = df.iloc[all_base_zone_index[items[0]] - 1].get('timestamp')
                        next_t = df.iloc[all_base_zone_index[items[0]] + 1].get('timestamp')
                        point1 = {"time": int(prev_t), "price": s_low_dat}
                        point2 = {"time": int(next_t), "price": s_high_dat}
                        valid_dz_list.append([point1,point2])

        return valid_dz_list

    def calculate_new_buy_zones(self):
        valid_dz_list = []
        df = pd.read_csv(self.csv_path)
        df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst = True)
        df = df[df.timestamp <= self.last_d_time]
        df['timestamp'] = (df['timestamp'].astype(np.int64) // 10**9).astype(int)
        # print(len(df), self.last_d_time, "666666666666666666666666666666666666666666")
        cmp_tstamp = df.iloc[-2]['timestamp'] 
        # for i in range(len(df) - 1):
        d_z, s_z, all_base_zone_index, dz_val, sz_val = self.calculate_full_zones()
        # print(all_base_zone_index)
        if len(all_base_zone_index) == 1:
            s_row_data = df.iloc[all_base_zone_index[0]]
            s_low_dat = s_row_data.get("low")
            if self.is_execute:
                wick_val = 'close' if int(s_row_data.get('is_bullish')) == 1 else 'open'
                s_high_dat = s_row_data.get(wick_val)
            else:
                s_high_dat = s_row_data.get("high")
            chk_int = self.check_zone_violation(df, all_base_zone_index[0], (s_low_dat, s_high_dat), True)
            if not(chk_int):
                df.loc[all_base_zone_index[0], 'final_zone'] = 'DZ'
        else:
            for items in d_z:
                if len(items) == 2:
                    low_li = []
                    high_li = []
                    prev_t = df.iloc[all_base_zone_index[items[0]] - 1].get('timestamp')
                    next_t = df.iloc[all_base_zone_index[items[1]] + 1].get('timestamp')
                    past_leg_out_index = all_base_zone_index[items[0]] - 1
                    low_li.append(abs(df.iloc[past_leg_out_index].get('low')))
                    for k in range(all_base_zone_index[items[0]], all_base_zone_index[items[1]] + 1):
                        # low_li.append(abs(df.iloc[k-].get('low')))
                        low_li.append(abs(df.iloc[k].get('low')))
                        if self.is_execute:
                            wick_val = 'close' if int(df.iloc[k].get('is_bullish')) == 1 else 'open'
                            high_li.append(abs(df.iloc[k].get(wick_val)))
                        else:
                            high_li.append(abs(df.iloc[k].get('high')))
                        
                        if k == all_base_zone_index[items[1]]:
                            while True:
                                k += 1
                                if k < len(df):
                                    if bool(df.iloc[k].get('is_basing')) == False:
                                        low_li.append(abs(df.iloc[k].get('low')))
                                    else:
                                        break
                                else:
                                    break
                            # low_li.append(abs(df.iloc[d_z[k]].get('low')))
                    ideal_zone_list = df['ideal_zone'].iloc[all_base_zone_index[items[0]]:all_base_zone_index[items[1]] + 1].to_list()
                    y1 = max(high_li)
                    y2 = min(low_li)
                    chk_int = self.check_zone_violation(df, all_base_zone_index[items[1]], (y2, y1), True)
                    if not(chk_int) and any(value != 'BADZONE' for value in ideal_zone_list):    
                        point1 = {"time": int(prev_t), "price": y2}
                        point2 = {"time": int(cmp_tstamp), "price": y1}
                        valid_dz_list.append([point1,point2])

                elif len(items) == 1:
                    s_low_dat = []
                    s_high_dat = []
                    zone_idx = all_base_zone_index[items[0]]
                    s_row_data = df.iloc[zone_idx]
                    s_low_dat.append(df.iloc[zone_idx - 1].get("low"))
                    s_low_dat.append(s_row_data.get("low"))
                    if self.is_execute:
                        wick_val = 'close' if int(s_row_data.get('is_bullish')) == 1 else 'open'
                        s_high_dat.append(s_row_data.get(wick_val))
                    else:
                        s_high_dat.append(s_row_data.get("high"))

                    while True:
                        zone_idx += 1
                        if zone_idx < len(df):
                            if bool(df.iloc[zone_idx].get('is_basing')) == False:
                                s_low_dat.append(df.iloc[zone_idx].get('low'))
                            else:
                                break
                        else:
                            break
                    chk_int = self.check_zone_violation(df, all_base_zone_index[items[0]], (min(s_low_dat), max(s_high_dat)), True)
                    if not(chk_int):
                        prev_t = df.iloc[all_base_zone_index[items[0]] - 1].get('timestamp')
                        next_t = df.iloc[all_base_zone_index[items[0]] + 1].get('timestamp')
                        point1 = {"time": int(prev_t), "price": min(s_low_dat)}
                        point2 = {"time": int(cmp_tstamp), "price": max(s_high_dat)}
                        valid_dz_list.append([point1,point2])

        # print(valid_dz_list)
        # if self.is_execute:
            
        
        return valid_dz_list
    
    def get_qualified_buy_zones(self):
        df = pd.read_csv(self.csv_path)
        print(self.csv_path, "qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq")
        df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst = True)
        df = df[df.timestamp <= self.last_d_time]
        df['timestamp'] = (df['timestamp'].astype(np.int64) // 10**9).astype(int)
        d_z, s_z, all_base_zone_index, dz_val, sz_val = self.calculate_full_zones()
        all_buy_zones = self.calculate_all_buy_zones()
        all_sell_zones = self.calculate_all_sell_zones()
        valid_dz_list = self.calculate_new_buy_zones()
        all_zones_with_lo = self.calculate_zones_with_leg_out(d_z, df, all_base_zone_index, True)
        all_zones_with_lo = sorted(all_zones_with_lo, key=lambda z: z[0]["time"])
        all_zones = all_buy_zones + all_sell_zones
        all_zones = sorted(all_zones, key=lambda z: z[0]["time"])
        new_qual_dz = self.qualified_zones(all_zones_with_lo, all_zones, valid_dz_list, df, True)
        return new_qual_dz
    
    def get_qualified_alterated_zones(self):
        final_dz_list = self.get_qualified_buy_zones()
        final_sz_list = self.get_qualified_sell_zones()
        overlapping_indexes = self.remove_overlapping_ranges(final_dz_list, final_sz_list)
        for rng in overlapping_indexes:
        #     # print(dz_val_list[rng], "##############################################")
            if 0 <= rng < len(final_dz_list):
                final_dz_list.pop(rng)
        bind_data = {
            'Buy' : final_dz_list,
            'Sell' : final_sz_list
        }
        return bind_data


    
    def remove_duplicates(self, list1, list2):
        return [item for item in list1 if item not in list2]

    def calculate_full_zones(self):
        # all_base_zone_index = []
        interim_list = []
        df = pd.read_csv(self.csv_path)
        df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst = True)
        df = df[df.timestamp <= self.last_d_time]
        df['timestamp'] = (df['timestamp'].astype(np.int64) // 10**9).astype(int)
        # print(df["is_basing"].to_list())
        if '1.0' in df["is_basing"].to_list() or '0.0' in df["is_basing"].to_list():
            df['is_basing'] = df['is_basing'].replace({'0.0': False, '1.0': True})
        if 'TRUE' in df["is_basing"].to_list() or 'FALSE' in df["is_basing"].to_list():
            df['is_basing'] = df['is_basing'].replace({'FALSE': False, 'TRUE': True})
            # print("pppppppppppppppppppppppppppppppppppppppp")
        last_false_index = df[df['is_basing'] == False].index[-1]

        all_base_zone_index = df[(df['is_basing'] == True) & (df.index <= last_false_index)].index.tolist()
        # print(all_base_list)
        # for i in range(len(df) - 1):
            
        #     if bool(df.iloc[i].get('is_basing')):
        #         all_base_zone_index.append(i)
        #         while True:
        #             if i + 1 < len(df):



            # if bool(df.iloc[i].get("is_basing")) == True and bool(df.iloc[i-1].get("is_basing")) == False and bool(df.iloc[i + 1].get("is_basing")) == False:
            #     all_base_zone_index.append(i)

            # elif bool(df.iloc[i].get("is_basing")) == True and bool(df.iloc[i-1].get("is_basing")) == False:
            #     j = i
            #     while j < len(df) and bool(df.iloc[j].get("is_basing")) == True:
            #         if j + 1 < len(df) and bool(df.iloc[j + 1].get("is_basing")) == False:
            #             all_base_zone_index.extend(range(i, j + 1))
            #             break
            #         j += 1
        # dz_list = []
        # print(all_base_zone_index)
        d_z, s_z, d_z_val, s_z_val = self.divide_buy_and_sell_zones(all_base_zone_index, df)
        # print(d_z, d_z_val, "69696969696969696969696969696")
        return d_z, s_z, all_base_zone_index, d_z_val, s_z_val
    
    def add_timestamp(self):
        if self.csv_path.__contains__("month"):
            return timedelta(days=30).total_seconds()
        
        elif self.csv_path.__contains__("week"):
            return timedelta(days=7).total_seconds()
        
        elif self.csv_path.__contains__("daily"):
            return timedelta(days=1).total_seconds()
        
        elif self.csv_path.__contains__("seventy_five"):
            return timedelta(minutes=75).total_seconds()
        
        elif self.csv_path.__contains__("sixty"):
            return timedelta(minutes=60).total_seconds()
        
        elif self.csv_path.__contains__("fifteen"):
            return timedelta(minutes=15).total_seconds()
        
    def find_increasing_indices(self, lst):
        increasing_indices = []
        single_values = []
        for i in range(len(lst) - 1):
            if lst[i+1] - lst[i] == 1:
                if not increasing_indices or (increasing_indices and increasing_indices[-1][-1] != i):
                    increasing_indices.append([i, i+1])
                else:
                    increasing_indices[-1][-1] = i+1
            else:
                if not (increasing_indices and increasing_indices[-1][-1] == i):
                    single_values.append(i)
                if lst[i+1] - lst[i] != 1 and (not increasing_indices or (increasing_indices and increasing_indices[-1][-1] != i+1)):
                    single_values.append(i+1)
        if not (increasing_indices and increasing_indices[-1][-1] == len(lst) - 1):
            single_values.append(len(lst) - 1)
        single_values = [i for i in single_values if i not in [j for i in increasing_indices for j in range(i[0], i[1]+1)]]
        return increasing_indices, single_values
    
    def ranges_intersect(self, range1, high_or_low, isDemand):
        start1, end1 = range1
        total_range = abs(range1[0] - range1[1])
        if self.is_execute:
            violate_range = min(start1, end1) + (total_range*0.5)
        else:
            violate_range = min(start1, end1) + (total_range*0.25)
        if isDemand:
            if high_or_low >= violate_range:
                return False
            else:
                return True
        else:
            if high_or_low >= violate_range:
                return True
            else:
                return False

    def calculate_dz(self):
        dz_list = []
        d_z = []
        df = pd.read_csv(self.csv_path)
        df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst = True)
        df = df[df.timestamp <= self.last_d_time]
        df['timestamp'] = (df['timestamp'].astype(np.int64) // 10**9).astype(int)
        cmp = df.iloc[len(df) - 1]['close']
        cmp_tstamp = df.iloc[-2]['timestamp']  
        # open,high,low,close,qty,tradeTime,timestamp,wick,is_basing,ideal_zone,zone_or_not,zone2,additional_zone_type,buy_sell_zone_type,buy_sell_zone,tick,is_leg_out
        for i in range(len(df) - 1):
            if i == (len(df) - 1): #  or i == (len(df) - 2)
                continue
            row_data = df.iloc[i]
            # if row_data.get('final_fz') == 'VZ' and (row_data.get("high") < cmp):
            if bool(row_data.get("is_basing")) == True and (row_data.get("high") <= cmp) and row_data.get('ideal_zone') != 'BADZONE': # row_data.get("open")
                chk_int = False
                found_leg_out = False
                for k in range(i+1, len(df)):
                    if bool(df.iloc[k]['is_leg_out']) == True and not(found_leg_out):
                        found_leg_out = True
                        continue
                    
                    if bool(df.iloc[k]['is_basing']) == True and not(found_leg_out):
                        continue

                    if self.is_execute:
                        wick_val = 'close' if int(df.iloc[i].get('is_bullish')) == 1 else 'open'
                        per_intersect = self.ranges_intersect((df.iloc[i].get("low"), df.iloc[i].get(wick_val)), df.iloc[k].get('low'), True)
                    else:
                        per_intersect = self.ranges_intersect((df.iloc[i].get("low"), df.iloc[i].get("high")), df.iloc[k].get('low'), True)
                        # print(df.iloc[i].to_list())
                    if per_intersect:
                        chk_int = True
                        break
                if not chk_int and found_leg_out:
                    # df1.loc[i, 'final_fz'] = 'VZ'
                    d_z.append(i)
        if len(d_z) >= 2:
            group, single = self.find_increasing_indices(d_z)
            for li in group:
                low_li = []
                high_li = []
                prev_t = df.iloc[d_z[li[0]] - 1].get('timestamp')
                next_t = df.iloc[d_z[li[1]] + 1].get('timestamp')
                for k in range(li[0], li[1]+1):
                    low_li.append(abs(df.iloc[d_z[k]].get('low')))
                    if self.is_execute:
                        wick_val = 'close' if int(df.iloc[d_z[k]].get('is_bullish')) == 1 else 'open'
                        high_li.append(abs(df.iloc[d_z[k]].get(wick_val)))
                    else:
                        high_li.append(abs(df.iloc[d_z[k]].get('high')))
                        # low_li.append(abs(df.iloc[d_z[k]].get('low')))
                y1 = max(high_li)
                y2 = min(low_li)
                point1 = {"time": int(prev_t), "price": y2, "act": int(df.iloc[i]['timestamp'])}
                point2 = {"time": int(cmp_tstamp), "price": y1, "act": int(df.iloc[i]['timestamp'])}
                dz_list.append([point1,point2])
            
            for si in single:
                s_row_data = df.iloc[d_z[si]]
                s_low_dat = s_row_data.get("low")
                if self.is_execute:
                    wick_val = 'close' if int(s_row_data.get('is_bullish')) == 1 else 'open'
                    s_high_dat = s_row_data.get(wick_val)
                else:
                    s_high_dat = s_row_data.get("high")
                    # s_low_dat = s_row_data.get("low")
                    
                prev_t = df.iloc[d_z[si] - 1].get('timestamp')
                next_t = df.iloc[d_z[si] + 1].get('timestamp')
                point1 = {"time": int(prev_t), "price": s_low_dat}
                point2 = {"time": int(cmp_tstamp), "price": s_high_dat}
                dz_list.append([point1,point2])

        elif len(d_z) == 1:
            s_row_data = df.iloc[d_z[0]]
            s_low_dat = s_row_data.get("low")
            if self.is_execute:
                wick_val = 'close' if int(s_row_data.get('is_bullish')) == 1 else 'open'
                s_high_dat = s_row_data.get(wick_val)
            else:
                s_high_dat = s_row_data.get("high")
                # s_low_dat = s_row_data.get("low")
                
            prev_t = df.iloc[d_z[0] - 1].get('timestamp')
            next_t = df.iloc[d_z[0] + 1].get('timestamp')
            point1 = {"time": int(prev_t), "price": s_low_dat}
            point2 = {"time": int(cmp_tstamp), "price": s_high_dat}
            dz_list.append([point1,point2])
            # if row_data.get("is_basing") == True and (row_data.get("open") < cmp): # row_data.get("open")
            #     chk_int = False
            #     for k in range(i+1, len(df)):
            #         if df.iloc[k]['is_leg_out'] == True:
            #             continue
            #         per_intersect = self.ranges_intersect((df.iloc[i].get("low"), df.iloc[i].get("high")), (df.iloc[k].get('low'), df.iloc[k].get('high')))
            #         if per_intersect > 50:
            #             chk_int = True
            #             break
            #     if not chk_int:
            #         p1_time = df.iloc[i-1]['timestamp']
            #         p2_time = df.iloc[i+1]['timestamp']
            #         point1 = {"time": int(p1_time), "price": row_data.get("low"), "act": int(df.iloc[i]['timestamp'])} # strftime("%Y-%m-%d") int(prev_day.timestamp())
            #         point2 = {"time": int(p2_time), "price": row_data.get("high"), "act": int(df.iloc[i]['timestamp'])}
            #         dz_list.append([point1, point2])

            # if row_data.get("buy_sell_zone") == "DZ":
            #     p1_time = df.iloc[i-1]['timestamp']
            #     p2_time = df.iloc[i+1]['timestamp']
            #     point1 = {"time": int(p1_time), "price": row_data.get("low"), "act": int(df.iloc[i]['timestamp'])} # strftime("%Y-%m-%d") int(prev_day.timestamp())
            #     point2 = {"time": int(p2_time), "price": row_data.get("high"), "act": int(df.iloc[i]['timestamp'])}
            #     dz_list.append([point1, point2])
        # print("calculate_zone_dz_list", dz_list)
        return dz_list
    
    def calculate_sz(self):
        sz_list = []
        s_z = []
        df = pd.read_csv(self.csv_path)
        df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst = True)
        df = df[df.timestamp <= self.last_d_time]
        df['timestamp'] = (df['timestamp'].astype(np.int64) // 10**9).astype(int)
        cmp = df.iloc[len(df) - 1]['close']
        cmp_tstamp = df.iloc[-2]['timestamp']
        # open,high,low,close,qty,tradeTime,timestamp,wick,is_basing,ideal_zone,zone_or_not,zone2,additional_zone_type,buy_sell_zone_type,buy_sell_zone,tick,is_leg_out
        for i in range(len(df) - 1):
            if i == (len(df) - 1): # or i == (len(df) - 2)
                continue
            row_data = df.iloc[i]
            if bool(row_data.get("is_basing")) == True and (row_data.get("high") >= cmp) and row_data.get('ideal_zone') != 'BADZONE':
                chk_int = False
                found_leg_out = False
                for k in range(i+1, len(df)):

                    if bool(df.iloc[k]['is_leg_out']) == True and not(found_leg_out):
                        found_leg_out = True
                        continue
                    
                    if bool(df.iloc[k]['is_basing']) == True and not(found_leg_out):
                        continue

                    if self.is_execute:
                        wick_val = 'close' if int(df.iloc[i].get('is_bullish')) == 0 else 'open'
                        per_intersect = self.ranges_intersect((df.iloc[i].get(wick_val), df.iloc[i].get("high")), df.iloc[k].get('high'), False)
                    else:
                        per_intersect = self.ranges_intersect((df.iloc[i].get("low"), df.iloc[i].get("high")), df.iloc[k].get('high'), False) 


                    if per_intersect:
                        chk_int = True
                        break
                if not chk_int and found_leg_out:
                    # print("SZ_VAL", self.csv_path, df.iloc[i].to_list())
                    s_z.append(i)

        # print("s_z", s_z)
        if len(s_z) >= 2:
            group, single = self.find_increasing_indices(s_z)
            # print("sz_find_increasing_indices", group, single)
            for li in group:
                low_li = []
                high_li = []
                prev_t = df.iloc[s_z[li[0]] - 1].get('timestamp')
                next_t = df.iloc[s_z[li[1]] + 1].get('timestamp')
                for k in range(li[0], li[1]+1):
                    high_li.append(abs(df.iloc[s_z[k]].get('high')))
                    if self.is_execute:
                        wick_val = 'close' if int(df.iloc[i].get('is_bullish')) == 0 else 'open'
                        low_li.append(abs(df.iloc[s_z[k]].get(wick_val)))
                    else:
                        low_li.append(abs(df.iloc[s_z[k]].get('low')))
                y1 = max(high_li)
                y2 = min(low_li)
                point1 = {"time": int(prev_t), "price": y2}
                point2 = {"time": int(cmp_tstamp), "price": y1}
                sz_list.append([point1,point2])

            for si in single:
                s_row_data = df.iloc[s_z[si]]
                # print("s_row_data", s_row_data)
                s_high_dat = s_row_data.get("high")

                if self.is_execute:
                    wick_val = 'close' if int(s_row_data.get('is_bullish')) == 0 else 'open'
                    s_low_dat = s_row_data.get(wick_val)
                else:
                    s_low_dat = s_row_data.get("low")

                prev_t = df.iloc[s_z[si] - 1].get('timestamp')
                next_t = df.iloc[s_z[si] + 1].get('timestamp')
                point1 = {"time": int(prev_t), "price": s_low_dat}
                point2 = {"time": int(cmp_tstamp), "price": s_high_dat}
                sz_list.append([point1,point2])
            # if row_data.get("is_basing") == True and (row_data.get("close") > cmp):
            #     chk_int = False
            #     for k in range(i+1, len(df)):
            #         if df.iloc[k]['is_leg_out'] == True:
            #             continue
            #         per_intersect = self.ranges_intersect((df.iloc[i].get("high"), df.iloc[i].get("open")), (df.iloc[k].get('close'), df.iloc[k].get('open')))
            #         if per_intersect > 50:
            #             chk_int = True
            #             break
            #     if not chk_int:
            #         p1_time = df.iloc[i-1]['timestamp']
            #         p2_time = df.iloc[i+1]['timestamp']
            #         point1 = {"time": int(p1_time), "price": row_data.get("low"), "act": int(df.iloc[i]['timestamp'])} # strftime("%Y-%m-%d") int(prev_day.timestamp())
            #         point2 = {"time": int(p2_time), "price": row_data.get("high"), "act": int(df.iloc[i]['timestamp'])}
            #         sz_list.append([point1, point2])
            # if row_data.get("buy_sell_zone") == "SZ":
            #     p1_time = df.iloc[i-1]['timestamp']
            #     p2_time = df.iloc[i+1]['timestamp']
            #     point1 = {"time": int(p1_time), "price": row_data.get("low"), "act": int(df.iloc[i]['timestamp'])} # strftime("%Y-%m-%d") int(prev_day.timestamp())
            #     point2 = {"time": int(p2_time), "price": row_data.get("high"), "act": int(df.iloc[i]['timestamp'])}
            #     sz_list.append([point1, point2])
        elif len(s_z) == 1:
            s_row_data = df.iloc[s_z[0]]
            s_high_dat = s_row_data.get("high")

            if self.is_execute:
                wick_val = 'close' if int(s_row_data.get('is_bullish')) == 0 else 'open'
                s_low_dat = s_row_data.get(wick_val)
            else:
                s_low_dat = s_row_data.get("low")

            prev_t = df.iloc[s_z[0] - 1].get('timestamp')
            next_t = df.iloc[s_z[0] + 1].get('timestamp')
            point1 = {"time": int(prev_t), "price": s_low_dat}
            point2 = {"time": int(cmp_tstamp), "price": s_high_dat}
            sz_list.append([point1,point2])

        return sz_list

    def remove_overlapping_ranges(self, list1, list2):
        def is_overlap(range1, range2):
            # Unpack the ranges
            low1, high1 = range1[0].get('price'), range1[1].get('price')
            low2, high2 = range2[0].get('price'), range2[1].get('price')
            
            # Check if ranges overlap
            return not (high1 < low2 or high2 < low1)

        # Create a new list for non-overlapping ranges
        overlapping_indexes = []
        
        for r2 in list2:
            for idx, r1 in enumerate(list1):
                if is_overlap(r1, r2):
                    overlapping_indexes.append(idx)
    
        return overlapping_indexes


class ZONE_TIME_FIXATURE:
    def __init__(self, tick, time_frame, last_d_time) -> None:
        # self.csv_path = 
        self.tick = tick
        self.last_d_time = last_d_time
        if time_frame == 25:
            self.time_list = ['weekly', 'daily', 'seventy_five']
        else:
            self.time_list = getattr(cfg, f"TIME_FRAMES_{time_frame}")
        #self.eval_csv_path = f"/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/processed_data_files/{self.tick}_{self.time_list[0]}.csv"
        self.eval_csv_path = os.path.join(os.getcwd(), "apps", "finprod_backend", "processed_data_files", f"{self.tick}_{self.time_list[0]}.csv")
        #self.ana_csv_path = f"/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/processed_data_files/{self.tick}_{self.time_list[1]}.csv"
        self.ana_csv_path = os.path.join(os.getcwd(), "apps", "finprod_backend", "processed_data_files", f"{self.tick}_{self.time_list[1]}.csv")
        #self.exe_csv_path = f"/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/processed_data_files/{self.tick}_{self.time_list[::-1][0]}.csv"
        self.exe_csv_path = os.path.join(os.getcwd(), "apps", "finprod_backend", "processed_data_files", f"{self.tick}_{self.time_list[::-1][0]}.csv")
        # self.cbsz = Calculate_BUY_SELL_ZONES(csv_path, tick, last_d_time)

    def find_closest(self, lst, target):
        return min(lst, key=lambda x: abs(x - target))
    

    def replace_timestamps(self, data, reference_list, act_stamp):
        for sublist in data:
            for entry in sublist:
                if entry['time'] not in reference_list:
                    entry['time'] = self.find_closest(reference_list, entry['time'])
                # if entry['act'] not in reference_list:
                entry['act'] = act_stamp
        return data

    def get_all_execute_timestamp_list(self, csv_path):
        df = pd.read_csv(csv_path)
        df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst = True)
        df = df[df.timestamp <= self.last_d_time]
        df['timestamp'] = (df['timestamp'].astype(np.int64) // 10**9).astype(int)
        return df['timestamp'].to_list()

    def calculate_and_adjust_dz(self):
        out_dict = {}
        # execute_time_list = []
        eval_dz_list = Calculate_BUY_SELL_ZONES(self.eval_csv_path, self.tick, self.last_d_time, False).calculate_new_buy_zones()
        ana_dz_list = Calculate_BUY_SELL_ZONES(self.ana_csv_path, self.tick, self.last_d_time, False).calculate_new_buy_zones()
        
        exe_time_list = self.get_all_execute_timestamp_list(self.exe_csv_path)
        # Calculate_BUY_SELL_ZONES(self.exe_csv_path, self.tick, self.last_d_time, False).calculate_dz()
        # for items in exe_dz_list:
            # execute_time_list.append(items[0].get('time'))
        updated_eval_list = self.replace_timestamps(eval_dz_list, exe_time_list, exe_time_list[::-1][0])
        # print(updated_eval_list)
        updated_ana_list = self.replace_timestamps(ana_dz_list, exe_time_list, exe_time_list[::-1][0])
        out_dict[self.time_list[0]] = updated_eval_list
        out_dict[self.time_list[1]] = updated_ana_list

        return out_dict

    def calculate_and_adjust_sz(self):
        out_dict = {}
        # execute_time_list = []
        eval_dz_list = Calculate_BUY_SELL_ZONES(self.eval_csv_path, self.tick, self.last_d_time, False).calculate_new_sell_zones()
        ana_dz_list = Calculate_BUY_SELL_ZONES(self.ana_csv_path, self.tick, self.last_d_time, False).calculate_new_sell_zones()
        
        exe_time_list = self.get_all_execute_timestamp_list(self.exe_csv_path)
        
        # Calculate_BUY_SELL_ZONES(self.exe_csv_path, self.tick, self.last_d_time, False).calculate_sz()
        
        # for items in exe_dz_list:
        #     execute_time_list.append(items[0].get('time'))

        updated_eval_list = self.replace_timestamps(eval_dz_list, exe_time_list, exe_time_list[::-1][0])
        # print(updated_eval_list)
        updated_ana_list = self.replace_timestamps(ana_dz_list, exe_time_list, exe_time_list[::-1][0])
        out_dict[self.time_list[0]] = updated_eval_list
        out_dict[self.time_list[1]] = updated_ana_list
        
        return out_dict



# if __name__ == "__main__":
#     t = "2024-05-01 12:00:00"
#     dt = datetime.strptime(t, "%Y-%m-%d %H:%M:%S")
#     cbz = Calculate_BUY_ZONES(csv_path="../processed_data_files/hindunilvr_daily.csv", tick="hdfc", last_d_time=dt)
#     ss = cbz.calculate_dz()
#     print(ss)