
import pandas as pd
import numpy as np
from datetime import timedelta
from apps.finprod_backend.modules.utils import utility
from apps.finprod_backend.modules.calculate_zone import Calculate_BUY_SELL_ZONES
import logging
from shared.config.settings import Config as cfg
from datetime import datetime
import talib
import os

logger = logging.getLogger()

class Calculate_setup_execute:
    def __init__(self, stock_name, time_frame, last_dt) -> None:
        self.stock_tick = stock_name
        self.time_frame = time_frame
        if time_frame == 25:
            self.time_list = ['weekly', 'daily', 'seventy_five']
            # getattr(cfg, f"TIME_FRAMES_2")
            # if 'sixty' in self.time_list:
            #     self.time_list.remove('sixty')
        else:
            self.time_list = getattr(cfg, f"TIME_FRAMES_{time_frame}")
        self.last_d_time = last_dt
        self.cmp_price = None

    def get_execute_df(self):
        exe_tf = self.time_list[::-1][0]
        #exe_file_path = f"/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/processed_data_files/{self.stock_tick}_{exe_tf}.csv"
        exe_file_path = os.path.join(os.getcwd(), 'apps', 'finprod_backend', 'processed_data_files', f"{self.stock_tick}_{exe_tf}.csv")
        # if self.time_frame == 2:
        #     exe_file_path = f"./processed_data_fi les/{self.stock_tick}_daily.csv"
        df = pd.read_csv(exe_file_path)
        # cbsz = Calculate_BUY_SELL_ZONES(csv_path=exe_file_path, tick=self.stock_tick, last_d_time=self.last_d_time, is_execute=True)
        # df_dz, _ = cbsz.update_new_buy_zones_df()
        # df_sz, _ = cbsz.update_new_sell_zones_df()
        # df = df_dz.combine_first(df_sz)
        df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst = True)
        df = df[df.timestamp <= self.last_d_time]
        return df
    
    def get_datr_frame(self):
        #exe_file_path = f"/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/processed_data_files/{self.stock_tick}_daily.csv"
        exe_file_path = os.path.join(os.getcwd(), 'apps', 'finprod_backend', 'processed_data_files', f"{self.stock_tick}_daily.csv")
        datr_df = pd.read_csv(exe_file_path)
        datr_df['timestamp'] = pd.to_datetime(datr_df['timestamp'], dayfirst = True)
        datr_df = datr_df[datr_df.timestamp <= self.last_d_time]
        return datr_df

    def find_increasing_indices(self, lst):
        increasing_indices = []
        single_values = []
        for i in range(len(lst) - 1):
            if lst[i+1] - lst[i] == 1:
                if not increasing_indices or (increasing_indices and increasing_indices[-1][-1] != i):
                    increasing_indices.append([i, i+1])
                else:
                    increasing_indices[-1][-1] = i+1
            else:
                if not (increasing_indices and increasing_indices[-1][-1] == i):
                    single_values.append(i)
                if lst[i+1] - lst[i] != 1 and (not increasing_indices or (increasing_indices and increasing_indices[-1][-1] != i+1)):
                    single_values.append(i+1)
        if not (increasing_indices and increasing_indices[-1][-1] == len(lst) - 1):
            single_values.append(len(lst) - 1)
        single_values = [i for i in single_values if i not in [j for i in increasing_indices for j in range(i[0], i[1]+1)]]
        return increasing_indices, single_values

    def add_timestamp(self):
        if self.time_frame == 1:
            return timedelta(days=30).total_seconds()
        elif self.time_frame == 2:
            return timedelta(hours=720).total_seconds()
        elif self.time_frame == 3:
            return timedelta(hours=720).total_seconds()
        elif self.time_frame == 25:
            return timedelta(hours=720).total_seconds()
    
    def find_overlaps_between_zones(self, list1, list2):
        overlaps = []
        for r1 in list1:
            for r2 in list2:
                start1, end1 = r1
                start2, end2 = r2
                overlap_start = max(start1, start2)
                overlap_end = min(end1, end2)
                if overlap_start < overlap_end:
                    overlaps.append((overlap_start, overlap_end)) # (r1, r2,             
        return overlaps
    
    def percentage_proximity_to_range(self, overlap_range, cmp):
        """
        Calculate the percentage distance of a cmp to an overlap range.
        """
        start, end = overlap_range
        if cmp < start:
            # Calculate the percentage distance when cmp is below the range
            return ((start - cmp) / cmp) * 100
        elif cmp > end:
            # Calculate the percentage distance when cmp is above the range
            return ((cmp - end) / cmp) * 100
        else:
            # Price is within the range, so proximity is 0%
            return 0
    
    def get_cmp_price_tstamp(self, file_name, last_d_time):
        df = pd.read_csv(file_name)
        df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst = True)
        df = df[df.timestamp <= last_d_time]
        cmp_ex = df.iloc[len(df) - 1]['close']
        self.cmp_price = cmp_ex
        cmp_t_stamp = int(df.iloc[len(df) - 1]['timestamp'].timestamp())
        return cmp_ex, cmp_t_stamp
    
    def get_qualified_exe_zones_info(self, time_index):
        dz_price_ranges = []
        sz_price_ranges = []
        exe_frame = self.time_list[time_index]
        #csv_file_path = f"/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/processed_data_files/{self.stock_tick}_{exe_frame}.csv"
        csv_file_path = os.path.join(os.getcwd(), 'apps', 'finprod_backend', 'processed_data_files', f"{self.stock_tick}_{exe_frame}.csv")
        exe_cbsz = Calculate_BUY_SELL_ZONES(csv_file_path, self.stock_tick, self.last_d_time, True)
        alt_qual = exe_cbsz.get_qualified_alterated_zones()
        qualified_dz_list = sorted(alt_qual['Buy'], key=lambda z: z[0]["time"], reverse=True)
        qualified_sz_list = sorted(alt_qual['Sell'], key=lambda z: z[0]["time"], reverse=True)
        
        for qual_dz in qualified_dz_list:
            dz_price_ranges.append((qual_dz[0]['price'], qual_dz[1]['price']))
        for qual_sz in qualified_sz_list:
            sz_price_ranges.append((qual_sz[0]['price'], qual_sz[1]['price']))
        return dz_price_ranges, sz_price_ranges 

    def get_ea_zones_info(self, time_index, is_exe):
        eval_frame = self.time_list[time_index]
        dz_price_ranges = []
        sz_price_ranges = []
        #csv_file_path = f"/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/processed_data_files/{self.stock_tick}_{eval_frame}.csv"
        csv_file_path = os.path.join(os.getcwd(), 'apps', 'finprod_backend', 'processed_data_files', f"{self.stock_tick}_{eval_frame}.csv")
        eval_cbsz = Calculate_BUY_SELL_ZONES(csv_file_path, self.stock_tick, self.last_d_time, is_exe)
        eval_df_dz, valid_dz_list = eval_cbsz.update_new_buy_zones_df()
        eval_df_sz, valid_sz_list = eval_cbsz.update_new_sell_zones_df()
        # cmp_price = eval_df_dz.iloc[len(eval_df_dz) - 1]['close']
        # cmp_time_stamp = int(eval_df_dz.iloc[len(eval_df_dz) - 1]['timestamp'].timestamp())
        # print(cmp_time_stamp)

        cmp_price, cmp_time_stamp = self.get_cmp_price_tstamp(csv_file_path, self.last_d_time)

        if 'final_zone' in eval_df_dz.keys():
            dz_rows = eval_df_dz[eval_df_dz['final_zone'] == 'DZ']
            dz_idx_lst = dz_rows['id'].to_list()
            
            if len(dz_idx_lst) >= 2:
                group, single = self.find_increasing_indices(dz_idx_lst)
                for vals in group:
                    low_r = []
                    high_r = []
                    for k in range(dz_idx_lst[vals[0]], dz_idx_lst[vals[1]]+1):
                        g_row_data = dz_rows[dz_rows['id'] == k]
                        # print(g_row_data.to_dict()) 
                        low_r.append(g_row_data.get('low').to_list()[0])  # Start range is the 'low' value of the current row
                        if is_exe:
                            high_r.append(g_row_data.get('close').to_list()[0] if int(g_row_data.get('is_bullish').to_list()[0]) == 1 else g_row_data.get('open').to_list()[0])
                        else:
                            high_r.append(g_row_data.get('high').to_list()[0])
                    # print((min(low_r), max(high_r)))
                    dz_price_ranges.append((min(low_r), max(high_r)))

                for single_vals in single:
                    row_data = dz_rows[dz_rows['id'] == dz_idx_lst[single_vals]] 
                    # dz_rows.iloc[dz_idx_lst[single_vals]]
                    low_range = row_data['low'].to_list()[0]  # Start range is the 'low' value of the current row
                    if is_exe:
                        high_range = row_data['close'].to_list()[0] if int(row_data['is_bullish'].to_list()[0]) == 1 else row_data['open'].to_list()[0]
                    else:
                        high_range = row_data['high'].to_list()[0]
                    dz_price_ranges.append((low_range, high_range))

            elif len(dz_idx_lst) == 1:
                row_data = dz_rows[dz_rows['id'] == dz_idx_lst[0]] 
                low_range = row_data['low'].to_list()[0]  # Start range is the 'low' value of the current row
                if is_exe:
                    high_range = row_data['close'].to_list()[0] if int(row_data['is_bullish'].to_list()[0]) == 1 else row_data['open'].to_list()[0]
                else:
                    high_range = row_data['high'].to_list()[0]
                dz_price_ranges.append((low_range, high_range))

        if 'final_zone' in eval_df_sz.keys():
            sz_rows = eval_df_sz[eval_df_sz['final_zone'] == 'SZ']
            sz_idx_lst = sz_rows.index.to_list()
            # [row['index'] for _, row in sz_rows.iterrows()]

            if len(sz_idx_lst) >= 2:
                group, single = self.find_increasing_indices(sz_idx_lst)
                for vals in group:
                    low_r = []
                    high_r = []
                    for k in range(sz_idx_lst[vals[0]], sz_idx_lst[vals[1]]+1):
                        g_row_data = sz_rows[sz_rows['id'] == k] 
                        high_r.append(g_row_data.get('high').to_list()[0])
                        if is_exe:
                            low_r.append(g_row_data.get('close').to_list()[0] if int(g_row_data.get('is_bullish').to_list()[0]) == 1 else g_row_data.get('open').to_list()[0])
                        else:
                            low_r.append(g_row_data.get('low').to_list()[0])  # Start range is the 'low' value of the current row
                    sz_price_ranges.append((min(low_r), max(high_r)))

                for single_vals in single:
                    row_data = sz_rows[sz_rows['id'] == sz_idx_lst[single_vals]]
                    high_range = row_data['high'].to_list()[0] 
                    if is_exe:
                        low_range = row_data['close'].to_list()[0] if int(row_data['is_bullish'].to_list()[0]) == 0 else row_data['open'].to_list()[0]  # Start range is the 'low' value of the current row
                    else:
                        low_range = row_data['low'].to_list()[0]
                    
                    sz_price_ranges.append((low_range, high_range))

            elif len(sz_idx_lst) == 1:
                row_data = sz_rows[sz_rows['id'] == sz_idx_lst[0]] 
                high_range = row_data['high'].to_list()[0] 
                if is_exe:
                    low_range = row_data['close'].to_list()[0] if int(row_data['is_bullish'].to_list()[0]) == 0 else row_data['open'].to_list()[0]  # Start range is the 'low' value of the current row
                else:
                    low_range = row_data['low'].to_list()[0]
                sz_price_ranges.append((low_range, high_range))

            # for index, row in sz_rows.iterrows():
            #     low_range = row['close'] if int(row['is_bullish']) == 0 else row['open']  # Start range is the 'low' value of the current row
            #     high_range = row['high']   # End range is the 'high' value of the current row
            #     sz_price_ranges.append((index, low_range, high_range))

        # print(f"{self.time_list[time_index]}..............................**********************")
        # print(dz_price_ranges, sz_price_ranges)
        return dz_price_ranges, sz_price_ranges, cmp_price, cmp_time_stamp
    
    def sort_ranges_by_percentage_proximity(self, overlapping_ranges, cmp):
        sorted_ranges = sorted(overlapping_ranges, key=lambda x: self.percentage_proximity_to_range(x, cmp))
        return sorted_ranges
    
    def find_closest_intervals(self, intervals, cmp, percent_cmp):
        # Sort intervals by their starting values
        # intervals = sorted(intervals, key=lambda x: x[0])
        
        # Initialize variables to track the minimum gap and closest intervals
        
        min_gap = float((percent_cmp/100)*cmp) #float('inf')
        closest_intervals_list = []
        # print("inf", min_gap)
        # Iterate through the sorted list and find the minimum gap between consecutive intervals
        for i in range(len(intervals) - 1):
            current_start = intervals[i][0]
            next_end = intervals[i + 1][1]
            
            # Calculate the gap between the current interval end and the next interval start
            gap = abs(current_start - next_end)
            # print("gap", gap, min_gap)
            # Check if this gap is the smallest found so far
            if 0 <= gap < min_gap:  # Ensure the intervals do not overlap
                # min_gap = gap
                closest_intervals = (intervals[i], intervals[i + 1])
                closest_intervals_list.append(closest_intervals)

        return closest_intervals_list

    def remove_duplicate_zones(self, lst):
        unique_list = []
        for item in lst:
            if item not in unique_list:
                unique_list.append(item)
        return unique_list

    def find_single_overlap_points(self, price_ranges):
        # Sort the ranges by their starting point
        price_ranges = sorted(price_ranges, key=lambda x: x[0])
        overlapping_points = []
        
        # Iterate over the sorted ranges and check for overlap
        for i in range(len(price_ranges)):
            for j in range(i + 1, len(price_ranges)):
                # Get the current pair of ranges
                range1 = price_ranges[i]
                range2 = price_ranges[j]
                if max(range1[0], range2[0]) <= min(range1[1], range2[1]):
                    # Calculate the overlapping range
                    overlap_start = max(range1[0], range2[0])
                    overlap_end = min(range1[1], range2[1])
                    # print("overlap_start overlap_end", overlap_start, overlap_end)
                    avg_point = max(overlap_start, overlap_end)
                    avg_point = round(avg_point, 2)
                    min_point = min(min(range1), min(range2))
                    overlapping_points.append(avg_point)
                    overlapping_points.append(min_point)
        # Return the list of single overlap points or an empty list if none
        return sorted(overlapping_points, reverse=True)

    def get_overlapping_zones(self, exe_dz, cmp):
        ut = utility()
        found_overlapping_zone = False
        overlapping_avg_points = self.find_single_overlap_points(exe_dz)
        Stop_loss = None
        entry = None
        if overlapping_avg_points:
            if ut.calculate_percentage_distance(cmp, overlapping_avg_points[0]) <= self.dynamic_percentage_distance(self.cmp_price):
                print(overlapping_avg_points[0], "ooooooooooooooooooooooooooooooooooooooooooooo")
                entry = overlapping_avg_points[0]
                Stop_loss = overlapping_avg_points[1]
                # ut.calculate_atr(self.get_execute_df(), entry, period=14)
                found_overlapping_zone = True
        return found_overlapping_zone, entry, Stop_loss

    def calculate_ema_zone(self, exe_dz):
        ut = utility()
        found_ema_zone = False
        entry = None
        stop_loss = None
        df = self.get_execute_df()
        df['EMA20'] = talib.EMA(df['close'], 20)
        if len(exe_dz) > 0:
            start_t = max(df[df['low'] == min(exe_dz[0])]['timestamp'])
            interim_df = df[df['close'] == max(exe_dz[0])]['timestamp']
            if interim_df.empty:
                interim_df = df[df['open'] == max(exe_dz[0])]['timestamp']
            end_t = max(interim_df)
            ema_df = df[df['timestamp'].between(start_t, end_t)]['EMA20'].to_list()
            # print(exe_dz, ema_df, "$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$")
            within_range = any((min(exe_dz[0]) * 0.999 <= value <= max(exe_dz[0]) * 1.001) for value in ema_df)
            # any(min(exe_dz[0]) <= value <= max(exe_dz[0]) for value in ema_df)
            if within_range:
                entry = exe_dz[0][1]
                stop_loss = exe_dz[0][0]
                if not(2.5 <= ut.calculate_percentage_distance(entry, stop_loss) <= 5):
                    stop_loss = ut.calculate_atr(self.get_execute_df(), entry, 14)
                found_ema_zone = True
        return found_ema_zone, entry, stop_loss
            

 
        # print(exe_dz)

    def get_consecutive_zones(self, conse_dz, cmp):
        ut = utility()
        found_conz_zone = False
        conz_entry = None
        stop_loss = None
        if conse_dz:
            conse_dz = conse_dz[0]
            range1 = min(conse_dz[0])
            range2 = max(conse_dz[1])
            conz_entry = range2 # round((range1+range2)/2, 2)
            stop_loss = min(conse_dz[1])
            zone_diff = abs(range2 - range1)
            within_per = zone_diff <= (cmp*0.01)
            print(within_per, ut.calculate_percentage_distance(cmp, conz_entry), self.dynamic_percentage_distance(self.cmp_price))
            print("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$")
            if abs(range2 - range1) <= (cmp*0.01) and ut.calculate_percentage_distance(cmp, conz_entry) <= self.dynamic_percentage_distance(self.cmp_price):
                found_conz_zone = True
        return found_conz_zone, conz_entry, stop_loss
    
    def get_overlapped_decition(self, cmp, dz_distance_list, dz_ana_distance_percent, dz_eva_distance_percent, overlap_dz_ana, overlap_dz_eva):
        found_overlapping_point = False
        ut = utility()
        entry = None
        Stop_loss = None
        dz_distance_list = list(filter(lambda x: x is not None, dz_distance_list))
        if len(dz_distance_list) > 0:
            print(dz_distance_list)
            if min(dz_distance_list) == dz_ana_distance_percent:
                entry = overlap_dz_ana[0][1]
                Stop_loss = ut.calculate_atr(self.get_execute_df(), entry, period=14)
                # found_overlapping_point = True
            elif min(dz_distance_list) == dz_eva_distance_percent:
                entry = overlap_dz_eva[0][1]
                Stop_loss = ut.calculate_atr(self.get_execute_df(), entry, period=14)
                # found_overlapping_point = True
        if entry is not None:
            if ut.calculate_percentage_distance(cmp, entry) <= self.dynamic_percentage_distance(cmp):
                found_overlapping_point = True

        return found_overlapping_point, entry, Stop_loss
    
    def dynamic_percentage_distance(self, cmp, base_percentage=7.5, reference_cmp=500, k=0.1):
        dynamic_percentage = base_percentage / (1 + k * cmp / reference_cmp)
        return dynamic_percentage
    
    def calculate_buy_target_point(self, exe_sz, ana_sz, eva_sz, entry, stop):
        print(entry)
        target = None
        if len(exe_sz) > 0:
            target = exe_sz[0][1] 
        elif len(ana_sz) > 0:
            if ana_sz[0][1] > entry: target = ana_sz[0][1] 
        elif len(eva_sz) > 0:
            if eva_sz[0][1] > entry: target = eva_sz[0][1]
        if target is None:
            target = entry + ((entry - stop)*2)
        return target


    def calculate(self):
        ut = utility()
        out_data = {}
        eva_dz, eva_sz, cmp, cmp_ts = self.get_ea_zones_info(0, False)
        ana_dz, ana_sz, cmp, cmp_ts = self.get_ea_zones_info(1, False)
        exe_dz, exe_sz = self.get_qualified_exe_zones_info(len(self.time_list) - 1)
        # exe_dz, exe_sz, cmp, cmp_ts = self.get_ea_zones_info(len(self.time_list) - 1, True)
        # print(cmp_exe, "cmpppppppppppppppppppppppppppppppppppppppp")
        eva_dz = sorted(eva_dz, reverse=True)
        eva_sz = sorted(eva_sz)
        ana_dz = sorted(ana_dz, reverse=True)
        ana_sz = sorted(ana_sz)
        exe_dz = sorted(exe_dz, reverse=True)
        exe_sz = sorted(exe_sz)
        # print(exe_sz)
        exe_dz = self.remove_duplicate_zones(exe_dz) 
        exe_sz = self.remove_duplicate_zones(exe_sz)

        conse_dz = self.find_closest_intervals(exe_dz, cmp, 1)
        conse_sz = self.find_closest_intervals(exe_sz, cmp, 1)
        # exe_dz = self.sort_ranges_by_percentage_proximity(list(set(exe_dz)), cmp)
        overlap_dz_eva = sorted(self.find_overlaps_between_zones(eva_dz, exe_dz), reverse=True)
        overlap_dz_ana = sorted(self.find_overlaps_between_zones(ana_dz, exe_dz), reverse=True)
        overlap_sz_eva = sorted(self.find_overlaps_between_zones(eva_sz, exe_sz))
        overlap_sz_ana = sorted(self.find_overlaps_between_zones(ana_sz, exe_sz))

        # dz_conz_distance_percent  = self.percentage_proximity_to_range(conse_dz[0][1], cmp) if len(conse_dz) > 0 else None
        dz_ana_distance_percent = self.percentage_proximity_to_range(overlap_dz_ana[0], cmp) if len(overlap_dz_ana) > 0 else None
        dz_eva_distance_percent = self.percentage_proximity_to_range(overlap_dz_eva[0], cmp) if len(overlap_dz_eva) > 0 else None

        # sz_conz_distance_percent  = self.percentage_proximity_to_range(conse_sz[0][1], cmp) if len(conse_sz) > 0 else None
        sz_ana_distance_percent = self.percentage_proximity_to_range(overlap_sz_ana[0], cmp) if len(overlap_sz_ana) > 0 else None
        sz_eva_distance_percent = self.percentage_proximity_to_range(overlap_sz_eva[0], cmp) if len(overlap_sz_eva) > 0 else None
        # print("analyse_distance", ana_distance_percent)
        # print("evaluiate_distance", eva_distance_percent)
        # print("conz_distance", conz_distance_percent)
        # dz_conz_distance_percent sz_conz_distance_percent
        dz_distance_list = [dz_eva_distance_percent, dz_ana_distance_percent]
        sz_distance_list = [sz_eva_distance_percent, sz_ana_distance_percent]

        ###################################################################
        # Exception Conditions to Not Trade
        # print(eva_dz, eva_sz)
        if len(eva_dz) == 0 and len(eva_sz) == 0 and len(ana_dz) == 0 and len(ana_sz) == 0:
            return None
        # print("###################################")
        
        # print("###################################")
        ###################################################################
        # found_overlapping_dz = False
        # found_overlapping_sz = False
        # found_consecuting_dz = False
        # found_consecuting_sz = False
        # # print(eva_sz, ana_sz)
        entry = None
        stop_loss = None
        out_data['PRICE_CMP'] = cmp
        print(exe_dz, "99999999999999999999999999999999999999999999999999999999999999")
        if len(eva_sz) == 0 and len(ana_sz) == 0:
            
            if len(exe_dz) > 0 and len(exe_sz) == 0:
                # if not(found_overlapping_dz):
                found_conse_dz, entry, stop_loss = self.get_consecutive_zones(conse_dz, cmp)
                print(found_conse_dz, "44444444444444444444444444444444444444444444444444444444444444444444")
                if not(found_conse_dz):
                    found_overlapping_dz, entry, stop_loss = self.get_overlapping_zones(exe_dz, cmp)
                    if not(found_overlapping_dz):
                        found_ema_zone, entry, stop_loss = self.calculate_ema_zone(exe_dz)
                        if not(found_ema_zone):
                            found_overlapping_point, entry, stop_loss = self.get_overlapped_decition(cmp, dz_distance_list, dz_ana_distance_percent, dz_eva_distance_percent, overlap_dz_ana, overlap_dz_eva)
                            if not(found_overlapping_point):
                                entry = exe_dz[0][1]
                                stop_loss = ut.calculate_atr(self.get_execute_df(), entry, 14)
                                
                out_data['BUY'], out_data['BUY_RRR'] = ut.create_2_no_sell_zone_buy_alert(entry, stop_loss)
                # out_data['BUY_RRR'] = self.calculate_risk_to_reward(entry, stop_loss, out_data['BUY']['target_price'])
                out_data['BUY_TIMESTAMPS'] = {
                                "entry_price_timestamp" : cmp_ts,
                                "target_price_timestamp" : cmp_ts,
                                "extend_timestamp" : cmp_ts + self.add_timestamp()
                            }

            elif len(exe_sz) > 0 and len(exe_dz) > 0:
                exe_trade_opt, exe_price_pos = ut.check_and_return_price_pos(exe_sz[0][1], exe_dz[0][0], cmp)
                if 'BUY' in exe_trade_opt:
                    found_conse_dz, entry, stop_loss = self.get_consecutive_zones(conse_dz, cmp)
                    if not(found_conse_dz):
                        found_overlapping_dz, entry, stop_loss = self.get_overlapping_zones(exe_dz, cmp)
                        if not(found_overlapping_dz):
                            found_ema_zone, entry, stop_loss = self.calculate_ema_zone(exe_dz)
                            if not(found_ema_zone):
                                found_overlapping_point, entry, stop_loss = self.get_overlapped_decition(cmp, dz_distance_list, dz_ana_distance_percent, dz_eva_distance_percent, overlap_dz_ana, overlap_dz_eva)
                                # print(found_conse_dz, "565656565656565656565656565656565656565656565656565")                            
                                if not(found_overlapping_point):
                                    entry = exe_dz[0][1]
                                    stop_loss = ut.calculate_atr(self.get_execute_df(), entry, 14)
                    target = self.calculate_buy_target_point(exe_sz, ana_sz, eva_sz, entry, stop_loss)
                    out_data['BUY'], out_data['BUY_RRR'] = ut.create_buy_alert(stop_loss, entry, target)
                    # out_data['BUY_RRR'] = self.calculate_risk_to_reward(entry, stop_loss, target)
                    out_data['BUY_TIMESTAMPS'] = {
                                    "entry_price_timestamp" : cmp_ts,
                                    "target_price_timestamp" : cmp_ts,
                                    "extend_timestamp" : cmp_ts + self.add_timestamp()
                                }

        elif len(eva_sz) == 0 and len(ana_sz) > 0:
            if len(exe_dz) > 0 and len(exe_sz) == 0:
                exe_trade_opt, exe_price_pos = ut.check_and_return_price_pos(ana_sz[0][1], exe_dz[0][0], cmp)
                if 'BUY' in exe_trade_opt:
                    found_conse_dz, entry, stop_loss = self.get_consecutive_zones(conse_dz, cmp)
                    if not(found_conse_dz):
                        found_overlapping_dz, entry, stop_loss = self.get_overlapping_zones(exe_dz, cmp)
                        if not(found_overlapping_dz):
                            found_ema_zone, entry, stop_loss = self.calculate_ema_zone(exe_dz)
                            if not(found_ema_zone):                            
                                found_overlapping_point, entry, stop_loss = self.get_overlapped_decition(cmp, dz_distance_list, dz_ana_distance_percent, dz_eva_distance_percent, overlap_dz_ana, overlap_dz_eva)
                                if not(found_overlapping_point):
                                    entry = exe_dz[0][1]
                                    stop_loss = ut.calculate_atr(self.get_execute_df(), entry, 14)
                    target = self.calculate_buy_target_point(exe_sz, ana_sz, eva_sz, entry, stop_loss)
                    out_data['BUY'], out_data['BUY_RRR'] = ut.create_buy_alert(stop_loss, entry, target)
                    # out_data['BUY_RRR'] = self.calculate_risk_to_reward(entry, stop_loss, target)
                    out_data['BUY_TIMESTAMPS'] = {
                                    "entry_price_timestamp" : cmp_ts,
                                    "target_price_timestamp" : cmp_ts,
                                    "extend_timestamp" : cmp_ts + self.add_timestamp()
                                }

            elif len(exe_sz) > 0 and len(exe_dz) > 0:
                if len(ana_dz) > 0:
                    exe_trade_opt, ana_price_pos = ut.check_and_return_price_pos(ana_sz[0][1], ana_dz[0][0], cmp)
                else:
                    ana_price_pos = None
                exe_trade_opt, exe_price_pos = ut.check_and_return_price_pos(exe_sz[0][1], exe_dz[0][0], cmp)
                # if ana_price_pos is not None:
                #     if ana_price_pos >= 66.6 and exe_price_pos <= 33.3:
                #         out_data['reason'] = f"Analyse at {ana_price_pos}% and execute at {exe_price_pos}%"
                #         return out_data
                
                if 'BUY' in exe_trade_opt:
                    found_conse_dz, entry, stop_loss = self.get_consecutive_zones(conse_dz, cmp)
                    if not(found_conse_dz):
                        found_overlapping_dz, entry, stop_loss = self.get_overlapping_zones(exe_dz, cmp)
                        if not(found_overlapping_dz):
                            found_ema_zone, entry, stop_loss = self.calculate_ema_zone(exe_dz)
                            if not(found_ema_zone):
                                found_overlapping_point, entry, stop_loss = self.get_overlapped_decition(cmp, dz_distance_list, dz_ana_distance_percent, dz_eva_distance_percent, overlap_dz_ana, overlap_dz_eva)
                                if not(found_overlapping_point):
                                    entry = exe_dz[0][1]
                                    stop_loss = ut.calculate_atr(self.get_execute_df(), entry, 14)
                    target = self.calculate_buy_target_point(exe_sz, ana_sz, eva_sz, entry, stop_loss)
                    out_data['BUY'], out_data['BUY_RRR'] = ut.create_buy_alert(stop_loss, entry, target)
                    # out_data['BUY_RRR'] = self.calculate_risk_to_reward(entry, stop_loss, target)
                    out_data['BUY_TIMESTAMPS'] = {
                                    "entry_price_timestamp" : cmp_ts,
                                    "target_price_timestamp" : cmp_ts,
                                    "extend_timestamp" : cmp_ts + self.add_timestamp()
                                }

        elif len(eva_sz) > 0 and len(ana_sz) == 0:
            if len(exe_dz) > 0 and len(exe_sz) == 0:
                if len(eva_dz) > 0 and len(eva_sz) > 0:
                    exe_trade_opt, eva_price_pos = ut.check_and_return_price_pos(eva_sz[0][1], eva_dz[0][0], cmp)
                else:
                    eva_price_pos = None
                exe_trade_opt, exe_price_pos = ut.check_and_return_price_pos(eva_sz[0][1], exe_dz[0][0], cmp)
                if eva_price_pos is not None:
                    if eva_price_pos >= 66.6 and exe_price_pos <= 33.3:
                        out_data['reason'] = f"Evaluate at {eva_price_pos}% and execute at {exe_price_pos}%"
                        return out_data
                if 'BUY' in exe_trade_opt:
                    found_conse_dz, entry, stop_loss = self.get_consecutive_zones(conse_dz, cmp)
                    if not(found_conse_dz):
                        found_overlapping_dz, entry, stop_loss = self.get_overlapping_zones(exe_dz, cmp)
                        if not(found_overlapping_dz):
                            found_ema_zone, entry, stop_loss = self.calculate_ema_zone(exe_dz)
                            if not(found_ema_zone):
                                found_overlapping_point, entry, stop_loss = self.get_overlapped_decition(cmp, dz_distance_list, dz_ana_distance_percent, dz_eva_distance_percent, overlap_dz_ana, overlap_dz_eva)
                                if not(found_overlapping_point):
                                    entry = exe_dz[0][1]
                                    stop_loss = ut.calculate_atr(self.get_execute_df(), entry, 14)
                    target = self.calculate_buy_target_point(exe_sz, ana_sz, eva_sz, entry, stop_loss)
                    out_data['BUY'], out_data['BUY_RRR'] = ut.create_buy_alert(stop_loss, entry, target)
                    # out_data['BUY_RRR'] = self.calculate_risk_to_reward(entry, stop_loss, target)
                    out_data['BUY_TIMESTAMPS'] = {
                                    "entry_price_timestamp" : cmp_ts,
                                    "target_price_timestamp" : cmp_ts,
                                    "extend_timestamp" : cmp_ts + self.add_timestamp()
                                }
                
            elif len(exe_sz) > 0 and len(exe_dz) > 0:
                if len(eva_dz) > 0:
                    exe_trade_opt, eva_price_pos = ut.check_and_return_price_pos(eva_sz[0][1], eva_dz[0][0], cmp)
                else:
                    eva_price_pos = None
                exe_trade_opt, exe_price_pos = ut.check_and_return_price_pos(exe_sz[0][1], exe_dz[0][0], cmp)
                if eva_price_pos is not None:
                    if eva_price_pos >= 66.6 and exe_price_pos <= 33.3:
                        out_data['reason'] = f"Evaluate at {eva_price_pos}% and execute at {exe_price_pos}%"
                        return out_data
    
                if 'BUY' in exe_trade_opt:
                    found_conse_dz, entry, stop_loss = self.get_consecutive_zones(conse_dz, cmp)
                    if not(found_conse_dz):
                        found_overlapping_dz, entry, stop_loss = self.get_overlapping_zones(exe_dz, cmp)
                        if not(found_overlapping_dz):
                            found_ema_zone, entry, stop_loss = self.calculate_ema_zone(exe_dz)
                            if not(found_ema_zone):
                                found_overlapping_point, entry, stop_loss = self.get_overlapped_decition(cmp, dz_distance_list, dz_ana_distance_percent, dz_eva_distance_percent, overlap_dz_ana, overlap_dz_eva)
                                if not(found_overlapping_point):
                                    entry = exe_dz[0][1]
                                    stop_loss = ut.calculate_atr(self.get_execute_df(), entry, 14)
                    target = self.calculate_buy_target_point(exe_sz, ana_sz, eva_sz, entry, stop_loss)
                    out_data['BUY'], out_data['BUY_RRR'] = ut.create_buy_alert(stop_loss, entry, target)
                    # out_data['BUY_RRR'] = self.calculate_risk_to_reward(entry, stop_loss, target)
                    out_data['BUY_TIMESTAMPS'] = {
                                    "entry_price_timestamp" : cmp_ts,
                                    "target_price_timestamp" : cmp_ts,
                                    "extend_timestamp" : cmp_ts + self.add_timestamp()
                                }

        elif len(eva_sz) > 0 and len(ana_sz) > 0:
            if len(exe_dz) > 0 and len(exe_sz) == 0:
                if len(eva_dz) > 0 and len(eva_sz) > 0:
                    _, eva_price_pos = ut.check_and_return_price_pos(eva_sz[0][1], eva_dz[0][0], cmp)
                else:
                    eva_price_pos = None
                if len(ana_dz) > 0 and len(ana_sz) > 0:
                    _, ana_price_pos = ut.check_and_return_price_pos(ana_sz[0][1], ana_dz[0][0], cmp)
                else:
                    ana_price_pos = None
                if len(ana_sz) > 0 and len(exe_dz) > 0:     
                    exe_trade_opt, exe_price_pos = ut.check_and_return_price_pos(ana_sz[0][1], exe_dz[0][0], cmp)
                if eva_price_pos is not None:
                    if eva_price_pos >= 66.6 and exe_price_pos <= 33.3:
                        out_data['reason'] = f"Evaluate at {eva_price_pos}% and execute at {exe_price_pos}%"
                        return out_data
                # if ana_price_pos is not None:
                #     if ana_price_pos >= 66.6 and exe_price_pos <= 33.3:
                #         out_data['reason'] = f"Analyse at {ana_price_pos}% and execute at {exe_price_pos}%"
                #         return out_data
                if 'BUY' in exe_trade_opt:
                    found_conse_dz, entry, stop_loss = self.get_consecutive_zones(conse_dz, cmp)
                    if not(found_conse_dz):
                        found_overlapping_dz, entry, stop_loss = self.get_overlapping_zones(exe_dz, cmp)
                        if not(found_overlapping_dz):
                            found_ema_zone, entry, stop_loss = self.calculate_ema_zone(exe_dz)
                            if not(found_ema_zone):
                                found_overlapping_point, entry, stop_loss = self.get_overlapped_decition(cmp, dz_distance_list, dz_ana_distance_percent, dz_eva_distance_percent, overlap_dz_ana, overlap_dz_eva)
                                if not(found_overlapping_point):
                                    entry = exe_dz[0][1]
                                    stop_loss = ut.calculate_atr(self.get_execute_df(), entry, 14)
                    target = self.calculate_buy_target_point(exe_sz, ana_sz, eva_sz, entry, stop_loss)
                    out_data['BUY'], out_data['BUY_RRR'] = ut.create_buy_alert(stop_loss, entry, target)
                    # out_data['BUY_RRR'] = self.calculate_risk_to_reward(entry, stop_loss, target)
                    out_data['BUY_TIMESTAMPS'] = {
                                    "entry_price_timestamp" : cmp_ts,
                                    "target_price_timestamp" : cmp_ts,
                                    "extend_timestamp" : cmp_ts + self.add_timestamp()
                                }
                    
            elif len(exe_sz) > 0 and len(exe_dz) > 0:
                if len(eva_dz) > 0:
                    _, eva_price_pos = ut.check_and_return_price_pos(eva_sz[0][1], eva_dz[0][0], cmp)
                else:
                    eva_price_pos = None
                if len(ana_dz) > 0:
                    _, ana_price_pos = ut.check_and_return_price_pos(ana_sz[0][1], ana_dz[0][0], cmp)
                else:
                    ana_price_pos = None
                
                exe_trade_opt, exe_price_pos = ut.check_and_return_price_pos(exe_sz[0][1], exe_dz[0][0], cmp)
                if eva_price_pos is not None:
                    if eva_price_pos >= 66.6 and exe_price_pos <= 33.3:
                        out_data['reason'] = f"Evaluate at {eva_price_pos}% and execute at {exe_price_pos}%"
                        return out_data
                # if ana_price_pos is not None:
                #     if ana_price_pos >= 66.6 and exe_price_pos <= 33.3:
                #         out_data['reason'] = f"Analyse at {ana_price_pos}% and execute at {exe_price_pos}%"
                #         return out_data
                if 'BUY' in exe_trade_opt:
                    found_conse_dz, entry, stop_loss = self.get_consecutive_zones(conse_dz, cmp)
                    if not(found_conse_dz):
                        found_overlapping_dz, entry, stop_loss = self.get_overlapping_zones(exe_dz, cmp)
                        if not(found_overlapping_dz):
                            found_ema_zone, entry, stop_loss = self.calculate_ema_zone(exe_dz)
                            if not(found_ema_zone):
                                found_overlapping_point, entry, stop_loss = self.get_overlapped_decition(cmp, dz_distance_list, dz_ana_distance_percent, dz_eva_distance_percent, overlap_dz_ana, overlap_dz_eva)
                                if not(found_overlapping_point):
                                    entry = exe_dz[0][1]
                                    stop_loss = ut.calculate_atr(self.get_execute_df(), entry, 14)
                    target = self.calculate_buy_target_point(exe_sz, ana_sz, eva_sz, entry, stop_loss)
                    out_data['BUY'], out_data['BUY_RRR'] = ut.create_buy_alert(stop_loss, entry, target)
                    # out_data['BUY_RRR'] = self.calculate_risk_to_reward(entry, stop_loss, target)
                    out_data['BUY_TIMESTAMPS'] = {
                                    "entry_price_timestamp" : cmp_ts,
                                    "target_price_timestamp" : cmp_ts,
                                    "extend_timestamp" : cmp_ts + self.add_timestamp()
                                }
                
        return out_data
        


        

        




