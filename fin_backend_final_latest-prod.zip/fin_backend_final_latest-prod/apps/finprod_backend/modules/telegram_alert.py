import telegram
import logging
# from telegram import ParseMode
from telegram.constants import ParseMode

logger = logging.getLogger()

class TELEGRAM_MSG:

    def __init__ (self):
        self.token = "7443534342:AAGbIiCLjYbkjkI2z2Bt5nOJkzQAnwQqgbs"
        self.channel_id = "-1002168429814"

    def send_msg(self, 
                 message = None, 
                 img_path = None,
                 doc_path = None,
                 video_path = None):
        try:
            bot = telegram.Bot(token = self.token)
            channel_id = self.channel_id
            if message:
                bot.send_message(chat_id = channel_id, text = message)
                print("Message sent successfully to telegram channel.")
            if img_path:
                bot.send_photo(chat_id = channel_id, photo = open(img_path, 'rb'), caption = message)
                print("Image sent successfully to telegram channel.")
            if doc_path:
                bot.send_document(chat_id = channel_id, document = open(doc_path, 'rb'))
                print("Document sent successfully to telegram channel.")
            if video_path:
                bot.send_video(chat_id = channel_id, video=open(video_path, 'rb'), caption = message)
                print("Video sent successfully to telegram channel.")
            return True
        except Exception as ex:
            logger.exception(ex)
            return False
