import pandas as pd
import plotly.graph_objects as go
from datetime import datetime, timedelta
import talib as ta
import json

# csv_path = "processed_data_files\hdb.csv"

class calculate_current_price_position:
    def __init__(self, csv_path, tick, time_frame) -> None:
        self.csv_path = csv_path
        self.tick = tick
        self.time_frame = time_frame
        self.valid_dz_indx = []
        self.valid_sz_indx = []

    def find_increasing_indices(self, lst):
        increasing_indices = []
        single_values = []
        for i in range(len(lst) - 1):
            if lst[i+1] - lst[i] == 1:
                if not increasing_indices or (increasing_indices and increasing_indices[-1][-1] != i):
                    increasing_indices.append([i, i+1])
                else:
                    increasing_indices[-1][-1] = i+1
            elif i > 0 and lst[i-1] + 1 != lst[i] and lst[i] + 1 != lst[i+1]:
                single_values.append(i)
        if lst[-1] != lst[-2] + 1:
            single_values.append(len(lst) - 1)
        return increasing_indices, single_values

    def draw_dz_sz_zones(self, df, fig, e_str_ftr, file_name : str):
        b_z = []
        df1 = df
        for i in range(len(df)):
            row_data = df.iloc[i]
            # print(row_data.get("is_leg_out"))
            # print(row_data.get("is_basing"))
            if i == (len(df) - 1):
                continue
            #######################################################################
            if row_data.get("is_basing") == True and (row_data.get("close") > row_data.get("open")):
                b_low_dat = row_data.get("low")
                b_high_dat = row_data.get("high")
                b_open_dat = row_data.get("open")
                b_close_dat = row_data.get("close")
                exp = row_data.get("timestamp")
                date_exp = datetime.strptime(exp, e_str_ftr)
                if file_name.__contains__("month"):
                    prev_day = date_exp - timedelta(days=15)
                    next_day = date_exp + timedelta(days=15)
                elif file_name.__contains__("week"):
                    prev_day = date_exp - timedelta(days=3.5)
                    next_day = date_exp + timedelta(days=3.5)
                elif file_name.__contains__("daily"):
                    prev_day = date_exp - timedelta(0.5)
                    next_day = date_exp + timedelta(0.5)
                elif file_name.__contains__("75"):
                    prev_day = date_exp - timedelta(minutes=37.5)
                    next_day = date_exp + timedelta(minutes=37.5)
                elif file_name.__contains__("60"):
                    prev_day = date_exp - timedelta(minutes=30)
                    next_day = date_exp + timedelta(minutes=30)
                elif file_name.__contains__("15"):
                    prev_day = date_exp - timedelta(minutes=7.5)
                    next_day = date_exp + timedelta(minutes=7.5)
                chk_int = False
                for k in range(i+1, len(df)):
                    if df.iloc[k]['is_leg_out'] == True:
                        continue
                    per_intersect = self.ranges_intersect((b_low_dat, b_close_dat), (df.iloc[k].get('open'), df.iloc[k].get('close')))
                    # print(fully_intersect)
                    if per_intersect > 50:
                        chk_int = True
                        break
                if not chk_int:
                    fig.add_shape(type='rect', x0=prev_day, y0=b_low_dat, x1=next_day, y1=b_high_dat, line=dict(color="green", width=2))

            if row_data.get("is_basing") == True and (row_data.get("open") > row_data.get("close")):
                b_low_dat = row_data.get("low")
                b_high_dat = row_data.get("high")
                b_open_dat = row_data.get("open")
                b_close_dat = row_data.get("close")
                exp = row_data.get("timestamp")
                date_exp = datetime.strptime(exp, e_str_ftr)
                if file_name.__contains__("month"):
                    prev_day = date_exp - timedelta(days=15)
                    next_day = date_exp + timedelta(days=15)
                elif file_name.__contains__("week"):
                    prev_day = date_exp - timedelta(days=3.5)
                    next_day = date_exp + timedelta(days=3.5)
                elif file_name.__contains__("daily"):
                    prev_day = date_exp - timedelta(0.5)
                    next_day = date_exp + timedelta(0.5)
                elif file_name.__contains__("75"):
                    prev_day = date_exp - timedelta(minutes=37.5)
                    next_day = date_exp + timedelta(minutes=37.5)
                elif file_name.__contains__("60"):
                    prev_day = date_exp - timedelta(minutes=30)
                    next_day = date_exp + timedelta(minutes=30)
                elif file_name.__contains__("15"):
                    prev_day = date_exp - timedelta(minutes=7.5)
                    next_day = date_exp + timedelta(minutes=7.5)
                chk_int = False
                for k in range(i+1, len(df)):
                    if df.iloc[k]['is_leg_out'] == True:
                        continue
                    per_intersect = self.ranges_intersect((b_high_dat, b_close_dat), (df.iloc[k].get('open'), df.iloc[k].get('close')))
                    # print(fully_intersect)
                    if per_intersect > 50:
                        chk_int = True
                        break
                if not chk_int:
                    fig.add_shape(type='rect', x0=prev_day, y0=b_low_dat, x1=next_day, y1=b_high_dat, line=dict(color="red", width=2))



            #######################################################################
            if row_data.get("buy_sell_zone") == "DZ":
                b_low_dat = row_data.get("low")
                b_high_dat = row_data.get("high")
                b_open_dat = row_data.get("open")
                b_close_dat = row_data.get("close")
                exp = row_data.get("timestamp")
                date_exp = datetime.strptime(exp, e_str_ftr)
                if file_name.__contains__("month"):
                    prev_day = date_exp - timedelta(days=15)
                    next_day = date_exp + timedelta(days=15)
                elif file_name.__contains__("week"):
                    prev_day = date_exp - timedelta(days=3.5)
                    next_day = date_exp + timedelta(days=3.5)
                elif file_name.__contains__("daily"):
                    prev_day = date_exp - timedelta(0.5)
                    next_day = date_exp + timedelta(0.5)
                elif file_name.__contains__("75"):
                    prev_day = date_exp - timedelta(minutes=37.5)
                    next_day = date_exp + timedelta(minutes=37.5)
                elif file_name.__contains__("60"):
                    prev_day = date_exp - timedelta(minutes=30)
                    next_day = date_exp + timedelta(minutes=30)
                elif file_name.__contains__("15"):
                    prev_day = date_exp - timedelta(minutes=7.5)
                    next_day = date_exp + timedelta(minutes=7.5)
                chk_int = False
                for k in range(i+1, len(df)):
                    if df.iloc[k]['is_leg_out'] == True:
                        continue
                    per_intersect = self.ranges_intersect((b_open_dat, b_close_dat), (df.iloc[k].get('open'), df.iloc[k].get('close')))
                    # print(fully_intersect)
                    if per_intersect > 50:
                        chk_int = True
                        break
                if not chk_int:
                    fig.add_shape(type='rect', x0=prev_day, y0=b_low_dat, x1=next_day, y1=b_high_dat, line=dict(color="green", width=2))
                    self.valid_dz_indx.append(i)
                # fig.add_shape(type='rect', x0=prev_day, y0=b_low_dat, x1=next_day, y1=b_high_dat, line=dict(color="red", width=2))
            elif row_data.get("buy_sell_zone") == "SZ":
                b_low_dat = row_data.get("low")
                b_high_dat = row_data.get("high")
                b_open_dat = row_data.get("open")
                b_close_dat = row_data.get("close")
                exp = row_data.get("timestamp")
                date_exp = datetime.strptime(exp, e_str_ftr)
                if file_name.__contains__("month"):
                    prev_day = date_exp - timedelta(days=15)
                    next_day = date_exp + timedelta(days=15)
                elif file_name.__contains__("week"):
                    prev_day = date_exp - timedelta(days=3.5)
                    next_day = date_exp + timedelta(days=3.5)
                elif file_name.__contains__("daily"):
                    prev_day = date_exp - timedelta(days=0.5)
                    next_day = date_exp + timedelta(days=0.5)
                elif file_name.__contains__("75"):
                    prev_day = date_exp - timedelta(minutes=37.5)
                    next_day = date_exp + timedelta(minutes=37.5)
                elif file_name.__contains__("60"):
                    prev_day = date_exp - timedelta(minutes=30)
                    next_day = date_exp + timedelta(minutes=30)
                elif file_name.__contains__("15"):
                    prev_day = date_exp - timedelta(minutes=7.5)
                    next_day = date_exp + timedelta(minutes=7.5)
                fully_intersect = False
                for k in range(i+1, len(df1)):
                    if df.iloc[k]['is_leg_out'] == True:
                        continue
                    per_intersect = self.ranges_intersect((b_open_dat, b_close_dat), (df.iloc[k].get('open'), df.iloc[k].get('close')))
                    if per_intersect > 50: 
                        fully_intersect = True
                        break
                if not fully_intersect:
                    fig.add_shape(type='rect', x0=prev_day, y0=b_low_dat, x1=next_day, y1=b_high_dat, line=dict(color="red", width=2))
                    self.valid_sz_indx.append(i)
        for j in range(len(df)):
            bad_row_data = df.iloc[j]
            if str(bad_row_data.get("ideal_zone")).__contains__('BADZONE'):
                b_z.append(j)
        # print(len(b_z), "555555555555555555555555")
        if len(b_z) >= 3:
            con_z, sin_z = self.find_increasing_indices(b_z)
            for li in con_z:
                low_li = []
                high_li = []
                prev_t = df.iloc[b_z[li[0]]].get('timestamp')
                next_t = df.iloc[b_z[li[1]]].get('timestamp')
                for k in range(li[0], li[1]+1):
                    low_li.append(abs(df.iloc[b_z[k]].get('low')))
                    high_li.append(abs(df.iloc[b_z[k]].get('high')))
                y1 = max(high_li)
                y2 = min(low_li)
                    # b_low_dat = row_data.get("low")
                    # b_high_dat = row_data.get("high")
                    # b_open_dat = row_data.get("open")
                    # b_close_dat = row_data.get("close")
                    # exp = row_data.get("timestamp")
                p_date_exp = datetime.strptime(prev_t, e_str_ftr)
                n_date_exp = datetime.strptime(next_t, e_str_ftr)

                if file_name.__contains__("month"):
                    prev_day = p_date_exp - timedelta(days=15)
                    next_day = n_date_exp + timedelta(days=15)
                elif file_name.__contains__("week"):
                    prev_day = p_date_exp - timedelta(days=3.5)
                    next_day = n_date_exp + timedelta(days=3.5)
                elif file_name.__contains__("daily"):
                    prev_day = p_date_exp - timedelta(0.5)
                    next_day = n_date_exp + timedelta(0.5)
                elif file_name.__contains__("75"):
                    prev_day = p_date_exp - timedelta(minutes=37.5)
                    next_day = n_date_exp + timedelta(minutes=37.5)
                elif file_name.__contains__("60"):
                    prev_day = p_date_exp - timedelta(minutes=30)
                    next_day = n_date_exp + timedelta(minutes=30)
                elif file_name.__contains__("15"):
                    prev_day = p_date_exp - timedelta(minutes=7.5)
                    next_day = n_date_exp + timedelta(minutes=7.5)
                fig.add_shape(type='rect', x0=prev_day, y0=y2, x1=next_day, y1=y1, line=dict(color="blue", width=2))
            for si in sin_z:
                s_row_data = df.iloc[b_z[si]]
                s_low_dat = s_row_data.get("low")
                s_high_dat = s_row_data.get("high")
                s_exp = s_row_data.get("timestamp")
                s_date_exp = datetime.strptime(s_exp, e_str_ftr)
                if file_name.__contains__("month"):
                    prev_day = s_date_exp - timedelta(days=15)
                    next_day = s_date_exp + timedelta(days=15)
                elif file_name.__contains__("week"):
                    prev_day = s_date_exp - timedelta(days=3.5)
                    next_day = s_date_exp + timedelta(days=3.5)
                elif file_name.__contains__("daily"):
                    prev_day = s_date_exp - timedelta(0.5)
                    next_day = s_date_exp + timedelta(0.5)
                elif file_name.__contains__("75"):
                    prev_day = s_date_exp - timedelta(minutes=37.5)
                    next_day = s_date_exp + timedelta(minutes=37.5)
                elif file_name.__contains__("60"):
                    prev_day = s_date_exp - timedelta(minutes=30)
                    next_day = s_date_exp + timedelta(minutes=30)
                elif file_name.__contains__("15"):
                    prev_day = s_date_exp - timedelta(minutes=7.5)
                    next_day = s_date_exp + timedelta(minutes=7.5)
                fig.add_shape(type='rect', x0=prev_day, y0=s_low_dat, x1=next_day, y1=s_high_dat, line=dict(color="blue", width=2))

    def closest(self, lst, K, isSZ):
        # calculate_difference = lambda x: abs(x - K)
        # print(lst)
        # sorted_list = sorted(lst, key=calculate_difference)
        sorted_list = lst[::-1]

        flag = len(set(sorted_list)) == len(sorted_list)
        # if(flag):
        #     print("List contains all unique elements")
        # else:
        #     print("List contains does not contains all unique elements")
        # print("Sorted list", sorted_list, type(sorted_list))
        # print(sorted_list, "List")
        if isSZ:
            found = False
            for idx, item in enumerate(sorted_list):
                # print(idx, item, type(idx), type(item), K)
                if item > K:
                    # print("ITEM", item)
                    found = True
                    return item, idx
                else:
                    continue
            # print(found)
            if not found:
                return None, None
            # first_match = next((item for item in sorted_list if item > K),None)
            # lst[min(range(len(lst)), key = lambda i: abs(lst[i]-K))]
            # return first_match
        else:
            found = False
            for idx, item in enumerate(sorted_list):
                if item < K:
                    found = True
                    return item, idx
                else:
                    continue
            if not found:
                return None, None
            # first_match = next((item for item in sorted_list if item < K),None)
            # lst[min(range(len(lst)), key = lambda i: abs(lst[i]-K))]
            # return first_match
    def second_closest(self, lst, K, idx, isSZ):
        sorted_list = lst.reverse()
        trim_list = sorted_list[idx:]
        if isSZ:
            for item in trim_list:
                if item > K:
                    return item
        else:
            for item in trim_list:
                if item < K:
                    return item
    def draw_ema(self, dataframe, s_time_ftr):
        dataframe['20EMA'] = ta.EMA(dataframe['close'], 20)
        g_list = dataframe['20EMA'].to_list()
        # print(g_list[len(g_list) - 1], "ema_cur")
        ema_trace = go.Scatter(x=dataframe['timestamp'].apply(lambda x: datetime.strptime(x, s_time_ftr)), y=dataframe['20EMA'], mode='lines', name='20EMA', line=dict(color="black", width=2))
        return ema_trace

    def calculate_frequency(self, file_name: str):
        if file_name.__contains__('75'):
            return "75min"
        elif file_name.__contains__('60'):
            return "60min"
        elif file_name.__contains__('15'):
            return "15min"
        else:
            return False

    def calculate_sz_by_near_dz(self, all_id_lst : list, cur_dz_id, cur_dz_high, dataframe):
        # print(all_id_lst)
        # print("cur_dz_id", cur_dz_id)
        rev_list = all_id_lst[::-1]
        index_of_dz = rev_list.index({'ZONE': 'DZ', 'ID': cur_dz_id})
        new_trim_list = rev_list[index_of_dz::]
        for items in new_trim_list:
            if items.get('ZONE') == 'SZ':
                comp = dataframe.iloc[items.get('ID')]
                if comp.get('low') > cur_dz_high:
                    return comp

        # print(rev_list)
    def calculate_price_point_per(self, high_point, low_point, cur_price_point):
        ranger_per = abs(high_point - low_point)/100
        diff = abs(cur_price_point - low_point)/ranger_per
        if diff >= 33.3 and diff <= 66.6:
            print("In fair price zone", diff)
        else:
            print("not ideal for trading", diff)
        return diff
    
    def ranges_intersect(self, range1, range2):
        start1, end1 = range1
        start2, end2 = range2
        range1 = (min(start1, end1), max(start1, end1))
        range2 = (min(start2, end2), max(start2, end2))
        overlap = max(0, min(range1[1], range2[1]) - max(range1[0], range2[0]))
        # total_range = max(range1[1], range2[1]) - min(range1[0], range2[0])
        total_range = abs(range1[0] - range1[1])
        percentage = (overlap / total_range) * 100
        # return max(range1[0], range2[0]) <= min(range1[1], range2[1])
        return percentage
    

    def draw_lines(self, data_row, data_frame, fig, isSZ, e_type : str, time_ftr : str, file_name: str):
        if e_type == 'evaluate' or e_type == 'analyse':
            if isSZ:
                b_low_dat = data_row.get("close")
                b_high_dat = data_row.get("high")
            else:
                b_low_dat = data_row.get("low")
                b_high_dat = data_row.get("close")
        elif e_type == 'execute':
            b_low_dat = data_row.get("low")
            b_high_dat = data_row.get("high")
        exp = data_row.get("timestamp")
        date_exp = datetime.strptime(exp, time_ftr)
        if file_name.__contains__("month"):
            prev_day = date_exp - timedelta(days=30)
            next_day = date_exp + timedelta(days=30)
        elif file_name.__contains__("week"):
            prev_day = date_exp - timedelta(days=7)
            next_day = date_exp + timedelta(days=7)
        elif file_name.__contains__("daily"):
            prev_day = date_exp - timedelta(days=1)
            next_day = date_exp + timedelta(days=1)
        elif file_name.__contains__("75"):
            prev_day = date_exp - timedelta(minutes=75)
            next_day = date_exp + timedelta(minutes=75)
        elif file_name.__contains__("60"):
            prev_day = date_exp - timedelta(minutes=60)
            next_day = date_exp + timedelta(minutes=60)
        elif file_name.__contains__("15"):
            prev_day = date_exp - timedelta(minutes=15)
            next_day = date_exp + timedelta(minutes=15)
        curr_stamp = datetime.strptime(data_frame.iloc[len(data_frame) - 1].get('timestamp'), time_ftr)
        # print("curr_stamp", curr_stamp)
        lin_col = 'red' if isSZ else 'green'
        # fig.add_shape(type='rect', x0=prev_day, y0=b_low_dat, x1=next_day, y1=b_high_dat, line=dict(color=lin_col, width=2))
        # fig.add_shape(type='rect', x0=prev_day, y0=b_low_dat, x1=next_day, y1=b_high_dat, line=dict(color="red", width=2))
        fig.add_shape(type='line', x0=prev_day, y0=b_low_dat, x1=curr_stamp, y1=b_low_dat, line=dict(color=lin_col, width=2))
        fig.add_shape(type='line', x0=prev_day, y0=b_high_dat, x1=curr_stamp, y1=b_high_dat, line=dict(color=lin_col, width=2))
        # print("line draw compl")

    def draw_eval_analyse_in_execute(self, eval_d : dict, ana_d : dict, d_frame, fig, time_ftr):
        curr_stamp = datetime.strptime(d_frame.iloc[len(d_frame) - 1].get('timestamp'), time_ftr)
        # EVALUATE
        eva_dzl = eval_d.get('demand_zone_low')
        eva_dzh = eval_d.get('demand_zone_high')
        eva_dzt = eval_d.get('demand_zone_timestamp')
        eva_dz_date_exp = datetime.strptime(eva_dzt, eval_d.get('demand_zone_timestamp_format'))
        fig.add_shape(type='rect', x0=eva_dz_date_exp, y0=eva_dzl, x1=curr_stamp, y1=eva_dzh, line=dict(color='darkgreen', width=2))

        eva_szl = eval_d.get('sell_zone_low')
        eva_szh = eval_d.get('sell_zone_high')
        eva_szt = eval_d.get('sell_zone_timestamp')
        eva_sz_date_exp = datetime.strptime(eva_szt, eval_d.get('sell_zone_timestamp_format'))
        fig.add_shape(type='rect', x0=eva_sz_date_exp, y0=eva_szl, x1=curr_stamp, y1=eva_szh, line=dict(color='darkred', width=2))
        # Analyse
        ana_dzl = ana_d.get('demand_zone_low')
        ana_dzh = ana_d.get('demand_zone_high')
        ana_dzt = ana_d.get('demand_zone_timestamp')
        ana_dz_date_exp = datetime.strptime(ana_dzt, ana_d.get('demand_zone_timestamp_format'))
        fig.add_shape(type='rect', x0=ana_dz_date_exp, y0=ana_dzl, x1=curr_stamp, y1=ana_dzh, line=dict(color='lightgreen', width=2))
        ana_szl = ana_d.get('sell_zone_low')
        ana_szh = ana_d.get('sell_zone_high')
        ana_szt = ana_d.get('sell_zone_timestamp')
        ana_sz_date_exp = datetime.strptime(ana_szt, ana_d.get('sell_zone_timestamp_format'))
        fig.add_shape(type='rect', x0=ana_sz_date_exp, y0=ana_szl, x1=curr_stamp, y1=ana_szh, line=dict(color='tomato', width=2))

    def calculate_overlapping(self, sz_row_data, dz_row_data):
        x = range(int(sz_row_data.get('low')), int(sz_row_data.get('high')))
        y = range(int(dz_row_data.get('low')), int(dz_row_data.get('high')))
        xs = set(x)
        gg = xs.intersection(y)
        if len(gg) > 0:
            return True
        else:
            return False
        
    def run_calculation(self, with_ema: bool, e_type: str, e_date : str, eval_dict : dict = None, ana_dict : dict = None):
        df = pd.read_csv(self.csv_path)
        # print(df.tail())
        print(str(self.csv_path).__contains__("15") or str(self.csv_path).__contains__("60") or str(self.csv_path).__contains__("75"), "*************")
        e_format = "%d/%m/%Y %H:%M:%S" if (str(self.csv_path).__contains__("15") or str(self.csv_path).__contains__("60") or str(self.csv_path).__contains__("75")) else "%d/%m/%Y"
        out_dict = {}
        input_date = datetime.strptime(e_date, "%d/%m/%Y")
        df['p_timestamp'] = pd.to_datetime(df['timestamp'], format=e_format)
        df['date_difference'] = abs(df['p_timestamp'] - input_date)
        closest_row = df.loc[df['date_difference'].idxmin()]
        # closest_date = closest_row['timestamp']
        # filter last date
        # print("closest_date_output", closest_row)
        # start_date = df.iloc[0]['p_timestamp']
        end_date = closest_row['p_timestamp']
        df = df[df['p_timestamp'].between(df.iloc[0]['p_timestamp'], end_date)]
        # df = df[(df['timestamp'] >= start_date) & (df['timestamp'] <= end_date)]
        # print(df.head())
        # print(df.tail())
        df.reset_index(drop=True, inplace=True)
        df.index = pd.DatetimeIndex(df['timestamp'], dayfirst=True)
        fig = go.Figure(data=[go.Candlestick(x=df.index, open=df['open'], high=df['high'], low=df['low'], close=df['close'])])
        last_row = df.iloc[len(df) - 1]
        last_row_high = last_row.get('high')
        last_row_low = last_row.get('low')
        last_row_close = last_row.get('close')
        out_dict['current_price'] = last_row_close
        # print(last_row_close)
        if with_ema:
            fig.add_trace(self.draw_ema(df, e_format))
        consecutive_dz = []
        consecutive_sz = []
        consecutive_dz_id = []
        consecutive_sz_id = []
        all_sz_dz_id = []
        for i in range(len(df)):
            row_data = df.iloc[i]
            # if row_data.get("buy_sell_zone") == "DZ":
            if row_data.get("buy_sell_zone") == "SZ":
                sell_close = row_data.get('low')
                consecutive_sz.append(sell_close)
                consecutive_sz_id.append(i)
                all_sz_dz_id.append({"ZONE" : "SZ", "ID" : i})

            if row_data.get("buy_sell_zone") == "DZ":
                sell_close = row_data.get('high')
                consecutive_dz.append(sell_close)
                consecutive_dz_id.append(i)
                all_sz_dz_id.append({"ZONE" : "DZ", "ID" : i})

        # print("Length_of_list", len(consecutive_sz), len(consecutive_dz), len(all_sz_dz_id))
        nearest_dz_val, dz_index_val = self.closest(consecutive_dz, last_row_low, False)
        nearest_sz_val, sz_index_val = self.closest(consecutive_sz, last_row_high, True)
        print("******************************", self.csv_path)
        self.draw_dz_sz_zones(df, fig, e_format, self.csv_path)
        # print("nearest", nearest_sz_val, nearest_dz_val)

        if nearest_dz_val is not None:
            # consecutive_sz_id[consecutive_sz.index(nearest)]
            nearest_data_dz = df.iloc[consecutive_dz_id[::-1][consecutive_dz[::-1].index(nearest_dz_val)]]
            #b_low_dat = nearest_data_dz.get("low")
            b_high_dat = nearest_data_dz.get("high")
            if e_type == 'evaluate' or e_type == 'analyse':
                out_dict['demand_zone_low'] = nearest_data_dz.get("low")
                out_dict['demand_zone_high'] = nearest_data_dz.get("close")
                out_dict['demand_zone_timestamp'] = nearest_data_dz.get("timestamp")
                out_dict['demand_zone_timestamp_format'] = e_format
            else:
                out_dict['demand_zone_low'] = nearest_data_dz.get("low")
                out_dict['demand_zone_high'] = nearest_data_dz.get("high")
                out_dict['demand_zone_timestamp'] = nearest_data_dz.get("timestamp")
                out_dict['demand_zone_timestamp_format'] = e_format

                print("execute")
                print("+++++++++++++++++++")
                # print(eval_dict)
                # try:
                #     self.draw_eval_analyse_in_execute(eval_dict, ana_dict, df, fig, e_format)
                #     print("Passed")
                # except:
                #     print("Failed")
                # print(ana_dict)
            vdzi_ctr = 0
        # if len(self.valid_dz_indx) > 0:
            # for vals in self.valid_dz_indx[::-1]:
            #     vdzi_ctr += 1
            #     self.draw_lines(df.iloc[vals], df, fig, False, e_type, e_format, self.csv_path)
            #     if vdzi_ctr > 2:
            #         break
                # self.draw_lines(nearest_data_dz, df, fig, False, e_type, e_format, self.csv_path)
            

            # cons_sz = self.calculate_sz_by_near_dz(all_sz_dz_id, consecutive_dz_id[consecutive_dz.index(nearest_dz_val)], b_high_dat, df)
            # if cons_sz is not None:
            #     # print("Not None")
            #     if e_type == 'execute' or e_type == 'analyse':
            #         out_dict['consecutive_sell_zone_high'] = cons_sz.get('high')
            #         out_dict['consecutive_sell_zone_low'] = cons_sz.get('close')
            #     else:
            #         out_dict['consecutive_sell_zone_high'] = cons_sz.get('high')
            #         out_dict['consecutive_sell_zone_low'] = cons_sz.get('low')
            #     self.draw_lines(cons_sz, df, fig, True, e_type, e_format, self.csv_path)

        else:
            print("No demand zone found")

        if nearest_sz_val is not None:
            nearest_data_sz = df.iloc[consecutive_sz_id[::-1][consecutive_sz[::-1].index(nearest_sz_val)]]
            if e_type == 'evaluate' or e_type == 'analyse':
                out_dict['sell_zone_high'] = nearest_data_sz.get('high')
                out_dict['sell_zone_low'] = nearest_data_sz.get('close')
                out_dict['sell_zone_timestamp'] = nearest_data_sz.get('timestamp')
                out_dict['sell_zone_timestamp_format'] = e_format
            else:
                out_dict['sell_zone_high'] = nearest_data_sz.get('high')
                out_dict['sell_zone_low'] = nearest_data_sz.get('low')
                out_dict['sell_zone_timestamp'] = nearest_data_sz.get('timestamp')
                out_dict['sell_zone_timestamp_format'] = e_format
            svszi_ctr = 0
            # if len(self.valid_sz_indx) > 0:
            # for vals in self.valid_sz_indx[::-1]:
            #     svszi_ctr += 1
            #     self.draw_lines(df.iloc[vals], df, fig, True, e_type, e_format, self.csv_path)
            #     if svszi_ctr > 2:
            #         break
                # self.draw_lines(nearest_data_sz, df, fig, True, e_type, e_format, self.csv_path)
        else:
            # print("No Sell zone found")
            nearest_sz_val, closest_index_val = self.closest(consecutive_sz, last_row_close, True)
            if nearest_sz_val is not None:
                nearest_data_sz = df.iloc[consecutive_sz_id[::-1][consecutive_sz[::-1].index(nearest_sz_val)]]
                if e_type == 'evaluate' or e_type == 'analyse':
                    out_dict['sell_zone_high'] = nearest_data_sz.get('high')
                    out_dict['sell_zone_low'] = nearest_data_sz.get('close')
                    out_dict['sell_zone_timestamp'] = nearest_data_sz.get('timestamp')
                    out_dict['sell_zone_timestamp_format'] = e_format
                else:
                    out_dict['sell_zone_high'] = nearest_data_sz.get('high')
                    out_dict['sell_zone_low'] = nearest_data_sz.get('low')
                    out_dict['sell_zone_timestamp'] = nearest_data_sz.get('timestamp')
                    out_dict['sell_zone_timestamp_format'] = e_format
                # self.draw_lines(nearest_data_sz, df, fig, True, e_type, e_format, self.csv_path)

        if nearest_dz_val and nearest_sz_val is not None:
            # check_overlap
            sz_row_dat = df.iloc[consecutive_sz_id[consecutive_sz.index(nearest_sz_val)]]
            dz_row_dat = df.iloc[consecutive_dz_id[consecutive_dz.index(nearest_dz_val)]]

            
            prices_pos_diff = self.calculate_price_point_per(sz_row_dat.get('high'), dz_row_dat.get('low'), last_row.get('close'))
            # print("prices_pos_diff", prices_pos_diff)
            out_dict['price_position_percent'] = prices_pos_diff

            isOverlapping = self.calculate_overlapping(nearest_data_dz, nearest_data_sz)
            out_dict['sell_demand_overlapping'] = isOverlapping
            # print("isOverlapping", isOverlapping)
            # if isOverlapping:
            #     nearest_sz_val = self.second_closest(consecutive_sz, last_row_high, sz_index_val, True)
            #     nearest_dz_val = self.second_closest(consecutive_sz, last_row_low, dz_index_val, False)

        fig.update_layout(title=f"{self.tick.upper()}: {self.time_frame.upper()} {e_type.upper()}", yaxis_title="Price (INR)")
        fig.update_yaxes(fixedrange=False, selector=None)
        if str(self.csv_path).__contains__('minute'):
            fig.update_xaxes(
                    rangebreaks=[
                        # NOTE: Below values are bound (not single values), ie. hide x to y
                        dict(bounds=["sat", "sun"]),  # hide weekends, eg. hide sat to before mon
                        dict(bounds=[16, 9], pattern="hour"),  # hide hours outside of 9.30am-4pm
                        # dict(values=["2019-12-25", "2020-12-24"])  # hide holidays (Christmas and New Year's, etc)
                    ]
                )
        fig.update_layout(xaxis_rangeslider_visible=False)
        # fig.show()
        fig.update_xaxes(showgrid=False)
        fig.update_yaxes(showgrid=False)
        fig.update_layout(plot_bgcolor='rgb(255,253,208)')
        fig.update_layout(
                            dragmode='drawopenpath',
                            newshape_line_color='black',
                            modebar_add=['drawline',
                                        'drawopenpath',
                                        'drawclosedpath',
                                        'drawcircle',
                                        'drawrect',
                                        'eraseshape'
                                    ]
                        )
        fig_json = json.loads(fig.to_json())
        # config={'staticPlot': True}
        # fig_json['config'] = config
        return fig_json, out_dict


# print(nearest_data_dz)
# print(nearest_data_sz)
# print(isOverlapping, "overlapping")
# b_low_dat = nearest_data_dz.get("low")
# b_high_dat = nearest_data_dz.get("high")
# exp = nearest_data_dz.get("timestamp")
# date_exp = datetime.strptime(exp, '%Y-%m-%d').date()

