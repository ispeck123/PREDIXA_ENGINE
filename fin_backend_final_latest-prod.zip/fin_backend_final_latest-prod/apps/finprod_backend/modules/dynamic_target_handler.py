import pandas as pd
from shared.db.dbconn import DBConnection
from sqlalchemy import text
from shared.config.settings import Config as cfg
from datetime import datetime
from apps.finprod_backend.modules.calculate_zone import Calculate_BUY_SELL_ZONES
# from modules.calculate_setup import Calculate_setup_execute
from apps.finprod_backend.modules.utils import utility
import os

db = DBConnection()

class DYNAMIC_TARGET:
    def __init__(self, order_id):
        self.order_id = order_id
        self.get_oder_details()

    def converter(self, qual_list):
        new_list = []
        for items in qual_list:
            low_r = items[0]['price']
            high_r = items[1]['price']
            zone = (min(low_r, high_r), max(low_r, high_r))
            new_list.append(zone)
        return new_list

    def get_oder_details(self):
        query = f"select * from auto_order_master where order_id={self.order_id}"
        res = db.raw_query(query)[0]
        stock_tick = res.get('stock_tick')
        entry_price = res.get('entry_price')
        target_price = res.get('target_price')
        time_frame = res.get('time_frame')
        exe_frame = getattr(cfg, f"TIME_FRAMES_{res.get('time_frame')}")[-1]
        #file_path = f"/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/processed_data_files/{stock_tick}_{exe_frame}.csv"
        file_path = os.path.join(os.getcwd(), "apps", "finprod_backend", "processed_data_files", f"{stock_tick}_{exe_frame}.csv")
        pcd_dt = datetime.strptime(res.get('purchased_cmp_date'), '%Y-%m-%dT%H:%M')
        entry_dt = datetime.strptime(res.get('entry_timestamp'), '%Y-%m-%dT%H:%M:%S.%f')
        self.calculate_zone_details(file_path, stock_tick, pcd_dt, entry_dt, time_frame, entry_price)

    def calculate_zone_details(self, file_path, tick, purchased_hit, entry_hit, time_fr, entry_p):
        cbsz = Calculate_BUY_SELL_ZONES(file_path, tick, entry_hit, True)
        df, sz_list = cbsz.update_new_sell_zones_df()
        qualified_sz_list = cbsz.get_qualified_sell_zones()
        df = df[df.timestamp >= purchased_hit]
        final_zone_list = df['final_zone'].to_list()
        if 'SZ' in final_zone_list:
            _, dz_list = cbsz.update_new_buy_zones_df()
            # print(final_zone_list)
            # print(sz_list)
            # print(dz_list)
            print("=======================================================================")
            print(qualified_sz_list)
            print("=======================================================================")
            self.calculate_new_target(dz_list, qualified_sz_list, entry_p)
        # df = pd.read_csv(file_path)
        # df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst = True)
        # df = df[df.timestamp <= self.entry_hit]
        # cse = Calculate_setup_execute(tick, time_fr)

    def calculate_new_target(self, dz_list, sz_list, entry_p):
        if len(sz_list) > 0:
            sz_list = self.converter(sz_list)
            sorted_sz_list = sorted(sz_list)
            print(sorted_sz_list, "==========================================++++++++++++++++++++++++++++++++++")
            uts = utility()
            # cse = Calculate_setup_execute(tick, time_fr, last_dt_time)
            # current_cmp, cmp_ts = cse.get_cmp_price_tstamp(file_path, last_dt_time)
            dz_tuple = min(dz_list, key=lambda x: abs(float(max(x)) - entry_p))
            # # filtered_sz_list = [tup for tup in sorted_sz_list if float(tup[0]) >= current_cmp]
            new_target = uts.calculate_target_buy_price(min(dz_tuple), max(sorted_sz_list[0]))
            self.update_target(new_target)
            # raise SystemExit

    def update_target(self, revised_target):
        rc = db.raw_connection()
        query = f"update auto_order_master set target_price={revised_target} where order_id={self.order_id}"
        rc.execute(text(query))
        rc.commit()
        rc.close()
    