from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import Session
from shared.config.settings import Config as cfg
from urllib.parse import quote as urlquote
import pandas as pd
import json
from sqlalchemy import text
import logging

# Init the Configuration
# config = Config()
logger = logging.getLogger()

class DBConnection:

    def __init__(self):
        # self.database = config.getDatabaseConfig()
        # Create a sqlite engine instance
        self.engine = create_engine(
            "mysql+pymysql://"+cfg.DB_USER+":"+urlquote(cfg.DB_PASSWORD)+"@"+cfg.DB_HOST+"/"+cfg.DB_SCHEMA,
            pool_recycle = 1800,
            pool_pre_ping = True
        )
        # Create a DeclarativeMeta instance
        self.Base = declarative_base()
        # Create the database
        self.Base.metadata.create_all(self.engine)
        # return self.engine
    
    def raw_connection(self):
        try:
            raw_connection = self.engine.connect()
            return raw_connection
        except Exception as ex:
            logger.exception(ex)
            return None
    
    def raw_query(self, my_query):
        try:
            with self.raw_connection() as rcc:
                data_list = pd.read_sql(my_query, rcc)
                results = json.loads(data_list.to_json(orient="table", index=False))["data"]
        except Exception as ex:
            logger.exception(ex)
            results = None
            # raise Exception(str(ex))
        return results
    
    def get_session(self):
        SessionLocal = Session(bind=self.engine)
        # sessionmaker(bind=engine)
        return SessionLocal
    
    def insert_update_query(self, my_query):
        try:
            with self.raw_connection() as conn:
                conn.execute(text(my_query))
                conn.commit()
                conn.close()
                return True 
        except Exception as ex:
            logger.exception(ex)
            print("\nException while inserting/updating:\n", ex)
            # raise Exception(str(ex))
            return False
    
    def close_engine(self):
        try:
            self.engine.dispose()
            return True
        except Exception as ex:
            logger.exception(ex)
            return False



#  (pymysql.err.OperationalError) (2006, "MySQL server has gone away (BrokenPipeError(32, 'Broken pipe'))")
# 29|FINPROD_BACKEND  | [SQL: select * from stock_master where stock_tick='nhpc';]
# 29|FINPROD_BACKEND  | (Background on this error at: https://sqlalche.me/e/20/e3q8)


