from shared.config.settings import Config as cfg
from apps.finprod_backend.modules.calculate_setup_old import Calculate_setup_execute
from apps.finprod_backend.modules.telegram_alert import TELEGRAM_MSG
from apps.finprod_backend.modules.calculate_model import ARIMA_AB, LSTM_RF, ARIMA_AB_BUY
from datetime import datetime
import logging
import os

logger = logging.getLogger()

class ALERT_CONTROLLER:
    def __init__(self) -> None:
        self.stock_list = cfg.stock_list
        self.tmsg = TELEGRAM_MSG()
    
    def send_tick_wise_telegram_alert(self, tick, setup_dict : dict):
        message_list = []
        first_string = f"""Current {tick} Predictions \n CMP - {setup_dict['daily'].get('PRICE_CMP')}"""
        message_list.append(first_string)

        for frames in setup_dict.keys():
            frame_dict = setup_dict[frames]
            
            frame_msg = f"At {frames} time frame findings"
            message_list.append(frame_msg)

            if 'PRICE_POS' in frame_dict.keys():
                position_str = f"Price at position {round(frame_dict['PRICE_POS'], 2)}"
            else:
                position_str = f"No Nearby Sell Zone Found."
            message_list.append(position_str)

            if 'BUY' in frame_dict.keys():
                buy_dict = frame_dict['BUY']
                buy_string = f"""Potential BUY Position At \n 
                entry_price: {buy_dict['entry_price']} \n
                stop_loss: {buy_dict['stop_loss']} \n
                target_price: {buy_dict['target_price']} \n model predicted this trade as {buy_dict['Model_Prediction']} with a probability of {buy_dict['Model_Probability']}% \n"""
                message_list.append(buy_string)
            
            if 'SELL' in frame_dict.keys():
                sell_dict = frame_dict['SELL']
                sell_string = f"""Potential SELL Position At \n 
                entry_price: {sell_dict['entry_price']} \n
                stop_loss: {sell_dict['entry_price']} \n
                target_price: {sell_dict['entry_price']} \n model predicted this trade as {sell_dict['Model_Prediction']} with a probability of {sell_dict['Model_Probability']}% \n"""
                message_list.append(sell_string)

        result_string = "\n".join(message_list)
        self.tmsg.send_msg(message=result_string)
                

    def calculate_all_stock_predictions(self):
        stock_out = {}
        for stock in self.stock_list:
            stock_frame_preds = self.calculate_stock_setup(stock)
            # self.send_tick_wise_telegram_alert(stock, stock_frame_preds)
            stock_out[stock] = stock_frame_preds
        return stock_out

    def calculate_stock_setup(self, tick):
        out_res = {}
        for idx, exe_frames in enumerate(cfg.EXECUTE_FRAMES):
            #file_path = f"/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/processed_data_files/{tick}_{exe_frames}.csv"
            file_path = os.path.join(os.getcwd(), 'apps', 'finprod_backend', 'processed_data_files', f"{tick}_{exe_frames}.csv")
            print("processing file......", file_path)
            try:
                last_d_time = datetime.now()
                cse = Calculate_setup_execute(tick, idx+1, last_d_time)
                setup_data = cse.calculate()
                if setup_data is not None:
                    if 'BUY' in setup_data.keys():
                        bind_data = {
                            "order_type" : 'Buy',
                            "entry_price" : setup_data['BUY'].get("entry_price"),
                            "target_price" : setup_data['BUY'].get("target_price"),
                            "stoploss_price" : setup_data['BUY'].get("stop_loss")
                        }
                        # print(setup_data)
                        # print(bind_data)
                        arm_ab = ARIMA_AB_BUY(file_path, bind_data, datetime.now(), tick)
                        model_out, prob = arm_ab.run()
                        setup_data['BUY']['Model_Prediction'] = model_out
                        setup_data['BUY']['Model_Probability'] = round(prob, 2)

                    if 'SELL' in setup_data.keys():
                        bind_data = {
                            "order_type" : 'Sell',
                            "entry_price" : setup_data['SELL'].get("entry_price"),
                            "target_price" : setup_data['SELL'].get("target_price"),
                            "stoploss_price" : setup_data['SELL'].get("stop_loss")
                        }
                        # print(setup_data)
                        # print(bind_data)
                        arm_ab = ARIMA_AB_BUY(file_path, bind_data, datetime.now(), tick)
                        model_out, prob = arm_ab.run()
                        setup_data['SELL']['Model_Prediction'] = model_out
                        setup_data['SELL']['Model_Probability'] = round(prob, 2)

                    out_res[exe_frames] = setup_data
                else:
                    out_res[exe_frames] = "Not Enough Data Available / Not A good condition to trade."
            except Exception as ex:
                logger.exception(ex, stack_info=True)
        return out_res


