from pydantic import BaseModel
from typing import List, Optional


class Findings(BaseModel):
    current_price: Optional[float] = None
    demand_zone_low: Optional[float] = None
    consecutive_sell_zone_high: Optional[float] = None
    consecutive_sell_zone_low: Optional[float] = None
    sell_zone_high: Optional[float] = None
    sell_zone_low: Optional[float] = None
    price_position_percent: Optional[float] = None
    sell_demand_overlapping: Optional[bool] = None
    demand_zone_high : Optional[float] = None




class alert_model(BaseModel):
    execute_findings: List[Optional[Findings]]
    analyze_findings: List[Optional[Findings]]
    evaluate_findings: Findings