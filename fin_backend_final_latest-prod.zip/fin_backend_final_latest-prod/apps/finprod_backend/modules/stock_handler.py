from apps.finprod_backend.modules.stock_logic import proc_all_stock_items
from apps.finprod_backend.modules.parse_create_csv import dump_csv, create_75munite_from_15munite
import os, logging
from shared.config.settings import Config as cfg
from datetime import datetime, timedelta
import yfinance as yf
import pandas as pd
from pathlib import Path
from shared.db.dbconn import DBConnection

dbc = DBConnection()
download_time_frames = ['1mo', '1wk', '1d', '60m', '15m']

frame_name_dict = {
    '1mo': 'monthly', 
    '1wk': 'weekly', 
    '1d': 'daily',
    '60m': 'sixty', 
    '15m': 'fifteen'
}

time_vals = ['9:15:00', '10:30:00', '11:45:00', '13:00:00', '14:15:00']

logger = logging.getLogger()

def return_now_and_previous_date(frame: str):
    now_date = datetime.now()
    if frame == '1mo' or frame == '1wk' or frame == '1d':
        start_date = '2020-01-01'
    elif frame == '60m':
        start_date = now_date - timedelta(days=729)
    elif frame == '15m':
        start_date = now_date - timedelta(days=59)
    return now_date, start_date


def get_stock_data(ticker, start_date, end_date, interval='1d'):
    """
    Fetch stock data from Yahoo Finance.

    Parameters:
    ticker (str): Stock symbol (e.g., 'AAPL' for Apple).
    start_date (str): Start date in the format 'YYYY-MM-DD'.
    end_date (str): End date in the format 'YYYY-MM-DD'.
    interval (str): Data frequency (valid intervals: '1m', '2m', '5m', '15m', '30m', '60m', '90m', '1d', '5d', '1wk', '1mo', '3mo').

    Returns:
    DataFrame: Stock data.
    """
    stock = yf.download(ticker, start=start_date, end=end_date, interval=interval)
    # print(stock.tail(5))
    print("/////////////////////////////////////////")
    selected_columns = ['Open', 'High', 'Low', 'Close', 'Volume']
    df_selected = stock.loc[:, (selected_columns, ticker)]
    df_selected.columns = df_selected.columns.droplevel(1)
    print(df_selected.tail(5))
    return df_selected

def proc_single_tick_item(tick : str, c_dir: str):
    stocks_to_proc = []
    input_dir = os.path.join(c_dir, "latest_data_csv")
    output_dir = os.path.join(c_dir,"processed_data_files")
    for items in os.listdir(input_dir):
        if items.__contains__(tick):
            stocks_to_proc.append(items)
    for avl_items in stocks_to_proc:
        proc_all_stock_items(avl_items, input_dir, output_dir)


def format_stock_data(stock_data: pd.DataFrame, tick: str, interval: str, c_dir: str):
    df = stock_data.rename(columns={
            'Open': 'open',
            'High': 'high',
            'Low': 'low',
            'Close': 'close',
            'Volume': 'qty',  # Temporarily renaming to tradeTime, will replace with actual times in step 2
            'Adj Close': 'tradeTime'
        })
    df.index = pd.to_datetime(stock_data.index)
    df['tradeTime'] = df.index.strftime('%H:%M:%S')
    df['tradeDate'] = df.index.strftime('%d/%m/%Y %H:%M:%S')
    df = df.reset_index(drop=True)[['open', 'high', 'low', 'close', 'qty', 'tradeTime', 'tradeDate']]
    # print(df.head())
    out_file_name = f"{c_dir}/latest_data_csv/{tick}_{frame_name_dict[interval]}.csv"
    df.to_csv(out_file_name)
    print("successfully created {}".format(out_file_name))


def download_single_stock_data(stock_name : str, y_fin_stock_name: str, c_dir: str):
    try:
        print(stock_name)
        # y_fin_stock_name = stock_name
        # y_fin_stock_name = cfg.y_fin_stock_list.__getitem__(cfg.stock_list.index(stock_name))
        for items in download_time_frames:
            end_date, start_date = return_now_and_previous_date(items)
            obt_sd = get_stock_data(y_fin_stock_name, start_date, end_date, items)
            if not obt_sd.empty:
                format_stock_data(obt_sd, stock_name, items, c_dir)
        # file_list = os.listdir('latest_data_csv')
        fifteen_file_name = f"{stock_name}_fifteen.csv"
        create_75munite_from_15munite(fifteen_file_name, c_dir)
        # for files in file_list:
            # if str(files).__contains__('fifteen') :
                # create_75munite_from_15munite(files)
    except Exception as ex:
        logger.exception(ex, stack_info=True)
        raise StopIteration
    

def format_and_store_delta_stock_data(stock_data: pd.DataFrame, tick: str, interval: str, country_dir: str):
    # Check if necessary columns exist
    required_columns = ['Open', 'High', 'Low', 'Close', 'Volume']
    for col in required_columns:
        if col not in stock_data.columns:
            raise ValueError(f"Missing required column: {col}")
    
    # Rename columns
    df = stock_data.rename(columns={
        'Open': 'open',
        'High': 'high',
        'Low': 'low',
        'Close': 'close',
        'Volume': 'qty',  
        #'Adj Close': 'tradeTime'  # Temporary column name
    })
    
    # Convert index to datetime
    df.index = pd.to_datetime(stock_data.index)
    df['tradeTime'] = df.index.strftime('%H:%M:%S')
    df['tradeDate'] = df.index.strftime('%d/%m/%Y %H:%M:%S')
    
    # Reorder columns
    df = df.reset_index(drop=True)[['open', 'high', 'low', 'close', 'qty', 'tradeTime', 'tradeDate']]
    df['tradeDate'] = pd.to_datetime(df['tradeDate'], format='%d/%m/%Y %H:%M:%S', errors='coerce')
    # print(df.tail())
    # print("33333333333333333333333333333333333333333333333333333333333333333333")
    # Define output file path
    output_dir = Path(f"{country_dir}/latest_data_csv")
    output_dir.mkdir(parents=True, exist_ok=True)
    out_file_name = output_dir / f"{tick}_{frame_name_dict[interval]}.csv"
    
    # Check if the file already exists
    if out_file_name.exists():
        # Load existing data
        existing_data = pd.read_csv(out_file_name)
        # Ensure consistency in date format
        existing_data['tradeDate'] = pd.to_datetime(existing_data['tradeDate'], format='%d/%m/%Y %H:%M:%S')
        existing_data = existing_data.drop(existing_data.index[-1])
        last_stamp_existing_data = existing_data.iloc[-1].get('tradeDate')
        existing_data['tradeDate'] = existing_data['tradeDate'].dt.strftime('%d/%m/%Y %H:%M:%S')
        # Append only new rows
        new_data = df[df['tradeDate'] > last_stamp_existing_data]
        new_data['tradeDate'] = new_data['tradeDate'].dt.strftime('%d/%m/%Y %H:%M:%S')
        if not new_data.empty:
            combined_data = pd.concat([existing_data, new_data]).drop_duplicates(subset=['tradeDate']).reset_index(drop=True)
            print(combined_data.tail())
            combined_data.to_csv(out_file_name, index=False)

            print(f"Successfully updated {out_file_name} with {len(new_data)} new rows.")
        else:
            print(f"No new data to update for {out_file_name}.")
        # print("##################################################")
    else:
         #Save the entire DataFrame if the file doesn't exist
        df.to_csv(out_file_name, index=False)
        print(f"Successfully created {out_file_name} with all data.")


def download_and_store_delta_data(nn_stock, nn_y_fin, country_dir):
    try:
        # print(stock_names)
        for items in download_time_frames:
            end_date, start_date = return_now_and_previous_date(items)
            # tick_name = nn_stock[idx]
            obt_sd = get_stock_data(nn_y_fin, start_date, end_date, items)
            format_and_store_delta_stock_data(obt_sd, nn_stock, items, country_dir)
        file_list = os.listdir(os.path.join(country_dir, 'latest_data_csv'))
        for files in file_list:
            if str(files).__contains__('fifteen') and str(files).__contains__(nn_stock):
                create_75munite_from_15munite(files, country_dir)
    except Exception as ex:
        logger.exception(ex, stack_info=True)
        raise StopIteration
    

def get_stock_details():
    nn_stock_list = []
    nn_y_fin_stock_list = []
    res = dbc.raw_query("select * from ind_stock_master where is_active=1;")
    for stock_details in res:
        nn_stock_list.append(stock_details.get('stock_tick'))
        nn_y_fin_stock_list.append(stock_details.get('y_finance'))
    return nn_stock_list, nn_y_fin_stock_list


def all_downloader_yfinance():
    try:
        nn_stock, nn_y_fin = get_stock_details()
        for idx, stock_names in enumerate(nn_y_fin):
            try:
                print(stock_names)
                for items in download_time_frames:
                    end_date, start_date = return_now_and_previous_date(items)
                    tick_name = nn_stock[idx]
                    obt_sd = get_stock_data(stock_names, start_date, end_date, items)
                    format_and_store_delta_stock_data(obt_sd, tick_name, items)
            except Exception as exx:
                pass
        file_list = os.listdir('latest_data_csv')
        for files in file_list:
            if str(files).__contains__('fifteen'):
                create_75munite_from_15munite(files)
    except Exception as ex:
        logger.exception(ex, stack_info=True)
        raise StopIteration
    

def ohlc_inverter(df: pd.DataFrame):
    max_price = df[['high']].max().max()
    min_price = df[['low']].min().min()
    # Invert prices using the formula: inverted = max + min - original
    df['open'] = max_price + min_price - df['open']
    df['low'] = max_price + min_price - df['low']
    df['high'] = max_price + min_price - df['high']
    df['close'] = max_price + min_price - df['close']
    return df


def get_stock_details_by_country(country_name: str):
    nn_stock_list = []
    nn_y_fin_stock_list = []
    if country_name.lower().__contains__('us'):
        qq = "select * from us_stock_master where is_active=1;"
    else:
        qq = "select * from ind_stock_master where is_active=1;"
    res = dbc.raw_query(qq)
    for stock_details in res:
        nn_stock_list.append(stock_details.get('stock_tick'))
        nn_y_fin_stock_list.append(stock_details.get('y_finance'))
    return nn_stock_list, nn_y_fin_stock_list



def get_all_stock_cmp(country_name: str):
    cmp_dict = {}
    st_list , _ = get_stock_details_by_country(country_name)
    country_dir = getattr(cfg, f'{country_name.lower()}_data_dir')
    # file_list = os.listdir()
    for items in st_list:
        file_name = os.path.join(country_dir, 'latest_data_csv', f'{items}_fifteen.csv')
        try:
            dff = pd.read_csv(file_name) 
            cmp_dict[items] = dff.iloc[-1].get('close')
        except Exception as ex:
            print(file_name)
            logger.exception(ex, stack_info=True)
    return cmp_dict
    