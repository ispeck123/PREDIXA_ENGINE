
import pandas as pd
import numpy as np
from datetime import timedelta
from apps.finprod_backend.modules.utils import utility
# from modules.calculate_zone import Calculate_BUY_SELL_ZONES
from apps.finprod_backend.modules.cal_z import DemandZoneCalculator, SupplyZoneCalculator, ZoneAnalyzer
import logging
from shared.config.settings import Config as cfg
from datetime import datetime
# import talib

logger = logging.getLogger()

class Calculate_setup_execute:
    def __init__(self, stock_name, time_frame, last_dt, country_dir) -> None:
        self.stock_tick = stock_name
        self.time_frame = time_frame
        self.country_dir = country_dir
        if time_frame == 25:
            self.time_list = ['weekly', 'daily', 'seventy_five']
            # getattr(cfg, f"TIME_FRAMES_2")
            # if 'sixty' in self.time_list:
            #     self.time_list.remove('sixty')
        else:
            self.time_list = getattr(cfg, f"TIME_FRAMES_{time_frame}")
        self.last_d_time = last_dt
        self.cmp_price = None

    def get_execute_df(self):
        exe_tf = self.time_list[-1]
        exe_file_path = f"{self.country_dir}/processed_data_files/{self.stock_tick}_{exe_tf}.csv"
        df = pd.read_csv(exe_file_path)
        df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst = True)
        df = df[df.timestamp <= self.last_d_time]
        return df
    
    def get_datr_frame(self):
        exe_file_path = f"{self.country_dir}/processed_data_files/{self.stock_tick}_daily.csv"
        datr_df = pd.read_csv(exe_file_path)
        datr_df['timestamp'] = pd.to_datetime(datr_df['timestamp'], dayfirst = True)
        datr_df = datr_df[datr_df.timestamp <= self.last_d_time]
        return datr_df

    def find_increasing_indices(self, lst):
        increasing_indices = []
        single_values = []
        for i in range(len(lst) - 1):
            if lst[i+1] - lst[i] == 1:
                if not increasing_indices or (increasing_indices and increasing_indices[-1][-1] != i):
                    increasing_indices.append([i, i+1])
                else:
                    increasing_indices[-1][-1] = i+1
            else:
                if not (increasing_indices and increasing_indices[-1][-1] == i):
                    single_values.append(i)
                if lst[i+1] - lst[i] != 1 and (not increasing_indices or (increasing_indices and increasing_indices[-1][-1] != i+1)):
                    single_values.append(i+1)
        if not (increasing_indices and increasing_indices[-1][-1] == len(lst) - 1):
            single_values.append(len(lst) - 1)
        single_values = [i for i in single_values if i not in [j for i in increasing_indices for j in range(i[0], i[1]+1)]]
        return increasing_indices, single_values

    def add_timestamp(self):
        if self.time_frame == 1:
            return timedelta(days=30).total_seconds()
        elif self.time_frame == 2:
            return timedelta(hours=720).total_seconds()
        elif self.time_frame == 3:
            return timedelta(hours=720).total_seconds()
        elif self.time_frame == 25:
            return timedelta(hours=720).total_seconds()
    
    def find_overlaps_between_zones(self, list1, list2):
        overlaps = []
        for r1 in list1:
            for r2 in list2:
                start1, end1 = r1
                start2, end2 = r2
                overlap_start = max(start1, start2)
                overlap_end = min(end1, end2)
                if overlap_start < overlap_end:
                    overlaps.append((overlap_start, overlap_end)) # (r1, r2,             
        return overlaps
    
    def percentage_proximity_to_range(self, overlap_range, cmp):
        """
        Calculate the percentage distance of a cmp to an overlap range.
        """
        start, end = overlap_range
        if cmp < start:
            # Calculate the percentage distance when cmp is below the range
            return ((start - cmp) / cmp) * 100
        elif cmp > end:
            # Calculate the percentage distance when cmp is above the range
            return ((cmp - end) / cmp) * 100
        else:
            # Price is within the range, so proximity is 0%
            return 0
    
    def get_cmp_price_tstamp(self, file_name, last_d_time):
        df = pd.read_csv(file_name)
        df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst = True)
        df = df[df.timestamp <= last_d_time]
        cmp_ex = df.iloc[len(df) - 1]['close']
        self.cmp_price = cmp_ex
        cmp_t_stamp = int(df.iloc[len(df) - 1]['timestamp'].timestamp())
        return cmp_ex, cmp_t_stamp
    
    # def filter_zones_based_on_trend(self, trend):
        
        
    def get_stock_trend(self):
        t_frame = self.time_list[1]
        file_name = f"{self.country_dir}/processed_data_files/{self.stock_tick}_{t_frame}.csv"
        dz_cal = DemandZoneCalculator(file_name, self.stock_tick, self.last_d_time, is_execute=False)
        sz_cal = SupplyZoneCalculator(file_name, self.stock_tick, self.last_d_time, is_execute=False)
        z_ana = ZoneAnalyzer(dz_cal, sz_cal)
        trend = z_ana.calculate_overall_trend()
        if trend == 'uptrend':
            return True
        elif trend == 'sideways':
            return False
        else:
            return False

    
    def get_qualified_exe_zones_info(self, time_index):
        dz_price_ranges = []
        sz_price_ranges = []
        exe_frame = self.time_list[time_index]
        csv_file_path = f"{self.country_dir}/processed_data_files/{self.stock_tick}_{exe_frame}.csv"
        exe_dz_cal = DemandZoneCalculator(csv_file_path, self.stock_tick, self.last_d_time, True)
        exe_sz_cal = SupplyZoneCalculator(csv_file_path, self.stock_tick, self.last_d_time, True)
        zone_analyser = ZoneAnalyzer(exe_dz_cal, exe_sz_cal)
        # trend = zone_analyser.calculate_overall_trend()
        res_t = self.get_stock_trend()
        if res_t:
            alt_qual = zone_analyser.get_qualified_alterated_zones(True)
            qualified_dz_list = sorted(alt_qual['Buy'], key=lambda z: z[0]["time"], reverse=True)
            qualified_sz_list = sorted(alt_qual['Sell'], key=lambda z: z[0]["time"], reverse=True)
            for qual_dz in qualified_dz_list:
                dz_price_ranges.append((qual_dz[0]['price'], qual_dz[1]['price']))
            for qual_sz in qualified_sz_list:
                sz_price_ranges.append((qual_sz[0]['price'], qual_sz[1]['price']))
        else:
            alt_qual = zone_analyser.get_qualified_alterated_zones(False)
            # print(alt_qual)
            qualified_dz_list = sorted(alt_qual['Buy'], key=lambda z: z[0]["time"], reverse=True)
            qualified_sz_list = sorted(alt_qual['Sell'], key=lambda z: z[0]["time"], reverse=True)
            for qual_dz in qualified_dz_list:
                dz_price_ranges.append((qual_dz[0]['price'], qual_dz[1]['price']))
            for qual_sz in qualified_sz_list:
                sz_price_ranges.append((qual_sz[0]['price'], qual_sz[1]['price']))


        return dz_price_ranges, sz_price_ranges, qualified_sz_list

    def get_ea_zones_info(self, time_index, is_exe):
        eval_frame = self.time_list[time_index]
        dz_price_ranges = []
        sz_price_ranges = []
        csv_file_path = f"{self.country_dir}/processed_data_files/{self.stock_tick}_{eval_frame}.csv"
        # eval_cbsz = Calculate_BUY_SELL_ZONES(csv_file_path, self.stock_tick, self.last_d_time, is_exe)
        eval_dz_cal = DemandZoneCalculator(csv_file_path, self.stock_tick, self.last_d_time, is_exe)
        eval_sz_cal = SupplyZoneCalculator(csv_file_path, self.stock_tick, self.last_d_time, is_exe)
        eval_df_dz = eval_dz_cal.calculate_zone_with_details()
        eval_df_sz = eval_sz_cal.calculate_zone_with_details()
        cmp_price, cmp_time_stamp = self.get_cmp_price_tstamp(csv_file_path, self.last_d_time)
        print(csv_file_path, cmp_price, cmp_time_stamp, "................................")
        # print(eval_df_dz, eval_df_sz)
        for demand_zones in eval_df_dz:
            dz_price_ranges.append(demand_zones["range"])
        for supply_zones in eval_df_sz:
            sz_price_ranges.append(supply_zones["range"])
        
        return dz_price_ranges, sz_price_ranges, cmp_price, cmp_time_stamp
    
    def sort_ranges_by_percentage_proximity(self, overlapping_ranges, cmp):
        sorted_ranges = sorted(overlapping_ranges, key=lambda x: self.percentage_proximity_to_range(x, cmp))
        return sorted_ranges
    
    def find_closest_intervals(self, intervals, cmp, percent_cmp):
        min_gap = float((percent_cmp/100)*cmp) #float('inf')
        closest_intervals_list = []
        # Iterate through the sorted list and find the minimum gap between consecutive intervals
        for i in range(len(intervals) - 1):
            current_start = intervals[i][0]
            next_end = intervals[i + 1][1]
            # Calculate the gap between the current interval end and the next interval start
            gap = abs(current_start - next_end)
            # print("gap", gap, min_gap)
            # Check if this gap is the smallest found so far
            if 0 <= gap < min_gap:  # Ensure the intervals do not overlap
                # min_gap = gap
                closest_intervals = (intervals[i], intervals[i + 1])
                closest_intervals_list.append(closest_intervals)

        return closest_intervals_list

    def remove_duplicate_zones(self, lst):
        unique_list = []
        for item in lst:
            if item not in unique_list:
                unique_list.append(item)
        return unique_list

    def find_single_overlap_points(self, price_ranges):
        # Sort the ranges by their starting point
        # price_ranges = sorted(price_ranges, key=lambda x: x[0])
        overlapping_points = []
        
        # Iterate over the sorted ranges and check for overlap
        for i in range(len(price_ranges)):
            for j in range(i + 1, len(price_ranges)):
                # Get the current pair of ranges
                range1 = price_ranges[i]
                range2 = price_ranges[j]
                if max(range1[0], range2[0]) <= min(range1[1], range2[1]):
                    # Calculate the overlapping range
                    overlap_start = max(range1[0], range2[0])
                    overlap_end = min(range1[1], range2[1])
                    # print("overlap_start overlap_end", overlap_start, overlap_end)
                    avg_point = max(overlap_start, overlap_end)
                    avg_point = round(avg_point, 2)
                    min_point = min(min(range1), min(range2))
                    overlapping_points.append(avg_point)
                    overlapping_points.append(min_point)
        # Return the list of single overlap points or an empty list if none
        return sorted(overlapping_points, reverse=True)

    def get_overlapping_zones(self, exe_dz, cmp):
        ut = utility()
        found_overlapping_zone = False
        overlapping_avg_points = self.find_single_overlap_points(exe_dz)
        Stop_loss = None
        entry = None
        if len(exe_dz) >= 2:
            high_r = max(max(exe_dz[0]), max(exe_dz[1]))
            low_r = min(min(exe_dz[0]), min(exe_dz[1]))
            # print(exe_dz)
            # print(ut.calculate_percentage_distance(cmp, overlapping_avg_points[0]), self.dynamic_percentage_distance(self.cmp_price), "******")
            if overlapping_avg_points:
                # if ut.calculate_percentage_distance(cmp, overlapping_avg_points[0]) <= self.dynamic_percentage_distance(self.cmp_price):
                    # print(overlapping_avg_points[0], "ooooooooooooooooooooooooooooooooooooooooooooo")
                entry = overlapping_avg_points[0]
                Stop_loss = min(sorted(exe_dz, reverse=True)[1])
                    # ut.calculate_atr(self.get_execute_df(), entry, period=14)
                print(low_r, entry, high_r, "********************555555555555")
                if low_r <= entry <= high_r:
                    found_overlapping_zone = True
        return found_overlapping_zone, entry, Stop_loss

    def calculate_ema_zone(self, exe_dz):
        ut = utility()
        found_ema_zone = False
        entry = None
        stop_loss = None
        df = self.get_execute_df()
        df['EMA20'] = df['close'].ewm(span=20, adjust=False).mean() 
        #talib.EMA(df['close'], 20)
        if len(exe_dz) > 0:
            start_t = max(df[df['low'] == min(exe_dz[0])]['timestamp'])
            interim_df = df[df['close'] == max(exe_dz[0])]['timestamp']
            if interim_df.empty:
                interim_df = df[df['open'] == max(exe_dz[0])]['timestamp']
            end_t = max(interim_df)
            ema_df = df[df['timestamp'].between(start_t, end_t)]['EMA20'].to_list()
            # print(exe_dz, ema_df, "$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$")
            within_range = any((min(exe_dz[0]) * 0.999 <= value <= max(exe_dz[0]) * 1.001) for value in ema_df)
            # any(min(exe_dz[0]) <= value <= max(exe_dz[0]) for value in ema_df)
            if within_range:
                entry = exe_dz[0][1]
                stop_loss = exe_dz[0][0]
                if not(2.5 <= ut.calculate_percentage_distance(entry, stop_loss) <= 15):
                    stop_loss = ut.calculate_atr(self.get_execute_df(), entry, 14)
                found_ema_zone = True
        return found_ema_zone, entry, stop_loss
            

 
        # print(exe_dz)

    def get_consecutive_zones(self, conse_dz, cmp):
        ut = utility()
        found_conz_zone = False
        conz_entry = None
        stop_loss = None
        if len(conse_dz) >= 2:
            # conse_dz = sorted(conse_dz[0], reverse=True)
            range1 = min(conse_dz[0])
            range2 = max(conse_dz[1])
            conz_entry = range1 # round((range1+range2)/2, 2)
            stop_loss = min(conse_dz[1])
            zone_diff = abs(range2 - range1)
            within_per = zone_diff <= (cmp*0.01)
            # print(within_per, ut.calculate_percentage_distance(cmp, conz_entry), self.dynamic_percentage_distance(self.cmp_price))
            print(zone_diff, cmp*0.01)
            print("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$", within_per, ut.calculate_percentage_distance(cmp, conz_entry), self.dynamic_percentage_distance(self.cmp_price)+3)
            if within_per and (ut.calculate_percentage_distance(cmp, conz_entry) <= self.dynamic_percentage_distance(self.cmp_price)+3):
                found_conz_zone = True
        return found_conz_zone, conz_entry, stop_loss
    
    def get_overlapped_decition(self, cmp, dz_distance_list, dz_ana_distance_percent, dz_eva_distance_percent, overlap_dz_ana, overlap_dz_eva):
        found_overlapping_point = False
        ut = utility()
        entry = None
        Stop_loss = None
        dz_distance_list = list(filter(lambda x: x is not None, dz_distance_list))
        if len(dz_distance_list) > 0:
            print(dz_distance_list)
            if min(dz_distance_list) == dz_ana_distance_percent:
                entry = overlap_dz_ana[0][1]
                Stop_loss = ut.calculate_atr(self.get_execute_df(), entry, period=14)
                # found_overlapping_point = True
            elif min(dz_distance_list) == dz_eva_distance_percent:
                entry = overlap_dz_eva[0][1]
                Stop_loss = ut.calculate_atr(self.get_execute_df(), entry, period=14)
                # Stop_loss = min(overlap_dz_eva[0])
                # found_overlapping_point = True
        if entry is not None:
            if ut.calculate_percentage_distance(cmp, entry) <= self.dynamic_percentage_distance(cmp):
                found_overlapping_point = True

        return found_overlapping_point, entry, Stop_loss
    
    def dynamic_percentage_distance(self, cmp, base_percentage=7.5, reference_cmp=500, k=0.1):
        dynamic_percentage = base_percentage / (1 + k * cmp / reference_cmp)
        return dynamic_percentage
    
    def calculate_buy_target_point(self, exe_sz, e_exe_sz, ana_sz, eva_sz, entry, stop):
        # print(entry)
        target = None
        if len(exe_sz) > 0:
            # exe_sz = sorted(exe_sz, reverse=True)
            ex_sz = e_exe_sz[0]
            target = max(ex_sz[0]['price'], ex_sz[1]['price'])
            # print(exe_sz, "55555555555555555555TTTTTTTTTTTTTTTTTTTTTTTTTTT")
        elif len(ana_sz) > 0 and target is None:
            if ana_sz[0][1] > entry: target = ana_sz[0][1] 
        elif len(eva_sz) > 0 and target is None:
            if eva_sz[0][1] > entry: target = eva_sz[0][1]
        if target is None:
            target = entry + ((entry - stop)*2)
        return target


    def calculate(self):
        ut = utility()
        out_data = {}
        eva_dz, eva_sz, cmp, cmp_ts = self.get_ea_zones_info(0, False)
        ana_dz, ana_sz, cmp, cmp_ts = self.get_ea_zones_info(1, False)
        exe_dz, exe_sz, e_exe_sz = self.get_qualified_exe_zones_info(len(self.time_list) - 1)
        eva_dz = sorted(eva_dz, key=lambda x: min(x), reverse=True)
        eva_sz = sorted(eva_sz, key=lambda x: max(x))
        ana_dz = sorted(ana_dz, reverse=True)
        ana_sz = sorted(ana_sz)
        exe_dz = sorted(exe_dz, reverse=True)
        exe_sz = sorted(exe_sz)
        # print(eva_dz, "#################################")
        # print(eva_sz, "##############################")
        # exe_dz = self.remove_duplicate_zones(exe_dz) 
        # exe_sz = self.remove_duplicate_zones(exe_sz)

        conse_dz = exe_dz #self.find_closest_intervals(exe_dz, cmp, 1)
        conse_sz = self.find_closest_intervals(exe_sz, cmp, 1)
        # exe_dz = self.sort_ranges_by_percentage_proximity(list(set(exe_dz)), cmp)
        overlap_dz_eva = sorted(self.find_overlaps_between_zones(eva_dz, exe_dz), reverse=True)
        overlap_dz_ana = sorted(self.find_overlaps_between_zones(ana_dz, exe_dz), reverse=True)
        overlap_sz_eva = sorted(self.find_overlaps_between_zones(eva_sz, exe_sz))
        overlap_sz_ana = sorted(self.find_overlaps_between_zones(ana_sz, exe_sz))

        # dz_conz_distance_percent  = self.percentage_proximity_to_range(conse_dz[0][1], cmp) if len(conse_dz) > 0 else None
        dz_ana_distance_percent = self.percentage_proximity_to_range(overlap_dz_ana[0], cmp) if len(overlap_dz_ana) > 0 else None
        dz_eva_distance_percent = self.percentage_proximity_to_range(overlap_dz_eva[0], cmp) if len(overlap_dz_eva) > 0 else None

        # sz_conz_distance_percent  = self.percentage_proximity_to_range(conse_sz[0][1], cmp) if len(conse_sz) > 0 else None
        sz_ana_distance_percent = self.percentage_proximity_to_range(overlap_sz_ana[0], cmp) if len(overlap_sz_ana) > 0 else None
        sz_eva_distance_percent = self.percentage_proximity_to_range(overlap_sz_eva[0], cmp) if len(overlap_sz_eva) > 0 else None
        # print("analyse_distance", ana_distance_percent)
        # print("evaluiate_distance", eva_distance_percent)
        # print("conz_distance", conz_distance_percent)
        # dz_conz_distance_percent sz_conz_distance_percent
        dz_distance_list = [dz_eva_distance_percent, dz_ana_distance_percent]
        sz_distance_list = [sz_eva_distance_percent, sz_ana_distance_percent]

        if len(eva_dz) == 0 and len(eva_sz) == 0 and len(ana_dz) == 0 and len(ana_sz) == 0:
            return None
        entry = None
        stop_loss = None
        out_data['PRICE_CMP'] = cmp
        out_data['STOCK_NAME'] = self.stock_tick
        out_data['TIME_FR'] = self.time_frame
        print(exe_dz, exe_sz, len(eva_sz), len(ana_sz), "99999999999999999999999999999999999999999999999999999999999999")
        if len(eva_sz) == 0 and len(ana_sz) == 0:
            print('block 1............................................')
            if len(exe_dz) > 0 and len(exe_sz) == 0:
                print('block 11............................')
                # if not(found_overlapping_dz):
                found_conse_dz, entry, stop_loss = self.get_consecutive_zones(conse_dz, cmp)
                print(found_conse_dz, "44444444444444444444444444444444444444444444444444444444444444444444")
                if not(found_conse_dz):
                    found_overlapping_dz, entry, stop_loss = self.get_overlapping_zones(exe_dz, cmp)
                    if not(found_overlapping_dz):
                        found_ema_zone, entry, stop_loss = self.calculate_ema_zone(exe_dz)
                        if not(found_ema_zone):
                            found_overlapping_point, entry, stop_loss = self.get_overlapped_decition(cmp, dz_distance_list, dz_ana_distance_percent, dz_eva_distance_percent, overlap_dz_ana, overlap_dz_eva)
                            if not(found_overlapping_point):
                                entry = max(exe_dz[0]) #[1]
                                stop_loss = min(exe_dz[0]) # ut.calculate_atr(self.get_execute_df(), entry, 14)
                                
                out_data['BUY'], out_data['BUY_RRR'] = ut.create_2_no_sell_zone_buy_alert(entry, stop_loss)
                # out_data['BUY_RRR'] = self.calculate_risk_to_reward(entry, stop_loss, out_data['BUY']['target_price'])
                out_data['BUY_TIMESTAMPS'] = {
                                "entry_price_timestamp" : cmp_ts,
                                "target_price_timestamp" : cmp_ts,
                                "extend_timestamp" : cmp_ts + self.add_timestamp()
                            }

            elif len(exe_sz) > 0 and len(exe_dz) > 0:
                print('block 12............................')
                exe_trade_opt, exe_price_pos = ut.check_and_return_price_pos(exe_sz[0][1], exe_dz[0][0], cmp)
                if 'BUY' in exe_trade_opt:
                    found_conse_dz, entry, stop_loss = self.get_consecutive_zones(conse_dz, cmp)
                    if not(found_conse_dz):
                        found_overlapping_dz, entry, stop_loss = self.get_overlapping_zones(exe_dz, cmp)
                        if not(found_overlapping_dz):
                            found_ema_zone, entry, stop_loss = self.calculate_ema_zone(exe_dz)
                            if not(found_ema_zone):
                                found_overlapping_point, entry, stop_loss = self.get_overlapped_decition(cmp, dz_distance_list, dz_ana_distance_percent, dz_eva_distance_percent, overlap_dz_ana, overlap_dz_eva)
                                # print(found_conse_dz, "565656565656565656565656565656565656565656565656565")                            
                                if not(found_overlapping_point):
                                    entry = max(exe_dz[0]) #[1]
                                    stop_loss = min(exe_dz[0]) # ut.calculate_atr(self.get_execute_df(), entry, 14)
                    target = self.calculate_buy_target_point(exe_sz, e_exe_sz, ana_sz, eva_sz, entry, stop_loss)
                    out_data['BUY'], out_data['BUY_RRR'] = ut.create_buy_alert(stop_loss, entry, target)
                    # out_data['BUY_RRR'] = self.calculate_risk_to_reward(entry, stop_loss, target)
                    out_data['BUY_TIMESTAMPS'] = {
                                    "entry_price_timestamp" : cmp_ts,
                                    "target_price_timestamp" : cmp_ts,
                                    "extend_timestamp" : cmp_ts + self.add_timestamp()
                                }

        elif len(eva_sz) == 0 and len(ana_sz) > 0:
            print('block 2...................................................................')
            if len(exe_dz) > 0 and len(exe_sz) == 0:
                print('block 21.....................................')
                print(ana_sz[0][1], exe_dz[0][0], cmp)
                exe_trade_opt, exe_price_pos = ut.check_and_return_price_pos(ana_sz[0][1], exe_dz[0][0], cmp)
                if 'BUY' in exe_trade_opt:
                    found_conse_dz, entry, stop_loss = self.get_consecutive_zones(conse_dz, cmp)
                    if not(found_conse_dz):
                        found_overlapping_dz, entry, stop_loss = self.get_overlapping_zones(exe_dz, cmp)
                        if not(found_overlapping_dz):
                            found_ema_zone, entry, stop_loss = self.calculate_ema_zone(exe_dz)
                            if not(found_ema_zone):                            
                                found_overlapping_point, entry, stop_loss = self.get_overlapped_decition(cmp, dz_distance_list, dz_ana_distance_percent, dz_eva_distance_percent, overlap_dz_ana, overlap_dz_eva)
                                if not(found_overlapping_point):
                                    entry = max(exe_dz[0]) # [1]
                                    stop_loss = min(exe_dz[0]) # ut.calculate_atr(self.get_execute_df(), entry, 14)
                    target = self.calculate_buy_target_point(exe_sz, e_exe_sz, ana_sz, eva_sz, entry, stop_loss)
                    out_data['BUY'], out_data['BUY_RRR'] = ut.create_buy_alert(stop_loss, entry, target)
                    # out_data['BUY_RRR'] = self.calculate_risk_to_reward(entry, stop_loss, target)
                    out_data['BUY_TIMESTAMPS'] = {
                                    "entry_price_timestamp" : cmp_ts,
                                    "target_price_timestamp" : cmp_ts,
                                    "extend_timestamp" : cmp_ts + self.add_timestamp()
                                }

            elif len(exe_sz) > 0 and len(exe_dz) > 0:
                print('block 22............................')
                if len(ana_dz) > 0:
                    exe_trade_opt, ana_price_pos = ut.check_and_return_price_pos(ana_sz[0][1], ana_dz[0][0], cmp)
                else:
                    ana_price_pos = None
                exe_trade_opt, exe_price_pos = ut.check_and_return_price_pos(exe_sz[0][1], exe_dz[0][0], cmp)
                # if ana_price_pos is not None:
                #     if ana_price_pos >= 66.6 and exe_price_pos <= 33.3:
                #         out_data['reason'] = f"Analyse at {ana_price_pos}% and execute at {exe_price_pos}%"
                #         return out_data
                
                if 'BUY' in exe_trade_opt:
                    found_conse_dz, entry, stop_loss = self.get_consecutive_zones(conse_dz, cmp)
                    if not(found_conse_dz):
                        found_overlapping_dz, entry, stop_loss = self.get_overlapping_zones(exe_dz, cmp)
                        if not(found_overlapping_dz):
                            found_ema_zone, entry, stop_loss = self.calculate_ema_zone(exe_dz)
                            if not(found_ema_zone):
                                found_overlapping_point, entry, stop_loss = self.get_overlapped_decition(cmp, dz_distance_list, dz_ana_distance_percent, dz_eva_distance_percent, overlap_dz_ana, overlap_dz_eva)
                                if not(found_overlapping_point):
                                    entry = max(exe_dz[0]) # [1]
                                    stop_loss = min(exe_dz[0]) # ut.calculate_atr(self.get_execute_df(), entry, 14)
                    target = self.calculate_buy_target_point(exe_sz, e_exe_sz, ana_sz, eva_sz, entry, stop_loss)
                    out_data['BUY'], out_data['BUY_RRR'] = ut.create_buy_alert(stop_loss, entry, target)
                    # out_data['BUY_RRR'] = self.calculate_risk_to_reward(entry, stop_loss, target)
                    out_data['BUY_TIMESTAMPS'] = {
                                    "entry_price_timestamp" : cmp_ts,
                                    "target_price_timestamp" : cmp_ts,
                                    "extend_timestamp" : cmp_ts + self.add_timestamp()
                                }

        elif len(eva_sz) > 0 and len(ana_sz) == 0:
            print('block 3 ..........................................................')
            if len(exe_dz) > 0 and len(exe_sz) == 0:
                print('block 31.....................................')
                if len(eva_dz) > 0 and len(eva_sz) > 0:
                    exe_trade_opt, eva_price_pos = ut.check_and_return_price_pos(max(eva_sz[0]), min(eva_dz[0]), cmp)
                else:
                    eva_price_pos = None
                exe_trade_opt, exe_price_pos = ut.check_and_return_price_pos(max(eva_sz[0]), exe_dz[0][0], cmp)
                if eva_price_pos is not None:
                    if eva_price_pos >= 66.6 and exe_price_pos <= 33.3:
                        out_data['reason'] = f"Evaluate at {eva_price_pos}% and execute at {exe_price_pos}%"
                        return out_data
                if 'BUY' in exe_trade_opt:
                    found_conse_dz, entry, stop_loss = self.get_consecutive_zones(conse_dz, cmp)
                    if not(found_conse_dz):
                        found_overlapping_dz, entry, stop_loss = self.get_overlapping_zones(exe_dz, cmp)
                        if not(found_overlapping_dz):
                            found_ema_zone, entry, stop_loss = self.calculate_ema_zone(exe_dz)
                            if not(found_ema_zone):
                                found_overlapping_point, entry, stop_loss = self.get_overlapped_decition(cmp, dz_distance_list, dz_ana_distance_percent, dz_eva_distance_percent, overlap_dz_ana, overlap_dz_eva)
                                if not(found_overlapping_point):
                                    entry = max(exe_dz[0]) #[1]
                                    stop_loss = min(exe_dz[0]) # ut.calculate_atr(self.get_execute_df(), entry, 14)
                    target = self.calculate_buy_target_point(exe_sz, e_exe_sz, ana_sz, eva_sz, entry, stop_loss)
                    out_data['BUY'], out_data['BUY_RRR'] = ut.create_buy_alert(stop_loss, entry, target)
                    # out_data['BUY_RRR'] = self.calculate_risk_to_reward(entry, stop_loss, target)
                    out_data['BUY_TIMESTAMPS'] = {
                                    "entry_price_timestamp" : cmp_ts,
                                    "target_price_timestamp" : cmp_ts,
                                    "extend_timestamp" : cmp_ts + self.add_timestamp()
                                }
                
            elif len(exe_sz) > 0 and len(exe_dz) > 0:
                print('block 32............................')
                if len(eva_dz) > 0:
                    exe_trade_opt, eva_price_pos = ut.check_and_return_price_pos(max(eva_sz[0]), min(eva_dz[0]), cmp)
                else:
                    eva_price_pos = None
                exe_trade_opt, exe_price_pos = ut.check_and_return_price_pos(exe_sz[0][1], exe_dz[0][0], cmp)
                if eva_price_pos is not None:
                    if eva_price_pos >= 66.6 and exe_price_pos <= 33.3:
                        out_data['reason'] = f"Evaluate at {eva_price_pos}% and execute at {exe_price_pos}%"
                        return out_data
    
                if 'BUY' in exe_trade_opt:
                    found_conse_dz, entry, stop_loss = self.get_consecutive_zones(conse_dz, cmp)
                    if not(found_conse_dz):
                        found_overlapping_dz, entry, stop_loss = self.get_overlapping_zones(exe_dz, cmp)
                        if not(found_overlapping_dz):
                            found_ema_zone, entry, stop_loss = self.calculate_ema_zone(exe_dz)
                            if not(found_ema_zone):
                                found_overlapping_point, entry, stop_loss = self.get_overlapped_decition(cmp, dz_distance_list, dz_ana_distance_percent, dz_eva_distance_percent, overlap_dz_ana, overlap_dz_eva)
                                if not(found_overlapping_point):
                                    entry = max(exe_dz[0]) #[1]
                                    stop_loss = min(exe_dz[0]) #ut.calculate_atr(self.get_execute_df(), entry, 14)
                                    print(stop_loss)
                    target = self.calculate_buy_target_point(exe_sz, e_exe_sz, ana_sz, eva_sz, entry, stop_loss)
                    out_data['BUY'], out_data['BUY_RRR'] = ut.create_buy_alert(stop_loss, entry, target)
                    # out_data['BUY_RRR'] = self.calculate_risk_to_reward(entry, stop_loss, target)
                    out_data['BUY_TIMESTAMPS'] = {
                                    "entry_price_timestamp" : cmp_ts,
                                    "target_price_timestamp" : cmp_ts,
                                    "extend_timestamp" : cmp_ts + self.add_timestamp()
                                }

        elif len(eva_sz) > 0 and len(ana_sz) > 0:
            print('block 4.........................................................')
            if len(exe_dz) > 0 and len(exe_sz) == 0:
                print('block 41.......................................')
                if len(eva_dz) > 0 and len(eva_sz) > 0:
                    print("This is the block")
                    _, eva_price_pos = ut.check_and_return_price_pos(max(eva_sz[0]), min(eva_dz[0]), cmp)
                else:
                    eva_price_pos = None
                if len(ana_dz) > 0 and len(ana_sz) > 0:
                    _, ana_price_pos = ut.check_and_return_price_pos(ana_sz[0][1], ana_dz[0][0], cmp)
                else:
                    ana_price_pos = None
                if len(ana_sz) > 0 and len(exe_dz) > 0:     
                    exe_trade_opt, exe_price_pos = ut.check_and_return_price_pos(ana_sz[0][1], exe_dz[0][0], cmp)
                if eva_price_pos is not None:
                    if eva_price_pos >= 66.6 and exe_price_pos <= 33.3:
                        out_data['reason'] = f"Evaluate at {eva_price_pos}% and execute at {exe_price_pos}%"
                        return out_data
                # if ana_price_pos is not None:
                #     if ana_price_pos >= 66.6 and exe_price_pos <= 33.3:
                #         out_data['reason'] = f"Analyse at {ana_price_pos}% and execute at {exe_price_pos}%"
                #         return out_data
                if 'BUY' in exe_trade_opt:
                    found_conse_dz, entry, stop_loss = self.get_consecutive_zones(conse_dz, cmp)
                    print(found_conse_dz, "found_conse_dz")
                    if not(found_conse_dz):
                        found_overlapping_dz, entry, stop_loss = self.get_overlapping_zones(exe_dz, cmp)
                        if not(found_overlapping_dz):
                            found_ema_zone, entry, stop_loss = self.calculate_ema_zone(exe_dz)
                            if not(found_ema_zone):
                                found_overlapping_point, entry, stop_loss = self.get_overlapped_decition(cmp, dz_distance_list, dz_ana_distance_percent, dz_eva_distance_percent, overlap_dz_ana, overlap_dz_eva)
                                if not(found_overlapping_point):
                                    entry = max(exe_dz[0]) #[1]
                                    stop_loss = min(exe_dz[0])  #ut.calculate_atr(self.get_execute_df(), entry, 14)
                    target = self.calculate_buy_target_point(exe_sz, e_exe_sz, ana_sz, eva_sz, entry, stop_loss)
                    out_data['BUY'], out_data['BUY_RRR'] = ut.create_buy_alert(stop_loss, entry, target)
                    # out_data['BUY_RRR'] = self.calculate_risk_to_reward(entry, stop_loss, target)
                    out_data['BUY_TIMESTAMPS'] = {
                                    "entry_price_timestamp" : cmp_ts,
                                    "target_price_timestamp" : cmp_ts,
                                    "extend_timestamp" : cmp_ts + self.add_timestamp()
                                }
                    
            elif len(exe_sz) > 0 and len(exe_dz) > 0:
                print('block 42.......................................')
                if len(eva_dz) > 0:
                    _, eva_price_pos = ut.check_and_return_price_pos(max(eva_sz[0]), min(eva_dz[0]), cmp)
                else:
                    eva_price_pos = None
                if len(ana_dz) > 0:
                    _, ana_price_pos = ut.check_and_return_price_pos(ana_sz[0][1], ana_dz[0][0], cmp)
                else:
                    ana_price_pos = None
                
                exe_trade_opt, exe_price_pos = ut.check_and_return_price_pos(exe_sz[0][1], exe_dz[0][0], cmp)
                if eva_price_pos is not None:
                    if eva_price_pos >= 66.6 and exe_price_pos <= 33.3:
                        out_data['reason'] = f"Evaluate at {eva_price_pos}% and execute at {exe_price_pos}%"
                        return out_data
                # if ana_price_pos is not None:
                #     if ana_price_pos >= 66.6 and exe_price_pos <= 33.3:
                #         out_data['reason'] = f"Analyse at {ana_price_pos}% and execute at {exe_price_pos}%"
                #         return out_data
                if 'BUY' in exe_trade_opt:
                    found_conse_dz, entry, stop_loss = self.get_consecutive_zones(conse_dz, cmp)
                    if not(found_conse_dz):
                        found_overlapping_dz, entry, stop_loss = self.get_overlapping_zones(exe_dz, cmp)
                        if not(found_overlapping_dz):
                            found_ema_zone, entry, stop_loss = self.calculate_ema_zone(exe_dz)
                            if not(found_ema_zone):
                                found_overlapping_point, entry, stop_loss = self.get_overlapped_decition(cmp, dz_distance_list, dz_ana_distance_percent, dz_eva_distance_percent, overlap_dz_ana, overlap_dz_eva)
                                if not(found_overlapping_point):
                                    entry = max(exe_dz[0]) #[1]
                                    stop_loss = min(exe_dz[0]) # ut.calculate_atr(self.get_execute_df(), entry, 14)
                    target = self.calculate_buy_target_point(exe_sz, e_exe_sz, ana_sz, eva_sz, entry, stop_loss)
                    print(target, stop_loss, "TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT")
                    out_data['BUY'], out_data['BUY_RRR'] = ut.create_buy_alert(stop_loss, entry, target)
                    # out_data['BUY_RRR'] = self.calculate_risk_to_reward(entry, stop_loss, target)
                    out_data['BUY_TIMESTAMPS'] = {
                                    "entry_price_timestamp" : cmp_ts,
                                    "target_price_timestamp" : cmp_ts,
                                    "extend_timestamp" : cmp_ts + self.add_timestamp()
                                }
                
        return out_data
        


        

        




