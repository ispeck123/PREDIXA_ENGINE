from sqlalchemy import create_engine, Column, Integer, String, DateTime, Boolean
from sqlalchemy.ext.declarative import declarative_base
# from classes.utilities import Config
from urllib.parse import quote as urlquote
import pandas as pd
import json
from shared.config.settings import Config as cfg
from sqlalchemy import text
import time
# from threading import Thread
from sqlalchemy.orm import sessionmaker, Session
import logging, os, sys

logger = logging.getLogger()


# insert_db_bool = True
# Init the Configuration
# config = Config()
# database = config.getDatabaseConfig()
# print(database.host)

# Create a sqlite engine instance
# engine = create_engine("mysql+pymysql://" + cfg.DB_USER + ":" +
#                        urlquote(cfg.DB_PASSWORD) + "@" + cfg.DB_HOST + ":" + str(cfg.DB_PORT) + "/" + cfg.DB_SCHEMA)
engine = create_engine(
    "mysql+pymysql://" + cfg.DB_USER + ":" + urlquote(cfg.DB_PASSWORD) +
    "@" + cfg.DB_HOST + ":" + str(cfg.DB_PORT) + "/" + cfg.DB_SCHEMA,
    pool_recycle=1800,      # Recycle connections every 30 mins
    pool_pre_ping=True,     # Check connection before using
    pool_size=10,           # Optional: control number of connections
    max_overflow=20         # Optional: allow overflow if needed
)

# Create a DeclarativeMeta instance
Base = declarative_base()

# Create the database
Base.metadata.create_all(engine)


# Region : For Raw Query
def raw_connection():
    raw_connection = engine.connect()
    return raw_connection


def raw_query(my_query: str):
    try:
        rc = raw_connection()
        data_list = pd.read_sql(text(my_query), rc)
        results = json.loads(data_list.to_json(orient="table", index=False))["data"]
        rc.close()
    except Exception as ex:
        results = ex
        print(ex)
        # raise Exception(str(ex))
    return results

def get_session():
    SessionLocal = Session(bind=engine)
    # sessionmaker(bind=engine)
    return SessionLocal


def restart_server():
    logging.warning("Restarting server due to broken connection...")
    python = sys.executable
    os.execv(python, [python] + sys.argv)