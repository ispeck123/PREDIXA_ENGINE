import os
import pandas as pd
import numpy as np
from datetime import datetime
from shared.config.settings import Config as cfg
from apps.finprod_backend.modules.calculate_zone import Calculate_BUY_SELL_ZONES


class Trend_Analyzer:
    def __init__(self, stock_tick: str, time_frame: int, last_dt_time):
        self.stock_tick = stock_tick
        self.time_frame = time_frame
        self.time_fr = getattr(cfg, f'TIME_FRAMES_{time_frame}')
        self.last_dt = last_dt_time

    def check_zone_violation(self, data_frame, check_start_index, zone_price_range, is_demand_or_sell):
        found_leg_out = False
        chk_int = False
        for j in range(check_start_index + 1, len(data_frame) - 1):
            if bool(data_frame.iloc[j]['is_leg_out']) == True and not(found_leg_out):
                continue
            else:
                found_leg_out = True
            w_val = 'low' if is_demand_or_sell else 'high'
            per_intersect = self.ranges_intersect(zone_price_range, data_frame.iloc[j].get(w_val), is_demand_or_sell)
            if per_intersect:
                chk_int = True
                break
        return chk_int
    
    def find_higher_highs(self, series):
        return series[-1] if series[-1] == max(series) else np.nan

    def find_lower_lows(self, series):
        return series[-1] if series[-1] == min(series) else np.nan
    
    def ranges_intersect(self, range1, high_or_low, isDemand):
        start1, end1 = range1
        total_range = abs(range1[0] - range1[1])
        if isDemand:
            violate_range = min(start1, end1) #+ (total_range*0.25)
            if high_or_low >= violate_range:
                return False
            else:
                return True
        else:
            violate_range = max(start1, end1) #- (total_range*0.25)
            if high_or_low >= violate_range:
                return True
            else:
                return False

    def process_data(self, csv_file_path):
        pddf = pd.read_csv(csv_file_path)
        pddf['timestamp'] = pd.to_datetime(pddf['timestamp'], dayfirst = True)
        pddf = pddf[pddf.timestamp <= self.last_dt]
        pddf['timestamp'] = (pddf['timestamp'].astype(np.int64) // 10**9).astype(int)
        return pddf
    
    def calculate_frame_length(self, keys):
        frame_name_dict = {
            'monthly': 3, 
            'weekly': 5, 
            'daily': 7,
            '60m': 15, 
            '15m': 30
        }
        return frame_name_dict[keys]

    
    def find_higher_high_and_lower_low(self):
        out_res = {}
        high_list = []
        low_list = []
        for frames in self.time_fr:
            length = self.calculate_frame_length(frames)
            #file_path = f'/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/processed_data_files/{self.stock_tick}_{frames}.csv'
            file_path = os.path.join(os.getcwd(), 'apps', 'finprod_backend', 'processed_data_files', f'{self.stock_tick}_{frames}.csv')
            df = self.process_data(file_path)
            df['highest_high'] = df['high'].rolling(window=length).apply(self.find_higher_highs, raw=True)
            df['lowest_low'] = df['low'].rolling(window=length).apply(self.find_lower_lows, raw=True)
            df = df.drop_duplicates(subset=['highest_high', 'lowest_low'])
            for i in range(len(df)):
                # print(np.isnan(df.iloc[i].get('highest_high')))
                if not(np.isnan(df.iloc[i].get('highest_high'))) :
                    time_point = int(df.iloc[i].get('timestamp'))
                    # next_t = df.iloc[i].get('timestamp')
                    high_list.append(time_point)
                    # point = {"time": int(prev_t), "price": df.iloc[i].get('highest_high')}
                    # point2 = {"time": int(cmp_tstamp), "price": s_high_d(at}
                if not(np.isnan(df.iloc[i].get('lowest_low'))) :
                    time_point = int(df.iloc[i].get('timestamp'))
                    low_list.append(time_point)
            out_res[frames] = {
                'higher_highs' : high_list,
                'lower_lows' : low_list
            }
        return out_res



        
    
    def get_buy_zones(self, csv_path):
        cbsz = Calculate_BUY_SELL_ZONES(csv_path, self.stock_tick, self.last_dt, False)
        buy_zone_list = cbsz.calculate_all_buy_zones()
        buy_zone_list = sorted(buy_zone_list, key=lambda z: z[0]["time"], reverse=True)
        return buy_zone_list[0], buy_zone_list[1]

    def calculate_buyzone_violation(self, df : pd.DataFrame, zone1, zone2):
        print(zone1[1]['time'])
        z1_row = df.loc[df['timestamp'] == zone1[1]["time"]]
        z2_row = df.loc[df['timestamp'] == zone2[1]["time"]]
        zone1_vl = self.check_zone_violation(df, int(z1_row.get('id')), (zone1[0]["price"], zone1[1]["price"]), True)
        zone2_vl = self.check_zone_violation(df, int(z2_row.get('id')), ((zone2[0]["price"], zone2[1]["price"])), True)
        return zone1_vl and zone2_vl
        
    def get_eva_ana_frames(self):
        if self.time_frame == 2:
            #eva_file = f'/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/processed_data_files/{self.stock_tick}_{self.time_fr[0]}.csv'
            eva_file = os.path.join(os.getcwd(), 'apps', 'finprod_backend', 'processed_data_files', f'{self.stock_tick}_{self.time_fr[0]}.csv')
            #ana_file = f'/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/processed_data_files/{self.stock_tick}_{self.time_fr[1]}.csv'
            ana_file = os.path.join(os.getcwd(), 'apps', 'finprod_backend', 'processed_data_files', f'{self.stock_tick}_{self.time_fr[1]}.csv')
            first_eva, second_eva = self.get_buy_zones(eva_file)
            eva_df = self.process_data(eva_file)
            first_ana, second_ana = self.get_buy_zones(ana_file)
            ana_df = self.process_data(ana_file)
            eva_trnd = self.calculate_buyzone_violation(eva_df, first_eva, second_eva)
            ana_trend = self.calculate_buyzone_violation(ana_df, first_ana, second_ana)
            print("eva_trnd, ana_trend", eva_trnd and ana_trend)
            return eva_trnd and ana_trend
        elif self.time_frame == 1:
            # eva_file = f'./processed_data_files/{self.stock_tick}_{self.time_fr[0]}.csv'
            #ana_file = f'/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/processed_data_files/{self.stock_tick}_{self.time_fr[1]}.csv'
            ana_file = os.path.join(os.getcwd(), 'apps', 'finprod_backend', 'processed_data_files', f'{self.stock_tick}_{self.time_fr[1]}.csv')
            # first_eva, second_eva = self.get_buy_zones(eva_file)
            # eva_df = self.process_data(eva_file)
            first_ana, second_ana = self.get_buy_zones(ana_file)
            ana_df = self.process_data(ana_file)
            # eva_trnd = self.calculate_buyzone_violation(eva_df, first_eva, second_eva)
            ana_trend = self.calculate_buyzone_violation(ana_df, first_ana, second_ana)
            # print("eva_trnd, ana_trend", eva_trnd and ana_trend)
            return ana_trend

    
    def get_nifty_position(self):
        #exe_nifty_file = f'/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/processed_data_files/{self.stock_tick}_{self.time_fr[-1]}.csv'
        exe_nifty_file = os.path.join(os.getcwd(), 'apps', 'finprod_backend', 'processed_data_files', f'{self.stock_tick}_{self.time_fr[-1]}.csv')
        first_nf, second_nf = self.get_buy_zones(exe_nifty_file)
        nifty_df = self.process_data(exe_nifty_file)
        nifty_trend = self.calculate_buyzone_violation(nifty_df, first_nf, second_nf)
        print("nifty_trend", nifty_trend)
        return nifty_trend

# if __name__ == '__main__':
#     at = Trend_Analyzer('hdfcbank', 1, datetime(year=2025, month=1, day=11))
        