import pandas as pd
import numpy as np
# import glob
# import os
# from sklearn.preprocessing import MinMaxScaler
# from sklearn.preprocessing import LabelEncoder
import joblib
import torch
from apps.finprod_backend.modules.lstm_model import StockModel
from apps.finprod_backend.modules.rnn_model import RnnStockModel
from apps.finprod_backend.modules.gru_model import GruStockModel
from collections import Counter
import torch.nn as nn
import pickle
from statsmodels.tsa.arima.model import ARIMA
from apps.finprod_backend.modules.calculate_zone import Calculate_BUY_SELL_ZONES
import warnings
# import talib

warnings.filterwarnings("ignore")


class Stock_Model_Loader_Daily:
    
    def __init__(self, test_file, test_info : dict, last_d_time):
        
        self.test_file = test_file
        self.test_info = test_info
        self.last_d_time = last_d_time
        self.test_data = pd.read_csv(test_file)
        self.test_data['timestamp'] = pd.to_datetime(self.test_data['timestamp'], dayfirst = True)
        self.test_data = self.test_data[self.test_data.timestamp <= self.last_d_time]
        self.test_data = self.test_data[['open', 'high', 'low','close','qty']].iloc[-90:,:]
        self.calculate_technical_indicators(self.test_data)
        self.test_data['ma5'].fillna(method = 'bfill' , inplace = True)
        self.test_data['ma10'].fillna(method = 'bfill' , inplace = True)
        self.test_data['volatility'].fillna(method = 'bfill' , inplace = True)
        self.test_data['rsi'].fillna(method = 'bfill' , inplace = True)
        # self.test_info = pd.read_csv(test_info)
        self.order_id = test_file.split('\\')[-1].split('.')[0]
        self.id_to_class = {0:'failed',1:'success'}
        
        
        close_scaler = joblib.load('./apps/finprod_backend/norm_models/close_price_norm.pkl')
        stat_scaler = joblib.load('./apps/finprod_backend/norm_models/statistical_norm.pkl')
        encode = joblib.load('./apps/finprod_backend/norm_models/order_type.pkl')
        
        # other_info = self.test_info[self.test_info['order_id']==int(self.order_id)]
        # asi = other_info[['order_type','entry_price','target_price','stoploss_price']]
        self.test_data['order_type'] = self.test_info['order_type'] # asi['order_type'].values[0]
        self.test_data['entry_price'] = self.test_info['entry_price'] #.values[0]
        self.test_data['target_price'] = self.test_info['target_price'] #.values[0]
        self.test_data['stoploss_price'] = self.test_info['stoploss_price'] #.values[0]
        # print(encode.transform(ds['order_type']))
        self.test_data['close_smoothed'] = close_scaler.transform(np.array(self.test_data['close_smoothed']).reshape(-1,1))
        self.test_data['entry_price'] = close_scaler.transform(np.array(self.test_data['entry_price']).reshape(-1,1))
        self.test_data['target_price'] = close_scaler.transform(np.array(self.test_data['target_price']).reshape(-1,1))
        self.test_data['stoploss_price'] = close_scaler.transform(np.array(self.test_data['stoploss_price']).reshape(-1,1))
        self.test_data[['open', 'high', 'low', 'close','qty', 'ma5', 'ma10', 'volatility', 'rsi']] = stat_scaler.transform(self.test_data[['open', 'high', 'low', 'close', 'qty', 'ma5', 'ma10', 'volatility', 'rsi']])
        self.test_data['order_type'] = encode.transform(self.test_data['order_type'])
        self.lstm_model = StockModel(10,1,50).to('cuda:0')
        self.rnn_model = RnnStockModel(10,2,50).to('cuda:0')
        self.gru_model = GruStockModel(10,1,50).to('cuda:0')
        self.lstm_model.load_state_dict(torch.load('./apps/finprod_backend/weight/lstm_model_imbalance.pt'))
        self.rnn_model.load_state_dict(torch.load('./apps/finprod_backend/weight/rnn_model_imbalance.pt'))
        self.gru_model.load_state_dict(torch.load('./apps/finprod_backend/weight/gru_model_imbalance.pt'))
        
        
    def calculate_technical_indicators(self, df):
        df['close_smoothed'] = df['close'].ewm(span=10, adjust=False).mean()
        df['ma5'] = df['close'].rolling(window=5).mean()
        df['ma10'] = df['close'].rolling(window=10).mean()
        df['volatility'] = df['close'].rolling(window=10).std()
        delta = df['close'].diff(1)
        gain = delta.where(delta > 0, 0.0)
        loss = -delta.where(delta < 0, 0.0)
        avg_gain = gain.rolling(window=14).mean()
        avg_loss = loss.rolling(window=14).mean()
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        df['rsi'] = rsi
        
        return df 
    
    def run(self):
        self.lstm_model.eval()
        self.rnn_model.eval()
        self.gru_model.eval()
        ensemble_models = [self.lstm_model , self.rnn_model , self.gru_model]
        with torch.no_grad():
            test_load = torch.tensor(self.test_data.iloc[:,[4]+[5] +[6] + [7] + [8] +[9]+list(range(-4, 0))].values,dtype=torch.float).unsqueeze(0).to('cuda:0')
            res = Counter([1 if model(test_load).item()>0.5 else 0 for model in ensemble_models])
            avg_prob = np.mean([model(test_load).item() for model in ensemble_models])
            print(self.id_to_class[res.most_common(1)[0][0]], avg_prob)
            return self.id_to_class[res.most_common(1)[0][0]], avg_prob
            


class Stock_Model_Loader_Minute:
    
    def __init__(self, test_file, test_info : dict, last_d_time):
        
        self.test_file = test_file
        self.test_info = test_info
        self.last_d_time = last_d_time
        self.test_data = pd.read_csv(test_file)
        self.test_data['timestamp'] = pd.to_datetime(self.test_data['timestamp'], dayfirst = True)
        self.test_data = self.test_data[self.test_data.timestamp <= self.last_d_time]
        self.test_data = self.test_data[['open', 'high', 'low','close','qty']].iloc[-329:,:]
        self.calculate_technical_indicators(self.test_data)
        self.test_data['ma5'].fillna(method = 'bfill' , inplace = True)
        self.test_data['ma10'].fillna(method = 'bfill' , inplace = True)
        self.test_data['volatility'].fillna(method = 'bfill' , inplace = True)
        self.test_data['rsi'].fillna(method = 'bfill' , inplace = True)
        # self.test_info = pd.read_csv(test_info)
        self.order_id = test_file.split('\\')[-1].split('.')[0]
        self.id_to_class = {0:'failed',1:'success'}
        
        
        close_scaler = joblib.load('./apps/finprod_backend/norm_models/close_price_norm_minutes.pkl')
        stat_scaler = joblib.load('./apps/finprod_backend/norm_models/statistical_norm_minutes.pkl')
        encode = joblib.load('./apps/finprod_backend/norm_models/order_type_minutes.pkl')
        
        # other_info = self.test_info[self.test_info['order_id']==int(self.order_id)]
        # asi = other_info[['order_type','entry_price','target_price','stoploss_price']]
        self.test_data['order_type'] = self.test_info['order_type'] # asi['order_type'].values[0]
        self.test_data['entry_price'] = self.test_info['entry_price'] #.values[0]
        self.test_data['target_price'] = self.test_info['target_price'] #.values[0]
        self.test_data['stoploss_price'] = self.test_info['stoploss_price'] #.values[0]
        # print(encode.transform(ds['order_type']))
        self.test_data['close_smoothed'] = close_scaler.transform(np.array(self.test_data['close_smoothed']).reshape(-1,1))
        self.test_data['entry_price'] = close_scaler.transform(np.array(self.test_data['entry_price']).reshape(-1,1))
        self.test_data['target_price'] = close_scaler.transform(np.array(self.test_data['target_price']).reshape(-1,1))
        self.test_data['stoploss_price'] = close_scaler.transform(np.array(self.test_data['stoploss_price']).reshape(-1,1))
        self.test_data[['open', 'high', 'low', 'close','qty', 'ma5', 'ma10', 'volatility', 'rsi']] = stat_scaler.transform(self.test_data[['open', 'high', 'low', 'close', 'qty', 'ma5', 'ma10', 'volatility', 'rsi']])
        self.test_data['order_type'] = encode.transform(self.test_data['order_type'])
        self.lstm_model = StockModel(10,1,50).to('cuda:0')
        self.rnn_model = RnnStockModel(10,2,50).to('cuda:0')
        self.gru_model = GruStockModel(10,1,50).to('cuda:0')
        self.lstm_model.load_state_dict(torch.load('./apps/finprod_backend/weight/lstm_model_minutes.pt'))
        self.rnn_model.load_state_dict(torch.load('./apps/finprod_backend/weight/rnn_model_minutes.pt'))
        self.gru_model.load_state_dict(torch.load('./apps/finprod_backend/weight/gru_model_minutes.pt'))
        
        
    def calculate_technical_indicators(self, df):
        df['close_smoothed'] = df['close'].ewm(span=10, adjust=False).mean()
        df['ma5'] = df['close'].rolling(window=5).mean()
        df['ma10'] = df['close'].rolling(window=10).mean()
        df['volatility'] = df['close'].rolling(window=10).std()
        delta = df['close'].diff(1)
        gain = delta.where(delta > 0, 0.0)
        loss = -delta.where(delta < 0, 0.0)
        avg_gain = gain.rolling(window=14).mean()
        avg_loss = loss.rolling(window=14).mean()
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        df['rsi'] = rsi
        
        return df 
    
    def run(self):
        self.lstm_model.eval()
        self.rnn_model.eval()
        self.gru_model.eval()
        ensemble_models = [self.lstm_model , self.rnn_model , self.gru_model]
        with torch.no_grad():
            test_load = torch.tensor(self.test_data.iloc[:,[4]+[5] +[6] + [7] + [8] +[9]+list(range(-4, 0))].values,dtype=torch.float).unsqueeze(0).to('cuda:0')
            res = Counter([1 if model(test_load).item()>0.5 else 0 for model in ensemble_models])
            avg_prob = np.mean([model(test_load).item() for model in ensemble_models])
            print(self.id_to_class[res.most_common(1)[0][0]], avg_prob)
            return self.id_to_class[res.most_common(1)[0][0]], avg_prob
        

class LSTM_RF:
    def __init__(self, test_file, test_info : dict, last_d_time) -> None:
        self.test_file = test_file
        self.test_info = test_info
        self.last_d_time = last_d_time
        self.test_data = pd.read_csv(test_file)
        self.test_data['timestamp'] = pd.to_datetime(self.test_data['timestamp'], dayfirst = True)
        self.test_data = self.test_data[self.test_data.timestamp <= self.last_d_time]
        self.test_data = self.test_data[['open', 'high', 'low','close','qty']].iloc[-90:,:]
        self.calculate_technical_indicators(self.test_data)
        self.test_data['ma5'].fillna(method = 'bfill' , inplace = True)
        self.test_data['ma10'].fillna(method = 'bfill' , inplace = True)
        self.test_data['volatility'].fillna(method = 'bfill' , inplace = True)
        self.test_data['rsi'].fillna(method = 'bfill' , inplace = True)
        self.order_id = test_file.split('\\')[-1].split('.')[0]
        self.id_to_class = {0:'failed',1:'success'}
        self.classes = ['failed', 'success']
        ################
        close_scaler = joblib.load('./apps/finprod_backend/norm_models/close_price_norm.pkl')
        stat_scaler = joblib.load('./apps/finprod_backend/norm_models/statistical_norm.pkl')
        encode = joblib.load('./apps/finprod_backend/norm_models/order_type.pkl')
        self.test_data['order_type'] = self.test_info['order_type'] # asi['order_type'].values[0]
        self.test_data['entry_price'] = self.test_info['entry_price'] #.values[0]
        self.test_data['target_price'] = self.test_info['target_price'] #.values[0]
        self.test_data['stoploss_price'] = self.test_info['stoploss_price'] #.values[0]
        # print(encode.transform(ds['order_type']))
        self.test_data['close_smoothed'] = close_scaler.transform(np.array(self.test_data['close_smoothed']).reshape(-1,1))
        self.test_data['entry_price'] = close_scaler.transform(np.array(self.test_data['entry_price']).reshape(-1,1))
        self.test_data['target_price'] = close_scaler.transform(np.array(self.test_data['target_price']).reshape(-1,1))
        self.test_data['stoploss_price'] = close_scaler.transform(np.array(self.test_data['stoploss_price']).reshape(-1,1))
        self.test_data[['open', 'high', 'low', 'close','qty', 'ma5', 'ma10', 'volatility', 'rsi']] = stat_scaler.transform(self.test_data[['open', 'high', 'low', 'close', 'qty', 'ma5', 'ma10', 'volatility', 'rsi']])
        self.test_data['order_type'] = encode.transform(self.test_data['order_type'])
        self.lstm_model = StockModel(10,1,70).to('cuda:0')
        self.lstm_model.load_state_dict(torch.load('./weight/lstm_updated.pt'))
        
    def calculate_technical_indicators(self, df):
        df['close_smoothed'] = df['close'].ewm(span=10, adjust=False).mean()
        df['ma5'] = df['close'].rolling(window=5).mean()
        df['ma10'] = df['close'].rolling(window=10).mean()
        df['volatility'] = df['close'].rolling(window=10).std()
        delta = df['close'].diff(1)
        gain = delta.where(delta > 0, 0.0)
        loss = -delta.where(delta < 0, 0.0)
        avg_gain = gain.rolling(window=14).mean()
        avg_loss = loss.rolling(window=14).mean()
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        df['rsi'] = rsi
        return df
    

    def run(self):
        self.lstm_mod = nn.Sequential(*list(self.lstm_model.children())[:-2])
        self.lstm_mod.eval()
        with open('./norm_models/best_rf_model.pkl', 'rb') as f:
            best_rf_model = pickle.load(f)
        with torch.no_grad():
            test_load = torch.tensor(self.test_data.iloc[:,[4]+[5] +[6] + [7] + [8] +[9]+list(range(-4, 0))].values,dtype=torch.float).unsqueeze(0).to('cuda:0')
            features = self.lstm_mod(test_load)
                
            feats = features[0][:,-1,:].squeeze(0).cpu().numpy()
            y_predicted_RF = best_rf_model.predict(feats.reshape(1, -1))
            y_predicted_proba_RF = best_rf_model.predict_proba(feats.reshape(1, -1))
            print(self.classes[int(y_predicted_RF)])
            print(np.max(y_predicted_proba_RF,1)[0])
            return self.classes[int(y_predicted_RF)], np.max(y_predicted_proba_RF,1)[0] 



class ARIMA_AB:
    def __init__(self, test_file, test_info : dict, last_d_time) -> None:
        self.test_file = test_file
        self.test_info = test_info
        self.last_d_time = last_d_time
        self.test_data = pd.read_csv(test_file)
        #####################
        self.test_data['timestamp'] = pd.to_datetime(self.test_data['timestamp'], dayfirst = True)
        self.test_data = self.test_data[self.test_data.timestamp <= self.last_d_time]
        self.test_data = self.test_data[['open', 'high', 'low','close','qty']].iloc[-90:,:]
        self.calculate_technical_indicators(self.test_data)
        self.test_data['ma5'].fillna(method = 'bfill' , inplace = True)
        self.test_data['ma10'].fillna(method = 'bfill' , inplace = True)
        self.test_data['volatility'].fillna(method = 'bfill' , inplace = True)
        self.test_data['rsi'].fillna(method = 'bfill' , inplace = True)
        self.order_id = test_file.split('\\')[-1].split('.')[0]
        self.id_to_class = {0:'failed',1:'success'}
        self.classes = ['failed', 'success']
        ############################
        close_scaler = joblib.load('./apps/finprod_backend/norm_models/arima_ab_scaler.pkl')
        encode = joblib.load('./apps/finprod_backend/norm_models/arima_ab_order_type.pkl')
        ###########################
        self.test_data['order_type'] = self.test_info['order_type'] # asi['order_type'].values[0]
        self.test_data['entry_price'] = self.test_info['entry_price'] #.values[0]
        self.test_data['target_price'] = self.test_info['target_price'] #.values[0]
        self.test_data['stoploss_price'] = self.test_info['stoploss_price'] #.values[0]
        ################################
        df_asi = self.test_data[['order_type', 'entry_price', 'target_price', 'stoploss_price']].iloc[[0]]
        # print("**************************************************")
        df_asi = df_asi.reset_index(drop=True)
        dat = self.test_data.iloc[:,5:]
        ar_features = self.fit_arima_and_extract_features(dat.iloc[:,:5],4,2,0)
        ar_features = ar_features.reset_index(drop=True)
        # print(ar_features)
        # print(df_asi)
        self.test_data = self.test_data.reset_index(drop=True)
        features_ = pd.concat([ar_features, df_asi], axis=1)
        # print("avl_coulmns", features_.columns)
        features_['order_type'] = encode.transform(features_['order_type'])
        norm_features = pd.DataFrame(close_scaler.transform(features_) ,columns = features_.columns)
        self.optimal_features = norm_features[[
            'order_type', 'entry_price', 'target_price', 'stoploss_price'
            ]]
        print("norm_features", norm_features)

    def calculate_technical_indicators(self, df):
        df['close_smoothed'] = df['close'].ewm(span=10, adjust=False).mean()
        df['ma5'] = df['close'].rolling(window=5).mean()
        df['ma10'] = df['close'].rolling(window=10).mean()
        df['volatility'] = df['close'].rolling(window=10).std()
        delta = df['close'].diff(1)
        gain = delta.where(delta > 0, 0.0)
        loss = -delta.where(delta < 0, 0.0)
        avg_gain = gain.rolling(window=14).mean()
        avg_loss = loss.rolling(window=14).mean()
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        df['rsi'] = rsi
        return df
    
    def fit_arima_and_extract_features(self, de, p, d, q):
        # series = ds.iloc[:, -5:]
        # model = ARIMA(series, order=(p, d, q))
        # model_fit = model.fit(disp=0)
        feature_names = de.columns[-5:]
        features = dict()
        for feature in feature_names:
            # features = dict()
            series = de[feature]
            model = ARIMA(series, order=(p, d, q))
            model_fit = model.fit()
            # Extract features
            features[f'{feature}_residuals_mean'] = model_fit.resid.mean()
            features[f'{feature}_fitted_values_mean'] =  model_fit.fittedvalues.mean()
            features[f'{feature}_arima_param1'] = model_fit.params.get('ar.L1', 0)
            features[f'{feature}_arima_param2'] = model_fit.params.get('ma.L1', 0)
        # features_df = pd.DataFrame(list(features.values()),columns = list(features.keys()))
        features_df = pd.DataFrame([features])
        # print(features_df)
        return  features_df
    
    def run(self):
        with open('./apps/finprod_backend/norm_models/best_ab_optimal_model.pkl', 'rb') as f:
            best_ab_model = pickle.load(f)
            y_predicted_AB = best_ab_model.predict(self.optimal_features)
            ind = int(y_predicted_AB)
            top5_proba = np.mean(np.array(sorted([estimator.predict_proba(self.optimal_features)[:,ind][0] for estimator in best_ab_model.estimators_],reverse=True)[:5]))
            # y_predicted_proba_AB = best_ab_model.predict_proba(self.optimal_features)
            # print(self.classes[int(y_predicted_AB)])
            # print(np.max(y_predicted_proba_AB,1)[0]) np.max(y_predicted_proba_AB,1)[0]
            print("Status:", self.classes[int(y_predicted_AB)], top5_proba)
            return self.classes[int(y_predicted_AB)], top5_proba
        


class ARIMA_AB_ZONE:
    def __init__(self, test_file, test_info : dict, last_d_time, tick) -> None:
        self.test_file = test_file
        self.test_info = test_info
        self.last_d_time = last_d_time
        self.map_dict = {'DZ':0,'SZ':1}
        # self.test_data = pd.read_csv(test_file)
        cbsz = Calculate_BUY_SELL_ZONES(test_file, tick, last_d_time, True)
        df1 = cbsz.update_new_buy_zones_df()
        df2 = cbsz.update_new_sell_zones_df()
        self.test_data = df1.combine_first(df2)
        #####################
        # self.test_data['timestamp'] = pd.to_datetime(self.test_data['timestamp'], dayfirst = True)
        # self.test_data = self.test_data[self.test_data.timestamp <= self.last_d_time]
        self.test_data = self.test_data[['open', 'high', 'low','close','qty','final_zone']].iloc[-90:,:]
        self.calculate_technical_indicators(self.test_data)
        self.test_data['final_zone'] = self.test_data['final_zone'].ffill().bfill()
        self.test_data = self.test_data.replace({'final_zone': self.map_dict})
        self.test_data['ma5'].fillna(method = 'bfill' , inplace = True)
        self.test_data['ma10'].fillna(method = 'bfill' , inplace = True)
        self.test_data['volatility'].fillna(method = 'bfill' , inplace = True)
        self.test_data['rsi'].fillna(method = 'bfill' , inplace = True)
        self.order_id = test_file.split('\\')[-1].split('.')[0]
        self.id_to_class = {0:'failed',1:'success'}
        self.classes = ['failed', 'success']
        ############################
        close_scaler = joblib.load('./apps/finprod_backend/norm_models/arima_ab_scaler.pkl')
        encode = joblib.load('./apps/finprod_backend/norm_models/arima_ab_order_type.pkl')
        ###########################
        self.test_data['order_type'] = self.test_info['order_type'] # asi['order_type'].values[0]
        self.test_data['entry_price'] = self.test_info['entry_price'] #.values[0]
        self.test_data['target_price'] = self.test_info['target_price'] #.values[0]
        self.test_data['stoploss_price'] = self.test_info['stoploss_price'] #.values[0]
        ################################
        df_asi = self.test_data[['order_type', 'entry_price', 'target_price', 'stoploss_price']].iloc[[0]]
        # print("**************************************************")
        df_asi = df_asi.reset_index(drop=True)
        dat = self.test_data.iloc[:,5:]
        ar_features = self.fit_arima_and_extract_features(dat.iloc[:,:6],10,2,0)
        ar_features = ar_features.reset_index(drop=True)
        # print(ar_features)
        # print(df_asi)
        self.test_data = self.test_data.reset_index(drop=True)
        features_ = pd.concat([ar_features, df_asi], axis=1)
        # print("avl_coulmns", features_.columns)
        features_['order_type'] = encode.transform(features_['order_type'])
        norm_features = pd.DataFrame(close_scaler.transform(features_) ,columns = features_.columns)
        self.optimal_features = norm_features[[
            'order_type', 'entry_price', 'target_price', 'stoploss_price'
        ]]
        # 'ma5_arima_param1', 'ma10_arima_param1', 'volatility_residuals_mean',
            # 'volatility_arima_param1', 'rsi_residuals_mean',
            # 'rsi_fitted_values_mean', 'rsi_arima_param1', 'order_type',
            # 'entry_price', 'target_price', 'stoploss_price'
        print("norm_features", norm_features)

    def calculate_technical_indicators(self, df):
        df['close_smoothed'] = df['close'].ewm(span=10, adjust=False).mean()
        df['ma5'] = df['close'].rolling(window=5).mean()
        df['ma10'] = df['close'].rolling(window=10).mean()
        df['volatility'] = df['close'].rolling(window=10).std()
        delta = df['close'].diff(1)
        gain = delta.where(delta > 0, 0.0)
        loss = -delta.where(delta < 0, 0.0)
        avg_gain = gain.rolling(window=14).mean()
        avg_loss = loss.rolling(window=14).mean()
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        df['rsi'] = rsi
        return df
    
    def fit_arima_and_extract_features(self, de, p, d, q):
        # series = ds.iloc[:, -5:]
        # model = ARIMA(series, order=(p, d, q))
        # model_fit = model.fit(disp=0)
        feature_names = de.columns[-6:]
        features = dict()
        for feature in feature_names:
            # features = dict()
            series = de[feature]
            model = ARIMA(series, order=(p, d, q))
            model_fit = model.fit()
            # Extract features
            # print(feature)
            features[f'{feature}_residuals_mean'] = model_fit.resid.mean()
            features[f'{feature}_fitted_values_mean'] =  model_fit.fittedvalues.mean()
            features[f'{feature}_arima_param1'] = model_fit.params.get('ar.L1', 0)
            features[f'{feature}_arima_param2'] = model_fit.params.get('ma.L1', 0)
        # features_df = pd.DataFrame(list(features.values()),columns = list(features.keys()))
        features_df = pd.DataFrame([features])
        # print(features_df)
        return  features_df
    
    def run(self):
        with open('./apps/finprod_backend/norm_models/best_ab_optimal_model.pkl', 'rb') as f:
            best_ab_model = pickle.load(f)
            y_predicted_AB = best_ab_model.predict(self.optimal_features)
            ind = int(y_predicted_AB)
            top5_proba = np.mean(np.array(sorted([estimator.predict_proba(self.optimal_features)[:,ind][0] for estimator in best_ab_model.estimators_],reverse=True)[:5]))
            # y_predicted_proba_AB = best_ab_model.predict_proba(self.optimal_features)
            # print(self.classes[int(y_predicted_AB)])
            # print(np.max(y_predicted_proba_AB,1)[0]) np.max(y_predicted_proba_AB,1)[0]
            print("Status:", self.classes[int(y_predicted_AB)], top5_proba)
            return self.classes[int(y_predicted_AB)], top5_proba


class ARIMA_AB_BUY:
    def __init__(self, test_file, test_info : dict, last_d_time, tick) -> None:
        self.test_file = test_file
        self.test_info = test_info
        self.last_d_time = last_d_time
        self.map_dict = {'DZ':1,'SZ':-1}
        # self.test_data = pd.read_csv(test_file)
        cbsz = Calculate_BUY_SELL_ZONES(test_file, tick, last_d_time, True)
        df1, _ = cbsz.update_new_buy_zones_df()
        df2, _ = cbsz.update_new_sell_zones_df()
        self.test_data = df1.combine_first(df2)
        #####################
        # self.test_data['timestamp'] = pd.to_datetime(self.test_data['timestamp'], dayfirst = True)
        # self.test_data = self.test_data[self.test_data.timestamp <= self.last_d_time]
        self.test_data = self.test_data[['open', 'high', 'low','close','qty','final_zone']].iloc[-90:,:]
        self.calculate_technical_indicators(self.test_data)
        self.test_data['final_zone'] = self.test_data['final_zone'].fillna(0)
        self.test_data = self.test_data.replace({'final_zone': self.map_dict})
        # self.test_data['ma5'].fillna(method = 'bfill' , inplace = True)
        # self.test_data['ma10'].fillna(method = 'bfill' , inplace = True)
        # self.test_data['volatility'].fillna(method = 'bfill' , inplace = True)
        # self.test_data['rsi'].fillna(method = 'bfill' , inplace = True)
        self.order_id = test_file.split('\\')[-1].split('.')[0]
        self.id_to_class = {0:'failed',1:'success'}
        self.classes = ['failed', 'success']
        ############################
        close_scaler = joblib.load('./apps/finprod_backend/norm_models/arima_ab_scaler.pkl')
        # encode = joblib.load('./norm_models/arima_ab_order_type.pkl')
        ###########################
        # self.test_data['order_type'] = self.test_info['order_type'] # asi['order_type'].values[0]
        self.test_data['entry_price'] = self.test_info['entry_price'] #.values[0]
        self.test_data['target_price'] = self.test_info['target_price'] #.values[0]
        self.test_data['stoploss_price'] = self.test_info['stoploss_price'] #.values[0]
        ################################
        df_asi = self.test_data[['entry_price', 'target_price', 'stoploss_price']].iloc[[0]]
        # print("**************************************************")
        df_asi = df_asi.reset_index(drop=True)
        dat = self.test_data.iloc[:,4:]
        print(dat.columns, "555555555555555555555555555555")
        ar_features = self.fit_arima_and_extract_features(dat,1,1,2)
        ar_features = ar_features.reset_index(drop=True)
        # print(ar_features)
        # print(df_asi)
        self.test_data = self.test_data.reset_index(drop=True)
        features_ = pd.concat([ar_features, df_asi], axis=1)
        print("avl_coulmns", features_.columns)
        desired_column_order = [
                                'qty_residuals_mean', 'qty_fitted_values_mean', 'qty_arima_param1',
                                'qty_arima_param2', 'final_zone_residuals_mean',
                                'final_zone_fitted_values_mean', 'final_zone_arima_param1',
                                'final_zone_arima_param2', 'close_smoothed_residuals_mean',
                                'close_smoothed_fitted_values_mean', 'close_smoothed_arima_param1',
                                'close_smoothed_arima_param2', 'volatility_residuals_mean',
                                'volatility_fitted_values_mean', 'volatility_arima_param1',
                                'volatility_arima_param2', 'ema_residuals_mean',
                                'ema_fitted_values_mean', 'ema_arima_param1', 'ema_arima_param2',
                                'entry_price', 'target_price', 'stoploss_price'
                                ]
        features_ = features_.reindex(columns=desired_column_order)
        # features_['order_type'] = encode.transform(features_['order_type'])
        norm_features = pd.DataFrame(close_scaler.transform(features_) ,columns = features_.columns)
        self.optimal_features = norm_features[[
            'qty_residuals_mean', 'qty_fitted_values_mean',
            'final_zone_fitted_values_mean', 'final_zone_arima_param1',
            'close_smoothed_residuals_mean', 'close_smoothed_arima_param2',
            'volatility_fitted_values_mean', 'volatility_arima_param2',
            'ema_arima_param1', 'entry_price', 'target_price', 'stoploss_price'
        ]]
        # 'ma5_arima_param1', 'ma10_arima_param1', 'volatility_residuals_mean',
            # 'volatility_arima_param1', 'rsi_residuals_mean',
            # 'rsi_fitted_values_mean', 'rsi_arima_param1', 'order_type',
            # 'entry_price', 'target_price', 'stoploss_price'
        # print("norm_features", norm_features)

    def calculate_technical_indicators(self, df):
        df['close_smoothed'] = df['close'].ewm(span=10, adjust=False).mean()
        # df['ma5'] = df['close'].rolling(window=5).mean()
        # df['ma10'] = df['close'].rolling(window=10).mean()
        df['ema'] = df['close'].ewm(span=20, adjust=False).mean()
        #talib.EMA(df['close'], 20)
        df['volatility'] = df['close'].rolling(window=10).std()
        # delta = df['close'].diff(1)
        # gain = delta.where(delta > 0, 0.0)
        # loss = -delta.where(delta < 0, 0.0)
        # avg_gain = gain.rolling(window=14).mean()
        # avg_loss = loss.rolling(window=14).mean()
        # rs = avg_gain / avg_loss
        # rsi = 100 - (100 / (1 + rs))
        # df['rsi'] = rsi
        return df
    
    def fit_arima_and_extract_features(self, de, p, d, q):
        # series = ds.iloc[:, -5:]
        # model = ARIMA(series, order=(p, d, q))
        # model_fit = model.fit(disp=0)
        feature_names = de.columns[:5]
        print(feature_names)
        features = dict()
        for feature in feature_names:
            # features = dict()
            series = de[feature]
            model = ARIMA(series, order=(p, d, q))
            model_fit = model.fit()
            # Extract features
            # print(feature)
            features[f'{feature}_residuals_mean'] = model_fit.resid.mean()
            features[f'{feature}_fitted_values_mean'] =  model_fit.fittedvalues.mean()
            features[f'{feature}_arima_param1'] = model_fit.params.get('ar.L1', 0)
            features[f'{feature}_arima_param2'] = model_fit.params.get('ma.L1', 0)
        # features_df = pd.DataFrame(list(features.values()),columns = list(features.keys()))
        features_df = pd.DataFrame([features])
        # print(features_df)
        return  features_df
    
    def run(self):
        with open('./apps/finprod_backend/norm_models/best_ab_optimal_model.pkl', 'rb') as f:
            best_ab_model = pickle.load(f)
            y_predicted_AB = best_ab_model.predict(self.optimal_features)
            ind = int(y_predicted_AB)
            top5_proba = np.mean(np.array(sorted([estimator.predict_proba(self.optimal_features)[:,ind][0] for estimator in best_ab_model.estimators_],reverse=True)[:5]))
            # y_predicted_proba_AB = best_ab_model.predict_proba(self.optimal_features)
            # print(self.classes[int(y_predicted_AB)])
            # print(np.max(y_predicted_proba_AB,1)[0]) np.max(y_predicted_proba_AB,1)[0]
            print("Status:", self.classes[int(y_predicted_AB)], top5_proba)
            return self.classes[int(y_predicted_AB)], top5_proba
        


