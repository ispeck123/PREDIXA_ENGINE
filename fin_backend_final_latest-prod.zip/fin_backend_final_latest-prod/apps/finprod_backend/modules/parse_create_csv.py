import os, ast
import json, pytz, csv
from datetime import datetime
from apps.finprod_backend.modules.time_utility import *
from shared.config.settings import Config as cfg
import pandas as pd


def convert_minute_data_to_csv(file_name : str):
    txt_dir = os.path.join(os.getcwd(), "apps", "finprod_backend", "latest_data")
    #txt_dir = "/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/latest_data"
    file_path = os.path.join(txt_dir, file_name)
    with open(file_path, 'r') as f_file:
        cont = f_file.readline()
    json_data = ast.literal_eval(cont)
    headers = json_data.get('data')[0].keys()
    dataset = json_data.get('data')
    csv_file_name = file_name.replace(".txt", ".csv")
    for rows in dataset:
        rows['tradeDate'] =f"{rows['tradeDate']} {rows['tradeTime']}"
    dump_csv(headers, csv_file_name, dataset)

def dump_csv(header, csv_file, data):
    print("creating_csv", csv_file)
    #csv_dump_path = os.path.join('/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/latest_data_csv', csv_file)
    csv_dump_path = os.path.join(os.getcwd(), "apps", "finprod_backend", "latest_data_csv", csv_file)
    with open(csv_dump_path, 'w', newline='') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=header)
        writer.writeheader()
        writer.writerows(data)
    print(f'CSV file "{csv_file}" created.')


def convert_daily_data_to_csv(file_name : str):
    #txt_dir = "/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/latest_data"
    txt_dir = os.path.join(os.getcwd(), "apps", "finprod_backend", "latest_data")
    file_path = os.path.join(txt_dir, file_name)
    with open(file_path, 'r') as f_file:
        cont = f_file.readline()
        json_data = ast.literal_eval(cont)
        headers = json_data.get('data')[0].keys()
        dataset = json_data.get('data')
        csv_file_name = file_name.replace(".txt", ".csv")
        dump_csv(headers, csv_file_name, dataset)


# def create_75munite_from_15munite(file_name : str):
#     txt_dir = "latest_data_csv"
#     file_path = os.path.join(txt_dir, file_name)
#     print(file_path)
#     df = pd.read_csv(file_path)[['open', 'high', 'low', 'close', 'qty', 'tradeTime', 'tradeDate']]
#     # df = df.reset_index(drop=True)[['open', 'high', 'low', 'close', 'qty', 'tradeTime', 'tradeDate']]
#     dff = df.values.tolist()
#     # print(dff, "////////////////////////////////")
#     # chunks = [df[x:x+5] for x in range(0, len(df), 100)]
#     sublists = [dff[i:i+5] for i in range(0, len(dff), 5)]
#     # print(sublists)
#     w_list = []
#     for items in sublists:
#         data = {}
#         data['open'] = items[0][0]
#         data['high'] = max([sublist[1] for sublist in items])
#         data['low'] = min([sublist[2] for sublist in items])
#         data['close'] = items[len(items) - 1][3]
#         data['qty'] = sum([sublist[4] for sublist in items]) 
#         data['tradeTime'] = items[0][5]
#         data['tradeDate'] = items[0][6]
#         w_list.append(data)
#     headers = w_list[0].keys()
#     csv_file_name = file_name.replace("fifteen", "seventy_five")
#     dump_csv(headers, csv_file_name, w_list)
#     print(csv_file_name)

def create_75munite_from_15munite(file_name: str, country_dir: str):
    # txt_dir = "latest_data_csv"
    file_path = os.path.join(country_dir, 'latest_data_csv', file_name)
    print("Reading:", file_path)

    df = pd.read_csv(file_path)[['open', 'high', 'low', 'close', 'qty', 'tradeTime', 'tradeDate']]
    
    chunk_size = 5
    output = []

    # Define operation map
    agg_map = {
        'open': lambda chunk: chunk.iloc[0]['open'],
        'high': lambda chunk: chunk['high'].max(),
        'low': lambda chunk: chunk['low'].min(),
        'close': lambda chunk: chunk.iloc[-1]['close'],
        'qty': lambda chunk: chunk['qty'].sum(),
        'tradeTime': lambda chunk: chunk.iloc[0]['tradeTime'],
        'tradeDate': lambda chunk: chunk.iloc[0]['tradeDate']
    }

    for i in range(0, len(df), chunk_size):
        chunk = df.iloc[i:i + chunk_size]
        if len(chunk) < chunk_size:
            break  # Skip incomplete chunk

        new_row = {col: func(chunk) for col, func in agg_map.items()}
        output.append(new_row)

    if output:
        headers = output[0].keys()
        csv_file_name = file_name.replace("fifteen", "seventy_five")
        csv_file_path = os.path.join(country_dir, 'latest_data_csv', csv_file_name)
        dump_csv(headers, csv_file_path, output)
        print("Saved as:", csv_file_name)
    else:
        print("No complete 75-minute chunks to save.")




def convert_monthly_data_to_csv(file_name : str, tick : str):
    #txt_dir = "/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/latest_data"
    txt_dir = os.path.join(os.getcwd(), "apps", "finprod_backend", "latest_data")
    file_path = os.path.join(txt_dir, file_name)
    csv_file_name = file_name.replace(".txt", ".csv")
    with open(file_path, 'r') as file:
        cont = file.readline()
    json_data = ast.literal_eval(cont)
    print(type(json_data))
    timestamp_string = json_data.get('timestamp')
    print(timestamp_string)
    headers = json_data.get('data')[0].keys()
    timestamp_format = "%Y-%m-%dT%H:%M:%S%z"
    print(101)
    parsed_timestamp = datetime.strptime(timestamp_string, timestamp_format)
    utc_timestamp = parsed_timestamp.astimezone(pytz.utc)
    indian_timezone = pytz.timezone("Asia/Kolkata")
    ist_timestamp = utc_timestamp.astimezone(indian_timezone)
    dataset = json_data.get('data')
       
    # print(ist_timestamp.date(), len(dataset), type(ist_timestamp.date()))
    stock_name_ll = tick.replace("_monthly", "")
    # cal_date = cfg.stock_enlist_dict.get(stock_name_ll)
    print(102)
    cal_date = datetime.strptime(cfg.stock_enlist_dict.get(stock_name_ll), '%d/%m/%Y')
    # cal_date = subtract_months(ist_timestamp.date(), len(dataset) - 1)
    for rows in dataset:
        rows['tradeDate'] = cal_date.strftime('%d/%m/%Y')
        cal_date = add_one_month(cal_date)
    # print(after_adding)
    dump_csv(headers, csv_file_name, dataset)

def convert_weekly_data_to_csv(file_name : str, tick : str):
    #txt_dir = "/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/latest_data"
    txt_dir = os.path.join(os.getcwd(), "apps", "finprod_backend", "latest_data")
    file_path = os.path.join(txt_dir, file_name)
    # print(file_path, "5555555555555555555555555555555555555555555")
    csv_file_name = file_name.replace(".txt", ".csv")
    with open(file_path, 'r') as file:
        cont = file.readline()
    json_data = ast.literal_eval(cont)
    print(type(json_data))
    print(json_data.get('data')[0].keys())
    # print(1033333333333333333333333333333333333333333333333333333333333333333333333333)
    timestamp_string = json_data.get('timestamp')
    headers = json_data.get('data')[0].keys()
    timestamp_format = "%Y-%m-%dT%H:%M:%S%z"
    parsed_timestamp = datetime.strptime(timestamp_string, timestamp_format)
    utc_timestamp = parsed_timestamp.astimezone(pytz.utc)
    indian_timezone = pytz.timezone("Asia/Kolkata")
    ist_timestamp = utc_timestamp.astimezone(indian_timezone)
    dataset = json_data.get('data')   
    # print(ist_timestamp.date(), len(dataset), type(ist_timestamp.date()))
    stock_name_ll = tick.replace("_weekly", "")
    # cal_date = subtract_weeks(ist_timestamp.date(), len(dataset) - 1)
    print(stock_name_ll)
    print(104)
    cal_date = datetime.strptime(cfg.stock_enlist_dict.get(stock_name_ll), '%d/%m/%Y') 
    for rows in dataset:
        rows['tradeDate'] = cal_date.strftime('%d/%m/%Y')
        cal_date = add_one_week(cal_date)
    # print(after_adding)
    dump_csv(headers, csv_file_name, dataset)

def run_conversion():
    file_list = os.listdir('latest_data')
    
    # print(file_list, ccsv_list)
    for file_items in file_list:
        print(file_items, "**************************")
        if file_items.__contains__('daily'):
            convert_daily_data_to_csv(file_items)
        elif file_items.__contains__('monthly'):
            convert_monthly_data_to_csv(file_items, file_items.rsplit(".")[0])
        elif file_items.__contains__('weekly'):
            convert_weekly_data_to_csv(file_items, file_items.rsplit(".")[0])
        elif file_items.__contains__('sixty'):
            convert_minute_data_to_csv(file_items)
        elif file_items.__contains__('fifteen'):
            convert_minute_data_to_csv(file_items)
    ccsv_list = os.listdir('latest_data_csv')
    for seventy_five_cr in ccsv_list:
        if seventy_five_cr.__contains__('fifteen'):
            print("**************************************")
            create_75munite_from_15munite(seventy_five_cr)


def remove_old_data():
    #path = "/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/latest_data_csv"
    path = os.path.join(os.getcwd(), "apps", "finprod_backend", "latest_data_csv")
    file_list = os.listdir(path)
    for items in file_list:
        df = pd.read_csv(os.path.join(path, items))
        df = df[pd.to_datetime(df['tradeDate'], dayfirst=True).dt.year >= 2020]
        df.to_csv(os.path.join(path, items))




# if __name__ == '__main__':
#     remove_old_data()
    # run_conversion()
    # create_75munite_from_15munite('latest_data_csv\hdfc_15minute.csv', 'hdfc')
    # convert_minute_data_to_csv('hdfc_60minute.txt')
    # convert_weekly_data_to_csv('hdfc_weekly.txt')