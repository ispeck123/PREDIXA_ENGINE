from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
import base64
from base64 import urlsafe_b64encode, urlsafe_b64decode
from SharekhanApi.sharekhanConnect import SharekhanConnect


key = "OilGoZEwzGNyob6ijoBOhGYe1X2fxrMm".encode('utf-8')
iv = base64.b64decode("AAAAAAAAAAAAAAAAAAAAAA==")

def encryptAPIString(plaintext): 
    raw = plaintext.encode('utf-8') 
    encryptor = Cipher(algorithms.AES(key),modes.GCM(iv, None, 16), default_backend()
    ).encryptor()
    ciphertext = encryptor.update(raw) + encryptor.finalize() 
    return base64UrlEncode(ciphertext+encryptor.tag)

def decryptAPIString(ciphertext): 
    enc = base64UrlDecode(ciphertext)[:-16]
    decryptor = Cipher(algorithms.AES(key),modes.GCM(iv), default_backend()
    ).decryptor() 
    return decryptor.update(enc)
 
def base64UrlEncode(data):
    return urlsafe_b64encode(data).rstrip(b'=')

def base64UrlDecode(base64Url):
    padding = b'=' * (4 - (len(base64Url) % 4))
    print(type(base64Url), type(padding))
    return urlsafe_b64decode(base64Url  + padding)

def decrypt_and_encrypt(r_token: str):
    decr = decryptAPIString(r_token.encode())
    print(decr)
    slices = str(decr.decode()).rsplit("|")
    reform = f"{slices[1]}|{slices[0]}"
    print("reform :", reform)
    re_en = encryptAPIString(reform)
    return re_en.decode()


def get_access_token(apiKey, requestToken, state, vendorkey=None, versionId=None):
    login = SharekhanConnect(apiKey)
    url = f"{SharekhanConnect._rootUrl}{SharekhanConnect._routes['api.access.token']}"
    params = {
    'apiKey': apiKey,
    'requestToken': requestToken,
    'state': state
    }
    if vendorkey is not None:
        params['vendorkey'] = vendorkey
    if versionId is not None:
        params['versionId'] = versionId
    response = login._postRequest("api.access.token", params)
    return response

# if __name__ == '__main__':
#     res = decrypt_and_encrypt('r38lF97GQC6GGE/IXztw0D739dIVSK1UmBAmRQjh8VwzFlB89/MPA7XEXs2wPmigms0iiKH8660=')
#     print(res)

