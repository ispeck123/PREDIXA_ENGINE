import os
from apps.finprod_backend.modules.calculate_current import calculate_current_price_position
from shared.config.settings import Config as cfg


class Evaluate_Analyse_Execute:
    def __init__(self, stock_name, time_frame, last_date) -> None:
        self.stock_name = stock_name
        self.time_frame = time_frame
        self.last_date = last_date
        
    def evaluate(self, f_time : str):
        csv_file_name = f"{self.stock_name}_{f_time}.csv"
        csv_file_path = os.path.join(cfg.PROCESSED_DIRECTORY, csv_file_name)
        evaluate = calculate_current_price_position(csv_file_path, self.stock_name, f_time)
        res, out_js = evaluate.run_calculation(True, 'evaluate', self.last_date)
        return res, out_js

    def analyse(self, f_time : str):
        csv_file_name = f"{self.stock_name}_{f_time}.csv"
        csv_file_path = os.path.join(cfg.PROCESSED_DIRECTORY, csv_file_name)
        analyse = calculate_current_price_position(csv_file_path, self.stock_name, f_time)
        res, out_js = analyse.run_calculation(True, 'analyse', self.last_date)
        return res, out_js

    def execute(self, f_time : str, e_dict, a_dict):
        csv_file_name = f"{self.stock_name}_{f_time}.csv"
        csv_file_path = os.path.join(cfg.PROCESSED_DIRECTORY, csv_file_name)
        execute = calculate_current_price_position(csv_file_path, self.stock_name, f_time)
        res, out_js = execute.run_calculation(False, 'execute', self.last_date, e_dict, a_dict)
        return res, out_js



if __name__ == '__main__':
    eae = Evaluate_Analyse_Execute('hdfc', cfg.TIME_FRAMES_1)
    eae.evaluate()
    eae.analyse()
    eae.execute()