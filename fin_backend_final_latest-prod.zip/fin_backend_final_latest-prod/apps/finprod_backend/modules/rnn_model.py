import torch
import torch.nn as nn

# class StockModel(nn.Module):
    
#     def __init__(self, in_features, num_layers, hidden_size):
#         super(StockModel, self).__init__()
        
#         self.hidden_size = hidden_size
#         self.lstm = nn.LSTM(in_features, hidden_size, num_layers, batch_first = True)
#         self.dense1 = nn.Linear(hidden_size+4, 2)
#         # self.dense2 = nn.Linear(10, 2)
#         # self.act = nn.ReLU()
        
#         # self.act = torch.sigmoid()
        
#     def forward(self, x1, x2):
        
#         h0 = torch.randn(1, 1, self.hidden_size).to('cuda:0')
#         c0 = torch.randn(1, 1, self.hidden_size).to('cuda:0')              
#         output, (hn, cn) = self.lstm(x1, (h0, c0))                            
#         out = self.dense1(torch.cat((output[:,-1,:],x2),dim=1))
        
        
#         # logit = torch.sigmoid(out)
        
#         return out
    
class RnnStockModel(nn.Module):
    
    def __init__(self, in_features, num_layers, hidden_size):
        super(RnnStockModel, self).__init__()
        
        self.hidden_size = hidden_size
        self.rnn = nn.RNN(in_features, hidden_size, num_layers, dropout=0.3,batch_first = True)
        self.dense1 = nn.Linear(hidden_size, 1)
        # self.dense2 = nn.Linear(10, 1)
        # self.batch_norm = nn.BatchNorm1d(10)
        self.act1 = nn.Sigmoid()
        # self.act2 = nn.ReLU()
        
        # self.act = torch.sigmoid()
        
    def forward(self, x):
        
        h0 = torch.randn(2, x.size(0), self.hidden_size).to('cuda:0')        
        output, hn = self.rnn(x, h0)  
                                 
        out = self.dense1(output[:,-1,:])
        # out = self.batch_norm(out)
        # out = self.act2(out)
        # out = self.dense2(out)
        
        
        logit = self.act1(out)
        
        return logit
    
# x = torch.randn(1,90,10).to('cuda:0')
# x_ = torch.randn(1,4).to('cuda:0')
# model = StockModel().to('cuda:0')

# c = model(x,x_)

# print(c.shape)