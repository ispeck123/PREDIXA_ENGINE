import ccxt
import pandas as pd
from datetime import datetime
from apps.finprod_backend.modules.stock_handler import proc_single_tick_item
from apps.finprod_backend.modules.parse_create_csv import create_75munite_from_15munite
import os

download_time_frames = ['1M', '1w', '1d', '1h', '15m']
frame_name_dict = {
    '1M': 'monthly', 
    '1w': 'weekly', 
    '1d': 'daily',
    '1h': 'sixty', 
    '15m': 'fifteen'
}


def format_all_stock_data(stock_data: pd.DataFrame, tick: str, interval: str):
    # Rename columns for standardization
    df = stock_data.rename(columns={
        'Open': 'open',
        'High': 'high',
        'Low': 'low',
        'Close': 'close',
        'Volume': 'qty',
        #'Adj Close': 'tradeTime'
    })
    
    # Ensure the index is a proper datetime format
    try:
        df.index = pd.to_datetime(stock_data.index, errors='coerce')
    except Exception as e:
        raise ValueError("Error converting index to datetime.") from e
    
    # Convert and format datetime explicitly
    df['tradeTime'] = df.index.strftime('%H:%M:%S')  # Extract time in HH:MM:SS
    df['tradeDate'] = df.index.strftime('%d/%m/%Y %H:%M:%S')  # Extract date in desired format

    # Verify and enforce the tradeDate format
    df['tradeDate'] = pd.to_datetime(df['tradeDate'], format='%d/%m/%Y %H:%M:%S', errors='coerce')
    if df['tradeDate'].isnull().any():
        raise ValueError("Invalid datetime values detected in 'tradeDate'.")
    
    # Convert tradeDate back to string in the required format
    df['tradeDate'] = df['tradeDate'].dt.strftime('%d/%m/%Y %H:%M:%S')

    # Reorganize the DataFrame
    df = df.reset_index(drop=True)[['open', 'high', 'low', 'close', 'qty', 'tradeTime', 'tradeDate']]
    
    # Save to CSV
    out_file_name = f"./latest_data_csv/{tick}_{frame_name_dict[interval]}.csv"
    df.to_csv(out_file_name, index=False)
    print(f"Successfully created {out_file_name}")



def get_stock_data(time_fr: str):
    # Use Binance Futures
    exchange = ccxt.binance({
        'enableRateLimit': True,
        'options': {'defaultType': 'future'}
    })
    symbol = 'BTC/USDT'
    timeframe = time_fr  # 1-minute candles
    limit = 1000      # Max records to fetch
    # Fetch OHLCV data
    ohlcv = exchange.fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)
    # Convert to DataFrame
    df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
    df = df.rename(columns={
        'volume': 'Volume',
    })
    df.index = pd.to_datetime(df['timestamp'], unit='ms')
    return df




def proc_btc_data_and_update():
    for items in download_time_frames:
        # end_date, start_date = return_now_and_previous_date(items)
        # tick_name = nn_stock[idx]
        obt_sd = get_stock_data(items)
        format_all_stock_data(obt_sd, 'btc_usd', items)

    for files in os.listdir('latest_data_csv'):
        if files.__contains__('btc_usd') and files.__contains__('fifteen'):
            create_75munite_from_15munite(files)

    proc_single_tick_item('btc_usd')



