import os
from shared.config.settings import Config as cfg
from apps.finprod_backend.modules.calculate_zone import Calculate_BUY_SELL_ZONES
from apps.finprod_backend.modules.telegram_alert import TELEGRAM_MSG
from datetime import datetime
from apps.finprod_backend.modules.utils import utility
import pandas as pd
from threading import Thread


class ALERT_NOTIFIER:
    def __init__(self):
        self.tmsg = TELEGRAM_MSG()
        #self.stock_proc_path = "/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/processed_data_files"
        self.stock_proc_path = os.path.join(os.getcwd(), 'apps', 'finprod_backend', 'processed_data_files')
        self.stock_exe_frames = cfg.EXECUTE_FRAMES
        self.stock_list = cfg.stock_list
        self.run()

    def get_cmp(self, file_path):
        df = pd.read_csv(file_path)
        cmp = df.iloc[len(df)-1].get('close')
        return cmp
    
    def stock_interim_thread_proc(self, stocks, exe_frames):
        exe_stock_file_path = os.path.join(self.stock_proc_path, f'{stocks}_{exe_frames}.csv')
        cmp = self.get_cmp(exe_stock_file_path)
        try:
            has_position_to_buy, is_qualified_zone, is_inside_zone, distance_from_cmp = self.check_nearest_zone_distance(exe_stock_file_path, stocks, cmp)
            print(stocks, exe_frames, has_position_to_buy, is_qualified_zone, distance_from_cmp)
            if has_position_to_buy:
                self.create_buy_alert_message(stocks, exe_frames, cmp, is_qualified_zone, is_inside_zone, distance_from_cmp)
        except Exception:
            pass

    def check_nearest_zone_distance(self, file_name: str, tick: str, cmp):
        ut = utility()
        cbsz = Calculate_BUY_SELL_ZONES(file_name, tick, datetime.now(), True) 
        qualified_buy_zones = cbsz.get_qualified_alterated_zones()
        qual_buy_zones = qualified_buy_zones.get('Buy')
        qual_buy_zones = sorted(qual_buy_zones, key=lambda z: z[0]["price"], reverse=True)
        qual_zone_high = qual_buy_zones[0][1].get('price')
        # buy_zones = cbsz.calculate_new_buy_zones()
        # buy_zones = sorted(buy_zones, key=lambda z: z[0]["price"], reverse=True)
        # buy_zone_high = buy_zones[0][1].get('price')
        # buy_zone_low = buy_zones[0][0].get('price')
        qual_high_dist = ut.calculate_percentage_distance(cmp, qual_zone_high)
        # buy_high_dist = ut.calculate_percentage_distance(cmp, buy_zone_high)
        has_position_buy = False
        is_qualified_zone = False
        is_inside_zone = False
        # if buy_zone_low <= cmp <= buy_high_dist:
        #     is_inside_zone = True
        if  0 <= qual_high_dist <= 1:
            has_position_buy = True
            is_qualified_zone = True
        # elif 0 <= buy_high_dist <= 2:
        #     has_position_buy = True
        return has_position_buy, is_qualified_zone, is_inside_zone, qual_high_dist #min(buy_high_dist, qual_high_dist)
        # print(qual_zone_high, qual_high_dist)
        # print(buy_zone_high, buy_high_dist)
    def get_stocks_notifier(self):
        th_list = []
        for stocks in self.stock_list:
            for exe_frames in self.stock_exe_frames:
                ts = Thread(target=self.stock_interim_thread_proc, args=(stocks, exe_frames))
                th_list.append(ts)
                ts.start()
        
        for threa in th_list:
            threa.join()
                # exe_stock_file_path = os.path.join(self.stock_proc_path, f'{stocks}_{exe_frames}.csv')
                # cmp = self.get_cmp(exe_stock_file_path)
                # try:
                #     has_position_to_buy, is_qualified_zone, is_inside_zone, distance_from_cmp = self.check_nearest_zone_distance(exe_stock_file_path, stocks, cmp)
                #     print(stocks, exe_frames, has_position_to_buy, is_qualified_zone, distance_from_cmp)
                #     if has_position_to_buy:
                #         self.create_buy_alert_message(stocks, exe_frames, cmp, is_qualified_zone, is_inside_zone, distance_from_cmp)
                # except Exception:
                #     pass
    
    def create_buy_alert_message(self, stock_name, time_frame, cmp, is_qualified_zone, is_inside_zone, distance):
        if is_qualified_zone:
            if is_inside_zone:
                message = (f"Alert: {stock_name} at {time_frame} INTERVAL is INSIDE a ****Qualified**** Buy Zone.\n"
                        f"Current price: {cmp}\n"
                        f"Distance to Qualified Zone: {distance:.2f}%")
            else:
                message = (f"Alert: {stock_name} at {time_frame} INTERVAL is within range of a *Qualified* Buy Zone.\n"
                        f"Current price: {cmp}\n"
                        f"Distance to Qualified Zone: {distance:.2f}%")
        else:   
            message = (f"Alert: {stock_name} at {time_frame} INTERVAL is within range of a NORMAL Buy Zone.\n"
                       f"Current price: {cmp}\n"
                       f"Distance to Buy Zone: {distance:.2f}%")
        self.tmsg.send_msg(message=message)



    def run(self):
        self.get_stocks_notifier()
        
        # df = pd.read_csv("processed_data_files/hdfc_daily.csv")
        # cmp = df.iloc[len(df)-1].get('close')
        # print(cmp, "*******************************")
        # self.check_nearest_zone("processed_data_files/hdfc_daily.csv", "hdfc", cmp)



