import pandas as pd
import numpy as np
from apps.finprod_backend.modules.cal_s import Calculate_setup_execute
# from modules.analyze_trend import Trend_Analyzer
from shared.db.dbconn import DBConnection
from shared.db.db_model import Auto_Order
from shared.config.settings import Config as cfg
from random import randint
import logging
from datetime import datetime
from apps.finprod_backend.modules.calculate_model import ARIMA_AB_ZONE, LSTM_RF, ARIMA_AB, ARIMA_AB_BUY
from concurrent.futures import ThreadPoolExecutor
from threading import Thread
from queue import Queue
import os

db = DBConnection()
logger = logging.getLogger()

def filter_data_with_buffer(file_name, start_time, end_time, buffer_before=0, buffer_after=0):
    df = pd.read_csv(file_name)
    df['tradeDate'] = pd.to_datetime(df['tradeDate'], dayfirst = True)
    df_1 = df[['tradeDate', 'open', 'high', 'low', 'close']]
    df_1.rename(columns = {'tradeDate': 'time'}, inplace = True)
    # Get the indices of the start and end times
    start_idx = df[df['tradeDate'] >= start_time].index.min()
    end_idx = df[df['tradeDate'] <= end_time].index.max()
    # Adjust the indices to include the buffer
    start_idx = max(0, start_idx - buffer_before)
    end_idx = min(len(df) - 1, end_idx + buffer_after)
    
    df_1['timestamp'] = df_1['time'].copy()
    df_1['time'] = df_1['time'].astype(np.int64) // 10**9
    # # Filter the data
    df_1 = (
        df_1.drop_duplicates(subset=['time'], keep='last')
            .sort_values('timestamp')
            .reset_index(drop=True)
    )
    ts = df_1['timestamp'].to_numpy(dtype='datetime64[ns]')
    start_pos = max(0, np.searchsorted(ts, np.datetime64(start_time), side='left') - buffer_before)
    end_pos = np.searchsorted(ts, np.datetime64(end_time),   side='right') - 1 + buffer_after
    end_pos = min(len(df_1) - 1, end_pos)
    if end_pos < start_pos:
        return []
    out = df_1.iloc[0:end_pos+1].copy()
    # # sorted_df = filtered_df.sort_values(by='time', ascending=True)
    # # filtered_df['timestamp'] = filtered_df['timestamp'].astype(np.int64) // 10**9
    # # print(filtered_df.to_dict(orient = 'records'))
    return out.to_dict(orient = 'records')


def filter_post_data_with_buffer(file_name, start_time, end_time, buffer_before=0, buffer_after=0):

    df = pd.read_csv(file_name)
    df['tradeDate'] = pd.to_datetime(df['tradeDate'], dayfirst = True)
    df_1 = df[['tradeDate', 'open', 'high', 'low', 'close']]
    df_1.rename(columns = {'tradeDate': 'time'}, inplace = True)
    df_1['timestamp'] = df_1['time'].copy()
    df_1['time'] = df_1['time'].astype(np.int64) // 10**9
    df_1 = (
        df_1.drop_duplicates(subset=['time'], keep='last')
            .sort_values('timestamp')
            .reset_index(drop=True)
    )
    ts = df_1['timestamp'].to_numpy(dtype='datetime64[ns]')
    start_pos = max(0, np.searchsorted(ts, np.datetime64(start_time), side='right') - buffer_before)
    end_pos   = np.searchsorted(ts, np.datetime64(end_time), side='right') - 1 + buffer_after
    end_pos   = min(len(df_1) - 1, end_pos)
    if end_pos < start_pos:
        return []
    out = df_1.iloc[start_pos:end_pos+1].copy()
    return out.to_dict(orient = 'records')


class AUTO_TRADER_GEN:
    def __init__(self, time_fr) -> None:
        self.stock_list = self.get_stock_details()
        self.time_frame = time_fr
        self.bq = Queue()
        self.exe_frame = getattr(cfg, f"TIME_FRAMES_{time_fr}")[-1]
        if 'nifty' in self.stock_list:
            self.stock_list.remove('nifty')
        if 'sjs_enterprise' in self.stock_list:
            self.stock_list.remove('sjs_enterprise')

    def get_stock_details(self):
        # nn_stock_list = ['hdfcbank', 'hindunilvr', 'icicibank', 'infy', 'tcs', 'reliance', 'itc', 'bhartiartl', 'vbl', 'bse_limited']
        nn_stock_list = ['mrk', 'micron_technology', 'microsoft_corporation']
        # nn_y_fin_stock_list = []
        # res = raw_query("select * from stock_master where is_active=1;")
        # for stock_details in res:
        #     nn_stock_list.append(stock_details.get('stock_tick'))
            # nn_y_fin_stock_list.append(stock_details.get('y_finance'))
        return nn_stock_list

    def generate_all_trading_day(self, start_date="2021-04-01", end_date=None):
        if end_date is None:
            end_date = pd.Timestamp.today().strftime('%Y-%m-%d')
        # Generate a range of business days
        trading_days = pd.bdate_range(start=start_date, end=end_date)
        print(trading_days)
        # Randomly select a trading day
        # random_day = np.random.choice(trading_days)
        # random_day = pd.Timestamp(random_day)
        return trading_days.tolist()

    def insert_buy_alerts(self, buy_dict, stock_name, dt):
        db_order = Auto_Order(
                stock_tick=stock_name,
                order_type='Buy',
                time_frame=self.time_frame,
                entry_price=buy_dict['entry_price'],
                stoploss_price=buy_dict['stop_loss'],
                target_price=buy_dict['target_price'],
                stock_quantity=100,
                purchased_cmp_date=dt.strftime("%Y-%m-%dT%H:%M"),
                purchased_on=datetime.now())
        
        session = db.get_session()
        session.add(db_order)
        session.commit()
        session.refresh(db_order)
        return {"order_id": db_order.order_id}
        
    def calculate_eva_ana_trend(self, tick, last_dt):
        avl_time_fr = getattr(cfg, f"TIME_FRAMES_{self.time_frame}")
        #eva_file = f"/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/processed_data_files/{tick}_{avl_time_fr[0]}.csv"
        eva_file = os.path.join(os.getcwd(), 'apps', 'finprod_backend', 'processed_data_files', f"{tick}_{avl_time_fr[0]}.csv")
        #ana_file = f"/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/processed_data_files/{tick}_{avl_time_fr[1]}.csv"
        ana_file = os.path.join(os.getcwd(), 'apps', 'finprod_backend', 'processed_data_files', f"{tick}_{avl_time_fr[1]}.csv")
        eva_df = pd.read_csv(eva_file)
        ana_df = pd.read_csv(ana_file)
        eva_df['timestamp'] = pd.to_datetime(eva_df['timestamp'], dayfirst = True)
        ana_df['timestamp'] = pd.to_datetime(ana_df['timestamp'], dayfirst = True)
        eva_df = eva_df[eva_df.timestamp <= last_dt]
        ana_df = ana_df[ana_df.timestamp <= last_dt]
        return self.determine_trend(eva_df) and self.determine_trend(ana_df)

    def insert_sell_alerts(self, sell_dict, stock_name, dt):
        db_order = Auto_Order(
            stock_tick=stock_name,
            order_type='Sell',
            time_frame=self.time_frame,
            entry_price=sell_dict['entry_price'],
            stoploss_price=sell_dict['stop_loss'],
            target_price=sell_dict['target_price'],
            stock_quantity=100,
            purchased_cmp_date=dt.strftime("%Y-%m-%dT%H:%M"),
            purchased_on=datetime.now())
        session = db.get_session()
        session.add(db_order)
        session.commit()
        session.refresh(db_order)
        return {"order_id": db_order.order_id}
    
    def generate_setups(self, idx, tdays, stocks):
        try:
            print(f"iteration no:{idx}", tdays, stocks)
            cse = Calculate_setup_execute(stocks, self.time_frame, tdays)
            random_trade_setups = cse.calculate()
            if random_trade_setups == None:
                return
            if 'BUY' in random_trade_setups:
                if (self.time_frame == 1 and random_trade_setups['BUY_RRR'] >= 1.5) or (self.time_frame == 2 and random_trade_setups['BUY_RRR'] >= 1.15):
                    buy_ord = self.insert_buy_alerts(random_trade_setups['BUY'], stocks, tdays)
                    self.bq.put(buy_ord)
                        # buy_list.append(buy_ord['order_id'])
        except Exception as ex:
            print("EXCEPTION OCCURED AT", tdays, stocks)
            logger.exception(ex, stack_info=True)

    def generate_stock_results(self, stocks):
        filepath = os.path.join(os.getcwd(), 'apps', 'finprod_backend', 'processed_data_files', f"{stocks}_sixty.csv")
        df = pd.read_csv(filepath)
        df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst=True)
        every_10th_row = df.iloc[::5]
        for idx, tdays in enumerate(every_10th_row.timestamp):
                # for stocks in self.stock_list:
            try:
                print(f"iteration no:{idx}", tdays, stocks)
                cse = Calculate_setup_execute(stocks, self.time_frame, tdays)
                random_trade_setups = cse.calculate()
                if random_trade_setups == None:
                    continue
                if 'BUY' in random_trade_setups:
                    if (self.time_frame == 1 and random_trade_setups['BUY_RRR'] >= 1.5) or (self.time_frame == 2 and random_trade_setups['BUY_RRR'] >= 1.15):
                        buy_ord = self.insert_buy_alerts(random_trade_setups['BUY'], stocks, tdays)
                        self.bq.put(buy_ord)
                        # buy_list.append(buy_ord['order_id'])
            except Exception as ex:
                print("EXCEPTION OCCURED AT", tdays, stocks)
                logger.exception(ex, stack_info=True)
    
    def start(self):
        buy_list = []
        sell_list = []
        t_res = []
        # ramdom_trading_days = self.generate_all_trading_day()
        for stocks in self.stock_list: #= 'hdfcbank'
            df = pd.read_csv(f'./processed_data_files/{stocks}_sixty.csv')
            df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst=True)
            every_10th_row = df.iloc[::5]
            for idx, tdays in enumerate(every_10th_row.timestamp):
                # for stocks in self.stock_list:
                try:
                    print(f"iteration no:{idx}", tdays, stocks)
                    cse = Calculate_setup_execute(stocks, self.time_frame, tdays)
                    random_trade_setups = cse.calculate()
                    if random_trade_setups == None:
                        continue
                    if 'BUY' in random_trade_setups:
                        if (self.time_frame == 1 and random_trade_setups['BUY_RRR'] >= 1.5) or (self.time_frame == 2 and random_trade_setups['BUY_RRR'] >= 1.15):
                            buy_ord = self.insert_buy_alerts(random_trade_setups['BUY'], stocks, tdays)
                            # self.bq.put(buy_ord)
                            print(f"BUY ORDER CREATED {buy_ord}")
                            buy_list.append(buy_ord['order_id'])
                except Exception as ex:
                    print("EXCEPTION OCCURED AT", tdays, stocks)
                    logger.exception(ex, stack_info=True)
            
                    # for stocks in self.stock_list:
                
            # df = pd.read_csv(f'./processed_data_files/{stocks}_daily.csv')
            # df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst=True)
            # every_10th_row = df.iloc[::5]
        # for i in range(100):
            # for idx, tdays in enumerate(every_10th_row.timestamp):
                # for stocks in self.stock_list:
                # try:
                    # print(f"iteration no:{idx}", tdays, stocks)
                    # if self.time_frame == 1:
                    #     ramdom_trading_day = self.generate_random_trading_day()
                    # elif self.time_frame == 2:
                    #     ramdom_trading_day = self.generate_random_trading_day(start_date='2022-12-15')
                    
                    # random_stock_tick = self.stock_list[randint(0, len(self.stock_list) - 1)]
                    # cse = Calculate_setup_execute(stocks, self.time_frame, tdays)
                    # random_trade_setups = cse.calculate()
                    # trend = self.calculate_eva_ana_trend(stocks, tdays)
                    # trend = self.determine_trend(cse.get_execute_df(), 5)
                    # print(random_trade_setups)
                    # if random_trade_setups == None:
                        # continue
                    # print(trend)
                    # if 'BUY' in random_trade_setups:
                        # if (self.time_frame == 1 and random_trade_setups['BUY_RRR'] >= 1.5) or (self.time_frame == 2 and random_trade_setups['BUY_RRR'] >= 1.15):
                            # file_path = f"./processed_data_files/{stocks}_{self.exe_frame}.csv"
                            # bind_data = {
                            #         "order_type" : 'Buy',
                            #         "entry_price" : random_trade_setups['BUY']['entry_price'],
                            #         "target_price" : random_trade_setups['BUY']['target_price'],
                            #         "stoploss_price" : random_trade_setups['BUY']['stop_loss']
                            #     }
                            # aaz = LSTM_RF(file_path, bind_data, ramdom_trading_day) 
                            # aaz = ARIMA_AB_BUY(file_path, bind_data, ramdom_trading_day, random_stock_tick)
                            # s_f, prob = aaz.run()
                            # if s_f == 'success':
                            # buy_ord = self.insert_buy_alerts(random_trade_setups['BUY'], stocks, tdays)
                            # buy_list.append(buy_ord['order_id'])
                    # if 'SELL' in random_trade_setups:
                    #     if random_trade_setups['SELL_RRR'] >= 2:
                    #         file_path = f"./processed_data_files/{random_stock_tick}_daily.csv"
                    #         bind_data = {
                    #                 "order_type" : 'Sell',
                    #                 "entry_price" : random_trade_setups['SELL']['entry_price'],
                    #                 "target_price" : random_trade_setups['SELL']['target_price'],
                    #                 "stoploss_price" : random_trade_setups['SELL']['stop_loss']
                    #             }
                    #         # aaz = ARIMA_AB(file_path, bind_data, ramdom_trading_day)
                    #         # aaz = LSTM_RF(file_path, bind_data, ramdom_trading_day)
                    #         # s_f, prob = aaz.run()
                    #         # if s_f == 'success':
                    #         sell_ord = self.insert_sell_alerts(random_trade_setups['SELL'], random_stock_tick, ramdom_trading_day)
                    #         sell_list.append(sell_ord['order_id'])
                # except Exception as ex:
                    # print("EXCEPTION OCCURED AT", tdays, stocks)
                    # logger.exception(ex, stack_info=True)
                    # raise SystemExit
        print("TOTAL ORDERD CREATED.......")
        print('BUY ORDERS', len(buy_list))
        print(buy_list)
        print('SELL ORDERS', len(sell_list))
        print(sell_list)


class AUTO_TRADER_RANDOM:
    def __init__(self, time_fr) -> None:
        self.stock_list = self.get_stock_details()
        self.time_frame = time_fr
        self.exe_frame = getattr(cfg, f"TIME_FRAMES_{time_fr}")[-1]
        if 'nifty' in self.stock_list:
            self.stock_list.remove('nifty')
        if 'sjs_enterprise' in self.stock_list:
            self.stock_list.remove('sjs_enterprise')

    # def analyze_logic_trend(self, stock_tick, last_dt):
    #     at = Trend_Analyzer(stock_tick, self.time_frame, last_dt)
    #     return not(at.get_eva_ana_frames())
    
    def get_stock_details(self):
        nn_stock_list = []
        # nn_y_fin_stock_list = []
        res = db.raw_query("select * from stock_master where is_active=1;")
        for stock_details in res:
            nn_stock_list.append(stock_details.get('stock_tick'))
            # nn_y_fin_stock_list.append(stock_details.get('y_finance'))
        return nn_stock_list

    def generate_random_trading_day(self, start_date='2022-12-15', end_date=None):
        if end_date is None:
            end_date = pd.Timestamp.today().strftime('%Y-%m-%d')
        # Generate a range of business days
        trading_days = pd.bdate_range(start=start_date, end=end_date)
        # print(trading_days)
        # Randomly select a trading day
        random_day = np.random.choice(trading_days)
        random_day = pd.Timestamp(random_day)
        return random_day
    
    def insert_buy_alerts(self, buy_dict, stock_name, dt):
        db_order = Auto_Order(
                stock_tick=stock_name,
                order_type='Buy',
                time_frame=self.time_frame,
                entry_price=buy_dict['entry_price'],
                stoploss_price=buy_dict['stop_loss'],
                target_price=buy_dict['target_price'],
                stock_quantity=100,
                purchased_cmp_date=dt.strftime("%Y-%m-%dT%H:%M"),
                purchased_on=datetime.now())
        session = db.get_session()
        session.add(db_order)
        session.commit()
        session.refresh(db_order)
        return {"order_id": db_order.order_id}
    
    def determine_trend(self, df: pd.DataFrame):
        """
        Calculate the trend (Uptrend, Downtrend, Reversal to Downtrend) based on 20 EMA and CMP.
        Parameters:
            data (pd.DataFrame): DataFrame containing 'close' column for CMP.
            ema_period (int): Period for EMA calculation (default is 20).
        Returns:
            bool: A single boolean indicating if the current trend condition is met.
        """
        # Validate input
        if 'close' not in df.columns:
            raise ValueError("Data must contain a 'close' column.")

        # Calculate the 20 EMA
        df['EMA20'] = df['close'].ewm(span=20, adjust=False).mean()
        #talib.EMA(df['close'], 20)

        # Ensure there are at least two rows to compare
        if len(df) < 2:
            return False
        # Get current and previous CMP and EMA
        current_cmp = df.iloc[-1]['close']
        current_ema = df.iloc[-1]['EMA20']
        previous_cmp = df.iloc[-2]['close']
        previous_ema = df.iloc[-2]['EMA20']
        # Determine trend conditions
        if current_cmp > current_ema and previous_cmp <= previous_ema:
            # CMP crosses above EMA: Reversal to Uptrend
            return True
        elif current_cmp < current_ema and previous_cmp >= previous_ema:
            # CMP crosses below EMA: Reversal to Downtrend
            return True
        elif current_cmp > current_ema:
            # CMP above EMA: Uptrend
            return True
        else:
            # All other conditions
            return False

        # 
        # ema_values = df['EMA20'].tail(period).values
        # last_zone = df['final_zone'].tail(14).to_list()
        # sz_count = last_zone.count('SZ')
        # Calculate the differences between consecutive EMA20 values
        # diff = ema_values[1:] - ema_values[:-1]
        
        # # Determine the trend based on the differences
        # if all(diff > 0):
        #     return "uptrend"
        # elif all(diff < 0):
        #     return "downtrend"
        # else:
        #     return "sideways"
        
    def calculate_eva_ana_trend(self, tick, last_dt):
        avl_time_fr = getattr(cfg, f"TIME_FRAMES_{self.time_frame}")
        #eva_file = f"/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/processed_data_files/{tick}_{avl_time_fr[0]}.csv"
        eva_file = os.path.join(os.getcwd(), 'apps', 'finprod_backend', 'processed_data_files', f"{tick}_{avl_time_fr[0]}.csv")
        #ana_file = f"/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/processed_data_files/{tick}_{avl_time_fr[1]}.csv"
        ana_file = os.path.join(os.getcwd(), 'apps', 'finprod_backend', 'processed_data_files', f"{tick}_{avl_time_fr[1]}.csv")
        eva_df = pd.read_csv(eva_file)
        ana_df = pd.read_csv(ana_file)
        eva_df['timestamp'] = pd.to_datetime(eva_df['timestamp'], dayfirst = True)
        ana_df['timestamp'] = pd.to_datetime(ana_df['timestamp'], dayfirst = True)
        eva_df = eva_df[eva_df.timestamp <= last_dt]
        ana_df = ana_df[ana_df.timestamp <= last_dt]
        return self.determine_trend(eva_df) and self.determine_trend(ana_df)


    def insert_sell_alerts(self, sell_dict, stock_name, dt):
        db_order = Auto_Order(
            stock_tick=stock_name,
            order_type='Sell',
            time_frame=self.time_frame,
            entry_price=sell_dict['entry_price'],
            stoploss_price=sell_dict['stop_loss'],
            target_price=sell_dict['target_price'],
            stock_quantity=100,
            purchased_cmp_date=dt.strftime("%Y-%m-%dT%H:%M"),
            purchased_on=datetime.now())
        session = db.get_session()
        session.add(db_order)
        session.commit()
        session.refresh(db_order)
        return {"order_id": db_order.order_id}
    
    def start(self):
        buy_list = []
        sell_list = []
        # ramdom_trading_days = self.generate_random_trading_day()
        for i in range(1000):
        # for idx, tdays in enumerate(ramdom_trading_days):
            # for stocks in self.stock_list:
            try:
                print(f"iteration no:{i}")
                if self.time_frame == 1:
                    ramdom_trading_day = self.generate_random_trading_day()
                elif self.time_frame == 2:
                    ramdom_trading_day = self.generate_random_trading_day(start_date='2022-12-15')
                
                random_stock_tick = self.stock_list[randint(0, len(self.stock_list) - 1)]
                cse = Calculate_setup_execute(random_stock_tick, self.time_frame, ramdom_trading_day)
                random_trade_setups = cse.calculate()
                # trend = self.analyze_logic_trend(random_stock_tick, ramdom_trading_day)
                # self.calculate_eva_ana_trend(random_stock_tick, ramdom_trading_day)
                # print(random_trade_setups)
                if random_trade_setups == None:
                    continue
                # print(trend)
                if 'BUY' in random_trade_setups:
                    if ((self.time_frame == 1 and random_trade_setups['BUY_RRR'] >= 2) or (self.time_frame == 2 and random_trade_setups['BUY_RRR'] >= 1.15)):
                        # file_path = f"./processed_data_files/{random_stock_tick}_{self.exe_frame}.csv"
                        # bind_data = {
                        #         "order_type" : 'Buy',
                        #         "entry_price" : random_trade_setups['BUY']['entry_price'],
                        #         "target_price" : random_trade_setups['BUY']['target_price'],
                        #         "stoploss_price" : random_trade_setups['BUY']['stop_loss']
                        #     }
                        # aaz = LSTM_RF(file_path, bind_data, ramdom_trading_day) 
                        # aaz = ARIMA_AB_BUY(file_path, bind_data, ramdom_trading_day, random_stock_tick)
                        # s_f, prob = aaz.run()
                        # if s_f == 'success':
                        buy_ord = self.insert_buy_alerts(random_trade_setups['BUY'], random_stock_tick, ramdom_trading_day)
                        buy_list.append(buy_ord['order_id'])
                # if 'SELL' in random_trade_setups:
                #     if random_trade_setups['SELL_RRR'] >= 2:
                #         file_path = f"./processed_data_files/{random_stock_tick}_daily.csv"
                #         bind_data = {
                #                 "order_type" : 'Sell',
                #                 "entry_price" : random_trade_setups['SELL']['entry_price'],
                #                 "target_price" : random_trade_setups['SELL']['target_price'],
                #                 "stoploss_price" : random_trade_setups['SELL']['stop_loss']
                #             }
                #         # aaz = ARIMA_AB(file_path, bind_data, ramdom_trading_day)
                #         # aaz = LSTM_RF(file_path, bind_data, ramdom_trading_day)
                #         # s_f, prob = aaz.run()
                #         # if s_f == 'success':
                #         sell_ord = self.insert_sell_alerts(random_trade_setups['SELL'], random_stock_tick, ramdom_trading_day)
                #         sell_list.append(sell_ord['order_id'])
            except Exception as ex:
                print("EXCEPTION OCCURED AT", ramdom_trading_day, random_stock_tick)
                logger.exception(ex, stack_info=True)
                # raise SystemExit
        print("TOTAL ORDERD CREATED.......")
        print('BUY ORDERS', len(buy_list))
        print(buy_list)
        print('SELL ORDERS', len(sell_list))
        print(sell_list)