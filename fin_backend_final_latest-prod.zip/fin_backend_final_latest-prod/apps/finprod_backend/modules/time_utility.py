from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
# Given date

def subtract_months(given_date : datetime.date, months_to_subtract):
    new_year = given_date.year - (months_to_subtract // 12)
    new_month = given_date.month - (months_to_subtract % 12)
    if new_month <= 0:
        new_month += 12
        new_year -= 1
    new_day = given_date.day
    if new_day > 28:
        new_day = min(new_day, (datetime(new_year, new_month + 1, 1) - timedelta(days=1)).day)
    # Create the new date
    new_date = datetime(new_year, new_month, new_day)
    return new_date

def add_one_month(date):
    new_date = date + relativedelta(months=1)
    return new_date

def subtract_weeks(date, num_weeks):
    delta = timedelta(weeks=num_weeks)
    new_date = date - delta
    return new_date

def add_one_week(date):
    delta = timedelta(weeks=1)
    new_date = date + delta
    return new_date