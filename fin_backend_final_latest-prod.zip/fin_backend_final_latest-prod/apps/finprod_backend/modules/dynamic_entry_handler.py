from shared.db.dbconn import DBConnection
from sqlalchemy import text
from apps.finprod_backend.modules.calculate_zone import Calculate_BUY_SELL_ZONES
import pandas as pd
from datetime import datetime
import os

db = DBConnection()

class DYNAMIC_ENTRY:
    def __init__(self, order_id):
        self.order_id = order_id
        pass
    
    def lower_entry_checker_frames(self, time_fr):
        if time_fr == 1:
            return ['sixty', 'fifteen']
        elif time_fr == 2:
            return ['fifteen']
        
    def update_entry_price(self, new_entry):
        
        rc = db.raw_connection()
        query = f'update auto_order_master set entry_price={new_entry} where order_id={self.order_id}'
        rc.execute(text(query))
        rc.commit()
        rc.close()
        
    def get_files_and_frame(self, fr, entry_p):
        #file_path = f'/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/processed_data_files/{self.stock_name}_{fr}.csv'
        file_path = os.path.join(os.getcwd(), 'apps', 'finprod_backend', 'processed_data_files', f'{self.stock_name}_{fr}.csv')
        cbsz = Calculate_BUY_SELL_ZONES(file_path, self.stock_name, self.pcd_dt, True)
        exe_dz = cbsz.get_qualified_buy_zones()
        if exe_dz[0][1] > entry_p:
            self.update_entry_price(exe_dz[0][1])



    def get_details_from_order_id(self):
        res  = db.raw_query(f"select * from auto_order_master where order_id={self.order_id}")
        self.time_frame = res[0].get('time_frame')
        self.stock_name = res[0].get('stock_tick')
        self.pcd_dt = datetime.strptime(res[0].get('purchased_cmp_date'), '%Y-%m-%dT%H:%M')
        frames = self.lower_entry_checker_frames(self.time_frame)
        entry_price = res[0].get('entry_price')
        for fra in frames:
            self.get_files_and_frame(fra, entry_price)
