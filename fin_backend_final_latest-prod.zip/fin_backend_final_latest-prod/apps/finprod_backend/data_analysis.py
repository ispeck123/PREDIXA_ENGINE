import pandas as pd
import csv, os
from datetime import datetime
from modules.dbconn import raw_query
from modules.utils import utility
from modules.calculate_zone import Calculate_BUY_SELL_ZONES
import time

class ENTRY_DATAC:
    def __init__(self):
        pass

    def get_orders(self):
        res = raw_query("select * from pending_order_master where order_type='Buy'")
        with open('entry.csv', 'w') as csvfile:
            # Creating a csv writer object
            csvwriter = csv.writer(csvfile)
            # Writing the headers
            csvwriter.writerow(res[0].keys())
            # Writing the data rows
            for items in res:
                csvwriter.writerow(items.values())
            # print(res)
    
    def get_min_entry_order_id(self):
        min_entry_df = pd.read_csv('min_entry.csv')
        order_list = min_entry_df['order_id'].to_list()
        print(len(order_list))

    def get_df_and_add(self):
        df = pd.read_csv("entry.csv")
        df['entry_min_distance'] = 0
        df.loc[df['is_trade_started'] == 1, 'entry_min_distance'] = 0
        df.loc[df['is_trade_started'] == 0, 'entry_min_distance'] = df[df['is_trade_started'] == 0].apply(self.get_closest_val_to_entry, axis=1)
        df = df[df['entry_min_distance'] <= 10]
        fdf = df[df['entry_min_distance'] <= 1]
        fdf.to_csv('min_entry.csv')
        df.to_csv('entry.csv')

    def get_closest_val_to_entry(self, row):
        # print(row)
        ut = utility()
        tick = row['stock_tick']
        price = row['entry_price']
        last_d_time = datetime.strptime(row['purchased_cmp_date'], "%Y-%m-%dT%H:%M")
        file_path = f"./processed_data_files/{tick}_daily.csv"
        fdf = pd.read_csv(file_path)
        fdf['timestamp'] = pd.to_datetime(fdf['timestamp'], dayfirst = True)
        fdf = fdf[fdf.timestamp >= last_d_time]
        # print(fdf['low'].isna().all())
        # closest_low_value = fdf['low'].iloc[(fdf['low'] - price).abs().idxmin()]
        closest_low_value = fdf['low'].min()
        close_low_percent = ut.calculate_percentage_distance(price, closest_low_value)
        return round(close_low_percent, 2)
    
    def collect_entry_files(self):
        entry_df = pd.read_csv("entry.csv")
        print(entry_df.head())
        for i in range(len(entry_df)):
            print(i)
            order_name = entry_df.iloc[i].get('order_id')
            if order_name is None:
                continue
            stock_name = entry_df.iloc[i].get('stock_tick')
            print(order_name, entry_df.iloc[i].get('purchased_cmp_date'), "########################################")
            last_d_time = datetime.strptime(entry_df.iloc[i].get('purchased_cmp_date'), "%Y-%m-%dT%H:%M")
            file_path = f"./processed_data_files/{stock_name}_daily.csv"
            cbsz = Calculate_BUY_SELL_ZONES(file_path, stock_name, last_d_time, True)
            df_dz, _ = cbsz.update_new_buy_zones_df()
            df_sz, _ = cbsz.update_new_sell_zones_df()
            # fdf = pd.read_csv(file_path)
            # fdf['timestamp'] = pd.to_datetime(fdf['timestamp'], dayfirst = True)
            # # fdf = fdf[fdf.timestamp <= last_d_time]
            # # fdf.to_csv(f'./ENTRY_FILES/{order_name}.csv')
            df = df_dz.combine_first(df_sz)
            # print(df.head())
            if df.empty:
                print("NuLL data on success order {}".format(order_name))
            export_file_name = os.path.join('ENTRY_FILES', f"{order_name}.csv")
            df.to_csv(export_file_name)
            # time.sleep(5)

















if __name__ == '__main__':
    edc = ENTRY_DATAC()
    # edc.get_orders()
    # edc.get_df_and_add()
    edc.get_min_entry_order_id()
    # edc.collect_entry_files()