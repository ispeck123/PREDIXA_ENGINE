import os, json
from shared.config.settings import Config as cfg
# from modules.dbconn import raw_query
from shared.db.dbconn import DBConnection
import pandas as pd

dbc = DBConnection()

def list_of_stocks(country_name : str):
    # path = "processed_data_files"
    # item_list = os.listdir(path)
    # dis_list = []
    
    if country_name.lower().__contains__('us'):
        query = "select * from us_stock_master where is_active=1;"
    else:
        query = "select * from ind_stock_master where is_active=1;"

    res = dbc.raw_query(query)
    # for stock_details in res:
    #     dis_list.append(str(stock_details.get('stock_tick')).upper())
    # for stocks in cfg.stock_list:
        # dis_list.append(str(stocks).upper())
    # for files in item_list:
        # s_name = files.rsplit("_")[0]
        # if s_name.upper() not in dis_list:
            # dis_list.append(s_name.upper()) # dis_list
    return res


def candle_chart_data_frame(stock_name : str, time_frame: int):
    #p_file_path = "/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/processed_data_files"
    p_file_path = os.path.join(os.getcwd(), "apps", "finprod_backend", "processed_data_files")
    out_res = {}
    if time_frame == 1:
        for t_f in cfg.TIME_FRAMES_1:
            file_name = os.path.join(p_file_path, f"{stock_name}_{t_f}.csv")
            df = pd.read_csv(file_name)
            df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst=True)
            df['timestamp'] = df['timestamp'].apply(lambda x: x.timestamp() * 1000)
            out_res[t_f] = {
                        "data": df[['timestamp', 'open', 'high', 'low', 'close']].values.tolist(),
                        "annotations" : {
                            "points": [{
                                        "x": df.iloc[5]['timestamp'],
                                        "y": df.iloc[5]['high'],
                                        "yAxisIndex": 0,
                                        "seriesIndex": 0,
                                        "marker": {
                                        "size": 5,
                                        "fillColor": "#fff",
                                        "strokeColor": "#333",
                                        "strokeWidth": 3,
                                        "shape": "circle",
                                        "radius": 2,
                                        "OffsetX": 0,
                                        "OffsetY": 0,
                                        "cssClass": '',
                                        },
                                        "label": {
                                            "borderColor": '#c2c2c2',
                                            "borderWidth": 1,
                                            "borderRadius": 2,
                                            "text": "undefined",
                                            "textAnchor": 'middle',
                                            "offsetX": 0,
                                            "offsetY": -15,
                                            "style": {
                                                "background": '#fff',
                                                "color": '#777',
                                                "fontSize": '12px',
                                                "fontWeight": 400,
                                                "cssClass": 'apexcharts-point-annotation-label',
                                                "padding": {
                                                "left": 5,
                                                "right": 5,
                                                "top": 0,
                                                "bottom": 2,
                                                }
                                            },
                                        }
                                    }]
                                }
                        }
    elif time_frame == 2:
        for t_f in cfg.TIME_FRAMES_2:
            file_name = os.path.join(p_file_path, f"{stock_name}_{t_f}.csv")
            df = pd.read_csv(file_name)
            df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst=True)
            df['timestamp'] = df['timestamp'].apply(lambda x: x.timestamp() * 1000)
            out_res[t_f] = {
                        "data": df[['timestamp', 'open', 'high', 'low', 'close']].values.tolist()
                    }
    elif time_frame == 3:
        for t_f in cfg.TIME_FRAMES_3:
            file_name = os.path.join(p_file_path, f"{stock_name}_{t_f}.csv")
            df = pd.read_csv(file_name)
            df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst=True)
            df['timestamp'] = df['timestamp'].apply(lambda x: x.timestamp() * 1000)
            out_res[t_f] = {
                        "data": df[['timestamp', 'open', 'high', 'low', 'close']].values.tolist()
                    }

    return out_res