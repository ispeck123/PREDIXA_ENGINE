import os
import pandas as pd
from datetime import datetime
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed
from modules.dbconn import raw_query, raw_connection
from modules.calculate_zone import Calculate_BUY_SELL_ZONES
from tqdm import tqdm
from Config import Config as cfg 
import re
import ast


# Ensure output dirs exist
os.makedirs("success", exist_ok=True)
os.makedirs("failed", exist_ok=True)

def clean_order_status(order_status_str: str):
    # Replace Timestamp('...') with just '...'
    cleaned = re.sub(r"Timestamp\('(.*?)'\)", r"'\1'", order_status_str)
    return ast.literal_eval(cleaned)

# ────────────────────────────────────────────────────────────────────────────────
def process_order_for_zones(order, category):
    try:
        stock_name = order.get('stock_tick')
        last_d_time = datetime.strptime(order.get('purchased_cmp_date'), "%Y-%m-%dT%H:%M")
        file_path = os.path.join(cfg.india_data_dir, 'latest_data_csv', f"{stock_name}_sixty.csv")

        # cbsz = Calculate_BUY_SELL_ZONES(csv_path=file_path, tick=stock_name, last_d_time=last_d_time, is_execute=True)
        # df_dz, _ = cbsz.update_new_buy_zones_df()
        # df_sz, _ = cbsz.update_new_sell_zones_df()
        # df = df_dz.combine_first(df_sz)
        df = pd.read_csv(file_path)
        df['tradeDate'] = pd.to_datetime(df['tradeDate'], dayfirst = True)
        df = df[df.tradeDate <= last_d_time]

        if df.empty:
            return None, f"Null data on {category} order {order.get('order_id')}"
        return df, order.get('order_id')
    except Exception as e:
        print(df.columns)
        return None, f"Exception on {category} order {order.get('order_id')}: {e}"

# ────────────────────────────────────────────────────────────────────────────────
def write_dataframe_to_csv(df, order_id, category):
    try:
        out_path = os.path.join(category, f"{order_id}.csv")
        df.to_csv(out_path)
    except Exception as e:
        print(f"Failed to write CSV for {order_id}: {e}")

# ────────────────────────────────────────────────────────────────────────────────
def fetch_auto_orders(status: str):
    # unique_india_order_master
    query = "SELECT * FROM auto_order_master WHERE is_evaluated=1 and time_frame=2"
    res = raw_query(query)

    filtered_orders = []
    for order in res:
        try:
            status_obj = clean_order_status(order['order_status'])
            if status_obj['status'] == status and order.get('order_type').lower() == 'buy':
                filtered_orders.append(order)
        except Exception as e:
            print(f"Skipping order due to error: {e} -- {order['order_status']}")

    return filtered_orders
    # return [
    #     order for order in res
    #     if eval(order['order_status'])['status'] == status and order.get('order_type') == 'Buy'
    # ]

# ────────────────────────────────────────────────────────────────────────────────
def generate_csv_parallel(category: str, status: str):
    orders = fetch_auto_orders(status)
    total = len(orders)
    if total == 0:
        print(f"No {category} orders found.")
        return

    print(f"🚀 Processing {total} {category.upper()} orders...")

    with ProcessPoolExecutor(max_workers=6) as p_pool, ThreadPoolExecutor(max_workers=6) as t_pool:
        futures = {
            p_pool.submit(process_order_for_zones, order, category): order
            for order in orders
        }

        with tqdm(total=total, desc=f"[{category.upper()}] Zone Processing", ncols=100) as pbar_process:
            for future in as_completed(futures):
                try:
                    df, result = future.result()
                    if df is not None:
                        t_pool.submit(write_dataframe_to_csv, df, result, category)
                    else:
                        print(result)
                except Exception as e:
                    print(f"Exception during {category} processing: {e}")
                finally:
                    pbar_process.update(1)

    print(f"✅ {category.capitalize()} CSV generation complete.")

# ────────────────────────────────────────────────────────────────────────────────
# def export_csv():
#     with raw_connection() as connection:
#         chunks = pd.read_sql("select * from auto_order_master;", connection, chunksize=50000)
#         first_chunk = True
#         for chunk in chunks:
#             chunk.to_csv('all_order.csv', mode='w' if first_chunk else 'a', header=first_chunk, index=False)
#             first_chunk = False
if __name__ == "__main__":
    generate_csv_parallel(category="success", status="success")
    generate_csv_parallel(category="failed", status="failed")
    # export_csv()
