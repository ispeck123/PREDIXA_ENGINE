from modules.stock_utils import AUTO_TRADER_RANDOM, AUTO_TRADER_GEN



if __name__ == '__main__':
    AUTO_TRADER_RANDOM(1).start()
    # AUTO_TRADER_GEN(1).start()