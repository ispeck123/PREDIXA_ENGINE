# Install the OpenBB SDK before running:
# pip install openbb

from openbb import obb
import pandas as pd

def download_futures_data(symbol: str, interval: str = "1d", start: str = "2023-01-01", end: str = None):
    """
    Download historical futures data for a given symbol using OpenBB SDK.

    Parameters:
    - symbol (str): The futures symbol (e.g., "ES1!" for S&P500, "NIFTY1!" for Nifty Futures)
    - interval (str): Data interval ('1d', '1wk', etc.)
    - start (str): Start date in 'YYYY-MM-DD' format
    - end (str): End date in 'YYYY-MM-DD' format (optional)
    """
    try:
        # Fetch the futures data
        df = obb.derivatives.futures.historical(
            symbol=symbol,
            interval=interval,
            start_date=start,
            end_date=end
        ).to_dataframe()
        # print(df.)
        if df.empty:
            print(f"No data found for symbol: {symbol}")
        else:
            file_name = f"{symbol.replace('!', '')}_futures_data.csv"
            df.to_csv(file_name)
            print(f"Data saved to {file_name}")

    except Exception as e:
        print(f"Error fetching data for {symbol}: {e}")

# Example usage
if __name__ == "__main__":
    # You can change the symbol here to any supported futures contract
    symbol = "CL"  # Replace with your futures symbol
    download_futures_data(symbol=symbol, interval="1d", start="2024-01-01")
