import requests
from datetime import datetime
from collections import defaultdict

def fetch_motilal_nsefo_scrips():
    url = "https://openapi.motilaloswal.com/rest/report/v1/getscripsbyexchangename"
    payload = {
        "exchangename": "E"
    }
    headers = {
            "Accept": "application/json, text/plain, */*",
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
            # These may be REQUIRED by MO's OpenAPI if you're logged in or using a token:
            # "Authorization": "Bearer YOUR_ACCESS_TOKEN",
            # "x-api-key": "YOUR_API_KEY"
        }

    response = requests.post(url, json=payload, headers=headers)

    if response.status_code != 200:
        raise Exception(f"API Error: {response.status_code} - {response.text}")
    print(response.text)
    data = response.json()

    # The scrips are typically under a 'data' or similar field
    scrips = data.get("data", [])
    return scrips

def categorize_futures_by_expiry(scrips):
    futures = [s for s in scrips if not s.get("cpType")]  # Filter out options

    # Group by expiry date
    expiry_groups = defaultdict(list)
    for s in futures:
        expiry = s.get("expirydate")
        if expiry:
            expiry_date = datetime.strptime(expiry, "%d-%b-%Y")
            expiry_groups[expiry_date].append(s)

    sorted_expiry = sorted(expiry_groups.keys())
    
    categorized = {
        "Near Expiry": expiry_groups.get(sorted_expiry[0], []),
        "Next Expiry": expiry_groups.get(sorted_expiry[1], []) if len(sorted_expiry) > 1 else [],
        "Far Expiry": sum([expiry_groups[e] for e in sorted_expiry[2:]], [])
    }

    return categorized

if __name__ == "__main__":
    # try:
    print("Fetching data from Motilal Oswal API...")
    scrips = fetch_motilal_nsefo_scrips()
    categorized = categorize_futures_by_expiry(scrips)

    print(f"\n✅ Total Futures Found: {sum(len(v) for v in categorized.values())}")
    for key, contracts in categorized.items():
        print(f"\n📦 {key} ({len(contracts)} contracts):")
        for scrip in contracts[:5]:  # show sample of 5 per category
            print(f" - {scrip['scripname']} (Expiry: {scrip['expirydate']})")

    # except Exception as e:
        # print(f"❌ Error: {e}")
