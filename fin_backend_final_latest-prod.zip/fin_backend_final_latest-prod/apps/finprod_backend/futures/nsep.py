from nsepythonserver import expiry_list, derivative_history

expiry_dates = expiry_list("RELIANCE", "list")

latest_expiry = expiry_dates[0]

start_date = "01-04-2025"          # format DD-MM-YYYY
end_date   = "21-04-2025"          # up to current date or desired end date
futures_df = derivative_history("RELIANCE", start_date, end_date, 
                                "futures", latest_expiry)

print(latest_expiry, "OHLC Data (last 5 days):")
print(futures_df[['FH_OPENING_PRICE','FH_TRADE_HIGH_PRICE', 
                  'FH_TRADE_LOW_PRICE','FH_CLOSING_PRICE']].tail(5))
