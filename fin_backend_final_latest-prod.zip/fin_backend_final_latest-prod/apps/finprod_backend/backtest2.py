import pandas as pd
import glob
import os

def detect_order_blocks(df):
    blocks = []
    for i in range(len(df)):
        current = df.iloc[i]
        
        if current['buy_sell_zone_type'] in ['RBR', 'DBR']:
            blocks.append({
                'type': 'bullish',
                'date': current['date'],
                'high': current['high'],
                'low': current['low'],
                'triggered': False
            })
        elif current['buy_sell_zone_type'] in ['DBD', 'RBD']:
            blocks.append({
                'type': 'bearish',
                'date': current['date'],
                'high': current['high'],
                'low': current['low'],
                'triggered': False
            })
    return blocks

def backtest_order_blocks(df, blocks):
    trades = []
    for block in blocks:
        for j in range(len(df)):
            current_candle = df.iloc[j]
            
            if current_candle['date'] <= block['date']:
                continue
            
            if current_candle['high'] >= block['low'] and current_candle['low'] <= block['high']:
                entry_price = current_candle['open']
                entry_date = current_candle['date']
                
                if block['type'] == 'bullish':
                    direction = 'long'
                    sl = block['low']
                    risk = entry_price - sl
                    tp = entry_price + 2 * risk
                else:
                    direction = 'short'
                    sl = block['high']
                    risk = sl - entry_price
                    tp = entry_price - 2 * risk
                
                exit_price, exit_date, status = None, None, 'open'
                for k in range(j + 1, len(df)):
                    candle = df.iloc[k]
                    if direction == 'long':
                        if candle['low'] <= sl:
                            exit_price = sl
                            exit_date = candle['date']
                            status = 'SL'
                            break
                        elif candle['high'] >= tp:
                            exit_price = tp
                            exit_date = candle['date']
                            status = 'TP'
                            break
                    else:
                        if candle['high'] >= sl:
                            exit_price = sl
                            exit_date = candle['date']
                            status = 'SL'
                            break
                        elif candle['low'] <= tp:
                            exit_price = tp
                            exit_date = candle['date']
                            status = 'TP'
                            break
                
                if exit_price is None:
                    exit_price = df.iloc[-1]['close']
                    exit_date = df.iloc[-1]['date']
                    status = 'open'
                
                profit = exit_price - entry_price if direction == 'long' else entry_price - exit_price
                trades.append({
                    'block_type': block['type'],
                    'entry_date': entry_date,
                    'entry_price': entry_price,
                    'exit_date': exit_date,
                    'exit_price': exit_price,
                    'profit': profit,
                    'status': status,
                    'direction': direction,
                    'sl': sl,
                    'tp': tp
                })
                
                block['triggered'] = True
                break
    return trades

def main():
    all_trades = []
    csv_files = glob.glob('./apps/finprod_backend/latest_data_csv/*.csv')
    
    for file in csv_files:
        if 'sixty' not in file:
            continue 
        stock_name = os.path.splitext(os.path.basename(file))[0]
        try:
            print(stock_name)
            df = pd.read_csv(file)
            df['date'] = pd.to_datetime(df['tradeDate'], dayfirst=True)
            df.sort_values('date', inplace=True)
            df.reset_index(drop=True, inplace=True)
            
            blocks = detect_order_blocks(df)
            trades = backtest_order_blocks(df, blocks)
            
            if trades:
                for trade in trades:
                    trade['stock'] = stock_name
                all_trades.extend(trades)
                
        except Exception as e:
            print(f"Error processing {file}: {str(e)}")
            continue

    if not all_trades:
        print("No trades executed across all files.")
        return
    
    trades_df = pd.DataFrame(all_trades)
    
    print("\n=== Overall Performance ===")
    print(f"Total Trades: {len(trades_df)}")
    print(f"Win Rate: {len(trades_df[trades_df['profit'] > 0])/len(trades_df):.2%}")
    print(f"Total Profit: {trades_df['profit'].sum():.2f}")
    print(f"Average Profit: {trades_df['profit'].mean():.2f}")
    print(f"Max Drawdown: {trades_df['profit'].cumsum().cummin().iloc[-1]:.2f}")
    
    print("\n=== Per-Stock Performance ===")
    grouped = trades_df.groupby('stock')
    for stock, group in grouped:
        print(f"\nStock: {stock}")
        print(f"Trades: {len(group)}")
        print(f"Win Rate: {len(group[group['profit'] > 0])/len(group):.2%}")
        print(f"Total Profit: {group['profit'].sum():.2f}")
        print(f"Average Profit: {group['profit'].mean():.2f}")

if __name__ == '__main__':
    main()
