from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta
from modules.cal_s import Calculate_setup_execute
from modules.dbconn import raw_query, get_session
from sqlitedict import SqliteDict
from models.reqmodel import Order
from Config import Config as cfg


db = SqliteDict(cfg.SQLITE_DB)


def insert_buy_alerts(buy_dict, time_fr, stock_name, dt):
    db_order = Order(
            stock_tick=stock_name,
            order_type='Buy',
            time_frame=time_fr,
            entry_price=buy_dict['entry_price'],
            stoploss_price=buy_dict['stop_loss'],
            target_price=buy_dict['target_price'],
            stock_quantity=100,
            purchased_cmp_date=dt.strftime("%Y-%m-%dT%H:%M"),
            purchased_on=datetime.now())
    session = get_session()
    session.add(db_order)
    session.commit()
    session.refresh(db_order)
    return {"order_id": db_order.order_id}


def accumulate_daily_trades():
    india_data = db.get('india', {})
    avl_trades = []
    fss = []
    res = raw_query(f"select * from ind_stock_master where is_active=1")
    with ThreadPoolExecutor(10) as t_pool:
        # for i in range(1, 4):
        for items in res:
            st_name = items.get('stock_tick')
            cse = Calculate_setup_execute(stock_name=st_name, time_frame=1, last_dt=(datetime.now()))
            future_to_input = t_pool.submit(cse.calculate)
            fss.append(future_to_input)

        for futs in fss:
            try:
                result = futs.result()
                print(result, "556565656+565656565656565655656565656565656565656565655666666666666666666666666666")
                if 'BUY_RRR' in result.keys():
                    if result['BUY_RRR'] >= 1.5:
                        avl_trades.append(result)
            except Exception as e:
                print(f"Task for input generated an exception: {e}")
    india_data['daily_trades'] = avl_trades
    # db['india']['daily_trades'] = avl_trades
    db['india'] = india_data 
    db.commit()
   

def accumulate_sixty_trades():
    india_data = db.get('india', {})
    avl_trades = []
    fss = []
    res = raw_query(f"select * from ind_stock_master where is_active=1")
    with ThreadPoolExecutor(10) as t_pool:
        # for i in range(1, 4):
        for items in res:
            st_name = items.get('stock_tick')
            cse = Calculate_setup_execute(stock_name=st_name, time_frame=2, last_dt=(datetime.now()- timedelta(days=2)))
            future_to_input = t_pool.submit(cse.calculate)
            fss.append(future_to_input)
        for futs in fss:
            try:
                result = futs.result()
                if 'BUY_RRR' in result.keys():
                    if result['BUY_RRR'] >= 1.15:
                        avl_trades.append(result)
            except Exception as e:
                print(f"Task for input generated an exception: {e}")
    
    india_data['sixty_trades'] = avl_trades
    db['india'] = india_data 
    db.commit()



def accumulate_fifteen_trades():
    india_data = db.get('india', {})
    avl_trades = []
    fss = []
    res = raw_query(f"select * from ind_stock_master where is_active=1")
    with ThreadPoolExecutor(10) as t_pool:
        # for i in range(1, 4):
        for items in res:
            st_name = items.get('stock_tick')
            cse = Calculate_setup_execute(stock_name=st_name, time_frame=3, last_dt=(datetime.now()- timedelta(days=2)))
            future_to_input = t_pool.submit(cse.calculate)
            fss.append(future_to_input)
        for futs in fss:
            try:
                result = futs.result()
                print(result, "565656565656565656565656565656565656")
                if 'BUY_RRR' in result.keys():
                    if result['BUY_RRR'] >= 1:
                        avl_trades.append(result)
            except Exception as e:
                print(f"Task for input generated an exception: {e}")
    india_data['fifteen_trades'] = avl_trades
    db['india'] = india_data 
    db.commit()


def push_trades_to_order(time_fr : int):
    time_frame = getattr(cfg, f'TIME_FRAMES_{time_fr}')[-1]
    print(time_frame, "*************************************")
    avl_trades = db[f'{time_frame}_trades']
    for items in avl_trades:
        insert_buy_alerts(items['BUY'], time_fr, items['STOCK_NAME'], (datetime.now()- timedelta(days=2)))
    







if __name__ == '__main__':
    # accumulate_daily_trades()
    # for items in db.keys():
    #     print(items)
    # print(db['india'])
    accumulate_sixty_trades()
    # accumulate_fifteen_trades()
    # push_trades_to_order(2)