import os
import pandas as pd
from datetime import datetime
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed
from modules.calculate_setup import Calculate_setup_execute
from modules.stock_handler import get_stock_details
from modules.dbhandler import DBConnection
from models.reqmodel import Ind_StockMaster, Us_StockMaster, auto_order
from Config import Config as cfg

dbc = DBConnection()

def generate_all_trading_day(start_date="2020-04-01", end_date=None):
    if end_date is None:
        end_date = pd.Timestamp.today().strftime('%Y-%m-%d')
    return list(pd.bdate_range(start=start_date, end=end_date)[::-1])  # reversed list

def insert_buy_alerts(buy_dict, time_fr, stock_name, dt, country, country_id, prediction, probability, order_type):
    
    session = dbc.get_session()
    try:
        stock_id = None
        if country.lower() == "india":
            stk = session.query(Ind_StockMaster).filter(Ind_StockMaster.stock_tick == stock_name, Ind_StockMaster.is_active==1).all()
        elif country.lower() == "us":
            stk = session.query(Us_StockMaster).filter(Us_StockMaster.stock_tick == stock_name, Us_StockMaster.is_active==1).all()
        else:
            stk = []
        
        if stk:
            stock_id = stk[0].id

        db_order = auto_order(
            stock_tick=stock_name,
            stock_id=stock_id,
            country_id=country_id,
            time_frame=time_fr,
            order_type=order_type,
            entry_price=buy_dict['entry_price'],
            stoploss_price=buy_dict['stop_loss'],
            target_price=buy_dict['target_price'],
            stock_quantity=100,
            purchased_cmp_date=dt.strftime("%Y-%m-%dT%H:%M"),
            purchased_on=datetime.now(),
            arima_ab_model_prediction=prediction,
            arima_ab_model_prob=probability,
        )
        session.add(db_order)
        session.commit()
        session.refresh(db_order)
        return {"order_id": db_order.order_id}
    except Exception as e:
        print(f"Insert error for {stock_name} on {dt}: {e}")
    finally:
        session.close()

def process_stock_date(stock_name, trading_day):
    try:
        cse = Calculate_setup_execute(stock_name, 1, trading_day, cfg.india_data_dir)
        setups = cse.calculate()
        results = []
        if setups:
            if 'BUY_RRR' in setups and setups['BUY_RRR'] >= 1.5:
                results.append(('Buy', setups['BUY'], setups['STOCK_NAME'], trading_day))
            if 'SELL_RRR' in setups and setups['SELL_RRR'] >= 1.5:
                results.append(('Sell', setups['SELL'], setups['STOCK_NAME'], trading_day))
        return results
    except Exception as e:
        print(f"Error processing {stock_name} at {trading_day}: {e}")
        return []

def run():
    t_days = generate_all_trading_day()
    all_ind_stocks, _ = get_stock_details()
    start_iteration = 50
    chunk_size = 50  # Customize as needed for performance vs concurrency
    max_workers = os.cpu_count() or 4

    # Reverse stocks too if needed for newer ones first
    all_ind_stocks = all_ind_stocks[::-1][:72]
    print(all_ind_stocks)
    total_chunks = (len(t_days) + chunk_size - 1) // chunk_size

    for i in range(0, len(t_days), chunk_size):
        # chunk_days = t_days[i:i+chunk_size]
        current_iteration = i // chunk_size
        # if current_iteration < start_iteration:
        #     continue
        print(f"Processing chunk {current_iteration + 1} of {total_chunks}")
        chunk_days = t_days[i:i+chunk_size]
        tasks = []

        with ProcessPoolExecutor(max_workers=max_workers) as executor:
            for stock in all_ind_stocks:
                for t_day in chunk_days:
                    tasks.append(executor.submit(process_stock_date, stock, t_day.to_pydatetime()))

            for future in as_completed(tasks):
                results = future.result()
                if results:
                    with ThreadPoolExecutor() as db_executor:
                        for order_type, buy_dict, stock_name, dt in results:
                            db_executor.submit(
                                insert_buy_alerts,
                                buy_dict, 1, stock_name, dt, 'india', 1, '', 0.0, order_type
                            )
                            print(f"order_placed for {stock_name} on {dt} [{order_type}]")

if __name__ == '__main__':
    run()
