import schedule
import time
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor
from sqlitedict import SqliteDict

from modules.cal_s import Calculate_setup_execute
from modules.dbconn import raw_query, get_session
from models.reqmodel import Order
from Config import Config as cfg


class TradeAccumulator:
    def __init__(self, db_path=cfg.SQLITE_DB):
        self.db = SqliteDict(db_path)

    def insert_buy_alerts(self, buy_dict, time_fr, stock_name, dt):
        db_order = Order(
            stock_tick=stock_name,
            order_type='Buy',
            time_frame=time_fr,
            entry_price=buy_dict['entry_price'],
            stoploss_price=buy_dict['stop_loss'],
            target_price=buy_dict['target_price'],
            stock_quantity=100,
            purchased_cmp_date=dt.strftime("%Y-%m-%dT%H:%M"),
            purchased_on=datetime.now()
        )
        session = get_session()
        session.add(db_order)
        session.commit()
        session.refresh(db_order)
        return {"order_id": db_order.order_id}

    def accumulate_trades(self, time_frame, db_key, rrr_threshold):
        avl_trades = []
        fss = []
        res = raw_query("SELECT * FROM stock_master WHERE is_active=1")
        with ThreadPoolExecutor(10) as t_pool:
            for item in res:
                st_name = item.get('stock_tick')
                cse = Calculate_setup_execute(
                    stock_name=st_name,
                    time_frame=time_frame,
                    last_dt=(datetime.now() - timedelta(days=2))
                )
                fss.append(t_pool.submit(cse.calculate))

            for fut in fss:
                try:
                    result = fut.result()
                    if 'BUY_RRR' in result and result['BUY_RRR'] >= rrr_threshold:
                        avl_trades.append(result)
                except Exception as e:
                    print(f"Exception in trade calculation: {e}")

        self.db[db_key] = avl_trades
        self.db.commit()

    def accumulate_all(self):
        self.accumulate_trades(time_frame=1, db_key='daily_trades', rrr_threshold=1.5)
        self.accumulate_trades(time_frame=2, db_key='sixty_trades', rrr_threshold=1.15)
        self.accumulate_trades(time_frame=3, db_key='fifteen_trades', rrr_threshold=1)

    def push_trades_to_order(self, time_fr):
        time_frame = getattr(cfg, f'TIME_FRAMES_{time_fr}')[-1]
        avl_trades = self.db.get(f'{time_frame}_trades', [])
        for items in avl_trades:
            self.insert_buy_alerts(items['BUY'], time_fr, items['STOCK_NAME'], datetime.now() - timedelta(days=2))


def job():
    print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] Starting scheduled trade accumulation and push...")
    trade_accumulator = TradeAccumulator()
    trade_accumulator.accumulate_all()
    trade_accumulator.push_trades_to_order(1)
    trade_accumulator.push_trades_to_order(2)
    trade_accumulator.push_trades_to_order(3)
    print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] Trade processing complete.")


if __name__ == '__main__':
    schedule.every().day.at("00:00").do(job)

    print("Scheduler started. Waiting for next run at 12:00 AM.")
    while True:
        schedule.run_pending()
        time.sleep(60)
