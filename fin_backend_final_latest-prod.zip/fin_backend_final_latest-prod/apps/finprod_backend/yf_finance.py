import os
import logging
import pandas as pd
from datetime import datetime, timedelta
from pathlib import Path
import yfinance as yf
from modules.dbhandler import DBConnection
from modules.parse_create_csv import create_75munite_from_15munite

logger = logging.getLogger()

FRAME_DICT = {
    '1mo': 'monthly',
    '1wk': 'weekly',
    '1d': 'daily',
    '60m': 'sixty',
    '15m': 'fifteen'
}

class StockDataDownloader:
    def __init__(self):
        self.output_dir = Path("latest_data_csv")
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.frames = ['1mo', '1wk', '1d', '60m', '15m']
        self.stock_map = self._fetch_stock_info()

    def _fetch_stock_info(self):
        dbc = DBConnection()
        results = dbc.raw_query("SELECT stock_tick, y_finance FROM stock_master WHERE is_active = 1")
        dbc.close_engine()
        return {row['y_finance']: row['stock_tick'] for row in results}

    def _get_date_range(self, frame):
        now = datetime.now()
        if frame in ['1mo', '1wk', '1d']:
            return '2020-01-01', now
        elif frame == '60m':
            return now - timedelta(days=729), now
        elif frame == '15m':
            return now - timedelta(days=59), now

    def download_data(self, ticker, start, end, interval):
        data = yf.download(ticker, start=start, end=end, interval=interval)
        if data.empty:
            logger.warning(f"No data for {ticker} at {interval}")
            return None
        return data

    def format_data(self, df):
        df = df.rename(columns={'Open': 'open', 'High': 'high', 'Low': 'low', 'Close': 'close', 'Volume': 'qty'})
        df.index = pd.to_datetime(df.index)
        df.index = df.index.tz_localize(None)
        df['tradeTime'] = df.index.strftime('%H:%M:%S')
        df['tradeDate'] = df.index.strftime('%d/%m/%Y %H:%M:%S')
        return df[['open', 'high', 'low', 'close', 'qty', 'tradeTime', 'tradeDate']].reset_index(drop=True)

    def _get_file_path(self, tick, interval):
        return self.output_dir / f"{tick}_{FRAME_DICT[interval]}.csv"

    def update_csv_delta(self, df_new, tick, interval):
        file_path = self._get_file_path(tick, interval)
        df_new['tradeDate'] = pd.to_datetime(df_new['tradeDate'], format='%d/%m/%Y %H:%M:%S', errors='coerce')

        if file_path.exists():
            df_existing = pd.read_csv(file_path)
            df_existing['tradeDate'] = pd.to_datetime(df_existing['tradeDate'], format='%d/%m/%Y %H:%M:%S')
            df_existing = df_existing.drop(df_existing.index[-1])  # remove possibly incomplete last row

            last_date = df_existing['tradeDate'].max()
            df_new = df_new[df_new['tradeDate'] > last_date]

            if not df_new.empty:
                df_combined = pd.concat([df_existing, df_new]).drop_duplicates(subset=['tradeDate'])
                df_combined['tradeDate'] = df_combined['tradeDate'].dt.strftime('%d/%m/%Y %H:%M:%S')
                df_combined.to_csv(file_path, index=False)
                print(f"Updated {file_path.name} with {len(df_new)} rows")
        else:
            df_new['tradeDate'] = df_new['tradeDate'].dt.strftime('%d/%m/%Y %H:%M:%S')
            df_new.to_csv(file_path, index=False)
            print(f"Created new file: {file_path.name}")

    def run_downloader(self, delta_only=True):
        for yfin_symbol, tick in self.stock_map.items():
            print(f"Processing: {yfin_symbol}")
            for frame in self.frames:
                start, end = self._get_date_range(frame)
                df = self.download_data(yfin_symbol, start, end, frame)
                if df is None:
                    continue
                formatted_df = self.format_data(df)

                if delta_only:
                    self.update_csv_delta(formatted_df, tick, frame)
                else:
                    file_path = self._get_file_path(tick, frame)
                    formatted_df.to_csv(file_path, index=False)
                    print(f"Overwritten {file_path.name} with full data")

    def generate_75_min_data(self):
        for file in os.listdir(self.output_dir):
            if "fifteen" in file:
                create_75munite_from_15munite(file)


if __name__ == "__main__":
    downloader = StockDataDownloader()
    downloader.run_downloader(delta_only=True)  # for incremental
    downloader.generate_75_min_data()
