from fastapi import FastAPI, Request, Response
from fastapi.responses import RedirectResponse
import plotly.graph_objs as go
import uvicorn
from fastapi.middleware.cors import CORSMiddleware
from shared.config.settings import Config as cfg, validate_required_config
from datetime import datetime
from apps.finprod_backend.modules.alert_model import alert_model
from apps.finprod_backend.modules.utils import utility
from sqlalchemy.orm import Session, sessionmaker
from shared.db.api_responce import APIResponse
from apps.finprod_backend.data_parser.stock_list import *
from apps.finprod_backend.endpoints.user import router as userRouter
from apps.finprod_backend.endpoints.order import router as orderRouter
from apps.finprod_backend.endpoints.stock import router as stockRouter
from apps.finprod_backend.endpoints.token import router as tokenRouter
from apps.finprod_backend.endpoints.candle_stick import router as candleStickRouter
from apps.finprod_backend.endpoints.stock_model import router as stock_model_router_cls
from apps.finprod_backend.endpoints.alert import router as alert_router
from apps.finprod_backend.endpoints.socket_test import router as websocket_router_cls
from apps.finprod_backend.endpoints.news import router as news_router_cls
from apps.finprod_backend.endpoints.available_trades import router as avl_trade_router_cls
from apps.finprod_backend.endpoints.subscription import router as subscriptions_router_cls
from apps.finprod_backend.endpoints.exchange import router as exchange_router_cls
from apps.finprod_backend.endpoints.index_futures import router as future_router_cls
from apps.finprod_backend.endpoints.zone_simulation import router as zone_simulation_router_cls
import logging, pandas, json
from concurrent.futures import ThreadPoolExecutor

logger = logging.getLogger()

app = FastAPI()


origins = ["*"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

validate_required_config()


@app.get("/")
async def index():
    return RedirectResponse("/docs")


    
    # fig_json = json.loads(fig.to_json())
    
    # Return the image as a FastAPI FileResponse
    # return fig_json




app.include_router(userRouter)
app.include_router(orderRouter)
app.include_router(stockRouter)
app.include_router(tokenRouter)
app.include_router(candleStickRouter)
app.include_router(stock_model_router_cls)
app.include_router(alert_router)
app.include_router(websocket_router_cls)
app.include_router(news_router_cls)
app.include_router(avl_trade_router_cls)
app.include_router(subscriptions_router_cls)
app.include_router(exchange_router_cls)
app.include_router(future_router_cls)
app.include_router(zone_simulation_router_cls)


if __name__ == '__main__':
    # uvicorn.run(app, host="0.0.0.0", port=2560)
    gunicorn_cmd = f"gunicorn -w 10 -k uvicorn.workers.UvicornWorker app:app -b 0.0.0.0:2560 --timeout 5000"
    os.system(gunicorn_cmd)

    