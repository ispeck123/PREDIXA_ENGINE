from apps.finprod_backend.modules.stock_utils import AUTO_TRADER_RANDOM, AUTO_TRADER_GEN


# at = AUTO_TRADER_RANDOM(1)
at = AUTO_TRADER_GEN(2)

at.start()