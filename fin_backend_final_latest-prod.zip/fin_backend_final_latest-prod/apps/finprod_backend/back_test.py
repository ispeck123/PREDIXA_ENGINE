from apps.finprod_backend.backtester.engine import BacktestEngine
from apps.finprod_backend.backtester.evaluator import TradeEvaluator
from apps.finprod_backend.backtester.result_analyzer import BacktestAnalyzer
import pandas as pd
from datetime import datetime
import os


stock_name = 'sandp_futures'
time_fr = 1



bt = BacktestEngine(stock_name, time_frame=time_fr, start_date=datetime(2020, 4, 1), end_date=datetime.now())
trades = bt.run()

filepath = os.path.join(os.getcwd(), "apps", "finprod_backend", "processed_data_files", f"{stock_name}_daily.csv") 
price_df = pd.read_csv(filepath)
price_df['timestamp'] = pd.to_datetime(price_df['timestamp'], dayfirst=True)

evaluator = TradeEvaluator(trades, price_df)
evaluated_results = evaluator.evaluate()

analyzer = BacktestAnalyzer(evaluated_results)
analyzer.summary()
analyzer.plot(filename=f'{stock_name}_daily.png')
