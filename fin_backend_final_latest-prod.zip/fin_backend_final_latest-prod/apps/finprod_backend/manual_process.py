from modules.stock_logic import proc_all_stock_items
from threading import Thread
import os, logging
from alert_schedular import trading_task

logger = logging.getLogger()

def all_manual_process():
    try:
        th_list = []
        input_dir = "./latest_data_csv"
        output_dir = "./processed_data_files"
        for stock_item in os.listdir(input_dir):
            # proc_all_stock_items(stock_item, input_dir, output_dir)
            Th = Thread(target=proc_all_stock_items, args=(stock_item, input_dir, output_dir))
            th_list.append(Th)
            Th.start()
        for threa in th_list:
            threa.join()
    except Exception as ex:
        logger.exception(ex, stack_info=True)



# 'ntpc', 'bel', 'bpcl', 'jiofin', 'atgl'

if __name__ == '__main__':
    all_manual_process()
    # proc_stock = ['ntpc', 'bel', 'bpcl', 'jiofin', 'atgl']
    # for stk in proc_stock:
    # proc_single_tick_item('ujjivansfb')
    # trading_task()
    