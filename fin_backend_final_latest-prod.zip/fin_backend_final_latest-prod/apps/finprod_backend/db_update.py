from sqlalchemy import Column, Integer, String, Float, Enum, TIMESTAMP, BigInteger, DateTime, Date, Boolean, UniqueConstraint, ForeignKey, Text, DECIMAL, func
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from pydantic import BaseModel, Field
from datetime import datetime, date
from typing import List
from sqlalchemy import create_engine
from sqlalchemy.orm import Session
from urllib.parse import quote as urlquote


engine = create_engine(
            "mysql+pymysql://root:" + urlquote('Root1234') + "@192.168.1.16/Fin_product",
            pool_recycle = 1800,
            pool_pre_ping = True
        )
    
Base = declarative_base()
Base.metadata.create_all(engine)
class Ind_StockMaster(Base):
    __tablename__ = 'ind_stock_master'

    id = Column(Integer, primary_key=True, autoincrement=True)
    stock_tick = Column(String(255), nullable=False)
    y_finance = Column(String(255), nullable=True)
    is_active = Column(Boolean, default=True)
    index_id = Column(Integer, ForeignKey('index_master.index_id'))


class Us_StockMaster(Base):
    __tablename__ = 'us_stock_master'

    id = Column(Integer, primary_key=True, autoincrement=True)
    stock_tick = Column(String(255), nullable=False)
    y_finance = Column(String(255), nullable=True)
    is_active = Column(Boolean, default=True)
    index_id = Column(Integer, ForeignKey('index_master.index_id'))


class Order(Base):
    __tablename__ = 'order_master'
    order_id = Column(Integer, primary_key=True)
    stock_tick = Column(String(200))
    stock_id = Column(Integer)
    country_id = Column(Integer)
    time_frame = Column(Integer)
    order_type = Column(String(200))
    entry_price = Column(Float)
    stoploss_price = Column(Float)
    target_price = Column(Float)
    stock_quantity = Column(BigInteger)
    purchased_cmp_date = Column(String(200))
    purchased_on = Column(DateTime)
    order_status = Column(String(200))
    is_trade_started = Column(Boolean)
    is_evaluated = Column(Boolean)
    entry_timestamp = Column(DateTime)
    completed_on = Column(DateTime)
    lstm_rf_model_prediction = Column(String(200))
    lstm_rf_model_prob = Column(Float)
    arima_ab_model_prediction = Column(String(200))
    arima_ab_model_prob = Column(Float)

class auto_order(Base):
    __tablename__ = 'auto_order_master'
    order_id = Column(Integer, primary_key=True)
    stock_tick = Column(String(200))
    stock_id = Column(Integer)
    country_id = Column(Integer)
    time_frame = Column(Integer)
    order_type = Column(String(200))
    entry_price = Column(Float)
    stoploss_price = Column(Float)
    target_price = Column(Float)
    stock_quantity = Column(BigInteger)
    purchased_cmp_date = Column(String(200))
    purchased_on = Column(DateTime)
    order_status = Column(String(200))
    is_trade_started = Column(Boolean)
    is_evaluated = Column(Boolean)
    entry_timestamp = Column(DateTime)
    completed_on = Column(DateTime)
    lstm_rf_model_prediction = Column(String(200))
    lstm_rf_model_prob = Column(Float)
    arima_ab_model_prediction = Column(String(200))
    arima_ab_model_prob = Column(Float)


if __name__ == "__main__":    
    session = Session(bind=engine, expire_on_commit=False)
    orders = session.query(Order).all()
    auto_orders = session.query(auto_order).all()
    
    for ordr in orders:
        stk = session.query(Ind_StockMaster).filter(Ind_StockMaster.stock_tick == ordr.stock_tick, Ind_StockMaster.is_active==1).all()
        if len(stk) > 0:
            ordr.stock_id = stk[0].id
            ordr.country_id = 1
            session.add(ordr)
            session.commit()
        else:
            stk = session.query(Us_StockMaster).filter(Us_StockMaster.stock_tick == ordr.stock_tick, Us_StockMaster.is_active==1).all()
            if len(stk) > 0:
                ordr.stock_id = stk[0].id
                ordr.country_id = 3
                session.add(ordr)
                session.commit()

    for ordr in auto_orders:
        stk = session.query(Ind_StockMaster).filter(Ind_StockMaster.stock_tick == ordr.stock_tick, Ind_StockMaster.is_active==1).all()
        if len(stk) > 0:
            ordr.stock_id = stk[0].id
            ordr.country_id = 1
            session.add(ordr)
            session.commit()
        else:
            stk = session.query(Us_StockMaster).filter(Us_StockMaster.stock_tick == ordr.stock_tick, Us_StockMaster.is_active==1).all()
            if len(stk) > 0:
                ordr.stock_id = stk[0].id
                ordr.country_id = 3
                session.add(ordr)
                session.commit()
    session.close()
