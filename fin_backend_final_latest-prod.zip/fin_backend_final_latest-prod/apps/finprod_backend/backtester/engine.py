# backtester/engine.py

from apps.finprod_backend.modules.cal_s import Calculate_setup_execute
from apps.finprod_backend.backtester.evaluator import TradeEvaluator
import pandas as pd
from datetime import datetime, timedelta
from shared.db.db_model import Auto_Order
from modules.dbconn import get_session
from shared.config.settings import Config as cfg

class BacktestEngine:
    def __init__(self, stock_name, time_frame, start_date, end_date):
        self.stock_name = stock_name
        self.time_frame = time_frame
        self.start_date = start_date
        self.end_date = end_date
        self.trades = []
    
    def insert_buy_alerts(self, buy_dict, time_fr, stock_name, dt):
        db_order = Auto_Order(
                stock_tick=stock_name,
                order_type='Buy',
                time_frame=time_fr,
                entry_price=buy_dict['entry_price'],
                stoploss_price=buy_dict['stop_loss'],
                target_price=buy_dict['target_price'],
                stock_quantity=100,
                purchased_cmp_date=dt.strftime("%Y-%m-%dT%H:%M"),
                purchased_on=datetime.now())
        session = get_session()
        session.add(db_order)
        session.commit()
        session.refresh(db_order)
        return {"order_id": db_order.order_id}

    def run(self):
        current_date = self.start_date
        while current_date <= self.end_date:
            print(current_date, self.stock_name, "**********************************")
            try:
                calc = Calculate_setup_execute(self.stock_name, self.time_frame, current_date)
                result = calc.calculate()
                if result and "BUY" in result:
                    trade = result["BUY"]
                    rrr = result["BUY_RRR"]
                    self.trades.append({
                        "date": current_date,
                        "entry": trade['entry_price'],
                        "stop": trade['stop_loss'],
                        "target": trade['target_price'],
                        "rrr": rrr,
                        "duration": result["BUY_TIMESTAMPS"]["extend_timestamp"]
                    })
                    self.insert_buy_alerts(result['BUY'], 1, result['STOCK_NAME'], current_date)
            except Exception as e:
                print(f"Error on {current_date}: {e}")
            current_date += timedelta(days=1)
        return self.trades
