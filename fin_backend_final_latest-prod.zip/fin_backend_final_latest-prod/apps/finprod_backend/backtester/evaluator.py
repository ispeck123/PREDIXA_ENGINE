# backtester/evaluator.py
from datetime import datetime, timedelta

class TradeEvaluator:
    def __init__(self, trade_log, price_df):
        self.trades = trade_log
        self.df = price_df  # Daily price CSV

    def evaluate(self):
        results = []
        for trade in self.trades:
            trade_df = self.df[(self.df['timestamp'] > trade['date']) & 
                               (self.df['timestamp'] <= datetime.fromtimestamp(trade['duration']))]
            hit_target = any(trade_df['high'] >= trade['target'])
            hit_stop = any(trade_df['low'] <= trade['stop'])

            if hit_stop and hit_target:
                outcome = 'mixed'
            elif hit_target:
                outcome = 'win'
            elif hit_stop:
                outcome = 'loss'
            else:
                outcome = 'expired'
            results.append({**trade, "outcome": outcome})
        return results
