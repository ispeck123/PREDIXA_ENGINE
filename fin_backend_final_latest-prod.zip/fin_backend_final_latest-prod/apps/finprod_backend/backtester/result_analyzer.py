# backtester/result_analyzer.py

import pandas as pd
import matplotlib.pyplot as plt

class BacktestAnalyzer:
    def __init__(self, evaluated_results):
        self.df = pd.DataFrame(evaluated_results)

    def summary(self):
        total = len(self.df)
        wins = len(self.df[self.df.outcome == 'win'])
        losses = len(self.df[self.df.outcome == 'loss'])
        expired = len(self.df[self.df.outcome == 'expired'])

        avg_rrr = self.df['rrr'].mean()
        win_rate = round((wins / total) * 100, 2) if total > 0 else 0

        print("Total Trades:", total)
        print("Win Rate:", win_rate, "%")
        print("Average RRR:", round(avg_rrr, 2))
        print("Expired Trades:", expired)
        print("Profit Factor (basic):", round(self.df[self.df.outcome == 'win']['rrr'].sum() /
                                               max(1, self.df[self.df.outcome == 'loss']['rrr'].sum()), 2))

    def plot(self, filename='equity_curve.png'):
        # Simple equity curve
        self.df['profit'] = self.df.apply(
            lambda x: x['rrr'] if x['outcome'] == 'win' else (-1 * x['rrr']), axis=1
        )
        self.df['equity'] = self.df['profit'].cumsum()
        self.df['equity'].plot(title="Equity Curve", figsize=(10, 5))
        plt.figure(figsize=(10, 5))
        plt.plot(self.df['equity'])
        plt.title("Equity Curve")
        plt.grid(True)
        plt.tight_layout()
        plt.savefig(filename)
        plt.close()  # Close the plot to free memory
        
