# import pandas as pd
# import os
# # Read the CSV file into a DataFrame
# path = "processed_data_files_cc"

# file_list = os.listdir(path)

# for items in file_list:

#     df = pd.read_csv(f'processed_data_files_cc/{items}')

#     # Assuming your date column is named 'date_column', you can filter the DataFrame
#     # to keep only rows where the date is on or after January 1, 2020.
#     df = df[pd.to_datetime(df['timestamp'], dayfirst=True).dt.year >= 2020]

#     # Save the filtered DataFrame back to a new CSV file
#     df.to_csv(f'processed_data_files/{items}')
for i in range(1, 4):
    print(i)