import pandas as pd
import ast, csv, os 
from modules.dbconn import raw_query
from modules.calculate_zone import Calculate_BUY_SELL_ZONES
from datetime import datetime
from threading import Thread
import re

def collect_pending_orders():
    query = f"select * from order_master where is_trade_started=0"
    res = raw_query(query)
    pen = []
    for orders in res:
        pen.append(orders.get('order_id'))
    print(pen)

def collect_wrong_predictions():
    query = f"select * from order_master where is_evaluated=1"
    cwp = []
    res = raw_query(query)
    for order in res:
        order_stat = order.get('order_status')
        
        conv_stat = ast.literal_eval(order_stat)
        if conv_stat['status'] == 'success' and order.get('arima_ab_model_prediction') == 'failed':
            cwp.append(order)
        elif conv_stat['status'] == 'failed' and order.get('arima_ab_model_prediction') == 'success':
            cwp.append(order)
    print(len(cwp))
    # for wpo in cwp:
    #     print(wpo.get('order_id'), wpo.get('order_type'))

def get_duration_of_trades():
    succ_list = []
    query = f"select * from auto_order_master where is_evaluated=1"
    res = raw_query(query)
    for orders in res:
        order_stat = ast.literal_eval(orders.get('order_status'))
        if order_stat['status'] == 'success':
            succ_list.append(orders.get('order_id'))
    # print(succ_list)
    for ords in succ_list:
        success_order = raw_query(f'select * from auto_order_master where order_id={ords};')[0]
        start_dt = datetime.strptime(success_order.get('entry_timestamp'), '%Y-%m-%dT%H:%M:%S.%f')
        end_dt = datetime.strptime(success_order.get('completed_on'), '%Y-%m-%dT%H:%M:%S.%f')
        duration = end_dt - start_dt
        duration_in_days = duration.days
        if duration_in_days == 0:
            print(ords)



def get_success_orders():
    # unique_india_order_master
    query = f"select * from auto_order_master where is_evaluated=1 and order_type='Buy' and time_frame=2;"
    res = raw_query(query)
    success_list = []
    for orders in res:
        # if orders.get('order_status')['status'] == 'success':
        order_stat = orders.get('order_status')
        order_stat = re.sub(r"Timestamp\('(.*?)'\)", r"'\1'", order_stat)
        # print(order_stat)
        # print(orders)
        conv_stat = ast.literal_eval(order_stat)
        if conv_stat['status'] == 'success': #orders.get('order_type') == 'Buy'
            success_list.append(orders)
    with open('success.csv', 'w') as csvfile:
    # Creating a csv writer object
        csvwriter = csv.writer(csvfile)
        
        # Writing the headers
        csvwriter.writerow(success_list[0].keys())
        
        # Writing the data rows
        for items in success_list:
            csvwriter.writerow(items.values())
        # csvwriter.writerows(success_list)
    print("success_count:", len(success_list))

def get_auto_success_orders():
    query = f"select * from unique_india_order_master where is_evaluated=1"
    res = raw_query(query)
    print(res)
    success_list = []
    buy_list = []
    sell_list = []
    success_buy_list = []
    success_sell_list = []
    for orders in res:
        # if orders.get('order_status')['status'] == 'success':
        order_stat = orders.get('order_status')
        order_type = orders.get('order_type')
        if order_type == 'Buy':
            buy_list.append(orders) 
        if order_type == 'Sell':
            sell_list.append(orders)

        # print(orders)
        conv_stat = ast.literal_eval(order_stat)
        if conv_stat['status'] == 'success' and order_type == 'Buy': #
            success_list.append(orders)
            success_buy_list.append(orders)

        if conv_stat['status'] == 'success' and order_type == 'Sell': #
            # success_list.append(orders)
            success_sell_list.append(orders)
    with open('success.csv', 'w') as csvfile:
    # Creating a csv writer object
        csvwriter = csv.writer(csvfile)
        
        # Writing the headers
        csvwriter.writerow(success_list[0].keys())
        
        # Writing the data rows
        for items in success_list:
            csvwriter.writerow(items.values())
        # csvwriter.writerows(success_list)
    print("success_count:", len(success_list))
    print("Total_Buy", len(buy_list))
    print("Total buy success", len(success_buy_list))
    print("Total Sell Count", len(sell_list))
    print("Total Sell Success", len(success_sell_list))


def get_failed_orders():
    # unique_india_order_master
    query = f"select * from auto_order_master where is_evaluated=1 and order_type='Buy' and time_frame=2;"
    res = raw_query(query)
    failed_list = []
    for orders in res:
        # if orders.get('order_status')['status'] == 'success':
        order_stat = orders.get('order_status')
        order_stat = re.sub(r"Timestamp\('(.*?)'\)", r"'\1'", order_stat)
        conv_stat = ast.literal_eval(order_stat)
        if conv_stat['status'] == 'failed': # orders.get('order_type') == 'Buy'
            failed_list.append(orders)
    with open('failed.csv', 'w') as csvfile:
    # Creating a csv writer object
        csvwriter = csv.writer(csvfile)
        # Writing the headers
        csvwriter.writerow(failed_list[0].keys())
        # Writing the data rows
        for items in failed_list:
            csvwriter.writerow(items.values())
        # csvwriter.writerows(success_list)
    print("failed_count:", len(failed_list))

def get_auto_failed_orders():
    query = f"select * from unique_india_order_master where is_evaluated=1"
    res = raw_query(query)
    failed_list = []
    for orders in res:
        # if orders.get('order_status')['status'] == 'success':
        order_stat = orders.get('order_status')
        # print(orders)
        conv_stat = ast.literal_eval(order_stat)
        if conv_stat['status'] == 'failed' and orders.get('order_type') == 'Sell':
            failed_list.append(orders)
    with open('failed.csv', 'w') as csvfile:
    # Creating a csv writer object
        csvwriter = csv.writer(csvfile)
        
        # Writing the headers
        csvwriter.writerow(failed_list[0].keys())
        
        # Writing the data rows
        for items in failed_list:
            csvwriter.writerow(items.values())
        # csvwriter.writerows(success_list)
    print("failed_count:", len(failed_list))


def get_success_order_csv_file_ohlc():
    query = f"select * from order_master where is_evaluated=1"
    res = raw_query(query)
    success_list = []
    for orders in res:
        # if orders.get('order_status')['status'] == 'success':
        order_stat = orders.get('order_status')
        # print(orders)
        conv_stat = ast.literal_eval(order_stat)
        if conv_stat['status'] == 'success': # orders.get('order_type') == 'Buy'
            success_list.append(orders)

    for items in success_list:
        stock_name = items.get('stock_tick')
        last_d_time = datetime.strptime(items.get('purchased_cmp_date'), "%Y-%m-%dT%H:%M")
        file_path = os.path.join('processed_data_files', f"{stock_name}_daily.csv")
        # df = pd.read_csv(file_path)
        # df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst = True)
        # df = df[df.timestamp <= last_d_time]
        # df.reset_index(drop=True, inplace=True)
        # df.index = pd.DatetimeIndex(df['timestamp'], dayfirst=True)
        cbsz = Calculate_BUY_SELL_ZONES(csv_path=file_path, tick=stock_name, last_d_time=last_d_time, is_execute=True)
        df_dz, _ = cbsz.update_new_buy_zones_df()
        df_sz, _ = cbsz.update_new_sell_zones_df()

        df = df_dz.combine_first(df_sz)
        # print(df.head())
        if df.empty:
            print("NuLL data on success order {}".format(items.get('order_id')))
        export_file_name = os.path.join('success', f"{items.get('order_id')}.csv")
        df.to_csv(export_file_name)

def get_auto_success_order_csv_file_ohlc():
    query = f"select * from unique_order_master where is_evaluated=1"
    res = raw_query(query)
    success_list = []
    th_list = []
    for orders in res:
        # if orders.get('order_status')['status'] == 'success':
        order_stat = orders.get('order_status')
        # print(orders)
        conv_stat = ast.literal_eval(order_stat)
        if conv_stat['status'] == 'success' and orders.get('order_type') == 'Buy':
            success_list.append(orders)

    for items in success_list:
        # ts = Thread(target=auto_success_multi, args=(items, ))
        # ts.start()
        # th_list.append(ts)
        auto_success_multi(items)
    # for ths in th_list:
    #     ths.join()
        


def get_failed_order_csv_file_ohlc():
    query = f"select * from order_master where is_evaluated=1"
    res = raw_query(query)
    success_list = []
    for orders in res:
        # if orders.get('order_status')['status'] == 'success':
        order_stat = orders.get('order_status')
        # print(orders)
        conv_stat = ast.literal_eval(order_stat)
        if conv_stat['status'] == 'failed': # orders.get('order_type') == 'Buy'
            success_list.append(orders)
    for items in success_list:
        stock_name = items.get('stock_tick')
        last_d_time = datetime.strptime(items.get('purchased_cmp_date'), "%Y-%m-%dT%H:%M")
        file_path = os.path.join('processed_data_files', f"{stock_name}_daily.csv")
        # df = pd.read_csv(file_path)
        # df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst = True)
        # df = df[df.timestamp <= last_d_time]
        # df.reset_index(drop=True, inplace=True)
        # df.index = pd.DatetimeIndex(df['timestamp'], dayfirst=True)
        # print(df.head())
        cbsz = Calculate_BUY_SELL_ZONES(csv_path=file_path, tick=stock_name, last_d_time=last_d_time, is_execute=True)
        df_dz = cbsz.update_new_buy_zones_df()
        df_sz = cbsz.update_new_sell_zones_df()

        df = df_dz.combine_first(df_sz)

        if df.empty:
            print("NuLL data on failed order {}".format(items.get('order_id')))
        export_file_name = os.path.join('failed', f"{items.get('order_id')}.csv")
        df.to_csv(export_file_name)

def get_auto_failed_order_csv_file_ohlc():
    query = f"select * from unique_order_master where is_evaluated=1"
    res = raw_query(query)
    success_list = []
    th_list = []
    for orders in res:
        # if orders.get('order_status')['status'] == 'success':
        order_stat = orders.get('order_status')
        # print(orders)
        conv_stat = ast.literal_eval(order_stat)
        if conv_stat['status'] == 'failed' and orders.get('order_type') == 'Buy':
            success_list.append(orders)
    for items in success_list:
        # ts = Thread(target=auto_failed_multi, args=(items, ))
        auto_failed_multi(items)
        # ts.start()
        # th_list.append(ts)

    # for ths in th_list:
        # ths.join()

        


def auto_success_multi(items : dict):
    stock_name = items.get('stock_tick')
    last_d_time = datetime.strptime(items.get('purchased_cmp_date'), "%Y-%m-%dT%H:%M")
    file_path = os.path.join('processed_data_files', f"{stock_name}_daily.csv")
    # df = pd.read_csv(file_path)
    # df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst = True)
    # df = df[df.timestamp <= last_d_time]
    # df.reset_index(drop=True, inplace=True)
    # df.index = pd.DatetimeIndex(df['timestamp'], dayfirst=True)
    cbsz = Calculate_BUY_SELL_ZONES(csv_path=file_path, tick=stock_name, last_d_time=last_d_time, is_execute=True)
    df_dz, _ = cbsz.update_new_buy_zones_df()
    df_sz, _ = cbsz.update_new_sell_zones_df()
    df = df_dz.combine_first(df_sz)
    # print(df.head())
    if df.empty:
        print("NuLL data on success order {}".format(items.get('order_id')))
    export_file_name = os.path.join('success', f"{items.get('order_id')}.csv")
    df.to_csv(export_file_name)

def auto_failed_multi(items : dict):
    stock_name = items.get('stock_tick')
    last_d_time = datetime.strptime(items.get('purchased_cmp_date'), "%Y-%m-%dT%H:%M")
    file_path = os.path.join('processed_data_files', f"{stock_name}_daily.csv")
    # df = pd.read_csv(file_path)
    # df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst = True)
    # df = df[df.timestamp <= last_d_time]
    # df.reset_index(drop=True, inplace=True)
    # df.index = pd.DatetimeIndex(df['timestamp'], dayfirst=True)
    # print(df.head())
    cbsz = Calculate_BUY_SELL_ZONES(csv_path=file_path, tick=stock_name, last_d_time=last_d_time, is_execute=True)
    df_dz, _ = cbsz.update_new_buy_zones_df()
    df_sz, _ = cbsz.update_new_sell_zones_df()
    df = df_dz.combine_first(df_sz)

    if df.empty:
        print("NuLL data on failed order {}".format(items.get('order_id')))
    export_file_name = os.path.join('failed', f"{items.get('order_id')}.csv")
    df.to_csv(export_file_name)


if __name__ == '__main__':
    get_success_orders()
    get_failed_orders()
    # get_auto_success_orders()
    # get_auto_failed_orders()
    # get_auto_success_order_csv_file_ohlc()
    # get_auto_failed_order_csv_file_ohlc()
    # get_duration_of_trades()
    # get_success_order_csv_file_ohlc()
    # get_failed_order_csv_file_ohlc()
    # collect_wrong_predictions()
    # collect_pending_orders()
    # df = pd.read_csv('processed_data_files/hdfc_daily.csv')
    # # df.reset_index(drop=True, inplace=True)
    # df.index = pd.DatetimeIndex(df['timestamp'], dayfirst=True)
    # df = df.last('3M')
    # df.reset_index(drop=True, inplace=True)
    # df.drop('Unnamed: 0', axis=1)
    # df.to_csv('sample.csv')