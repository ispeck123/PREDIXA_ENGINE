from modules.calculate_setup import Calculate_setup_execute
from datetime import datetime
from Config import Config as cfg
from modules.stock_handler import get_stock_details
from modules.dbhandler import DBConnection
from models.reqmodel import Ind_StockMaster, Us_StockMaster, auto_order
import os
import  pandas as pd

def generate_all_trading_day(start_date="2020-04-01", end_date=None):
    if end_date is None:
        end_date = pd.Timestamp.today().strftime('%Y-%m-%d')
    # Generate a range of business days
    trading_days = pd.bdate_range(start=start_date, end=end_date)
    # print(trading_days)
    return trading_days

def insert_buy_alerts(buy_dict, time_fr, stock_name, dt, country, country_id, prediction, probability, order_type):
    dbc = DBConnection()
    session = dbc.get_session()
    if country.lower() == "india": 
        stk = session.query(Ind_StockMaster).filter(Ind_StockMaster.stock_tick == stock_name, Ind_StockMaster.is_active==1).all()
        stock_id = stk[0].id
    elif country.lower() == "us": 
        stk = session.query(Us_StockMaster).filter(Us_StockMaster.stock_tick == stock_name, Us_StockMaster.is_active==1).all()
        stock_id = stk[0].id
    else:
        stock_id = None
    if stk and len(stk) == 0:
        stock_id = None

    db_order = auto_order(
            stock_tick=stock_name,
            stock_id=stock_id,
            country_id=country_id,
            time_frame=time_fr,
            order_type=order_type,
            entry_price=buy_dict['entry_price'],
            stoploss_price=buy_dict['stop_loss'],
            target_price=buy_dict['target_price'],
            stock_quantity=100,
            purchased_cmp_date=dt.strftime("%Y-%m-%dT%H:%M"),
            purchased_on=datetime.now(),
            arima_ab_model_prediction = prediction,
            arima_ab_model_prob = probability)
    
    session.add(db_order)
    session.commit()
    session.refresh(db_order)
    session.close()
    dbc.close_engine()
    return {"order_id": db_order.order_id}

if __name__ == '__main__':
    # cse = Calculate_setup_execute('hdfcbank', 1, datetime(day=28, month=1, year=2025), cfg.india_data_dir)
    # setup = cse.calculate()
    # print(setup)
    # gasc = get_all_stock_cmp('us')
    # print(gasc)
    t_days = generate_all_trading_day()
    
    all_ind_stocks, _ = get_stock_details()
    for stocks in all_ind_stocks:
        
            # full_stock_path = os.path.join(cfg.india_data_dir, 'processed_data_files', f'{stocks}_daily.csv')
            # print(full_stock_path)
        for trading_days in t_days:
            try:
                cse = Calculate_setup_execute(stocks, 1, trading_days.to_pydatetime(), cfg.india_data_dir)
                setups = cse.calculate()
                if setups is not None:
                    if 'BUY_RRR' in setups.keys():
                        if setups['BUY_RRR'] >= 1.5:
                            insert_buy_alerts(setups['BUY'], 1, setups['STOCK_NAME'], trading_days.to_pydatetime(), 'india', 1, '', 0.0, 'Buy')
                            print('order_placed for *****************************', stocks, trading_days)
                    if 'SELL_RRR' in setups.keys():
                        if setups['SELL_RRR'] >= 1.5:
                            insert_buy_alerts(setups['SELL'], 1, setups['STOCK_NAME'], trading_days.to_pydatetime(), 'india', 1, '', 0.0, 'Sell')
                            print('order_placed for *****************************', stocks, trading_days)
            except:
                pass
                # cse = Calculate_setup_execute()

                
    