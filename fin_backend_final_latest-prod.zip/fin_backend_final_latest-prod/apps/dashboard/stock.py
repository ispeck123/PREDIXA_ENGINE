from fastapi import APIRouter, Request
import logging
from shared.db.req_model import CreateStockModel, SaveDashboard
from shared.db.api_responce import APIResponse
from shared.db.dbconn import DBConnection
from shared.db.db_model import Index, Ind_StockMaster, Us_StockMaster, Ind_StockIndexMap, Us_StockIndexMap, CustomDashboard
from data_fetchers.kiteconnect.kite_session import get_instrument_token
from datetime import datetime
from typing import List
import pandas as pd
from shared.config.settings import fyers_config_credentials as fcc
from sqlalchemy import or_
import re

logger = logging.getLogger()

router = APIRouter()
db = DBConnection()

# @router.post("/add_new_stock", tags=['Stock'])
# async def add_new_stock(request: Request, model: CreateStockModel):
#     apiresponce = APIResponse(request)
#     try:
#         db = DBConnection()
#         session = db.get_session()
#         valid_index_ids = session.query(Index.index_id).filter(Index.index_id.in_(model.index_ids)).all()
#         valid_index_ids = {idx[0] for idx in valid_index_ids}  # Extract IDs from tuples

#         invalid_ids = set(model.index_ids) - valid_index_ids
#         if invalid_ids:
#             apiresponce.setMsg("invalid index")
#             apiresponce.setResponse({"invalid_ids": list(invalid_ids)})
#             session.close()
#             db.close_engine()
#             return apiresponce

#         added = False
#         if model.country.lower().__contains__('us'):
#             db_order = Us_StockMaster(stock_tick=model.stock_name, y_finance=model.y_stock_name)
#             added = True
#         else:
#             instrument_token = get_instrument_token(model.y_stock_name.split('.')[0])
#             if instrument_token:
#                 db_order = Ind_StockMaster(stock_tick=model.stock_name, 
#                                            y_finance=model.y_stock_name, 
#                                            kite_symbol = model.y_stock_name.split('.')[0],
#                                            kite_token = instrument_token)
#                 added = True
#             else:
#                 session.close()
#                 db.close_engine()
#                 apiresponce.setMsg("failed")
#                 apiresponce.setResponse("Instrument token not found for this stock !")
#                 return apiresponce
#         if added:
#             session.add(db_order)
#             session.commit()
#             session.refresh(db_order)

#             index_ids = model.index_ids

#             if model.country.lower().__contains__('us'):
#                 mapping_entries = [
#                             Us_StockIndexMap(stock_id=db_order.id, index_id=idx_id)
#                             for idx_id in index_ids]
#             else:
#                 mapping_entries = [
#                             Ind_StockIndexMap(stock_id=db_order.id, index_id=idx_id)
#                             for idx_id in index_ids]
#             session.add_all(mapping_entries)
#             session.commit()
#             apiresponce.setMsg("success")
#             apiresponce.setResponse({"stock_id": db_order.id, "country" : model.country})
#             session.close()
#             db.close_engine()
#     except Exception as ex:
#         logger.error(ex)
#         apiresponce.setMsg("failed")
#         apiresponce.setResponse(str(ex))
#     return apiresponce


@router.post("/add_new_stock", tags=['Stock'])
async def add_new_stock(request: Request, model: CreateStockModel):
    apiresponce = APIResponse(request)
    try:
        print(model.stock_name)
        if bool(re.search(r'[^A-Za-z0-9_]', model.stock_name)):
            apiresponce.setMsg("failed")
            apiresponce.setResponse("Special characters not supported in stock name !")
            return apiresponce
        
        model.symbol = model.symbol.upper()
        session = db.get_session()
        if model.country.lower().__contains__('us'):
            existing = session.query(Us_StockMaster).filter(Us_StockMaster.y_finance == model.symbol, 
                                                            Us_StockMaster.is_active == 1).all()
        else:
            existing = session.query(Ind_StockMaster).filter(or_(Ind_StockMaster.y_finance == model.symbol,
                                                                 Ind_StockMaster.kite_symbol == model.symbol,
                                                                 Ind_StockMaster.fyers_symbol == model.symbol),
                                                            Ind_StockMaster.is_active == 1).all()
        if existing and len(existing) > 0:
            session.close()
            apiresponce.setMsg("failed")
            apiresponce.setResponse("Stock already exists !")
            return apiresponce
        
        valid_index_ids = session.query(Index.index_id).filter(Index.index_id.in_(model.index_ids)).all()
        valid_index_ids = {idx[0] for idx in valid_index_ids}  # Extract IDs from tuples

        invalid_ids = set(model.index_ids) - valid_index_ids
        if invalid_ids:
            apiresponce.setMsg("invalid index")
            apiresponce.setResponse({"invalid_ids": list(invalid_ids)})
            session.close()
            return apiresponce

        added = False
        if model.country.lower().__contains__('us'):
            db_order = Us_StockMaster(stock_tick=model.stock_name, y_finance=model.symbol)
            added = True
        else:
            y_fin_symbol = model.symbol.split(':')[1]
            y_fin_symbol = y_fin_symbol.split('-')[0]
            instrument_token = get_instrument_token(y_fin_symbol)
            #if instrument_token:
            db_order = Ind_StockMaster(stock_tick = model.stock_name, 
                                        y_finance = f"{y_fin_symbol}.NS", 
                                        kite_symbol = y_fin_symbol,
                                        kite_token = instrument_token,
                                        fyers_symbol = model.symbol)
            added = True
            # else:
            #     session.close()
            #     db.close_engine()
            #     apiresponce.setMsg("failed")
            #     apiresponce.setResponse("Instrument token not found for this stock !")
            #     return apiresponce
        if added:
            session.add(db_order)
            session.commit()
            session.refresh(db_order)

            index_ids = model.index_ids

            if model.country.lower().__contains__('us'):
                mapping_entries = [
                            Us_StockIndexMap(stock_id=db_order.id, index_id=idx_id)
                            for idx_id in index_ids]
            else:
                mapping_entries = [
                            Ind_StockIndexMap(stock_id=db_order.id, index_id=idx_id)
                            for idx_id in index_ids]
            session.add_all(mapping_entries)
            session.commit()
            apiresponce.setMsg("success")
            apiresponce.setResponse({"stock_id": db_order.id, "country" : model.country})
            session.close()
    except Exception as ex:
        logger.exception(ex)
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/search_stock", tags=['Stock'])
async def search_stock(country: str, key: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        key = key.lower()
        response = []
        session = db.get_session()
        if country.lower() == 'us':
            stock = session.query(Us_StockMaster).filter(Us_StockMaster.stock_tick.like(f'{key}%'),
                                                         Us_StockMaster.is_active == 1).first()
            print(stock)
        else:
            stock = session.query(Ind_StockMaster).filter(Ind_StockMaster.stock_tick.like(f'{key}%'),
                                                          Ind_StockMaster.is_active == 1).first()
            print(stock)
        if stock:      
            apiresponce.setMsg("success")
            apiresponce.setResponse(stock)
        else:
            apiresponce.setMsg("failed")
            apiresponce.setResponse("No stock found for the given key")
        session.close()
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.post("/save_custom_dashboard", tags=['Stock'])
async def save_custom_dashboard(models: List[SaveDashboard], request: Request):
    apiresponce = APIResponse(request)
    try:
        session = db.get_session()
        ids = []
        for model in models:
            if model.id:
                row = session.query(CustomDashboard).filter(CustomDashboard.id == model.id).all()
            # else:
            #     row = session.query(CustomDashboard).filter(CustomDashboard.country_id == model.country_id,
            #                                                 CustomDashboard.user_id == model.user_id).all()
            if model.expiry_date:
                model.expiry_date = datetime.strptime(model.expiry_date, "%d-%B-%Y")
                model.expiry_date = datetime.strftime(model.expiry_date, "%Y-%m-%d")
            if model.id and row and len(row) > 0:
                row[0].stock_id = model.stock_id if model.stock_id else row[0].stock_id
                row[0].stock_tick = model.stock_tick if model.stock_tick else row[0].stock_tick
                row[0].future_symbol = model.future_symbol if model.future_symbol else row[0].future_symbol
                row[0].expiry_date = model.expiry_date if model.expiry_date else row[0].expiry_date
                row[0].created_at = datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")
                session.add(row[0])
                session.commit()
                ids.append(row[0].id)
                print("Dashboard saved !")       
            else:
                dashboard = CustomDashboard(user_id = model.user_id, 
                                            country_id = model.country_id,
                                            stock_id = model.stock_id,
                                            stock_tick = model.stock_tick,
                                            future_symbol = model.future_symbol,
                                            expiry_date = model.expiry_date,
                                            created_at = datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S"))
                session.add(dashboard)
                session.commit()
                ids.append(dashboard.id)
                print("Dashboard saved !")
        apiresponce.setMsg("success")
        apiresponce.setResponse({"dashboard_ids": ids})
        session.close()
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/get_custom_dashboard", tags=['Stock'])
async def get_custom_dashboard(request: Request, user_id: str, country_id: str):
    apiresponce = APIResponse(request)
    try:
        session = db.get_session()
        rows = session.query(CustomDashboard).filter(CustomDashboard.country_id == country_id,
                                                    CustomDashboard.user_id == user_id).order_by(CustomDashboard.created_at.desc()).all()
        
        if rows and len(rows) > 0:
            for row in rows:
                if row.stock_id and row.stock_tick:
                    row.type = "stock"
                elif row.future_symbol and row.expiry_date:
                    row.type = "future"
                if row.expiry_date:
                    row.expiry_date = datetime.strftime(row.expiry_date, "%d-%B-%Y")
            #print(rows)
            apiresponce.setMsg("success")
            apiresponce.setResponse(rows)
                    
        else:
            apiresponce.setMsg("failed")
            apiresponce.setResponse("Not found !")
        session.close()
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce

@router.get("/get_fyers_symbol", tags=['Stock'])
async def get_fyers_symbol(symbol: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        symbol = symbol.upper()
        # Download and load the CSV (you can cache this locally)
        df = pd.read_csv(fcc.SYMBOL_CSV_URL, header=None, usecols=[1, 9])
        matches = df[
                df[9].str.upper().str.contains(symbol)
            ]
        found_symbols = [{"symbol": s, "name": str(n).replace(" ", "_")} for n, s in zip(matches[1].values, matches[9].values)]
        #print(found_symbols)
        if len(found_symbols) > 0:      
            apiresponce.setMsg("success")
            apiresponce.setResponse({"match_symbols": found_symbols})
        else:
            apiresponce.setMsg("failed")
            apiresponce.setResponse("No symbol found !")

    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/get_fyers_future_symbol", tags=['Stock'])
async def get_fyers_future_symbol(symbol: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        symbol = symbol.upper()
        # Download and load the CSV (you can cache this locally)
        df = pd.read_csv(fcc.FUTURE_SYMBOL_CSV_URL, header=None, usecols=[1, 9])

        # symbol column
        df[9] = df[9].astype(str)
        df[1] = df[1].astype(str)

        matches = df[
                df[9].str.match(rf"NSE:{symbol}\d{{2}}[A-Za-z]+FUT$", na=False)
            ]
        found_symbols = [{"symbol": s, "name": str(n).replace(" ", "_")} for n, s in zip(matches[1].values, matches[9].values)]
        #print(found_symbols)
        if len(found_symbols) > 0:      
            apiresponce.setMsg("success")
            apiresponce.setResponse({"match_symbols": found_symbols})
        else:
            apiresponce.setMsg("failed")
            apiresponce.setResponse("No symbol found !")

    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/get_fyers_commodity_symbol", tags=['Stock'])
async def get_fyers_commodity_symbol(symbol: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        symbol = symbol.upper()
        # Download and load the CSV (you can cache this locally)
        df = pd.read_csv(fcc.COMMODITY_SYMBOL_CSV_URL, header=None, usecols=[1, 9])

        # symbol column
        df[9] = df[9].astype(str)
        df[1] = df[1].astype(str)

        df = df[df[9].astype(str).str.contains(f"MCX:{symbol}", na=False)]
        df = df[df[9].astype(str).str.contains("FUT", na=False)]

        found_symbols = [{"symbol": s, "name": str(n).replace(" ", "_")} for n, s in zip(df[1].values, df[9].values)]
        #print(found_symbols)
        if len(found_symbols) > 0:      
            apiresponce.setMsg("success")
            apiresponce.setResponse({"match_symbols": found_symbols})
        else:
            apiresponce.setMsg("failed")
            apiresponce.setResponse("No symbol found !")

    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce