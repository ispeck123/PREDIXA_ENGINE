from fastapi import APIRouter, Request
from shared.db.req_model import AddTickerTape
from shared.db.db_model import TickerTape
from shared.db.api_responce import APIResponse
from shared.db.dbconn import DBConnection
import logging

logger = logging.getLogger()

router = APIRouter()
db = DBConnection()

@router.post("/add/new/ticker/tape", tags = ["Ticker Tape"])
async def add_new_ticker_tape(request: Request, model: AddTickerTape):
    apiresponce = APIResponse(request)
    try:
        session = db.get_session()
        row = TickerTape(
            stock_tick = model.stock_tick,
            expiry_date = model.expity_date,
            fyers_symbol = model.fyers_symbol,
            exchange_id = model.exchange_id,
            exchange = model.exchange,
            order = model.order,
            status = True
        )
        session.add(row)
        session.commit()
        session.close()
        apiresponce.setMsg("success")
        apiresponce.setResponse(row)
    except Exception as ex:
        logger.exception(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce