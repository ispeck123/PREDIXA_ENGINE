# import os, sys
# sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
# from apps.dashboard.index_scraper import index_scraper
# import threading
# from apps.dashboard.index_scraper import run_kite_socket# routes.py (part of FastAPI)

# from time import sleep

# # Start Kite WebSocket in background
# threading.Thread(target=run_kite_socket, daemon=True).start()

# index_scraper()
# while True:
#     sleep(2)



# import os, sys
# sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse
import asyncio
import json
import logging
import os
import sys
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import RedirectResponse
#import threading
#from apps.dashboard.index_scraper import run_kite_socket, index_scraper
#from apps.dashboard.price_store import get_stocks_list
#from apps.dashboard.index_scraper import get_stock_price_from_kite
import uvicorn
from shared.db.dbconn import DBConnection
from shared.db.db_model import User
from apps.dashboard.stock import router as stock_router
from apps.dashboard.candle import router as candle_router
from apps.dashboard.websocket_server import router as websocket_router
from data_fetchers.fyers.get_stock_prices import StockPriceFetcher
# from data_fetchers.fyers.fyers_ticker import FyersTickerManager
import time
from datetime import datetime
from apps.dashboard.ticker_tape import router as ticker_tape_router
from shared.config.settings import validate_required_config

# LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()

# logging.basicConfig(
#     level=getattr(logging, LEVEL, logging.INFO),
#     format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
#     handlers=[logging.StreamHandler(sys.stdout)],
# )

logger = logging.getLogger()
db = DBConnection()
# fyt = FyersTickerManager()
syt = StockPriceFetcher()
# Start Kite WebSocket in background
# threading.Thread(target=run_kite_socket, daemon=True).start()

app = FastAPI()

origins = ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

validate_required_config()

@app.get("/")
async def index():
    return RedirectResponse("/docs")



@app.get("/stock_live_prices")
async def stock_live_prices_page(index_id: int = 1, 
                         user_id: int = 1,
                         stock_exchange: str = "NSE", 
                         search_key: str = '', 
                         page_no: str = '', 
                         limit: int = 10):
    html = f"""
    <html>
    <head>
        <title>Stock Live Prices</title>
        <style>
            table {{
                border-collapse: collapse;
                width: 80%;
                margin: auto;
            }}
            th, td {{
                border: 1px solid #999;
                padding: 8px;
                text-align: center;
            }}
            th {{
                background-color: #f2f2f2;
            }}
            .positive {{
                color: green;
                font-weight: bold;
            }}
            .negative {{
                color: red;
                font-weight: bold;
            }}
        </style>
    </head>
    <body>
        <h2 style="text-align: center;">Live Prices of Stocks</h2>
        <div style="text-align:center;"><strong>Total Stocks:</strong> <span id="total-stocks">Loading...</span></div>
        <div style="text-align:center;"><strong>Page No:</strong> <span id="page-no">Loading...</span></div>
        <br>
        <table>
            <thead>
                <tr>
                    <th>Stock Id</th>
                    <th>Stock</th>
                    <th>Price</th>
                    <th>Previous Close</th>
                    <th>Day Change</th>
                    <th>Day Change %</th>
                    <th>Watchlist Id</th>
                </tr>
            </thead>
            <tbody id="data">
                <tr><td colspan="7">Waiting for data...</td></tr>
            </tbody>
        </table>

        <script>
            const index_id = {index_id};
            const user_id = {user_id};
            const stock_exchange = "{stock_exchange}";
            const search_key = "{search_key}";
            const page_no = "{page_no}";
            const limit = {limit};
            const ws = new WebSocket(`ws://192.168.1.16:9000/ws/stock_live_prices?index_id={index_id}&user_id={user_id}&stock_exchange={stock_exchange}&search_key={search_key}&page_no={page_no}&limit={limit}`);

            ws.onmessage = function(event) {{
                let response = JSON.parse(event.data);
                let data = response.stocks;
                let totalStocks = response.total_stocks;
                let pageNo = response.page_no;

                document.getElementById("total-stocks").textContent = totalStocks;
                document.getElementById("page-no").textContent = pageNo;

                let body = document.getElementById("data");
                body.innerHTML = "";

                for (let row of data) {{
                    let changeClass = row.day_change.startsWith("+") ? "positive" : "negative";

                    body.innerHTML += `<tr>
                        <td>${{row.stock_id}}</td>
                        <td>${{row.stock}}</td>
                        <td>${{row.price}}</td>
                        <td>${{row.prev_close}}</td>
                        <td class="${{changeClass}}">${{row.day_change}}</td>
                        <td class="${{changeClass}}">${{row.day_change_percentage}}</td>
                        <td>${{row.watchlist_id}}</td>
                    </tr>`;
                }}
            }};

            ws.onerror = function(event) {{
                console.error("WebSocket error:", event);
            }};

            ws.onclose = function() {{
                console.log("WebSocket closed");
            }};
        </script>
    </body>
    </html>
    """
    return HTMLResponse(html)


@app.websocket("/ws/stock_live_prices")
async def stock_live_prices(websocket: WebSocket, 
                         index_id: int = 1, 
                         user_id: int = 1,
                         stock_exchange: str = "NSE", 
                         search_key: str = None, 
                         page_no: str = None, 
                         limit: int = 10):
    await websocket.accept()
    try:
        while True:
            try:
                page_no = int(page_no)
            except Exception as er:
                page_no = None
                print("page_no:", page_no)
            
            #db = DBConnection()
            total_stocks = db.raw_query(f"""select ism.id, ism.stock_tick, ism.y_finance, ism.fyers_symbol, w.id as watchlist_id
                                  from ind_stock_master ism
                                  inner join ind_stock_index_map isim on ism.id = isim.stock_id
                                  left join watchlist w on ism.id = w.ind_stock_id
                                  where ism.is_active = 1 and ism.fyers_symbol is not null 
                                  and isim.index_id = {index_id}
                                  and (w.user_id = {user_id} or w.user_id is null)
                                  order by ism.stock_tick""")
            if total_stocks == None:
                total_stocks = []
            
            stocks = []
            if (search_key == None or search_key == 'null' or search_key == '') and (page_no == None or page_no == 'null' or page_no == ''):
                page_no = 1
                offset = (page_no - 1) * limit
                stocks = db.raw_query(f"""select ism.id, ism.stock_tick, ism.y_finance, ism.fyers_symbol, w.id as watchlist_id
                                  from ind_stock_master ism
                                  inner join ind_stock_index_map isim on ism.id = isim.stock_id
                                  left join watchlist w on ism.id = w.ind_stock_id
                                  where ism.is_active = 1 and ism.fyers_symbol is not null 
                                  and isim.index_id = {index_id}
                                  and (w.user_id = {user_id} or w.user_id is null)
                                  order by ism.stock_tick limit {limit} offset {offset}""")
                
            elif (search_key == None or search_key == 'null' or search_key == '') and (page_no != None and page_no != 'null' and page_no != ''):
                offset = (page_no - 1) * limit
                stocks = db.raw_query(f"""select ism.id, ism.stock_tick, ism.y_finance, ism.fyers_symbol, w.id as watchlist_id
                                  from ind_stock_master ism
                                  inner join ind_stock_index_map isim on ism.id = isim.stock_id
                                  left join watchlist w on ism.id = w.ind_stock_id
                                  where ism.is_active = 1 and ism.fyers_symbol is not null 
                                  and isim.index_id = {index_id}
                                  and (w.user_id = {user_id} or w.user_id is null)
                                  order by ism.stock_tick limit {limit} offset {offset}""")
            
            elif (search_key != None and search_key != 'null' and search_key != '') and (page_no == None or page_no == 'null' or page_no == ''):
                found = False
                for i in range(len(total_stocks)):
                    if search_key.lower() in total_stocks[i]['stock_tick'].lower():
                        found = i+1
                        break
                #print("found:", found)
                if found:
                    page_no = ((found - 1) // limit) + 1
                    offset = (page_no - 1) * limit
                    stocks = db.raw_query(f"""select ism.id, ism.stock_tick, ism.y_finance, ism.fyers_symbol, w.id as watchlist_id
                                  from ind_stock_master ism
                                  inner join ind_stock_index_map isim on ism.id = isim.stock_id
                                  left join watchlist w on ism.id = w.ind_stock_id
                                  where ism.is_active = 1 and ism.fyers_symbol is not null 
                                  and isim.index_id = {index_id}
                                  and (w.user_id = {user_id} or w.user_id is null)
                                  order by ism.stock_tick limit {limit} offset {offset}""")
            
            elif (search_key != None and search_key != 'null' and search_key != '') and (page_no != None and page_no != 'null' and page_no != ''):
                offset = (page_no - 1) * limit
                stocks = db.raw_query(f"""select ism.id, ism.stock_tick, ism.y_finance, ism.fyers_symbol, w.id as watchlist_id
                                  from ind_stock_master ism
                                  inner join ind_stock_index_map isim on ism.id = isim.stock_id
                                  left join watchlist w on ism.id = w.ind_stock_id
                                  where ism.is_active = 1 and ism.fyers_symbol is not null 
                                  and isim.index_id = {index_id}
                                  and (w.user_id = {user_id} or w.user_id is null)
                                  order by ism.stock_tick limit {limit} offset {offset}""")
            #print(stocks)    
            if stocks != None and len(stocks) > 0:
                # print(stocks)
                #print("before fyers connection")

                data = await syt.get_stock_price_from_fyers(stocks)
                # print(datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"), "Printing data")
                #print("data------------", data)
            else:
                data = []
                #print("data------------", data)
            # db.close_engine()
            #logger.info("data------------", data)
            if data:
                # print(datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"), "Sending data to WebSocket")
                await websocket.send_json({"total_stocks": len(total_stocks), "stocks": data, "page_no": page_no})
            else:
                await websocket.send_text("Error fetching stock price")
            await asyncio.sleep(5)
    except WebSocketDisconnect as ex:
        #logger.exception(ex, exc_info=True, stack_info=True)
        print("WebSocket Error: Client disconnected from price WebSocket")
    except asyncio.CancelledError:
        return
    except Exception as e:
        logger.exception(e, exc_info=True, stack_info=True)
        print("WebSocket Error:", e)
    # finally:
        # db.close_engine()

# @app.websocket("/ws/kite_prices")
# async def kite_prices_ws(websocket: WebSocket, index_id: int = None):
#     await websocket.accept()
#     try:
#         while True:
#             #with price_lock:
#                 data = index_scraper()
#                 # price_data = get_stocks_list()
#                 # data = json.dumps(price_data, default=str)
#                 print(data)
#                 if data:
#                     await websocket.send_text(data)
#                 else:
#                     await websocket.send_text(json.dumps({}))
#                 await asyncio.sleep(10)
#     except WebSocketDisconnect:
#         print("Client disconnected from price WebSocket")
#     except Exception as e:
#         print("WebSocket Error:", e)


@app.get("/stock_live_prices/watchlist")
async def stock_live_prices_watchlist(
                         user_id: int = 1,
                         country_id: int = 1, 
                         stock_exchange: str = "NSE", 
                         search_key: str = '', 
                         page_no: str = '', 
                         limit: int = 10):
    html = f"""
    <html>
    <head>
        <title>Stock Live Prices</title>
        <style>
            table {{
                border-collapse: collapse;
                width: 80%;
                margin: auto;
            }}
            th, td {{
                border: 1px solid #999;
                padding: 8px;
                text-align: center;
            }}
            th {{
                background-color: #f2f2f2;
            }}
            .positive {{
                color: green;
                font-weight: bold;
            }}
            .negative {{
                color: red;
                font-weight: bold;
            }}
        </style>
    </head>
    <body>
        <h2 style="text-align: center;">Live Prices of Stocks</h2>
        <div style="text-align:center;"><strong>Total Stocks:</strong> <span id="total-stocks">Loading...</span></div>
        <div style="text-align:center;"><strong>Page No:</strong> <span id="page-no">Loading...</span></div>
        <br>
        <table>
            <thead>
                <tr>
                    <th>Stock Id</th>
                    <th>Stock</th>
                    <th>Price</th>
                    <th>Previous Close</th>
                    <th>Day Change</th>
                    <th>Day Change %</th>
                    <th>Watchlist Id</th>
                </tr>
            </thead>
            <tbody id="data">
                <tr><td colspan="7">Waiting for data...</td></tr>
            </tbody>
        </table>

        <script>
            const user_id = {user_id};
            const country_id = {country_id};
            const stock_exchange = "{stock_exchange}";
            const search_key = "{search_key}";
            const page_no = "{page_no}";
            const limit = {limit};
            const ws = new WebSocket(`ws://192.168.1.16:9000/ws/stock_live_prices/watchlist?user_id={user_id}&country_id={country_id}&stock_exchange={stock_exchange}&search_key={search_key}&page_no={page_no}&limit={limit}`);

            ws.onmessage = function(event) {{
                let response = JSON.parse(event.data);
                let data = response.stocks;
                let totalStocks = response.total_stocks;
                let pageNo = response.page_no;

                document.getElementById("total-stocks").textContent = totalStocks;
                document.getElementById("page-no").textContent = pageNo;

                let body = document.getElementById("data");
                body.innerHTML = "";

                for (let row of data) {{
                    let changeClass = row.day_change.startsWith("+") ? "positive" : "negative";

                    body.innerHTML += `<tr>
                        <td>${{row.stock_id}}</td>
                        <td>${{row.stock}}</td>
                        <td>${{row.price}}</td>
                        <td>${{row.prev_close}}</td>
                        <td class="${{changeClass}}">${{row.day_change}}</td>
                        <td class="${{changeClass}}">${{row.day_change_percentage}}</td>
                        <td>${{row.watchlist_id}}</td>
                    </tr>`;
                }}
            }};

            ws.onerror = function(event) {{
                console.error("WebSocket error:", event);
            }};

            ws.onclose = function() {{
                console.log("WebSocket closed");
            }};
        </script>
    </body>
    </html>
    """
    return HTMLResponse(html)


@app.websocket("/ws/stock_live_prices/watchlist")
async def stock_live_prices_ws_watchlist(websocket: WebSocket,
                         user_id: int = 1,
                         country_id: int = 1, 
                         stock_exchange: str = "NSE", 
                         search_key: str = None, 
                         page_no: str = None, 
                         limit: int = 10):
    await websocket.accept()
    try:
        
        #db = DBConnection()
        session = db.get_session()
        user = session.query(User).filter(User.id == user_id).first()
        if not user:
            session.close()
            db.close_engine()
            await websocket.send_text("User not found")
            return

        while True:

            try:
                page_no = int(page_no)
            except Exception as er:
                #print("page_no:", page_no)
                page_no = None
            
            total_stocks = db.raw_query(f"""select ism.id, ism.stock_tick, ism.y_finance, ism.fyers_symbol, w.id as watchlist_id
                                        from ind_stock_master ism
                                        inner join watchlist w on ism.id = w.ind_stock_id
                                        where ism.is_active = 1 and w.user_id = {user_id} 
                                        and w.country_id = {country_id}
                                        order by ism.stock_tick""")
            if total_stocks == None:
                total_stocks = []
            
            stocks = []
            if (search_key == None or search_key == 'null' or search_key == '') and (page_no == None or page_no == 'null' or page_no == ''):
                page_no = 1
                offset = (page_no - 1) * limit
                stocks = db.raw_query(f"""select ism.id, ism.stock_tick, ism.y_finance, ism.fyers_symbol, w.id as watchlist_id
                                        from ind_stock_master ism
                                        inner join watchlist w on ism.id = w.ind_stock_id
                                        where ism.is_active = 1 and w.user_id = {user_id} 
                                        and w.country_id = {country_id}
                                        order by ism.stock_tick limit {limit} offset {offset}""")
                
            elif (search_key == None or search_key == 'null' or search_key == '') and (page_no != None and page_no != 'null' and page_no != ''):
                offset = (page_no - 1) * limit
                stocks = db.raw_query(f"""select ism.id, ism.stock_tick, ism.y_finance, ism.fyers_symbol, w.id as watchlist_id
                                        from ind_stock_master ism
                                        inner join watchlist w on ism.id = w.ind_stock_id
                                        where ism.is_active = 1 and w.user_id = {user_id} 
                                        and w.country_id = {country_id}
                                        order by ism.stock_tick limit {limit} offset {offset}""")
            
            elif (search_key != None and search_key != 'null' and search_key != '') and (page_no == None or page_no == 'null' or page_no == ''):
                found = False
                for i in range(len(total_stocks)):
                    if total_stocks[i]['stock_tick'].lower().startswith(search_key.lower()):
                        found = i+1
                        break
                if not found:
                    for i in range(len(total_stocks)):
                        if search_key.lower() in total_stocks[i]['stock_tick'].lower():
                            found = i+1
                            break
                #print("found:", found)
                if found:
                    page_no = ((found - 1) // limit) + 1
                    offset = (page_no - 1) * limit
                    stocks = db.raw_query(f"""select ism.id, ism.stock_tick, ism.y_finance, ism.fyers_symbol, w.id as watchlist_id
                                        from ind_stock_master ism
                                        inner join watchlist w on ism.id = w.ind_stock_id
                                        where ism.is_active = 1 and w.user_id = {user_id} 
                                        and w.country_id = {country_id}
                                        order by ism.stock_tick limit {limit} offset {offset}""")
            
            elif (search_key != None and search_key != 'null' and search_key != '') and (page_no != None and page_no != 'null' and page_no != ''):
                offset = (page_no - 1) * limit
                stocks = db.raw_query(f"""select ism.id, ism.stock_tick, ism.y_finance, ism.fyers_symbol, w.id as watchlist_id
                                        from ind_stock_master ism
                                        inner join watchlist w on ism.id = w.ind_stock_id
                                        where ism.is_active = 1 and w.user_id = {user_id} 
                                        and w.country_id = {country_id}
                                        order by ism.stock_tick limit {limit} offset {offset}""")
                
            if stocks != None and len(stocks) > 0:
                data = await syt.get_stock_price_from_fyers(stocks)
            else:
                data = []
            #print(data)
            db.close_engine()
            if data:
                await websocket.send_json({"total_stocks": len(total_stocks), "stocks": data, "page_no": page_no})
            else:
                await websocket.send_text("Error fetching stock price")
            await asyncio.sleep(5)
    except WebSocketDisconnect:
        print("WebSocket Error: Client disconnected from price WebSocket")
    except asyncio.CancelledError:
        return
    except Exception as e:
        logger.exception(e, exc_info=True, stack_info=True)
        print("WebSocket Error:", e)
    # finally:
    #     db.close_engine()


@app.get("/ind_stock_live_prices")
async def ind_stock_live_prices_page(stock_exchange: str = "NSE", 
                         user_id: int = 1, 
                         search_key: str = '', 
                         page_no: str = '', 
                         limit: int = 10):
    html = f"""
    <html>
    <head>
        <title>Stock Live Prices</title>
        <style>
            table {{
                border-collapse: collapse;
                width: 80%;
                margin: auto;
            }}
            th, td {{
                border: 1px solid #999;
                padding: 8px;
                text-align: center;
            }}
            th {{
                background-color: #f2f2f2;
            }}
            .positive {{
                color: green;
                font-weight: bold;
            }}
            .negative {{
                color: red;
                font-weight: bold;
            }}
        </style>
    </head>
    <body>
        <h2 style="text-align: center;">Live Prices of Stocks</h2>
        <div style="text-align:center;"><strong>Total Stocks:</strong> <span id="total-stocks">Loading...</span></div>
        <div style="text-align:center;"><strong>Page No:</strong> <span id="page-no">Loading...</span></div>
        <br>
        <table>
            <thead>
                <tr>
                    <th>Stock Id</th>
                    <th>Stock</th>
                    <th>Price</th>
                    <th>Previous Close</th>
                    <th>Day Change</th>
                    <th>Day Change %</th>
                </tr>
            </thead>
            <tbody id="data">
                <tr><td colspan="6">Waiting for data...</td></tr>
            </tbody>
        </table>

        <script>
            const stock_exchange = "{stock_exchange}";
            const search_key = "{search_key}";
            const page_no = "{page_no}";
            const limit = {limit};
            const ws = new WebSocket(`ws://192.168.1.16:9000/ws/ind_stock_live_prices?stock_exchange={stock_exchange}&search_key={search_key}&page_no={page_no}&limit={limit}`);

            ws.onmessage = function(event) {{
                let response = JSON.parse(event.data);
                let data = response.stocks;
                let totalStocks = response.total_stocks;
                let pageNo = response.page_no;

                document.getElementById("total-stocks").textContent = totalStocks;
                document.getElementById("page-no").textContent = pageNo;

                let body = document.getElementById("data");
                body.innerHTML = "";

                for (let row of data) {{
                    let changeClass = row.day_change.startsWith("+") ? "positive" : "negative";

                    body.innerHTML += `<tr>
                        <td>${{row.stock_id}}</td>
                        <td>${{row.stock}}</td>
                        <td>${{row.price}}</td>
                        <td>${{row.prev_close}}</td>
                        <td class="${{changeClass}}">${{row.day_change}}</td>
                        <td class="${{changeClass}}">${{row.day_change_percentage}}</td>
                    </tr>`;
                }}
            }};

            ws.onerror = function(event) {{
                console.error("WebSocket error:", event);
            }};

            ws.onclose = function() {{
                console.log("WebSocket closed");
            }};
        </script>
    </body>
    </html>
    """
    return HTMLResponse(html)

@app.websocket("/ws/ind_stock_live_prices")
async def ind_stock_live_prices_ws(websocket: WebSocket, 
                         stock_exchange: str = "NSE",
                         user_id: int = 1, 
                         search_key: str = None, 
                         page_no: str = None, 
                         limit: int = 10):
    await websocket.accept()
    try:
        while True:
            
            try:
                page_no = int(page_no)
            except Exception as er:
                #print("page_no:", page_no)
                page_no = None
            
            #db = DBConnection()
            total_stocks = db.raw_query(f"""select * from ind_stock_master 
                                  where is_active = 1 and fyers_symbol is not null 
                                  order by stock_tick""")
            if total_stocks == None:
                total_stocks = []
            
            stocks = []
            if (search_key == None or search_key == 'null' or search_key == '') and (page_no == None or page_no == 'null' or page_no == ''):
                page_no = 1
                offset = (page_no - 1) * limit
                stocks = db.raw_query(f"""select * from ind_stock_master 
                                  where is_active = 1 and fyers_symbol is not null 
                                  order by stock_tick limit {limit} offset {offset}""")
                
            elif (search_key == None or search_key == 'null' or search_key == '') and (page_no != None and page_no != 'null' and page_no != ''):
                offset = (page_no - 1) * limit
                stocks = db.raw_query(f"""select * from ind_stock_master 
                                  where is_active = 1 and fyers_symbol is not null 
                                  order by stock_tick limit {limit} offset {offset}""")
            
            elif (search_key != None and search_key != 'null' and search_key != '') and (page_no == None or page_no == 'null' or page_no == ''):
                found = False
                for i in range(len(total_stocks)):
                    if search_key.lower() in total_stocks[i]['stock_tick'].lower():
                        found = i+1
                        break
                #print("found:", found)
                if found:
                    page_no = ((found - 1) // limit) + 1
                    offset = (page_no - 1) * limit
                    stocks = db.raw_query(f"""select * from ind_stock_master 
                                  where is_active = 1 and fyers_symbol is not null 
                                  order by stock_tick limit {limit} offset {offset}""")
            
            elif (search_key != None and search_key != 'null' and search_key != '') and (page_no != None and page_no != 'null' and page_no != ''):
                offset = (page_no - 1) * limit
                stocks = db.raw_query(f"""select * from ind_stock_master 
                                  where is_active = 1 and fyers_symbol is not null 
                                  order by stock_tick limit {limit} offset {offset}""")
            #print(stocks)    
            if stocks != None and len(stocks) > 0:
                data = await syt.get_stock_price_from_fyers(stocks)
            else:
                data = []
            #print(data)
            # db.close_engine()
            if data:
                await websocket.send_json({"total_stocks": len(total_stocks), "stocks": data, "page_no": page_no})
            else:
                await websocket.send_text("Error fetching stock price")
            await asyncio.sleep(5)
    except WebSocketDisconnect:
        print("WebSocket Error: Client disconnected from price WebSocket")
    except asyncio.CancelledError:
        return
    except Exception as e:
        logger.exception(e, exc_info=True, stack_info=True)
        print("WebSocket Error:", e)
    # finally:
        # db.close_engine()


@app.get("/all_stock_live_prices")
async def all_stock_live_prices_page():
    html = f"""
    <html>
    <head>
        <title>Stock Live Prices</title>
        <style>
            table {{
                border-collapse: collapse;
                width: 80%;
                margin: auto;
            }}
            th, td {{
                border: 1px solid #999;
                padding: 8px;
                text-align: center;
            }}
            th {{
                background-color: #f2f2f2;
            }}
            .positive {{
                color: green;
                font-weight: bold;
            }}
            .negative {{
                color: red;
                font-weight: bold;
            }}
        </style>
    </head>
    <body>
        <h2 style="text-align: center;">Live Prices of Stocks</h2>
        <div style="text-align:center;"><strong>Total Stocks:</strong> <span id="total-stocks">Loading...</span></div>
        <div style="text-align:center;"><strong>Page No:</strong> <span id="page-no">Loading...</span></div>
        <br>
        <table>
            <thead>
                <tr>
                    <th>Stock Id</th>
                    <th>Stock</th>
                    <th>Price</th>
                    <th>Previous Close</th>
                    <th>Day Change</th>
                    <th>Day Change %</th>
                    <th>Watchlist Id</th>
                </tr>
            </thead>
            <tbody id="data">
                <tr><td colspan="7">Waiting for data...</td></tr>
            </tbody>
        </table>

        <script>
            const ws = new WebSocket(`ws://192.168.1.16:9000/ws/all_stock_live_prices`);

            ws.onmessage = function(event) {{
                let response = JSON.parse(event.data);
                let data = response.stocks;
                let totalStocks = response.total_stocks;
                let pageNo = response.page_no;

                document.getElementById("total-stocks").textContent = totalStocks;
                document.getElementById("page-no").textContent = pageNo;

                let body = document.getElementById("data");
                body.innerHTML = "";

                for (let row of data) {{
                    let changeClass = row.day_change.startsWith("+") ? "positive" : "negative";

                    body.innerHTML += `<tr>
                        <td>${{row.stock_id}}</td>
                        <td>${{row.stock}}</td>
                        <td>${{row.price}}</td>
                        <td>${{row.prev_close}}</td>
                        <td class="${{changeClass}}">${{row.day_change}}</td>
                        <td class="${{changeClass}}">${{row.day_change_percentage}}</td>
                        <td>${{row.watchlist_id}}</td>
                    </tr>`;
                }}
            }};

            ws.onerror = function(event) {{
                console.error("WebSocket error:", event);
            }};

            ws.onclose = function() {{
                console.log("WebSocket closed");
            }};
        </script>
    </body>
    </html>
    """
    return HTMLResponse(html)


@app.websocket("/ws/all_stock_live_prices")
async def all_stock_live_prices(websocket: WebSocket, symbol : str = None):
    await websocket.accept()
    try:
        while True:      
            stocks = []
            if symbol in (None, '', "null", "all"):
                stocks = db.raw_query(f"""select ism.id, ism.stock_tick, ism.y_finance, ism.fyers_symbol, ism.kite_symbol as stock_symbol 
                                    from ind_stock_master ism
                                    where ism.is_active = 1 and ism.fyers_symbol is not null             
                                    order by ism.stock_tick""")
                #print("@@@@@@@@@@@@@@@@@@@@@@@@@\n", stocks)
            else: 
                stocks = db.raw_query(f"""select ism.id, ism.stock_tick, ism.y_finance, ism.fyers_symbol, ism.kite_symbol as stock_symbol 
                                    from ind_stock_master ism
                                    where ism.stock_tick = '{symbol}' 
                                    and ism.is_active = 1 and ism.fyers_symbol is not null             
                                    order by ism.stock_tick""")
                

            #print(stocks)    
            if stocks != None and len(stocks) > 0:
                # print(stocks)
                #print("before fyers connection")

                data = await syt.get_stock_price_from_fyers(stocks)
                # print(datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"), "Printing data")
                #print("data------------", data)
            else:
                data = []
                #print("data------------", data)
            # db.close_engine()
            #logger.info("data------------", data)
            if data:
                #print(datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"), "Sending data to WebSocket")
                await websocket.send_json({"total_stocks": len(data), "stocks": data})
            else:
                await websocket.send_text("Error fetching stock price")
            await asyncio.sleep(5)
    except WebSocketDisconnect as ex:
        #logger.exception(ex, exc_info=True, stack_info=True)
        print("WebSocket Error: Client disconnected from price WebSocket")
    except asyncio.CancelledError:
        return
    except Exception as e:
        logger.exception(e, exc_info=True, stack_info=True)
        print("WebSocket Error:", e)


app.include_router(stock_router)
app.include_router(candle_router)
app.include_router(ticker_tape_router)
app.include_router(websocket_router)