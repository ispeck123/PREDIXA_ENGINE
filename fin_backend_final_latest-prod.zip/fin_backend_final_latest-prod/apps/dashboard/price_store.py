# shared_price_store.py
from threading import Lock
from shared.db.dbconn import DBConnection
from shared.db.db_model import Ind_StockMaster
db = DBConnection()

def get_stocks_list():
    session = db.get_session()
    stocks = session.query(Ind_StockMaster).filter(Ind_StockMaster.is_active == True, Ind_StockMaster.kite_token != None).all()
    # stocks = db.raw_query("""select * from ind_stock_master ism
    #                         inner join ind_stock_index_map isim on ism.id = isim.stock_id
    #                         where ism.is_active = 1 and ism.kite_token is not null 
    #                         and isim.index_id = {index_id}
    #                         order by ism.stock_tick""".format(index_id))
    tokens = [stock.kite_token for stock in stocks]
    price_data = {}  # { token: { price, timestamp, etc. } }
    for stock in stocks:
        price_data[stock.kite_token] = {
            "stock_id": stock.id,
            "stock": stock.stock_tick,
            "price": 0
        }
    session.close()
    db.close_engine()
    price_lock = Lock()
    return price_data
