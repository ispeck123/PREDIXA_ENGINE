from fastapi import APIRouter, Request, WebSocket, WebSocketDisconnect
import logging
from shared.db.dbconn import DBConnection
from shared.db.db_model import OMSOrders, FuturesMaster
from datetime import datetime
import asyncio
from data_fetchers.fyers.fyers_holdings import FyersHoldings
from typing import Any
from data_fetchers.fyers.get_commodity_prices import CommodityPriceFetcher
from data_fetchers.fyers.get_future_prices import FuturePriceFetcher
import time
from fastapi.responses import HTMLResponse
from data_fetchers.fyers.option_chain import get_futures_option_data
from apps.finprod_backend.scraper.index_scraper import index_price, stock_price, stock_price_by_stock_index_map


logger = logging.getLogger()

router = APIRouter()
db = DBConnection()
session = db.get_session()

cpf = CommodityPriceFetcher()
time.sleep(2)

fpf = FuturePriceFetcher()
time.sleep(2)

@router.websocket("/ws/get/oms/order")
async def get_oms_order(websocket: WebSocket):
    await websocket.accept()
    try:
        while True:
            rows = db.raw_query("""select * from oms_orders order by created_at desc""")
            if len(rows) > 0:
                await websocket.send_json({"data": rows})
            else:
                await websocket.send_text("Error fetching data")
            await asyncio.sleep(30)
    except WebSocketDisconnect as ex:
        #logger.exception(ex, exc_info=True, stack_info=True)
        logger.error("WebSocket Error: Client disconnected")
    except Exception as e:
        logger.exception(e, exc_info=True, stack_info=True)
        logger.error("WebSocket Error:", e)
        await websocket.close()


exchanges = {10: "NSE", 11: "MCX", 12: "BSE"}
segments = {
                10: "Capital Market", 
                11: "Equity Derivatives", 
                12: "Currency Derivatives",
                20: "Commodity Derivatives"
            }

@router.websocket("/ws/holdings")
async def ws_holdings(websocket: WebSocket, 
                         symbol: str | None = None,
                         page_no: Any = 1,
                         limit: int = 10):
    logger.info("ENTERED WS ENDPOINT")
    await websocket.accept()

    try:
        page_no = int(page_no)
    except:
        page_no = 1
    try:
        logger.info("*****************")
        holding_data = {}
        found = False
        start_time = datetime.now().timestamp()
        while True:
            res = FyersHoldings().get_holdings()
            hlds = res.get("holdings", [])
            if len(hlds) > 0:
                hlds = sorted(
                            hlds,
                            key=lambda row: row.get("symbol", "").lower()
                        )
                hlds = list(map(lambda h: {**h, "exchange": exchanges.get(h.get("exchange")), "segment": segments.get(h.get("segment"))}, hlds))
                res["holdings"] = hlds
                holding_data = res
                logger.info("*****************")
                if symbol in [None, '', "null"]:
                    symbol = None
                else:
                    for i in range(len(hlds)):
                        if hlds[i]["symbol"].lower().startswith(symbol.lower()):
                            found = i+1
                            break
                    if not found:
                        for i in range(len(hlds)):
                            if symbol.lower() in hlds[i]["symbol"].lower():
                                found = i+1
                                break
                
                limit = min(limit, len(hlds))
                if found:
                    page_no = ((found - 1) // limit) + 1
                
                offset = (page_no - 1) * limit
                hlds = hlds[offset : offset + limit]
                res["holdings"] = hlds
                res["page_no"] = page_no
                await websocket.send_json(res)
            
            elif len(holding_data) > 0:
                res = holding_data
                hlds = res.get("holdings", [])

                if symbol in [None, '', "null"]:
                    symbol = None
                else:
                    for i in range(len(hlds)):
                        if hlds[i]["symbol"].lower().startswith(symbol.lower()):
                            found = i+1
                            break
                    if not found:
                        for i in range(len(hlds)):
                            if symbol.lower() in hlds[i]["symbol"].lower():
                                found = i+1
                                break

                limit = min(limit, len(hlds))
                if found:
                    page_no = ((found - 1) // limit) + 1
                
                offset = (page_no - 1) * limit
                hlds = hlds[offset : offset + limit]
                res["holdings"] = hlds
                res["page_no"] = page_no
                await websocket.send_json(res)
            
            else:
                await websocket.send_text("No data found!")
            now_time = datetime.now().timestamp()
            if (now_time - start_time) > 60*5:  # 5 minutes
                holding_data = {}

            
            await asyncio.sleep(60)
    except WebSocketDisconnect:
        print("WebSocket Error: Client disconnected from WebSocket")
    
    except Exception as e:
        logger.exception(e, exc_info=True, stack_info=True)
        print("WebSocket Error:", e)
        await websocket.close()


@router.websocket("/ws/commodity_live_price")
async def commodity_live_price(websocket: WebSocket, symbol: str, expiry_date: str):
    await websocket.accept()
    try:
        while True:      
            stocks = [{"symbol": symbol.upper(), "expiry_date": expiry_date}]
            
                
            #print(stocks)    
            if stocks != None and len(stocks) > 0:
                # print(stocks)
                #print("before fyers connection")

                data = await cpf.get_stock_price_from_fyers(stocks)
                # print(datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"), "Printing data")
                #print("data------------", data)
            else:
                data = []
                #print("data------------", data)
            # db.close_engine()
            #logger.info("data------------", data)
            if data:
                # print(datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"), "Sending data to WebSocket")
                await websocket.send_json({"data": data})
            else:
                await websocket.send_text("Error fetching stock price")
            await asyncio.sleep(5)
    except WebSocketDisconnect as ex:
        #logger.exception(ex, exc_info=True, stack_info=True)
        print("WebSocket Error: Client disconnected from price WebSocket")
    except Exception as e:
        logger.exception(e, exc_info=True, stack_info=True)
        print("WebSocket Error:", e)
        await websocket.close()


@router.websocket("/ws/all_future_live_prices")
async def all_future_live_prices(websocket: WebSocket, expiry: str = None):
    await websocket.accept()
    try:
        while True:      
            stocks = []
            # stocks = db.raw_query(f"""select fm.id, fm.symbol, fm.exchange, fm.expiry_date
            #                     from futures_master fm            
            #                     order by fm.symbol""")
            
            session = db.get_session()
            expiry_dates = session.query(FuturesMaster.expiry_date).distinct().order_by(FuturesMaster.expiry_date).all()
            # logger.info(expiry_dates)
            if len(expiry_dates) > 0:
                expiry_dates_dict = {
                    "near": expiry_dates[0][0],
                    "next" : expiry_dates[1][0],
                    "far" : expiry_dates[2][0]
                }

            if expiry and expiry.lower() not in ("near", "next", "far"):
                stocks = session.query(FuturesMaster).order_by(FuturesMaster.symbol).all()
            else:
                stocks = session.query(FuturesMaster).filter(FuturesMaster.expiry_date == expiry_dates_dict[expiry]).order_by(FuturesMaster.symbol).all()
            session.close()
                

            #print(stocks)    
            if stocks != None and len(stocks) > 0:
                # print(stocks)
                #print("before fyers connection")

                data = await fpf.get_stock_price_from_fyers(stocks)
                # print(datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"), "Printing data")
                #print("data------------", data)
            else:
                data = []
                #print("data------------", data)
            # db.close_engine()
            #logger.info("data------------", data)
            if data:
                # print(datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"), "Sending data to WebSocket")
                await websocket.send_json({"total_stocks": len(data), "stocks": data})
            else:
                await websocket.send_text("Error fetching stock price")
            await asyncio.sleep(5)
    except WebSocketDisconnect as ex:
        #logger.exception(ex, exc_info=True, stack_info=True)
        print("WebSocket Error: Client disconnected from price WebSocket")
    except Exception as e:
        logger.exception(e, exc_info=True, stack_info=True)
        print("WebSocket Error:", e)
        await websocket.close()


@router.get("/all_future_live_prices", tags=['Websockets'])
async def all_future_live_prices_page(expiry: str = None):
    html = f"""
    <html>
    <head>
        <title>Future Live Prices</title>
        <style>
            table {{
                border-collapse: collapse;
                width: 80%;
                margin: auto;
            }}
            th, td {{
                border: 1px solid #999;
                padding: 8px;
                text-align: center;
            }}
            th {{
                background-color: #f2f2f2;
            }}
            .positive {{
                color: green;
                font-weight: bold;
            }}
            .negative {{
                color: red;
                font-weight: bold;
            }}
        </style>
    </head>
    <body>
        <h2 style="text-align: center;">Live Prices of Futures</h2>
        <div style="text-align:center;"><strong>Total Stocks:</strong> <span id="total-stocks">Loading...</span></div>
        <div style="text-align:center;"><strong>Page No:</strong> <span id="page-no">Loading...</span></div>
        <br>
        <table>
            <thead>
                <tr>
                    <th>Stock Id</th>
                    <th>Stock</th>
                    <th>Expiry Date</th>
                    <th>Price</th>
                    <th>Previous Close</th>
                    <th>Day Change</th>
                    <th>Day Change %</th>
                    <th>Watchlist Id</th>
                </tr>
            </thead>
            <tbody id="data">
                <tr><td colspan="8">Waiting for data...</td></tr>
            </tbody>
        </table>

        <script>
            const expiry = "{expiry}";
            const ws = new WebSocket(`ws://192.168.1.16:9000/ws/all_future_live_prices?expiry={expiry}`);

            ws.onmessage = function(event) {{
                let response = JSON.parse(event.data);
                let data = response.stocks;
                let totalStocks = response.total_stocks;
                let pageNo = response.page_no;

                document.getElementById("total-stocks").textContent = totalStocks;
                document.getElementById("page-no").textContent = pageNo;

                let body = document.getElementById("data");
                body.innerHTML = "";

                for (let row of data) {{
                    let changeClass = row.day_change.startsWith("+") ? "positive" : "negative";

                    body.innerHTML += `<tr>
                        <td>${{row.id}}</td>
                        <td>${{row.symbol}}</td>
                        <td>${{row.expiry_date}}</td>
                        <td>${{row.price}}</td>
                        <td>${{row.prev_close}}</td>
                        <td class="${{changeClass}}">${{row.day_change}}</td>
                        <td class="${{changeClass}}">${{row.day_change_percentage}}</td>
                        <td>${{row.watchlist_id}}</td>
                    </tr>`;
                }}
            }};

            ws.onerror = function(event) {{
                console.error("WebSocket error:", event);
            }};

            ws.onclose = function() {{
                console.log("WebSocket closed");
            }};
        </script>
    </body>
    </html>
    """
    return HTMLResponse(html)


@router.websocket("/ws/future_live_price")
async def future_live_price(websocket: WebSocket, symbol: str, expiry_date: str):
    await websocket.accept()
    try:
        while True:      
            stocks = []
            # stocks = db.raw_query(f"""select fm.id, fm.symbol, fm.exchange, fm.expiry_date
            #                     from futures_master fm            
            #                     order by fm.symbol""")
            
            session = db.get_session()

            stocks = session.query(FuturesMaster).filter(FuturesMaster.symbol == symbol.upper(), FuturesMaster.expiry_date == expiry_date).all()
            session.close()
                

            #print(stocks)    
            if stocks != None and len(stocks) > 0:
                # print(stocks)
                #print("before fyers connection")

                data = await fpf.get_stock_price_from_fyers(stocks)
                # print(datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"), "Printing data")
                #print("data------------", data)
            else:
                data = []
                #print("data------------", data)
            # db.close_engine()
            #logger.info("data------------", data)
            if data:
                # print(datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"), "Sending data to WebSocket")
                await websocket.send_json({"data": data})
            else:
                await websocket.send_text("Error fetching stock price")
            await asyncio.sleep(5)
    except WebSocketDisconnect as ex:
        #logger.exception(ex, exc_info=True, stack_info=True)
        print("WebSocket Error: Client disconnected from price WebSocket")
    except asyncio.CancelledError:
        return
    except Exception as e:
        logger.exception(e, exc_info=True, stack_info=True)
        print("WebSocket Error:", e)
        await websocket.close()


@router.websocket("/ws/get_future_oi")
async def ws_get_future_oi(websocket: WebSocket, 
                         symbol: str,
                         expiry_date: str):
    await websocket.accept()
    try:
        option_chain_data = {}
        start_time = datetime.now().timestamp()
        while True:
            res = get_futures_option_data(symbol, expiry_date)            
            if len(res) > 0:
                option_chain_data = res
                await websocket.send_json(res)
            elif len(option_chain_data) > 0:
                await websocket.send_json(option_chain_data)
            else:
                await websocket.send_text("No data found!")
            now_time = datetime.now().timestamp()
            if (now_time - start_time) > 60*5:  # 5 minutes
                option_chain_data = {}
            await asyncio.sleep(60)
    except WebSocketDisconnect:
        print("WebSocket Error: Client disconnected from WebSocket")
    except Exception as e:
        logger.exception(e, exc_info=True, stack_info=True)
        print("WebSocket Error:", e)
        await websocket.close()


@router.get("/get_future_oi_from_websocket", tags=['Websockets'])
async def get_future_oi_from_websocket(symbol: str, expiry_date: str):
    html = f"""
    <html>
    <head>
        <title>WebSocket JSON Viewer</title>
        <style>
            body {{
                font-family: monospace;
                background: #f9f9f9;
                padding: 20px;
            }}
            pre {{
                background: #272822;
                color: #f8f8f2;
                padding: 15px;
                border-radius: 8px;
                overflow-x: auto;
                white-space: pre-wrap;
                word-wrap: break-word;
            }}
        </style>
    </head>
    <body>
        <h2>WebSocket JSON Response</h2>
        <pre id="json">Waiting for data...</pre>

        <script>
            const symbol = "{symbol}";
            const expiry_date = "{expiry_date}";
            const ws = new WebSocket(`ws://192.168.1.16:9000/ws/get_future_oi?symbol={symbol}&expiry_date={expiry_date}`);

            ws.onmessage = function(event) {{
                try {{
                    let response = JSON.parse(event.data);
                    document.getElementById("json").textContent = 
                        JSON.stringify(response, null, 4); // pretty-print
                }} catch (e) {{
                    document.getElementById("json").textContent = event.data;
                }}
            }};

            ws.onerror = function(event) {{
                console.error("WebSocket error:", event);
                document.getElementById("json").textContent = "WebSocket error!";
            }};

            ws.onclose = function() {{
                console.log("WebSocket closed");
            }};
        </script>
    </body>
    </html>
    """
    return HTMLResponse(html)


@router.websocket("/index_price/{country_id}")
async def index_price_websocket(websocket: WebSocket, country_id: str):
    await websocket.accept()
    try:
        while True:
            res = index_price(country_id)
            if res:
                await websocket.send_json(res)
            else:
                await websocket.send_text("Error fetching index price")
            await asyncio.sleep(5)
    except WebSocketDisconnect:
        print(f"Client disconnected !")
    except Exception as e:
        print(f"Error: {e}")
        await websocket.close()


@router.get("/get_index_price/{country_id}", tags=['Websockets'])
async def get_index_price(country_id: str):
    html_content = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Live Index Prices</title>
        <style>
            body {{
                font-family: Arial, sans-serif;
                text-align: center;
                margin: 20px;
            }}
            table {{
                width: 60%;
                margin: auto;
                border-collapse: collapse;
            }}
            th, td {{
                border: 1px solid black;
                padding: 10px;
                text-align: center;
            }}
            th {{
                background-color: #4CAF50;
                color: white;
            }}
            .positive {{
                color: green;
                font-weight: bold;
            }}
            .negative {{
                color: red;
                font-weight: bold;
            }}
        </style>
    </head>
    <body>
        <h2>Live Index Prices</h2>
        <table>
            <thead>
                <tr>
                    <th>Index</th>
                    <th>Price</th>
                    <th>Day Change</th>
                    <th>Change (%)</th>
                    <th>Index ID</th>
                </tr>
            </thead>
            <tbody id="stock-data">
                <tr><td colspan="5">Waiting for data...</td></tr>
            </tbody>
        </table>

        <script>
            const country_id = "{country_id}";
            const socket = new WebSocket(`ws://192.168.1.16:9000/index_price/{country_id}`);

            socket.onopen = function(event) {{
                console.log("Connected to WebSocket...");
            }};

            socket.onmessage = function(event) {{
                let data = JSON.parse(event.data);
                let tableBody = document.getElementById("stock-data");
                tableBody.innerHTML = ""; // Clear previous data

                for (let stock in data) {{
                    let stockInfo = data[stock];
                    let changeClass = stockInfo.day_change.startsWith("+") ? "positive" : "negative";

                    let row = `
                        <tr>
                            <td><strong>${{stock}}</strong></td>
                            <td>${{stockInfo.price.toLocaleString()}}</td>
                            <td class="${{changeClass}}">${{stockInfo.day_change}}</td>
                            <td class="${{changeClass}}">${{stockInfo.day_change_percentage}}</td>
                            <td class="${{changeClass}}">${{stockInfo.index_id}}</td>
                        </tr>
                    `;
                    tableBody.innerHTML += row;
                }}
            }};

            socket.onerror = function(event) {{
                console.error("WebSocket Error:", event);
            }};

            socket.onclose = function(event) {{
                console.log("WebSocket Disconnected");
            }};
        </script>
    </body>
    </html>
    """
    return HTMLResponse(content=html_content)


@router.websocket("/stock_price")
async def stock_price_websocket(websocket: WebSocket, index_id: str = ''):
    await websocket.accept()
    try:
        while True:
            res = stock_price(index_id)
            if res:
                await websocket.send_json(res)
            else:
                await websocket.send_text("Error fetching stock price")
            await asyncio.sleep(5)
    except WebSocketDisconnect:
        print(f"Client disconnected !")
    except Exception as e:
        print(f"Error: {e}")
        await websocket.close()


@router.get("/get_stock_price", tags=['Websockets'])
async def get_stock_price(index_id: str = ''):
    html_content = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Live Stock Prices</title>
        <style>
            body {{
                font-family: Arial, sans-serif;
                text-align: center;
                margin: 20px;
            }}
            table {{
                width: 60%;
                margin: auto;
                border-collapse: collapse;
            }}
            th, td {{
                border: 1px solid black;
                padding: 10px;
                text-align: center;
            }}
            th {{
                background-color: #4CAF50;
                color: white;
            }}
            .positive {{
                color: green;
                font-weight: bold;
            }}
            .negative {{
                color: red;
                font-weight: bold;
            }}
        </style>
    </head>
    <body>
        <h2>Live Stock Prices</h2>
        <table>
            <thead>
                <tr>
                    <th>Stock</th>
                    <th>Price</th>
                    <th>Day Change</th>
                    <th>Change (%)</th>
                    <th>Stock ID</th>
                    <th>Currency</th>
                </tr>
            </thead>
            <tbody id="stock-data">
                <tr><td colspan="6">Waiting for data...</td></tr>
            </tbody>
        </table>

        <script>
            const index_id = "{index_id}";
            const socket = new WebSocket(`ws://192.168.1.16:9000/stock_price?index_id={index_id}`);

            socket.onopen = function(event) {{
                console.log("Connected to WebSocket...");
            }};

            socket.onmessage = function(event) {{
                let data = JSON.parse(event.data);
                let tableBody = document.getElementById("stock-data");
                tableBody.innerHTML = ""; // Clear previous data

                for (let stock in data) {{
                    let stockInfo = data[stock];
                    let changeClass = stockInfo.day_change.startsWith("+") ? "positive" : "negative";

                    let row = `
                        <tr>
                            <td><strong>${{stock}}</strong></td>
                            <td>${{stockInfo.price.toLocaleString()}}</td>
                            <td class="${{changeClass}}">${{stockInfo.day_change}}</td>
                            <td class="${{changeClass}}">${{stockInfo.day_change_percentage}}</td>
                            <td class="${{changeClass}}">${{stockInfo.stock_id}}</td>
                            <td class="${{changeClass}}">${{stockInfo.currency}}</td>
                        </tr>
                    `;
                    tableBody.innerHTML += row;
                }}
            }};

            socket.onerror = function(event) {{
                console.error("WebSocket Error:", event);
            }};

            socket.onclose = function(event) {{
                console.log("WebSocket Disconnected");
            }};
        </script>
    </body>
    </html>
    """
    return HTMLResponse(content=html_content)


@router.websocket("/stock_price_by_stock_index_map")
async def stock_price_by_stock_index_map_websocket(websocket: WebSocket, index_id: str = '', page_id: int = 1, limit: int = 10, country: str = 'India'):
    await websocket.accept()
    try:
        while True:
            res = stock_price_by_stock_index_map(index_id, page_id, limit, country)
            # print(res)
            if res:
                await websocket.send_json(res)
            else:
                await websocket.send_text("Error fetching stock price")
            await asyncio.sleep(5)
    except WebSocketDisconnect:
        print(f"Client disconnected !")
    except Exception as e:
        print(f"Error: {e}")
        await websocket.close()


@router.get("/get_stock_price_by_stock_index_map", tags=['Websockets'])
async def get_stock_price_by_stock_index_map(index_id: str = '', page_id: int = 1, limit: int = 10, country: str = 'India'):
    html_content = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Live Stock Prices</title>
        <style>
            body {{
                font-family: Arial, sans-serif;
                text-align: center;
                margin: 20px;
            }}
            table {{
                width: 60%;
                margin: auto;
                border-collapse: collapse;
            }}
            th, td {{
                border: 1px solid black;
                padding: 10px;
                text-align: center;
            }}
            th {{
                background-color: #4CAF50;
                color: white;
            }}
            .positive {{
                color: green;
                font-weight: bold;
            }}
            .negative {{
                color: red;
                font-weight: bold;
            }}
        </style>
    </head>
    <body>
        <h2>Live Stock Prices</h2>
        <table>
            <thead>
                <tr>
                    <td colspan="6" id="total-count" style="font-weight:bold; text-align:center;">Total Count : Loading...</td>
                </tr>
                <tr>
                    <th>Stock</th>
                    <th>Price</th>
                    <th>Day Change</th>
                    <th>Change (%)</th>
                    <th>Stock ID</th>
                    <th>Currency</th>
                </tr>
            </thead>
            <tbody id="stock-data">
                <tr><td colspan="6">Waiting for data...</td></tr>
            </tbody>
        </table>

        <script>
            const index_id = "{index_id}";
            const page_id = {page_id};
            const limit = {limit};
            const country = "{country}";
            const socket = new WebSocket(`ws://192.168.1.16:9000/stock_price_by_stock_index_map?index_id={index_id}&page_id={page_id}&limit={limit}&country={country}`);

            socket.onopen = function(event) {{
                console.log("Connected to WebSocket...");
            }};

            socket.onmessage = function(event) {{
                let data = JSON.parse(event.data);
                let tableBody = document.getElementById("stock-data");
                tableBody.innerHTML = ""; // Clear previous data

                document.getElementById("total-count").innerHTML = `Total Count: ${{data["total_count"]}}`;

                for (let stock in data["price_response"]) {{
                    let stockInfo = data["price_response"][stock];
                    let changeClass = stockInfo.day_change.startsWith("+") ? "positive" : "negative";

                    let row = `
                        <tr>
                            <td><strong>${{stock}}</strong></td>
                            <td>${{stockInfo.price.toLocaleString()}}</td>
                            <td class="${{changeClass}}">${{stockInfo.day_change}}</td>
                            <td class="${{changeClass}}">${{stockInfo.day_change_percentage}}</td>
                            <td class="${{changeClass}}">${{stockInfo.stock_id}}</td>
                            <td class="${{changeClass}}">${{stockInfo.currency}}</td>
                        </tr>
                    `;
                    tableBody.innerHTML += row;
                }}
            }};

            socket.onerror = function(event) {{
                console.error("WebSocket Error:", event);
            }};

            socket.onclose = function(event) {{
                console.log("WebSocket Disconnected");
            }};
        </script>
    </body>
    </html>
    """
    return HTMLResponse(content=html_content)