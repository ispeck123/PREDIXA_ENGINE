# from fastapi import APIRouter, Request, WebSocket, WebSocketDisconnect
from starlette.websockets import WebSocket, WebSocketDisconnect, WebSocketState
from fastapi import APIRouter
from uvicorn.protocols.utils import ClientDisconnected
from shared.db.api_responce import APIResponse
from fastapi.responses import HTMLResponse
from apps.finprod_backend.scraper.realtime_update import CandleBuilder, get_latest_stock_price, update_ohlc, get_last_data_from_files, get_current_candle_timestamp
import asyncio
from shared.db.dbconn import DBConnection
from shared.db.db_model import Ind_StockMaster
from shared.config.settings import stock_data_dir_config
# from data_fetchers.fyers.fyers_ticker import FyersTickerManager
from data_fetchers.fyers.market_data_live import fyers_live_symbol_data
import logging
from datetime import datetime, timezone
import time
import pandas as pd
import numpy as np
import redis.asyncio as redis
import os, contextlib
import json

logger = logging.getLogger("ws.candles")

router = APIRouter()
dbc = DBConnection()

REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")
r = redis.from_url(REDIS_URL, encoding="utf-8", decode_responses=True)

# TICKER = FyersTickerManager()
#fyers_ticker = FyersTickerManager()

def _to_float(v):
    try:
        return float(v) if v is not None else None
    except Exception:
        return None


def get_ohlc_values(stock_tick: str, candle_frame: str):
    stock_file_path = f"{stock_data_dir_config.indian_stock_data_dir}/latest_data_csv/{stock_tick}_{candle_frame}.csv"
    df = pd.read_csv(stock_file_path)
    df['tradeDate'] = pd.to_datetime(df['tradeDate'], dayfirst = True)
    df['timestamp'] = df['tradeDate'].astype(np.int64) // 10**9
    last_row = df.iloc[-1]
    return {
        'time': int(last_row['timestamp']),
        'open': last_row['open'],
        'high': last_row['high'],
        'low': last_row['low'],
        'close': last_row['close']
    }


@router.get("/test_websocket")
async def get():
    html_content = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Stock Price WebSocket</title>
    </head>
    <body>
        <h1>Stock Price WebSocket</h1>
        <label for="stock_id">Enter Stock Id:</label>
        <input id="stock_id" type="text" />
        <label for="time_frame">Enter Time Frame:</label>
        <input id="time_frame" type="text" />
        <button onclick="connect()">Connect</button>
        <button onclick="disconnect()">Disconnect</button>
        <h3>Stock Price: <span id="stock_price">N/A</span></h3>

        <script>
            let websocket;
            function connect() {
                const stockId = document.getElementById("stock_id").value;
                const timeFrame = document.getElementById("time_frame").value;
                websocket = new WebSocket(`ws://103.13.113.132:2580/ws/${stockId}/${timeFrame}`);

                websocket.onmessage = function(event) {
                    document.getElementById("stock_price").textContent = event.data;
                };

                websocket.onclose = function() {
                    console.log("Disconnected from server");
                };
            }

            function disconnect() {
                if (websocket) {
                    websocket.close();
                }
            }
        </script>
    </body>
    </html>
    """
    return HTMLResponse(content=html_content)


# @router.websocket("/ws/{stock_id}/{time_frame}")
# async def websocket_endpoint(websocket: WebSocket, stock_id: int, time_frame : int):
#     await websocket.accept()
#     fsml = None
#     try:
#         fsml = fyers_live_symbol_data()
#         session = dbc.get_session()
#         stock = session.query(Ind_StockMaster).filter(Ind_StockMaster.id == stock_id, Ind_StockMaster.is_active == 1).first()
#         session.close()
#         #print(stock)
#         if not stock:
#             if websocket.application_state == WebSocketState.CONNECTED:
#                 await websocket.send_text("Invalid or inactive stock id")
#             return  # No loop, just exit
#         fsml.add_syms([stock.fyers_symbol], websocket)
#             # res = get_last_data_from_files(stock[0].stock_tick, time_frame)
#             #print(res)
#         await asyncio.sleep(1.0)
#         # for _ in range(10):
#         #     probe = f_ticker.get_latest_price(stock.fyers_symbol)
#         #     if probe is not None:
#         #         break
#         #     await asyncio.sleep(0.2)

#         while True:
#             #price = get_latest_stock_price(stock[0].fyers_symbol)
#             # try:
#             # all_price = f_ticker.latest_prices
#             # logger.info("Latest prices: %s", all_price)
#             candle_data = fsml.get_latest_price(stock.fyers_symbol)
#             candle_data["stock_tick"] = stock.stock_tick
#             candle_data["time"] = get_current_candle_timestamp(time_frame)
#             # if price is None:
#             #     if websocket.application_state == WebSocketState.CONNECTED:
#             #         await websocket.send_text("Error fetching stock price")
#             #     await asyncio.sleep(5)
#             #     continue
#             logger.info("Latest price: %s", candle_data)
#             # candle_data = {
#             #     "stock_tick": stock.stock_tick,
#             #     "price": price,
#             #     "time" : int(datetime.now(timezone.utc).timestamp())
#             # }
#             # candle_data = update_ohlc(stock.stock_tick, price, time_frame)
#             # candle_data["stock_tick"] = stock.stock_tick
#             #print(price)
#             # t_stamp = datetime.strptime(datetime.now().today(), )
#             # if websocket.application_state != WebSocketState.CONNECTED:
#             #     break
#             await websocket.send_json(candle_data)
#             await asyncio.sleep(5)
            
 
#     except WebSocketDisconnect:
#         # await websocket.close()
#         # print(f"Client disconnected: {stock.stock_tick}")
#         logger.info("Client disconnected: %s", getattr(stock, "stock_tick", stock_id))
#     except Exception as e:
#         # await websocket.close()
#         # print(f"Error: {e}")
#         logger.info("Error: %s", e)
#     finally:
#         try:
#             if 'fsml' in locals() and fsml and 'websocket' in locals():
#                 fsml.fyers.close_connection()
#         except Exception:
#             pass
#         try:
#             if websocket.application_state == WebSocketState.CONNECTED: 
#                 await websocket.close()
#         except Exception:
#             pass

@router.websocket("/ws/{stock_id}/{time_frame}")
async def websocket_endpoint(websocket: WebSocket, stock_id: int, time_frame: str):
    await websocket.accept()
    logger.info("WS CONNECT path=%s stock_id=%s tf=%s client=%s",
                websocket.url.path, stock_id, time_frame, websocket.client)
    session = None
    pubsub = None
    symbol = None

    # coalescing queue so we don't spam the browser during bursts
    queue: asyncio.Queue[str] = asyncio.Queue(maxsize=1000)

    async def _send_heartbeat():
        try:
            while True:
                await asyncio.sleep(20)  # 20s is a saner heartbeat than 1s
                if websocket.application_state == WebSocketState.CONNECTED:
                    await websocket.send_text('{"type":"ping"}')
                else:
                    break
        except Exception:
            pass

    async def _pubsub_reader(channel: str):
        nonlocal pubsub
        pubsub = r.pubsub()
        await pubsub.subscribe(channel)
        try:
            async for msg in pubsub.listen():
                if msg.get("type") != "message":
                    continue
                data = msg.get("data")
                try:
                    queue.put_nowait(data)
                except asyncio.QueueFull:
                    _ = queue.get_nowait()
                    await queue.put(data)
        finally:
            with contextlib.suppress(Exception):
                await pubsub.unsubscribe(channel)
                await pubsub.close()

    async def _sender(stock_tick: str, builder: CandleBuilder):
        """
        Drain coalesced ticks every ~100ms.
        For each batch, update the CandleBuilder and send ONE 'current_candle' payload.
        """
        batch = []
        try:
            while websocket.application_state == WebSocketState.CONNECTED:
                try:
                    item = await asyncio.wait_for(queue.get(), timeout=0.1)
                    batch.append(item)
                    while True:
                        item = queue.get_nowait()
                        batch.append(item)
                except (asyncio.TimeoutError, asyncio.QueueEmpty):
                    pass

                if not batch:
                    continue

                # Process the batch: update builder for symbol's current bucket
                for raw in batch:
                    try:
                        p = json.loads(raw)
                        if p.get("symbol") != symbol:
                            continue
                        ltp = p.get("close")
                        t_ms = int(p.get("time")) if p.get("time") is not None else int(time.time() * 1000)
                        ohlc_values = get_ohlc_values(stock_tick, time_frame)
                        logger.info("OHLC: %s", ohlc_values)
                        builder.update(ltp=ltp, tick_time_ms=t_ms, ohlc_values=ohlc_values)
                    except Exception as ex:
                        logger.debug("Bad tick payload: %s (%s)", raw, ex)

                snap = builder.snapshot()
                batch.clear()

                if snap:
                    payload = {
                        "type": "current_candle",
                        "data": {
                            "stock_tick": stock_tick,
                            "symbol": snap["symbol"],
                            "time": snap["t_open"],   # candle start (UTC seconds)
                            "open": snap["o"],
                            "high": snap["h"],
                            "low":  snap["l"],
                            "close": snap["c"],
                            "count": snap["count"],
                            "status": snap["status"],
                        },
                    }
                    await websocket.send_json(payload)
        except WebSocketDisconnect:
            pass
        except Exception as e:
            logger.info("WS sender error: %s", e)

    try:
        # 1) DB lookup
        session = dbc.get_session()
        stock = (
            session.query(Ind_StockMaster)
            .filter(Ind_StockMaster.id == stock_id, Ind_StockMaster.is_active == 1)
            .first()
        )
        session.close(); session = None

        if not stock:
            if websocket.application_state == WebSocketState.CONNECTED:
                await websocket.send_text("Invalid or inactive stock id")
            return

        symbol = stock.fyers_symbol
        stock_tick = stock.stock_tick

        # CandleBuilder per-connection
        builder = CandleBuilder(symbol)

        # 2) Seed from latest snapshot (optional but nice for immediate UI)
        #    This seeds the current bucket with the latest known 'close'
        snap = await r.hgetall(f"price:{symbol}")
        if snap and snap.get("close") is not None:
            try:
                latest_close = float(snap["close"])
                # Use now as tick time; bucket will be computed inside builder
                ohlc_values = get_ohlc_values(stock_tick, time_frame)
                logger.info("OHLC: %s", ohlc_values)
                builder.update(ltp=latest_close, tick_time_ms=int(time.time() * 1000), ohlc_values=ohlc_values)
            except Exception as exs:
                logger.exception("Failed to seed candle: %s", exs)
                pass

        # Send an initial message: either a candle snapshot or explicit 'no data yet'
        first = builder.snapshot()
        logger.info("WS first: %s", first)
        if first:
            await websocket.send_json({
                "type": "current_candle",
                "data": {
                    "stock_tick": stock_tick,
                    "symbol": first["symbol"],
                    "time": first["t_open"],
                    "open": first["o"],
                    "high": first["h"],
                    "low":  first["l"],
                    "close": first["c"],
                    "count": first["count"],
                    "status": first["status"],
                }
            })
        else:
            await websocket.send_json({"type": "current_candle", "data": None})

        # 3) Start pubsub reader + sender + heartbeat
        channel = f"prices:{symbol}"
        tasks = [
            asyncio.create_task(_pubsub_reader(channel), name="pubsub_reader"),
            asyncio.create_task(_sender(stock_tick, builder), name="sender"),
            asyncio.create_task(_send_heartbeat(), name="heartbeat"),
        ]

        done, pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_EXCEPTION)
        for t in pending:
            t.cancel()
    except asyncio.CancelledError:
        logger.debug("pubsub_reader cancelled")
        return
    except WebSocketDisconnect:
        logger.info("Client disconnected: %s", getattr(stock, "stock_tick", stock_id))
    except Exception as e:
        logger.info("WS error: %s", e)
        with contextlib.suppress(Exception):
            if websocket.application_state == WebSocketState.CONNECTED:
                await websocket.send_text("Server error")
    finally:
        with contextlib.suppress(Exception):
            if pubsub:
                await pubsub.close()
        with contextlib.suppress(Exception):
            if websocket.application_state == WebSocketState.CONNECTED:
                await websocket.close()
        with contextlib.suppress(Exception):
            if session:
                session.close()