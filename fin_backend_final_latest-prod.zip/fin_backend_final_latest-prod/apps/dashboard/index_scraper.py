from shared.config.settings import kite_config
from data_fetchers.kiteconnect.kite_session import load_access_token
from kiteconnect import KiteTicker, KiteConnect
from shared.db.dbconn import DBConnection
from shared.db.db_model import Ind_StockMaster
import time
from apps.dashboard.price_store import get_stocks_list
import json
import logging

logger = logging.getLogger()

price_data = get_stocks_list()
api_key = kite_config().api_key

access_token = load_access_token()["access_token"]  # get this via login flow

db = DBConnection()
# Instrument tokens for stocks (get from instrument dump)
# tokens = [738561, 5633, 128737]  # Example: INFY, RELIANCE, SBIN



kws = KiteTicker(api_key, access_token)

def on_ticks(ws, ticks):
    #with price_lock:
        for tick in ticks:
            print(tick)
            #print(f"{tick['instrument_token']} - LTP: {tick.get('last_price')}")
            session = db.get_session()
            stock = session.query(Ind_StockMaster).filter(Ind_StockMaster.is_active == True, Ind_StockMaster.kite_token == tick['instrument_token']).all()
            session.close()
            if len(stock) > 0:
                #print(f"Stock: {stock[0].stock_tick}, LTP: {tick.get('last_price')}")
                price_data[tick['instrument_token']]['price'] = tick.get("last_price")
        # for tick in ticks:
        #     time.sleep(1)
        #     #print(tick)
        #     print(f"{tick['instrument_token']} - LTP: {tick.get('last_price')}")
        #     db = DBConnection()
        #     session = db.get_session()
        #     stock = session.query(Ind_StockMaster).filter(Ind_StockMaster.is_active == True, Ind_StockMaster.kite_token == tick['instrument_token']).all()
        #     if len(stock) > 0:
        #         print(f"Stock: {stock[0].stock_tick}, LTP: {tick.get('last_price')}")

def on_connect(ws, response):
    print("WebSocket connected!")
    session = db.get_session()
    stocks = session.query(Ind_StockMaster).filter(Ind_StockMaster.is_active == True, Ind_StockMaster.kite_token != None).all()
    tokens = [stock.kite_token for stock in stocks]
    print("Subscribed tokens:", tokens)
    ws.subscribe(tokens)
    ws.set_mode(ws.MODE_LTP, tokens)  # For only LTP. Use MODE_FULL for OHLC, volume, etc.
    session.close()

def on_close(ws, code, reason):
    print("WebSocket closed", code, reason)

def run_kite_socket():
    kws.on_ticks = on_ticks
    kws.on_connect = on_connect
    kws.on_close = on_close
    kws.connect(threaded=True)

# kws.on_ticks = on_ticks
# kws.on_connect = on_connect
# kws.on_close = on_close

def index_scraper():
    # print("Starting index scraper...")
    # kws.connect(threaded=True)
    # print("Index scraper started.")
    
    #while True:
    i = 0
    while i < 2:
        #with price_lock:
            data = json.dumps(price_data, default=str)
            print(data)
            #time.sleep(2)
            if i == 1:
                 return data
            i += 1
            #return data

def get_stock_price_from_kite(stocks, stock_exchange):
    try:
        instruments = [f"{stock_exchange}:{stock['kite_symbol']}" for stock in stocks]
        kite = KiteConnect(api_key=api_key)
        kite.set_access_token(access_token)    
        quote = kite.quote(instruments)
        stock_data = []
        for instrument, data in quote.items():
            prev = data["ohlc"]["close"]
            last = data["last_price"]
            if last is not None and prev is not None:
                kite_symbol = instrument.split(":")[1]
                for stock in stocks:
                    if stock['kite_symbol'] == kite_symbol:
                        stock_data.append({
                            "stock_id": stock['id'],
                            "stock": stock['stock_tick'].upper(),                    
                            "price": last,
                            "prev_close": prev,
                            "day_change": f"+{round((last - prev), 2)} Today" if (round((last - prev), 2) > 0) else f"{round((last - prev), 2)} Today",
                            "day_change_percentage": f"+{round(((last - prev) / prev) * 100, 2)} %" if (round(((last - prev) / prev) * 100, 2) > 0) else f"{round(((last - prev) / prev) * 100, 2)} %"
                        })         
        return stock_data
    except Exception as ex:
        logger.exception(ex)
        return stock_data


if __name__ == "__main__":
    index_scraper()
    while True:
        try:
            pass
        except KeyboardInterrupt:
            print("Exiting...")
            kws.stop()
            break
        except Exception as e:
            print(f"Error: {e}")
            kws.stop()
            break
    kws.stop()
    
