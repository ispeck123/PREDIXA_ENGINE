import mysql.connector
from datetime import datetime

def refresh_futures_master_and_update_categories(db_config, expiry_map, evaluation_date=None):
    """
    Updates the futures_master and futures_category_map based on the fresh expiry list.
    """

    if evaluation_date is None:
        evaluation_date = datetime.today().date()

    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor(dictionary=True)

    try:
        for symbol, new_expiry_list in expiry_map.items():
            print(f"\nProcessing symbol: {symbol}")

            # 1. Fetch existing futures for the symbol
            cursor.execute(
                "SELECT id, expiry_date FROM futures_master WHERE symbol = %s",
                (symbol,)
            )
            existing_rows = cursor.fetchall()
            existing_expiries = {row['expiry_date']: row['id'] for row in existing_rows}
            print(existing_expiries)

            new_expiry_set = set(datetime.strptime(d, "%Y-%m-%d").date() for d in new_expiry_list)

            for expiry, futures_id in existing_expiries.items():
                if expiry not in new_expiry_set:
                    print(f"Deleting old expiry {expiry} for {symbol}")

                    # FIRST delete from futures_category_map
                    cursor.execute(
                        "DELETE FROM futures_category_map WHERE futures_id = %s",
                        (futures_id,)
                    )

                    # THEN delete from futures_master
                    cursor.execute(
                        "DELETE FROM futures_master WHERE id = %s",
                        (futures_id,)
                    )

            # 2. Insert missing expiry dates into futures_master
            for expiry_str in new_expiry_list:
                expiry_dt = datetime.strptime(expiry_str, "%Y-%m-%d").date()

                if expiry_dt not in existing_expiries:
                    print(f"Inserting new expiry {expiry_dt} for {symbol}")
                    cursor.execute(
                        """
                        INSERT INTO futures_master (symbol, exchange, expiry_date, instrument, created_at, last_updated)
                        VALUES (%s, %s, %s, %s, NOW(), NOW())
                        """,
                        (symbol, 'NSEFO', expiry_dt, 'FUTSTK')
                    )

            conn.commit()

        # 3. After updating futures_master, now refresh category mapping
        update_futures_category_map(db_config, evaluation_date)

        print("\nFutures master and category map updated successfully.")

    except Exception as e:
        print(f"Error: {e}")
        conn.rollback()
    finally:
        cursor.close()
        conn.close()


def update_futures_category_map(db_config, evaluation_date):
    """
    Updates the futures_category_map table after futures_master is refreshed.
    """
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor(dictionary=True)

    try:
        # Fetch fresh list from futures_master
        cursor.execute(
            "SELECT id, symbol, expiry_date FROM futures_master WHERE expiry_date >= CURDATE() ORDER BY symbol, expiry_date"
        )
        rows = cursor.fetchall()

        # Group by symbol
        futures_by_symbol = {}
        for row in rows:
            futures_by_symbol.setdefault(row['symbol'], []).append(row)

        for symbol, futures_list in futures_by_symbol.items():
            for idx, future in enumerate(futures_list[:3]):  # Only NEAR, NEXT, FAR
                category = None
                if idx == 0:
                    category = 'NEAR'
                elif idx == 1:
                    category = 'NEXT'
                elif idx == 2:
                    category = 'FAR'

                if category:
                    # Delete existing mapping first
                    cursor.execute(
                        "DELETE FROM futures_category_map WHERE futures_id = %s AND evaluation_date = %s",
                        (future['id'], evaluation_date)
                    )
                    # Insert new mapping
                    cursor.execute(
                        """
                        INSERT INTO futures_category_map (futures_id, category, evaluation_date)
                        VALUES (%s, %s, %s)
                        """,
                        (future['id'], category, evaluation_date)
                    )

        conn.commit()

    except Exception as e:
        print(f"Error: {e}")
        conn.rollback()
    finally:
        cursor.close()
        conn.close()