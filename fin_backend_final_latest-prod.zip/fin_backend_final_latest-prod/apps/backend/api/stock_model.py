from fastapi import APIRouter, Request
from shared.db.req_model import Stock_RCM
from shared.db.dbconn import DBConnection
from stock_model.model_predictor import Indian_model_predictor, US_model_predictor
from shared.db.api_responce import APIResponse
from shared.utils.logger import logger
from datetime import datetime
from sqlalchemy import text
import re
from dateutil import parser

router = APIRouter()
dbc = DBConnection()

@router.post("/fetch_stock_model_prediction", tags=['Stock Model'])
async def fetch_stock_model_prediction(request: Request, model: Stock_RCM):
    apiresponce = APIResponse(request)
    try:
        # out_res = {}
        last_d_time = datetime.strptime(model.last_d_time, "%Y-%m-%d %H:%M:%S")
        # frame = getattr(cfg, f'TIME_FRAMES_{time_frame}')
        print(model.last_d_time)
        # for t_fr in frame:
        if model.country_id == 1:
            imp = Indian_model_predictor(model.tick, model.time_frame, model.order_type, last_d_time)
            out_res, prob = imp.fetch_model_stats(model.entry_price, model.target_price, model.stoploss_price)
        else:
            ump = US_model_predictor(model.tick, model.time_frame, last_d_time)
            out_res, prob = ump.fetch_model_stats(model.entry_price, model.target_price, model.stoploss_price)
        
        apiresponce.setMsg(out_res)
        apiresponce.setResponse({"probability" : round(prob*100, 2)})
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.post("/fetch_futures_and_commodity_model_prediction", tags=['Stock Model'])
async def fetch_futures_and_commodity_model_prediction(request: Request, exp_date: str, segment: str, model: Stock_RCM):
    apiresponce = APIResponse(request)
    try:
        numbers = re.findall(r'\d+', exp_date)
        exp_num = ''.join(numbers)
        last_d_time = datetime.strptime(model.last_d_time, "%Y-%m-%d %H:%M:%S")
        # frame = getattr(cfg, f'TIME_FRAMES_{time_frame}')
        # for t_fr in frame:
        # if model.country_id == 1:
        imp = Indian_model_predictor(model.tick, model.time_frame, model.order_type, last_d_time)
        out_res, prob = imp.fetch_model_stats_future_and_commodity(model.entry_price, model.target_price, model.stoploss_price, exp_num, segment)
        # else:
            # ump = US_model_predictor(model.tick, model.time_frame, last_d_time)
            # out_res, prob = ump.fetch_model_stats(model.entry_price, model.target_price, model.stoploss_price)
        
        apiresponce.setMsg(out_res)
        apiresponce.setResponse({"probability" : round(prob*100, 2)})
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.post("/update_arima_ab_stock_model_predictions", tags=['Stock Model'])
async def update_stock_model_predictions(request: Request):
    apiresponce = APIResponse(request)
    try:
        res = dbc.raw_query("select * from order_master where arima_ab_model_prob=0.0;")
        print(res)
        for items in res:
            bind_data = {
                "order_type" : items.get("order_type"),
                "entry_price" : items.get("entry_price"),
                "target_price" : items.get("target_price"),
                "stoploss_price" : items.get("stoploss_price")
            }
            tick = items.get("stock_tick")
            t_fr = items.get("time_frame")
            # file_name = f"./processed_data_files/{tick}_daily.csv"
            last_d_time = parser.parse(items.get("purchased_cmp_date"))
            stm = Indian_model_predictor(tick, t_fr,  bind_data['order_type'], last_d_time)
            out_res, prob = stm.fetch_model_stats(bind_data['entry_price'], bind_data['target_price'], bind_data['stoploss_price'])
            query = f"update order_master set arima_ab_model_prediction='{out_res}', arima_ab_model_prob={prob} where order_id={items.get('order_id')}"
            rc = dbc.raw_connection()
            rc.execute(text(query))
            rc.commit()
            rc.close()
            print(items.get('order_id'))
            # print(out_res, prob)
        apiresponce.setMsg("success")
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce