from fastapi import APIRouter, Request, HTTPException, WebSocket, WebSocketDisconnect
import logging
from data_fetchers.fyers.fyers_holdings import FyersHoldings
import asyncio
from datetime import datetime
from typing import Any
logger = logging.getLogger()
#db = DBConnection()
router = APIRouter()

exchanges = {10: "NSE", 11: "MCX", 12: "BSE"}
segments = {
                10: "Capital Market", 
                11: "Equity Derivatives", 
                12: "Currency Derivatives",
                20: "Commodity Derivatives"
            }

# @router.websocket("/ws/get/holdings")
# async def ws_get_holdings(websocket: WebSocket, 
#                          symbol: str | None = None,
#                          page_no: Any = 1,
#                          limit: int = 10):
#     await websocket.accept()
#     try:
#         page_no = int(page_no)
#     except:
#         page_no = 1
#     try:
#         holding_data = {}
#         found = False
#         start_time = datetime.now().timestamp()
#         while True:
#             res = FyersHoldings().get_holdings()
#             hlds = res.get("holdings", [])
#             if len(hlds) > 0:
#                 hlds = sorted(
#                             hlds,
#                             key=lambda row: row.get("symbol", "").lower()
#                         )
#                 hlds = list(map(lambda h: {**h, "exchange": exchanges.get(h.get("exchange")), "segment": segments.get(h.get("segment"))}, hlds))
#                 res["holdings"] = hlds
#                 holding_data = res
                
#                 if symbol in [None, '', "null"]:
#                     symbol = None
#                 else:
#                     for i in range(len(hlds)):
#                         if hlds[i]["symbol"].lower().startswith(symbol.lower()):
#                             found = i+1
#                             break
#                     if not found:
#                         for i in range(len(hlds)):
#                             if symbol.lower() in hlds[i]["symbol"].lower():
#                                 found = i+1
#                                 break
                
#                 limit = min(limit, len(hlds))
#                 if found:
#                     page_no = ((found - 1) // limit) + 1
                
#                 offset = (page_no - 1) * limit
#                 hlds = hlds[offset : offset + limit]
#                 res["holdings"] = hlds
#                 res["page_no"] = page_no
#                 await websocket.send_json(res)
            
#             elif len(holding_data) > 0:
#                 res = holding_data
#                 hlds = res.get("holdings", [])

#                 if symbol in [None, '', "null"]:
#                     symbol = None
#                 else:
#                     for i in range(len(hlds)):
#                         if hlds[i]["symbol"].lower().startswith(symbol.lower()):
#                             found = i+1
#                             break
#                     if not found:
#                         for i in range(len(hlds)):
#                             if symbol.lower() in hlds[i]["symbol"].lower():
#                                 found = i+1
#                                 break

#                 limit = min(limit, len(hlds))
#                 if found:
#                     page_no = ((found - 1) // limit) + 1
                
#                 offset = (page_no - 1) * limit
#                 hlds = hlds[offset : offset + limit]
#                 res["holdings"] = hlds
#                 res["page_no"] = page_no
#                 await websocket.send_json(res)
            
#             else:
#                 await websocket.send_text("No data found!")
#             now_time = datetime.now().timestamp()
#             if (now_time - start_time) > 60*5:  # 5 minutes
#                 holding_data = {}

            
#             await asyncio.sleep(60)
#     except WebSocketDisconnect:
#         print("WebSocket Error: Client disconnected from WebSocket")
#     except asyncio.CancelledError:
#         return
#     except Exception as e:
#         logger.exception(e, exc_info=True, stack_info=True)
#         print("WebSocket Error:", e)