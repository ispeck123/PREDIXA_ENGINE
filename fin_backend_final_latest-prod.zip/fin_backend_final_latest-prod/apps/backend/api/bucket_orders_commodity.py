from fastapi import APIRouter, HTTPException, Request
from shared.db.db_model import OMSOrderBucketCommodity, Commodity_Order
from shared.db.req_model import BucketOrderBase, Update_BucketOrderBase, GetOrder, ApproveReject_BucketOrderBase
from shared.db.fyers_req_model import get_fyers, SingleGttOrderRequest
from shared.db.dbconn import DBConnection
from shared.db.api_responce import APIResponse
import logging
from datetime import datetime
from sqlalchemy import text, or_
import ast, re
from data_fetchers.fyers.get_stock_prices import StockPriceFetcher


logger = logging.getLogger("fyers_orders")
logging.basicConfig(level=logging.INFO)

db = DBConnection()
router = APIRouter()
#spf = StockPriceFetcher()


def safe_parse_order_status(order_status):
    if not isinstance(order_status, str):
        return order_status  # Already a dict

    if order_status.strip().startswith("{"):
        try:
            # Clean Timestamp if present
            order_status = re.sub(r"Timestamp\('(.*?)'\)", r"'\1'", order_status)
            return ast.literal_eval(order_status)
        except Exception as e:
            logging.error(f"Failed to eval order_status: {order_status} — {e}")
            return {"status": "unknown", "error": str(e)}
    else:
        # It's a simple status string like 'PENDING'
        return {"status": order_status.strip().lower()}


@router.post("/get/bucket/order/count/commodity", tags=["bucket_orders"])
async def get_bucket_orders_count_commodity(req_model: GetOrder, request: Request):
    apiresponce = APIResponse(request)
    try:
        if req_model.time_frame == None or req_model.time_frame == 'null' or req_model.time_frame == '':
            req_model.time_frame = '%%'
        
        if req_model.order_type.lower() == "all":
            order_types = ("buy", "sell", "Buy", "Sell", "BUY", "SELL")
        else:
            order_types = (req_model.order_type.lower(), req_model.order_type.upper(), req_model.order_type.capitalize())

        if req_model.prediction_type == None or req_model.prediction_type == 'null' or req_model.prediction_type == '':
            prediction_type = " "
        else:
            prediction_type = f"and arima_ab_model_prediction like '%{req_model.prediction_type}%'"
        
        req_model.status = req_model.status.strip().lower()

        if req_model.status == 'all':
            print('1')
            total_count = db.raw_query(text(f"""select count(*) as count from oms_order_bucket_commodity 
                                where country_id = {req_model.country_id} 
                                and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                and time_frame like '{req_model.time_frame}' 
                                and order_type in {order_types}
                                {prediction_type};"""))
        elif req_model.status != 'pending' and req_model.status != 'progress':
            print('2')
            total_count = db.raw_query(text(f"""select count(*) as count from oms_order_bucket_commodity 
                                where country_id = {req_model.country_id} 
                                and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                and order_status like '%{req_model.status}%'
                                and time_frame like '{req_model.time_frame}' 
                                and order_type in {order_types}
                                {prediction_type};"""))
        elif req_model.status == 'pending':
            print('3')
            total_count = db.raw_query(text(f"""select count(*) as count from oms_order_bucket_commodity 
                                where country_id = {req_model.country_id} 
                                and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                and order_status is null
                                and time_frame like '{req_model.time_frame}'
                                and order_type in {order_types}
                                {prediction_type};"""))
        elif req_model.status == 'progress':
            print('4')
            total_count = db.raw_query(text(f"""select count(*) as count from oms_order_bucket_commodity 
                                where country_id = {req_model.country_id} 
                                and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                and order_status like '%pending%'
                                and time_frame like '{req_model.time_frame}'
                                and order_type in {order_types}
                                {prediction_type};"""))
        print("total_count:", total_count)
        if total_count and len(total_count) > 0:
            apiresponce.setMsg("success")
            apiresponce.setResponse(total_count)
        else:
            apiresponce.setMsg("success")
            apiresponce.setResponse([{"count": 0}])
    except Exception as ex:
        logger.exception(ex)
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.post("/get/bucket/orders/commodity", tags=["bucket_orders"])
async def get_bucket_orders_commodity(req_model: GetOrder, request: Request):
    apiresponce = APIResponse(request)
    try:
        # if req_model.stock_tick == None or req_model.stock_tick == 'null' or req_model.stock_tick == '':
        #     req_model.stock_tick = ''
        # req_model.stock_tick = '%' + req_model.stock_tick + '%'
        try:
            req_model.page_no = int(req_model.page_no)
        except Exception as er:
            print("page_no:", req_model.page_no)
            req_model.page_no = None
        
        try:
            req_model.trade_id = int(req_model.trade_id)
        except Exception as er:
            req_model.trade_id = None

        if req_model.time_frame == None or req_model.time_frame == 'null' or req_model.time_frame == '':
            req_model.time_frame = '%%'
        
        if req_model.order_by_purchased_cmp_date:
            order_by = "purchased_cmp_date desc"
        else:
            order_by = "stock_tick asc"
        
        if req_model.order_type.lower() == "all":
            order_types = ("buy", "sell", "Buy", "Sell", "BUY", "SELL")
        else:
            order_types = (req_model.order_type.lower(), req_model.order_type.upper(), req_model.order_type.capitalize())

        if req_model.prediction_type == None or req_model.prediction_type == 'null' or req_model.prediction_type == '':
            prediction_type = " "
        else:
            prediction_type = f"and arima_ab_model_prediction like '%{req_model.prediction_type}%'"
        
        req_model.status = req_model.status.strip().lower()

        res = []


        if (req_model.trade_id != None and req_model.trade_id != 'null' and req_model.trade_id != ''):
            if req_model.status == 'all':
                print('1')
                total_res = db.raw_query(text(f"""select * from oms_order_bucket_commodity 
                                    where country_id = {req_model.country_id} 
                                    and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                    and time_frame like '{req_model.time_frame}' 
                                    and order_type in {order_types}
                                    {prediction_type}
                                    order by {order_by};"""))
            elif req_model.status != 'pending' and req_model.status != 'progress':
                print('2')
                total_res = db.raw_query(text(f"""select * from oms_order_bucket_commodity 
                                    where country_id = {req_model.country_id} 
                                    and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                    and order_status like '%{req_model.status}%'
                                    and time_frame like '{req_model.time_frame}' 
                                    and order_type in {order_types}
                                    {prediction_type}
                                    order by {order_by};"""))
            elif req_model.status == 'pending':
                print('3')
                total_res = db.raw_query(text(f"""select * from oms_order_bucket_commodity 
                                    where country_id = {req_model.country_id} 
                                    and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                    and order_status is null
                                    and time_frame like '{req_model.time_frame}'
                                    and order_type in {order_types}
                                    {prediction_type}
                                    order by {order_by};"""))
            elif req_model.status == 'progress':
                print('4')
                total_res = db.raw_query(text(f"""select * from oms_order_bucket_commodity 
                                    where country_id = {req_model.country_id} 
                                    and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                    and order_status like '%pending%'
                                    and time_frame like '{req_model.time_frame}'
                                    and order_type in {order_types}
                                    {prediction_type}
                                    order by {order_by};"""))
            #print("total_res:", total_res)
            found = False
            for i in range(len(total_res)):
                if req_model.trade_id == total_res[i]['trade_signal_id']:
                    found = i+1
                    break
            print("found:", found)
            if found:
                req_model.page_no = ((found - 1) // req_model.limit) + 1
                offset = (req_model.page_no - 1) * req_model.limit
                #print("page_no:", req_model.page_no)
                #print("offset:", offset)
                res = total_res[offset : offset + req_model.limit]
            else:
                pass

        elif (req_model.stock_tick == None or req_model.stock_tick == 'null' or req_model.stock_tick == '') and (req_model.page_no == None or req_model.page_no == 'null' or req_model.page_no == ''):
            req_model.page_no = 1
            offset = (req_model.page_no - 1) * req_model.limit
            if req_model.status == 'all':
                print('5')
                res = db.raw_query(text(f"""select * from oms_order_bucket_commodity 
                                                where country_id = {req_model.country_id} 
                                                and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types} 
                                                {prediction_type}
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
                print(f"""select * from oms_order_bucket_commodity 
                                                where country_id = {req_model.country_id} 
                                                and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types} 
                                                {prediction_type}
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};""")
            elif req_model.status != 'pending' and req_model.status != 'progress':
                print('6')
                res = db.raw_query(text(f"""select * from oms_order_bucket_commodity 
                                                where country_id = {req_model.country_id} 
                                                and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and order_status like '%{req_model.status}%'
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types} 
                                                {prediction_type}
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
            elif req_model.status == 'pending':
                print('7')
                res = db.raw_query(text(f"""select * from oms_order_bucket_commodity 
                                                where country_id = {req_model.country_id} 
                                                and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and order_status is null
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                {prediction_type}
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
            elif req_model.status == 'progress':
                print('8')
                res = db.raw_query(text(f"""select * from oms_order_bucket_commodity 
                                                where country_id = {req_model.country_id} 
                                                and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and order_status like '%pending%'
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                {prediction_type}
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
                   
        elif (req_model.stock_tick == None or req_model.stock_tick == 'null' or req_model.stock_tick == '') and (req_model.page_no != None and req_model.page_no != 'null' and req_model.page_no != ''):
            offset = (req_model.page_no - 1) * req_model.limit
            if req_model.status == 'all':
                print('9')
                res = db.raw_query(text(f"""select * from oms_order_bucket_commodity 
                                                where country_id = {req_model.country_id} 
                                                and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                {prediction_type}
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
                print(text(f"""select * from oms_order_bucket_commodity 
                                                where country_id = {req_model.country_id} 
                                                and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                {prediction_type}
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
            elif req_model.status != 'pending' and req_model.status != 'progress':
                print('10')
                res = db.raw_query(text(f"""select * from oms_order_bucket_commodity 
                                                where country_id = {req_model.country_id} 
                                                and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and order_status like '%{req_model.status}%' 
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                {prediction_type}
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
            elif req_model.status == 'pending':
                print('11')
                res = db.raw_query(text(f"""select * from oms_order_bucket_commodity 
                                                where country_id = {req_model.country_id} 
                                                and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and order_status is null 
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                {prediction_type}
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
            elif req_model.status == 'progress':
                print('12')
                res = db.raw_query(text(f"""select * from oms_order_bucket_commodity 
                                                where country_id = {req_model.country_id} 
                                                and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and order_status like '%pending%'
                                                and time_frame like '{req_model.time_frame}' 
                                                and order_type in {order_types}
                                                {prediction_type}
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
        
        elif (req_model.stock_tick != None and req_model.stock_tick != 'null' and req_model.stock_tick != '') and (req_model.page_no == None or req_model.page_no == 'null' or req_model.page_no == ''):            
            if req_model.status == 'all':
                print('13')
                total_res = db.raw_query(text(f"""select * from oms_order_bucket_commodity 
                                    where country_id = {req_model.country_id} 
                                    and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                    and time_frame like '{req_model.time_frame}' 
                                    and order_type in {order_types}
                                    {prediction_type}
                                    order by {order_by};"""))
            elif req_model.status != 'pending' and req_model.status != 'progress':
                print('14')
                total_res = db.raw_query(text(f"""select * from oms_order_bucket_commodity 
                                    where country_id = {req_model.country_id} 
                                    and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                    and order_status like '%{req_model.status}%'
                                    and time_frame like '{req_model.time_frame}' 
                                    and order_type in {order_types}
                                    {prediction_type}
                                    order by {order_by};"""))
            elif req_model.status == 'pending':
                print('15')
                total_res = db.raw_query(text(f"""select * from oms_order_bucket_commodity 
                                    where country_id = {req_model.country_id} 
                                    and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                    and order_status is null
                                    and time_frame like '{req_model.time_frame}'
                                    and order_type in {order_types}
                                    {prediction_type}
                                    order by {order_by};"""))
            elif req_model.status == 'progress':
                print('16')
                total_res = db.raw_query(text(f"""select * from oms_order_bucket_commodity 
                                    where country_id = {req_model.country_id} 
                                    and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                    and order_status like '%pending%'
                                    and time_frame like '{req_model.time_frame}'
                                    and order_type in {order_types}
                                    {prediction_type}
                                    order by {order_by};"""))
            found = False
            for i in range(len(total_res)):
                if total_res[i]['stock_tick'].lower().startswith(req_model.stock_tick.lower()):
                    found = i+1
                    break
            if not found:
                for i in range(len(total_res)):
                    if req_model.stock_tick.lower() in total_res[i]['stock_tick'].lower():
                        found = i+1
                        break
            #print("found:", found)
            if found:
                req_model.page_no = ((found - 1) // req_model.limit) + 1
                offset = (req_model.page_no - 1) * req_model.limit
                #print("offset:", offset)
                res = total_res[offset : offset + req_model.limit]
            else:
                pass
        
        elif (req_model.stock_tick != None and req_model.stock_tick != 'null' and req_model.stock_tick != '') and (req_model.page_no != None and req_model.page_no != 'null' and req_model.page_no != ''):
            offset = (req_model.page_no - 1) * req_model.limit
            if req_model.status == 'all':
                print('17')
                res = db.raw_query(text(f"""select * from oms_order_bucket_commodity 
                                                where country_id = {req_model.country_id} 
                                                and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                {prediction_type}
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
            elif req_model.status != 'pending' and req_model.status != 'progress':
                print('18')
                res = db.raw_query(text(f"""select * from oms_order_bucket_commodity 
                                                where country_id = {req_model.country_id} 
                                                and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and order_status like '%{req_model.status}%' 
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                {prediction_type}
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
            elif req_model.status == 'pending':
                print('19')
                res = db.raw_query(text(f"""select * from oms_order_bucket_commodity 
                                                where country_id = {req_model.country_id} 
                                                and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and order_status is null 
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                {prediction_type}
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
            elif req_model.status == 'progress':
                print('20')
                res = db.raw_query(text(f"""select * from oms_order_bucket_commodity 
                                                where country_id = {req_model.country_id} 
                                                and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}' 
                                                and order_status like '%pending%' 
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                {prediction_type}
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
         
        
        apiresponce.setMsg("success")
        apiresponce.setResponse({"orders": res, "page_no": req_model.page_no})
    except Exception as ex:
        logger.exception(ex)
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/bucket/orders/commodity/{order_id}", tags=["bucket_orders"])
async def get_bucket_order_commodity_by_id(order_id: int, request: Request):
    apiresponce = APIResponse(request)
    try:
        session = db.get_session()
        res = session.query(OMSOrderBucketCommodity).filter(OMSOrderBucketCommodity.order_id == order_id).first()
        if res is None:
            apiresponce.setMsg("failed")
            apiresponce.setResponse("Order Not Found")
            return apiresponce
        apiresponce.setMsg("success")
        apiresponce.setResponse(res)
        return apiresponce
    except Exception as e:
        logger.exception("Failed to fetch bucket order by id")
        raise HTTPException(status_code=502, detail=f"Error fetching bucket order by id: {e}")
    finally:
        session.close()


@router.post("/create/bucket/orders/commodity", tags=["bucket_orders"])
async def create_bucket_order_commodity(body: BucketOrderBase, request: Request):
    apiresponce = APIResponse(request)
    try:
        session = db.get_session()
        if body.trade_id != None:
            bucket_order = session.query(OMSOrderBucketCommodity).filter(OMSOrderBucketCommodity.trade_signal_id == body.trade_id).all()
            if bucket_order and len(bucket_order) > 0:
                apiresponce.setMsg("failed")
                apiresponce.setResponse("Bucket order already exists for the given trade")
                session.close()
                return apiresponce
        order_id = None
        if body.trade_id != None:
            order = session.query(Commodity_Order).filter(Commodity_Order.trade_signal_id == body.trade_id).all()
            if order and len(order) > 0 and order[0].order_id != None:
                order_id = order[0].order_id
            else:
                order_id = body.order_id
        oms_order_bucket = OMSOrderBucketCommodity(
            order_id = order_id,
            trade_signal_id = body.trade_id,
            country_id = body.country_id,
            stock_tick = body.stock_tick,
            stock_id = body.stock_id,
            time_frame = body.time_frame,
            order_type = body.order_type,
            entry_price = body.entry_price,
            stoploss_price = body.stoploss_price,
            target_price = body.target_price,
            stock_quantity = body.stock_quantity,
            purchased_cmp_date = body.purchased_cmp_date,
            purchased_on = datetime.now(),
            order_status = "pending",
            expiry_date = body.expiry_date)
        session.add(oms_order_bucket)
        session.commit()
        apiresponce.setMsg("success")
        apiresponce.setResponse(oms_order_bucket)
    except Exception as e:
        logger.exception("Failed to create bucket order")
        raise HTTPException(status_code=502, detail=f"Error creating bucket order: {e}")
    finally:
        session.close()
    return apiresponce


@router.post("/approve/reject/bucket/orders/commodity", tags=["bucket_orders"])
async def approve_reject_bucket_orders_commodity(body: ApproveReject_BucketOrderBase, request: Request):
    apiresponce = APIResponse(request)
    try:
        session = db.get_session()
        row = session.query(OMSOrderBucketCommodity).filter(OMSOrderBucketCommodity.bucket_id == body.bucket_id).first()
        if len(row) == 0:
            raise HTTPException(status_code=404, detail="Bucket order not found !")
        print(body.status)
        row[0].approval_status = body.status
        row[0].approved_by = body.approved_by
        row[0].approved_at = datetime.now()
        session.add(row[0])
        session.commit()
        apiresponce.setMsg("success")
        apiresponce.setResponse("Bucket order updated successfully")
        #return apiresponce
    except Exception as ex:
        logger.exception("Failed to update bucket order")
        raise HTTPException(status_code=502, detail=f"Error updating bucket order: {ex}")
    finally:
        session.close()
    return apiresponce