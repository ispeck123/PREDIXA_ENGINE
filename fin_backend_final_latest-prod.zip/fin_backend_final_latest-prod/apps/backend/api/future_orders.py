from fastapi import APIRouter, Request
from shared.utils.logger import logger
from shared.db.req_model import Future_and_commodity_OrderBase, GetOrder
from shared.db.api_responce import APIResponse
from shared.db.db_model import Future_Order
from shared.db.dbconn import DBConnection
from datetime import datetime
from sqlalchemy import text
import json
import ast

dbc = DBConnection()
router = APIRouter()

@router.post("/create_futures_order", tags=['Futures Order'])
async def create_futures_order(request: Request, order: Future_and_commodity_OrderBase):
    apiresponce = APIResponse(request)
    try:
        db_order = Future_Order(
                country_id=order.country_id,
                stock_id=order.stock_id,
                stock_tick=order.stock_tick,
                time_frame=order.time_frame,
                order_type=order.order_type,
                entry_price=order.entry_price,
                stoploss_price=order.stoploss_price,
                target_price=order.target_price,
                stock_quantity=order.stock_quantity,
                purchased_cmp_date=order.purchased_cmp_date,
                purchased_on=datetime.now(),
                arima_ab_model_prediction=order.prediction,
                arima_ab_model_prob=order.probability,
                expiry_date=order.exp_date,
                trade_signal_id = order.trade_id)
        
        session = dbc.get_session()
        session.add(db_order)
        session.commit()
        session.refresh(db_order)
        session.close()
        apiresponce.setMsg("success")
        apiresponce.setResponse({"order_id": db_order.order_id})
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce



@router.post("/get_futures_order_count", tags=['Futures Order'])
async def get_futures_order_count(req_model: GetOrder, request: Request):
    apiresponce = APIResponse(request)
    try:
        if req_model.stock_tick == None or req_model.stock_tick == 'null' or req_model.stock_tick == '':
            req_model.stock_tick = ''
        req_model.stock_tick = '%' + req_model.stock_tick + '%'

        if req_model.time_frame == None or req_model.time_frame == 'null' or req_model.time_frame == '':
            req_model.time_frame = '%%'
        
        if req_model.order_type.lower() == "all":
            order_types = ("buy", "sell", "Buy", "Sell", "BUY", "SELL")
        else:
            order_types = (req_model.order_type.lower(), req_model.order_type.upper(), req_model.order_type.capitalize())
        
        if req_model.prediction_type == None or req_model.prediction_type == 'null' or req_model.prediction_type == '':
            req_model.prediction_type = '%%'
        
        res = {"success": 0, "failed": 0, "pending": 0, "in_progress": 0}

        for status in res.keys():
            if status != 'pending' and status != 'in_progress':
                res[status] = len(dbc.raw_query(text(f"""select * from future_order_master
                                            where country_id = {req_model.country_id}
                                            and stock_tick like '{req_model.stock_tick}'
                                            and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}'
                                            and order_status like '%{status}%'
                                            and time_frame like '{req_model.time_frame}'
                                            and order_type in {order_types}
                                            and arima_ab_model_prediction like '{req_model.prediction_type}'
                                            order by entry_timestamp desc;""")))
            elif status == 'pending':
                res[status] = len(dbc.raw_query(text(f"""select * from future_order_master
                                            where country_id = {req_model.country_id}
                                            and stock_tick like '{req_model.stock_tick}'
                                            and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}'
                                            and order_status is null
                                            and time_frame like '{req_model.time_frame}'
                                            and order_type in {order_types}
                                            and arima_ab_model_prediction like '{req_model.prediction_type}'
                                            order by purchased_cmp_date desc;""")))
            elif status == 'in_progress':
                res[status] = len(dbc.raw_query(text(f"""select * from future_order_master
                                            where country_id = {req_model.country_id}
                                            and stock_tick like '{req_model.stock_tick}'
                                            and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}'
                                            and order_status like '%pending%'
                                            and time_frame like '{req_model.time_frame}'
                                            and order_type in {order_types}
                                            and arima_ab_model_prediction like '{req_model.prediction_type}'
                                            order by entry_timestamp desc;""")))

        print(res)
        apiresponce.setMsg("success")
        apiresponce.setResponse(res)
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.post("/get_futures_order_list", tags=['Futures Order'])
async def get_futures_order_list(req_model: GetOrder, request: Request):
    print(req_model.__dict__)
    apiresponce = APIResponse(request)
    try:
        # if req_model.stock_tick == None or req_model.stock_tick == 'null' or req_model.stock_tick == '':
        #     req_model.stock_tick = ''
        # req_model.stock_tick = '%' + req_model.stock_tick + '%'

        if req_model.time_frame == None or req_model.time_frame == 'null' or req_model.time_frame == '':
            req_model.time_frame = '%%'

        if req_model.order_by_purchased_cmp_date:
            order_by = "purchased_cmp_date desc"
        else:
            order_by = "stock_tick asc"
        
        if req_model.order_type.lower() == "all":
            order_types = ("buy", "sell", "Buy", "Sell", "BUY", "SELL")
        else:
            order_types = (req_model.order_type.lower(), req_model.order_type.upper(), req_model.order_type.capitalize())

        try:
            req_model.page_no = int(req_model.page_no)
        except Exception as er:
            print("page_no:", req_model.page_no)
            req_model.page_no = None
        
        if req_model.prediction_type == None or req_model.prediction_type == 'null' or req_model.prediction_type == '':
            req_model.prediction_type = '%%'
        
        res = []
        
        if (req_model.stock_tick == None or req_model.stock_tick == 'null' or req_model.stock_tick == '') and (req_model.page_no == None or req_model.page_no == 'null' or req_model.page_no == ''):
            req_model.page_no = 1
            offset = (req_model.page_no - 1) * req_model.limit
            if req_model.status != 'pending' and req_model.status != 'progress':
                res = dbc.raw_query(text(f"""select * from future_order_master
                                                where country_id = {req_model.country_id}
                                                and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}'
                                                and order_status like '%{req_model.status}%'
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                and arima_ab_model_prediction like '{req_model.prediction_type}'
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
            elif req_model.status == 'pending':
                res = dbc.raw_query(text(f"""select * from future_order_master
                                                where country_id = {req_model.country_id}
                                                and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}'
                                                and order_status is null
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                and arima_ab_model_prediction like '{req_model.prediction_type}'
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
            elif req_model.status == 'progress':
                res = dbc.raw_query(text(f"""select * from future_order_master
                                                where country_id = {req_model.country_id}
                                                and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}'
                                                and order_status like '%pending%'
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                and arima_ab_model_prediction like '{req_model.prediction_type}'
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))

        elif (req_model.stock_tick == None or req_model.stock_tick == 'null' or req_model.stock_tick == '') and (req_model.page_no != None and req_model.page_no != 'null' and req_model.page_no != ''):
            offset = (req_model.page_no - 1) * req_model.limit
            if req_model.status != 'pending' and req_model.status != 'progress':
                res = dbc.raw_query(text(f"""select * from future_order_master
                                                where country_id = {req_model.country_id}
                                                and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}'
                                                and order_status like '%{req_model.status}%'
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                and arima_ab_model_prediction like '{req_model.prediction_type}'
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
            elif req_model.status == 'pending':
                res = dbc.raw_query(text(f"""select * from future_order_master
                                                where country_id = {req_model.country_id}
                                                and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}'
                                                and order_status is null
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                and arima_ab_model_prediction like '{req_model.prediction_type}'
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
            elif req_model.status == 'progress':
                res = dbc.raw_query(text(f"""select * from future_order_master
                                                where country_id = {req_model.country_id}
                                                and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}'
                                                and order_status like '%pending%'
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                and arima_ab_model_prediction like '{req_model.prediction_type}'
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))

        elif (req_model.stock_tick != None and req_model.stock_tick != 'null' and req_model.stock_tick != '') and (req_model.page_no == None or req_model.page_no == 'null' or req_model.page_no == ''):         
            if req_model.status != 'pending' and req_model.status != 'progress':
                total_res = dbc.raw_query(text(f"""select * from future_order_master
                                    where country_id = {req_model.country_id}
                                    and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}'
                                    and order_status like '%{req_model.status}%'
                                    and time_frame like '{req_model.time_frame}'
                                    and order_type in {order_types}
                                    and arima_ab_model_prediction like '{req_model.prediction_type}'
                                    order by {order_by};"""))
            elif req_model.status == 'pending':
                total_res = dbc.raw_query(text(f"""select * from future_order_master
                                    where country_id = {req_model.country_id}
                                    and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}'
                                    and order_status is null
                                    and time_frame like '{req_model.time_frame}'
                                    and order_type in {order_types}
                                    and arima_ab_model_prediction like '{req_model.prediction_type}'
                                    order by {order_by};"""))
            elif req_model.status == 'progress':
                total_res = dbc.raw_query(text(f"""select * from future_order_master
                                    where country_id = {req_model.country_id}
                                    and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}'
                                    and order_status like '%pending%'
                                    and time_frame like '{req_model.time_frame}'
                                    and order_type in {order_types}
                                    and arima_ab_model_prediction like '{req_model.prediction_type}'
                                    order by {order_by};"""))
            found = False
            for i in range(len(total_res)):
                if req_model.stock_tick.lower() in total_res[i]['stock_tick'].lower():
                    found = i+1
                    break
            #print("found:", found)
            if found:
                req_model.page_no = ((found - 1) // req_model.limit) + 1
                offset = (req_model.page_no - 1) * req_model.limit
                #print("offset:", offset)
                res = total_res[offset : offset + req_model.limit]
                # if req_model.status != 'pending' and req_model.status != 'progress':
                #     res = dbc.raw_query(text(f"""select * from future_order_master
                #                                     where country_id = {req_model.country_id}
                #                                     and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}'
                #                                     and order_status like '%{req_model.status}%'
                #                                     and time_frame like '{req_model.time_frame}'
                #                                     and order_type in {order_types}
                #                                     order by {order_by}
                #                                     limit {req_model.limit} offset {offset};"""))
                # elif req_model.status == 'pending':
                #     res = dbc.raw_query(text(f"""select * from future_order_master
                #                                     where country_id = {req_model.country_id}
                #                                     and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}'
                #                                     and order_status is null
                #                                     and time_frame like '{req_model.time_frame}'
                #                                     and order_type in {order_types}
                #                                     order by {order_by}
                #                                     limit {req_model.limit} offset {offset};"""))
                # elif req_model.status == 'progress':
                #     res = dbc.raw_query(text(f"""select * from future_order_master
                #                                     where country_id = {req_model.country_id}
                #                                     and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}'
                #                                     and order_status like '%pending%'
                #                                     and time_frame like '{req_model.time_frame}'
                #                                     and order_type in {order_types}
                #                                     order by {order_by}
                #                                     limit {req_model.limit} offset {offset};"""))
            else:
                pass

        elif (req_model.stock_tick != None and req_model.stock_tick != 'null' and req_model.stock_tick != '') and (req_model.page_no != None and req_model.page_no != 'null' and req_model.page_no != ''):
            offset = (req_model.page_no - 1) * req_model.limit
            if req_model.status != 'pending' and req_model.status != 'progress':
                res = dbc.raw_query(text(f"""select * from future_order_master
                                                where country_id = {req_model.country_id}
                                                and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}'
                                                and order_status like '%{req_model.status}%'
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                and arima_ab_model_prediction like '{req_model.prediction_type}'
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
            elif req_model.status == 'pending':
                res = dbc.raw_query(text(f"""select * from future_order_master
                                                where country_id = {req_model.country_id}
                                                and date(purchased_cmp_date) between '{req_model.start_date}' and '{req_model.end_date}'
                                                and order_status is null
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                and arima_ab_model_prediction like '{req_model.prediction_type}'
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
            elif req_model.status == 'progress':
                res = dbc.raw_query(text(f"""select * from future_order_master
                                                where country_id = {req_model.country_id}
                                                and date(entry_timestamp) between '{req_model.start_date}' and '{req_model.end_date}'
                                                and order_status like '%pending%'
                                                and time_frame like '{req_model.time_frame}'
                                                and order_type in {order_types}
                                                and arima_ab_model_prediction like '{req_model.prediction_type}'
                                                order by {order_by}
                                                limit {req_model.limit} offset {offset};"""))
        if res != None:
            for order in res:
                try:
                    if order['order_status'] == None:
                        order['order_status'] = 'pending'
                    else:
                        # order['order_status'] = order['order_status'].replace("'", '"')
                        # order['order_status'] = json.loads(order['order_status'])
                        order['order_status'] = ast.literal_eval(order['order_status'])
                        status = order['order_status']

                        if order['order_status']['status'] == 'success':
                            order['order_status'] = 'success'
                            order['reason'] = status.get('reason', None)
                            order['profit_amount'] = status.get('profit_amount', None)

                        elif order['order_status']['status'] == 'failed':
                            order['order_status'] = 'failed'
                            order['reason'] = status.get('reason', None)
                            order['loss_amount'] = status.get('loss_amount', None)

                        elif order['order_status']['status'] == 'pending':
                            order['order_status'] = 'executed'
                            order['difference'] = status.get('difference', None)
                            order['percentage_change'] = status.get('percentage_change', None)
                except Exception as err:
                    logger.exception(err)
                    print(order['order_status'])
                    order['order_status'] = None 

        apiresponce.setMsg("success")
        apiresponce.setResponse({"orders": res, "page_no": req_model.page_no})
    except Exception as ex:
        logger.exception(ex)
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/delete_futures_order", tags=['Futures Order'])
async def delete_futures_order(order_id: int, request: Request):
    apiresponce = APIResponse(request)
    try:
        rc = dbc.raw_connection()
        query = f"delete from future_order_master where order_id={order_id};"
        rc.execute(text(query))
        rc.commit()
        rc.close()
        apiresponce.setMsg("success")
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce