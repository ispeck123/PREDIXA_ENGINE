from fastapi import APIRouter, Request, HTTPException, Query
from fastapi.responses import HTMLResponse
from shared.db.db_model import UserAlert, Ind_StockMaster, GLOBAL_COMMODITY_ALERTS  # your ORM model
from shared.db.dbconn import DBConnection  # your DB session provider
from shared.db.req_model import UserAlertCreate, UserAlertUpdate, GetAlert  # the schema above
from shared.db.api_responce import APIResponse
from shared.utils.logger import logger
from datetime import datetime
from typing import Optional
from pathlib import Path

dbc = DBConnection()
router = APIRouter()

@router.post("/alerts/create", tags=['Alerts'])
def create_user_alert(request: Request, alert: UserAlertCreate):
    apiresponce = APIResponse(request)
    try:
        session = dbc.get_session()
        new_alert = UserAlert(
                user_id=alert.user_id,
                country_id=alert.country_id,
                stock_symbol=alert.stock_symbol,
                exchange=alert.exchange,
                alert_type=alert.alert_type,
                trigger_price=alert.trigger_price,
                price_range_min=alert.price_range_min,
                price_range_max=alert.price_range_max,
                threshold=alert.threshold,
                timeframe=alert.timeframe,
                note=alert.note,
                is_active=alert.is_active,
                recurrent=alert.recurrent,
                expiry_date=alert.expiry_date,
                email_notification=alert.email_notification,
                webhook_url=alert.webhook_url,
                target_percentage=alert.target_percentage,
                cooldown_minutes=alert.cooldown_minutes,
                created_at=datetime.now(),
                updated_at=datetime.now(),
                is_sys = False
            )

        session.add(new_alert)
        session.commit()
        session.refresh(new_alert)
        apiresponce.setMsg("success")
        apiresponce.setResponse({"message": "Alert created successfully", "alert_id": new_alert.id})
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.put("/alerts/update/{alert_id}", tags=['Alerts'])
def update_user_alert(request: Request, alert_id: int, alert_data: UserAlertUpdate):
    apiresponce = APIResponse(request)
    try:
        session = dbc.get_session()
        alert = session.query(UserAlert).filter(UserAlert.id == alert_id).first()
        if not alert:
            raise HTTPException(status_code=404, detail="Alert not found")

        update_data = alert_data.model_dump(exclude_unset=True)
        for key, value in update_data.items():
            setattr(alert, key, value)

        alert.updated_at = datetime.utcnow()
        session.commit()
        session.refresh(alert)
        apiresponce.setMsg("success")
        apiresponce.setResponse({"message": "Alert updated successfully", "alert_id": alert.id})
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


# @router.get("/get_alerts", tags=['Alerts'])
# def get_alerts(request: Request, user_id: Optional[int] = Query(None)):
#     apiresponce = APIResponse(request)
#     try:
#         session = dbc.get_session()
#         query = session.query(UserAlert, Ind_StockMaster.stock_tick).join(
#             Ind_StockMaster, UserAlert.stock_symbol == Ind_StockMaster.kite_symbol
#         )
#         if user_id is not None:
#             query = query.filter(UserAlert.user_id == user_id, UserAlert.is_active == True)
#             # alerts = session.query(UserAlert).filter(UserAlert.user_id == user_id, UserAlert.is_active == 1).all()
#         else:
#             query = query.filter(UserAlert.is_active == True)
#         alerts = query.all()
#         apiresponce.setMsg("success")
#         apiresponce.setResponse(alerts)
#     except Exception as ex:
#         logger.error(ex, stack_info=True)
#         apiresponce.setMsg("failed")
#         apiresponce.setResponse(str(ex))
#     return apiresponce


# @router.post("/get_alerts_by_filter", tags=['Alerts'])
# def get_alerts_by_filter(request: Request, model: GetAlert):
#     apiresponce = APIResponse(request)
#     try:
#         dbc = DBConnection()
#         session = dbc.get_session()
#         if model.user_id == None or model.user_id == "null" or model.user_id.lower() == "all" or model.user_id == "":
#             model.user_id = f"%{model.user_id}%"
#             alerts = session.query(UserAlert).filter(UserAlert.user_id == user_id, UserAlert.is_active == 1).all()
#         else:
#             alerts = session.query(UserAlert).filter(UserAlert.is_active == 1).all()
#         apiresponce.setMsg("success")
#         apiresponce.setResponse(alerts)
#     except Exception as ex:
#         logger.error(ex, stack_info=True)
#         apiresponce.setMsg("failed")
#         apiresponce.setResponse(str(ex))
#     return apiresponce


@router.delete("/alerts/delete/{alert_id}", tags=['Alerts'])
def delete_user_alert(request: Request, alert_id: int):
    apiresponce = APIResponse(request)
    try:
        session = dbc.get_session()
        alert = session.query(UserAlert).filter(UserAlert.id == alert_id).first()
        if not alert:
            raise HTTPException(status_code=404, detail="Alert not found")
        session.delete(alert)
        session.commit()
        apiresponce.setMsg("success")
        apiresponce.setResponse({"message": f"Alert ID {alert_id} deleted successfully"})
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce
    

    

@router.post("/xauusd/alerts/create", tags=['Alerts'])
def create_user_alert(request: Request, alert: UserAlertCreate):
    apiresponce = APIResponse(request)
    try:
        session = dbc.get_session()
        new_alert = GLOBAL_COMMODITY_ALERTS(
                user_id=alert.user_id,
                country_id=alert.country_id,
                stock_symbol=alert.stock_symbol,
                exchange=alert.exchange,
                alert_type=alert.alert_type,
                trigger_price=alert.trigger_price,
                price_range_min=alert.price_range_min,
                price_range_max=alert.price_range_max,
                threshold=alert.threshold,
                timeframe=alert.timeframe,
                note=alert.note,
                is_active=alert.is_active,
                recurrent=alert.recurrent,
                expiry_date=alert.expiry_date,
                email_notification=alert.email_notification,
                webhook_url=alert.webhook_url,
                target_percentage=alert.target_percentage,
                cooldown_minutes=alert.cooldown_minutes,
                created_at=datetime.now(),
                updated_at=datetime.now()
            )

        session.add(new_alert)
        session.commit()
        session.refresh(new_alert)
        apiresponce.setMsg("success")
        apiresponce.setResponse({"message": "Alert created successfully", "alert_id": new_alert.id})
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/get_xauusd_alert_page", tags=['Alerts'])
async def get_xauusd_alert_page():
    html_path = Path("./firebase_auth/public/index.html")
    if html_path.exists():
        return HTMLResponse(content=html_path.read_text(), status_code=200)
    return HTMLResponse(content="File not found", status_code=404)


@router.get("/generate_custom_alerts", tags = ['Alerts'])
async def generate_custom_alerts():
    pass