from fastapi import APIRouter, Depends, HTTPException, status, Query, WebSocket, WebSocketDisconnect
import logging
from shared.utils.logger import logger
from shared.db.fyers_req_model import PlaceOrderRequest, PlaceOrderResponse, BracketOrderRequest, BracketOrderResponse, CreateGTTOCORequest, CombinedOrderResponse, build_gtt_oco_payload, get_ltp_for_symbol
from shared.db.fyers_req_model import get_fyers, ExitPositionsResponse, ExitPositionsRequest, ExitPositionItemResponse, UpdateLiveOrderRequest
from shared.db.fyers_req_model import FyersClient, SingleGttOrderRequest, ModifyGttRequest, classify_gtt_orders, build_modify_gtt_payload
from shared.db.db_model import OMSOrderBucket, OMSOrderBucketCommodity, OMSOrderBucketFuture, OMSOrders, OMSOrderEvents, Order, Future_Order, Commodity_Order
from shared.db.req_model import OrderBase
from shared.db.dbconn import DBConnection
from data_fetchers.fyers.fyers_utils import normalize_cash_oco_prices, get_pending_oco_by_id, get_pending_gtt_by_id
import asyncio
from typing import List

logger = logging.getLogger("fyers_orders")
logging.basicConfig(level=logging.INFO)

router = APIRouter()
db = DBConnection()
session = db.get_session()


@router.post("/fyers/orders", response_model=PlaceOrderResponse, status_code=status.HTTP_201_CREATED, tags=["fyers_orders"])
def place_order(
    body: PlaceOrderRequest,
    fyers: FyersClient = Depends(get_fyers),
    dry_run: bool = Query(False, description="If true, validate & return mapped payload without placing order"),
):
    """Place an order on FYERS with full validation.

    - Validates conditional fields based on order/product type
    - Optionally returns the mapped payload without executing if dry_run=true
    - Forwards the request to FYERS and normalizes the success/error shape
    """
    # PRODUCTION GUARD: Check GLOBAL_HALT before any new cash entry
    try:
        from scripts.futures_state_store import StateStore
        from scripts.futures_risk_engine import RiskEngine
        from shared.db.dbconn import DBConnection
        store = StateStore(DBConnection().engine)
        risk = RiskEngine(store)
        if risk.cash_entry_allowed() == 'GLOBAL_REALIZED_LOSS_CEILING':
            raise HTTPException(status_code=403, detail="GLOBAL_HALT ACTIVE: New cash entries blocked")
    except Exception as e:
        if isinstance(e, HTTPException): raise e
        raise HTTPException(status_code=500, detail=f"Global Halt check failed: {e}")

    payload = body.to_fyers_payload()

    if dry_run:
        # Helpful for testing integrations without actually placing orders
        return PlaceOrderResponse(s="ok", code=1101, message="Dry run - payload validated", id=None)

    try:
        resp = fyers.place_order(payload)
    except Exception as e:
        logger.exception("FYERS place_order raised an exception")
        raise HTTPException(status_code=502, detail=f"FYERS exception: {e}")

    # Normalize FYERS response
    if not isinstance(resp, dict):
        raise HTTPException(status_code=502, detail="Unexpected response from FYERS")

    if resp.get("s") != "ok":
        # Forward FYERS-provided details where possible
        detail = {
            "status": resp.get("s"),
            "code": resp.get("code"),
            "message": resp.get("message", "Order failed"),
            "id": resp.get("id"),
        }
        raise HTTPException(status_code=400, detail=detail)

    return PlaceOrderResponse(**resp)


@router.post("/fyers/orders/bracket-cnc", response_model=BracketOrderResponse, status_code=201, tags=["fyers_orders"])
def place_cnc_bracket(
    body: BracketOrderRequest,
    fyers: FyersClient = Depends(get_fyers),
):
    """
    Places a 3-leg CNC pseudo bracket order:
    1. Entry LIMIT order
    2. Stoploss SELL LIMIT order
    3. Target SELL LIMIT order
    """

    # 1. ENTRY ORDER
    # PRODUCTION GUARD: Check GLOBAL_HALT before any new cash entry
    try:
        from scripts.futures_state_store import StateStore
        from scripts.futures_risk_engine import RiskEngine
        from shared.db.dbconn import DBConnection
        store = StateStore(DBConnection().engine)
        risk = RiskEngine(store)
        if risk.cash_entry_allowed() == 'GLOBAL_REALIZED_LOSS_CEILING':
            raise HTTPException(status_code=403, detail="GLOBAL_HALT ACTIVE: New cash entries blocked")
    except Exception as e:
        if isinstance(e, HTTPException): raise e
        raise HTTPException(status_code=500, detail=f"Global Halt check failed: {e}")

    entry_order = {
        "symbol": body.symbol,
        "qty": body.qty,
        "type": 1,               # LIMIT
        "side": 1,               # BUY
        "productType": "CNC",
        "limitPrice": body.entry_price,
        "stopPrice": 0,
        "validity": "DAY"
    }

    entry_resp = fyers.place_order(entry_order)
    if entry_resp.get("s") != "ok":
        return BracketOrderResponse(
            status="error",
            entry_id=None,
            stoploss_id=None,
            target_id=None,
            message="Entry failed: " + entry_resp.get("message", "")
        )

    entry_id = entry_resp.get("id")

    # 2. STOPLOSS ORDER (SELL)
    stoploss_order = {
        "symbol": body.symbol,
        "qty": body.qty,
        "type": 1,               # LIMIT (CNC does NOT allow SL-MARKET)
        "side": -1,              # SELL
        "productType": "CNC",
        "limitPrice": body.stoploss_price,
        "stopPrice": 0,
        "validity": "DAY"
    }

    # Protective exit: allowed even when GLOBAL_HALT is active.
    sl_resp = fyers.place_protective_order(stoploss_order)
    sl_id = sl_resp.get("id") if sl_resp.get("s") == "ok" else None

    # 3. TARGET ORDER (SELL)
    target_order = {
        "symbol": body.symbol,
        "qty": body.qty,
        "type": 1,               # LIMIT
        "side": -1,              # SELL
        "productType": "CNC",
        "limitPrice": body.target_price,
        "stopPrice": 0,
        "validity": "DAY"
    }

    # Protective exit: allowed even when GLOBAL_HALT is active.
    tgt_resp = fyers.place_protective_order(target_order)
    tgt_id = tgt_resp.get("id") if tgt_resp.get("s") == "ok" else None

    return BracketOrderResponse(
        status="ok",
        entry_id=entry_id,
        stoploss_id=sl_id,
        target_id=tgt_id,
        message="Bracket CNC orders placed successfully"
    )



@router.post("/fyers/gtt/custom_oco_bracket", response_model=CombinedOrderResponse, status_code=status.HTTP_201_CREATED, tags=["fyers_orders"])
def create_gtt_oco(body: CreateGTTOCORequest, fyers: FyersClient = Depends(get_fyers), dry_run: bool = Query(False, description="If true, validate & return mapped GTT payload without creating it on FYERS")):
    try:
        # PRODUCTION GUARD: Check GLOBAL_HALT before any new cash entry
        from scripts.futures_state_store import StateStore
        from scripts.futures_risk_engine import RiskEngine
        from shared.db.dbconn import DBConnection
        store = StateStore(DBConnection().engine)
        risk = RiskEngine(store)
        if risk.cash_entry_allowed() == 'GLOBAL_REALIZED_LOSS_CEILING':
            raise HTTPException(status_code=403, detail="GLOBAL_HALT ACTIVE: New cash entries blocked")

        ltp = get_ltp_for_symbol(fyers, body.symbol)
    except HTTPException as e:
        raise HTTPException(status_code=e.status_code, detail=e.detail)
    except Exception as e:
        logger.exception("Failed to fetch LTP for symbol %s", body.symbol)
        raise HTTPException(status_code=502, detail=f"Error fetching LTP: {e}")
    
    entry_payload = PlaceOrderRequest(symbol=body.symbol, qty=body.qty, type=1, side=body.side, productType="CNC", limitPrice=body.entry, ).to_fyers_payload()
    gtt_payload = build_gtt_oco_payload(body, ltp=ltp)

    if dry_run:
        # Return just to show what will be sent to FYERS
        return PlaceOrderResponse(
            s="ok",
            code=1101,
            message="Dry run - GTT OCO payload validated",
            id=None,  # no id yet
            # If your PlaceOrderResponse has extra fields, add them here
        )

    try:
        entry_resp = fyers.place_order(entry_payload)
    except Exception as e:
        logger.exception("FYERS place_order raised an exception")
        raise HTTPException(status_code=502, detail=f"FYERS exception: {e}")

    if entry_resp.get("s") != "ok":
        detail = {
            "status": entry_resp.get("s"),
            "code": entry_resp.get("code"),
            "message": entry_resp.get("message", "Entry order failed"),
            "id": entry_resp.get("id"),
        }
        raise HTTPException(status_code=400, detail=detail)

    try:
        # This GTT is the protective OCO for the already accepted cash entry.
        gtt_resp = fyers.place_protective_gtt(gtt_payload)
    except Exception as e:
        logger.exception("FYERS place_gtt_order raised an exception", exc_info=True, stack_info=True)
        raise HTTPException(status_code=502, detail=f"FYERS GTT exception: {e}")

    if not isinstance(gtt_resp, dict):
        raise HTTPException(status_code=502, detail="Unexpected response from FYERS for GTT")

    if gtt_resp.get("s") != "ok":
        detail = {
            "status": gtt_resp.get("s"),
            "code": gtt_resp.get("code"),
            "message": gtt_resp.get("message", "GTT order failed"),
            "id": gtt_resp.get("id"),
        }
        raise HTTPException(status_code=400, detail=detail)

    return CombinedOrderResponse(
        entry=PlaceOrderResponse(**entry_resp),
        gtt=PlaceOrderResponse(**gtt_resp),
    )

    




@router.delete("/delete/oms/order", tags=["fyers_orders"])
def delete_oms_order():

    try:
        pass
    except Exception as e:
        logger.exception("FYERS delete_oms_order raised an exception")
        raise HTTPException(status_code=502, detail=f"FYERS exception: {e}")


@router.post("/update/oms/order", tags=["fyers_orders"])
def update_oms_order():
    
    try:
        pass
    except Exception as e:
        logger.exception("FYERS update_oms_order raised an exception")
        raise HTTPException(status_code=502, detail=f"FYERS exception: {e}")


@router.post("/create/oms/order", tags=["fyers_orders"])
def create_oms_order(body: OrderBase, fyers: FyersClient = Depends(get_fyers), dry_run: bool = Query(False, description="If true, validate & return mapped GTT payload without creating it on FYERS")):
    try:
        # PRODUCTION GUARD: Check GLOBAL_HALT before any new cash entry
        from scripts.futures_state_store import StateStore
        from scripts.futures_risk_engine import RiskEngine
        from shared.db.dbconn import DBConnection
        store = StateStore(DBConnection().engine)
        risk = RiskEngine(store)
        if risk.cash_entry_allowed() == 'GLOBAL_REALIZED_LOSS_CEILING':
            raise HTTPException(status_code=403, detail="GLOBAL_HALT ACTIVE: New cash entries blocked")

        ltp = get_ltp_for_symbol(fyers, body.symbol)
    except HTTPException as e:
        raise HTTPException(status_code=e.status_code, detail=e.detail)
    except Exception as e:
        logger.exception("Failed to fetch LTP for symbol %s", body.symbol)
        raise HTTPException(status_code=502, detail=f"Error fetching LTP: {e}")
    
    entry_payload = PlaceOrderRequest(symbol=body.symbol, qty=body.stock_quantity, type=1, side=body.order_type, productType="CNC", limitPrice=body.entry_price).to_fyers_payload()
    gtt_payload = build_gtt_oco_payload(body, ltp=ltp)

    if dry_run:
        # Return just to show what will be sent to FYERS
        return PlaceOrderResponse(
            s="ok",
            code=1101,
            message="Dry run - GTT OCO payload validated",
            id=None,  # no id yet
            # If your PlaceOrderResponse has extra fields, add them here
        )

    try:
        entry_resp = fyers.place_order(entry_payload)
    except Exception as e:
        logger.exception("FYERS place_order raised an exception")
        raise HTTPException(status_code=502, detail=f"FYERS exception: {e}")

    if entry_resp.get("s") != "ok":
        detail = {
            "status": entry_resp.get("s"),
            "code": entry_resp.get("code"),
            "message": entry_resp.get("message", "Entry order failed"),
            "id": entry_resp.get("id"),
        }
        raise HTTPException(status_code=400, detail=detail)

    try:
        gtt_resp = fyers.place_protective_gtt(gtt_payload)
    except Exception as e:
        logger.exception("FYERS place_gtt_order raised an exception", exc_info=True, stack_info=True)
        raise HTTPException(status_code=502, detail=f"FYERS GTT exception: {e}")

    if not isinstance(gtt_resp, dict):
        raise HTTPException(status_code=502, detail="Unexpected response from FYERS for GTT")

    if gtt_resp.get("s") != "ok":
        detail = {
            "status": gtt_resp.get("s"),
            "code": gtt_resp.get("code"),
            "message": gtt_resp.get("message", "GTT order failed"),
            "id": gtt_resp.get("id"),
        }
        raise HTTPException(status_code=400, detail=detail)

    return CombinedOrderResponse(
        entry=PlaceOrderResponse(**entry_resp),
        gtt=PlaceOrderResponse(**gtt_resp),
    )


# @router.websocket("/ws/get/oms/order")
# async def get_oms_order(websocket: WebSocket):
#     await websocket.accept()
#     try:
#         while True:
#             rows = session.query(OMSOrders).order_by(OMSOrders.created_at.desc()).all()
#             if len(rows) > 0:
#                 await websocket.send_json({"data": rows})
#             else:
#                 await websocket.send_text("Error fetching data")
#             await asyncio.sleep(30)
#     except WebSocketDisconnect as ex:
#         #logger.exception(ex, exc_info=True, stack_info=True)
#         logger.error("WebSocket Error: Client disconnected")
#     except asyncio.CancelledError:
#         return
#     except Exception as e:
#         logger.exception(e, exc_info=True, stack_info=True)
#         logger.error("WebSocket Error:", e)
#         await websocket.close()



@router.post("/fyers/positions/exit", response_model=ExitPositionsResponse, status_code=status.HTTP_200_OK, tags=["fyers_orders"])
def exit_positions(body: ExitPositionsRequest, fyers: FyersClient = Depends(get_fyers), dry_run: bool = Query(False, description="If true, validate and return the mapped payloads without calling FYERS",)):
    results: List[ExitPositionItemResponse] = []
    print("Dry run:", dry_run)
    for position_id in body.id:
        payload = {"id": position_id}

        if dry_run:
            results.append(
                ExitPositionItemResponse(
                    id=position_id,
                    success=True,
                    response={
                        "dry_run": True,
                        "payload": payload,
                    },
                )
            )
            continue
        try:
            api_response = fyers._client.exit_positions(data=payload)
            # You can customize success detection based on actual FYERS response format
            logger.info("Exit position response: %s", api_response)
            is_success = True
            if isinstance(api_response, dict):
                # common pattern: s == "ok" / "error"
                status_value = str(api_response.get("s", "")).lower()
                if status_value == "error":
                    is_success = False

            results.append(
                ExitPositionItemResponse(
                    id=position_id,
                    success=is_success,
                    response=api_response if isinstance(api_response, dict) else {"raw": api_response},
                )
            )

        except Exception as e:
            results.append(
                ExitPositionItemResponse(
                    id=position_id,
                    success=False,
                    response={"error": str(e)},
                )
            )

    overall_success = all(item.success for item in results)

    return ExitPositionsResponse(
        success=overall_success,
        results=results,
    )


@router.get("/fyers/pending/gtt_orders", tags=["fyers_orders"])
def get_pending_gtt_orders(fyers: FyersClient = Depends(get_fyers)):
    """
    Get pending GTT orders from FYERS.
    """
    try:
        holdings_response = fyers._client.holdings()
        gtt_response = fyers._client.gtt_orderbook()
        return classify_gtt_orders(holdings_response, gtt_response)
    except Exception as e:
        logger.exception(e, exc_info=True, stack_info=True)
        logger.error("Error getting pending GTT orders:", e)
        raise HTTPException(status_code=500, detail="Error getting pending GTT orders")



@router.post("/fyers/cancel/gtt_order", tags=["fyers_orders"])
def cancel_gtt_order(gtt_id: str, fyers: FyersClient = Depends(get_fyers)):
    """
    Cancel a GTT order from FYERS.
    """
    try:
        data = {"id": gtt_id}
        response = fyers._client.cancel_gtt_order(data=data)
        return response
    except Exception as e:
        logger.exception(e, exc_info=True, stack_info=True)
        logger.error("Error canceling GTT order:", e)
        raise HTTPException(status_code=500, detail="Error canceling GTT order")


@router.post("/fyers/modify/gtt_order", tags=["fyers_orders"])
def modify_gtt_order(req: ModifyGttRequest, fyers: FyersClient = Depends(get_fyers)):
    """
    Modify a GTT order from FYERS.
    """
    try:
        # Step 1: get current GTT orderbook
        gtt_response = fyers._client.gtt_orderbook()

        if gtt_response.get("s") != "ok":
            raise HTTPException(status_code=400, detail={
                "message": "Failed to fetch GTT orderbook",
                "response": gtt_response
            })

        order_book = gtt_response.get("orderBook", [])
        target_order = next((x for x in order_book if str(x.get("id")) == str(req.id)), None)

        if not target_order:
            raise HTTPException(status_code=404, detail=f"GTT order not found for id {req.id}")

        # Step 2: build payload based on single/OCO
        payload = build_modify_gtt_payload(
            order=target_order,
            entry=req.entry,
            sl=req.sl,
            tp=req.tp,
            qty=req.qty
        )

        # Step 3: call modify API
        fyers_response = fyers._client.modify_gtt_order(data=payload)

        return {
            "message": "GTT modify request processed",
            "gtt_type": "single" if target_order.get("gtt_oco_ind") == 1 else "oco",
            "payload_sent": payload,
            "fyers_response": fyers_response
        }

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))



@router.post("/orders/gtt/single", tags=["fyers_orders"])
def place_single_gtt_order(payload: SingleGttOrderRequest, fyers: FyersClient = Depends(get_fyers)):
    try:

        # PRODUCTION GUARD: Check GLOBAL_HALT before any new cash entry
        from scripts.futures_state_store import StateStore
        from scripts.futures_risk_engine import RiskEngine
        from shared.db.dbconn import DBConnection
        store = StateStore(DBConnection().engine)
        risk = RiskEngine(store)
        if risk.cash_entry_allowed() == 'GLOBAL_REALIZED_LOSS_CEILING':
            raise HTTPException(status_code=403, detail="GLOBAL_HALT ACTIVE: New cash entries blocked")

        data = payload.model_dump()

        response = fyers.place_cash_gtt(data)

        if not response:
            raise HTTPException(
                status_code=502,
                detail="Empty response from Fyers"
            )

        if response.get("s") != "ok":
            raise HTTPException(
                status_code=400,
                detail=response
            )

        return {
            "msg": "success",
            "response": response
        }

    except HTTPException:
        raise

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to place GTT order: {str(e)}"
        )


@router.post("/orders/gtt/oco", tags=["fyers_orders"])
def place_oco_gtt_order(body: CreateGTTOCORequest, fyers: FyersClient = Depends(get_fyers)):
    try:

        try:
            ltp = get_ltp_for_symbol(fyers, body.symbol)
        except HTTPException as e:
            raise HTTPException(status_code=e.status_code, detail=e.detail)
        except Exception as e:
            logger.exception("Failed to fetch LTP for symbol %s", body.symbol)
            raise HTTPException(status_code=502, detail=f"Error fetching LTP: {e}")

        gtt_payload = build_gtt_oco_payload(body, ltp=ltp)
        # This endpoint places an OCO for an existing long position.  Protective
        # exits remain valid during GLOBAL_HALT.
        response = fyers.place_protective_gtt(gtt_payload)

        if not response:
            raise HTTPException(
                status_code=502,
                detail="Empty response from Fyers"
            )

        if response.get("s") != "ok":
            raise HTTPException(
                status_code=400,
                detail=response
            )

        return {
            "msg": "success",
            "response": response
        }

    except HTTPException:
        raise

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to place GTT order: {str(e)}"
        )


@router.post("/orders/live/update", tags=["fyers_orders"])
def update_live_order(body: UpdateLiveOrderRequest, fyers: FyersClient = Depends(get_fyers)):
    try:
        try:
            if body.marketSection == "Stocks":
                session = db.get_session()
                if not body.bucket_id:
                    order_id = body.orderId
                    bucket_row = session.query(OMSOrderBucket).filter(OMSOrderBucket.order_id == order_id).first()
                    if not bucket_row:
                        raise HTTPException(status_code=404, detail="Bucket not found")
                else:
                    bucket_id = body.bucket_id
                    bucket_row = session.query(OMSOrderBucket).filter(OMSOrderBucket.bucket_id == bucket_id).first()
                
                print("payload", body.__dict__)
                print("bucket_row:", bucket_row)
                if not bucket_row:
                    raise HTTPException(status_code=404, detail="Bucket not found")
                order_row = session.query(Order).filter(Order.order_id == body.orderId).first()
                if not order_row:
                    raise HTTPException(status_code=404, detail="Order not found")
            elif body.marketSection == "Future":

                session = db.get_session()
                if not body.bucket_id:
                    order_id = body.orderId
                    bucket_row = session.query(OMSOrderBucketFuture).filter(OMSOrderBucketFuture.order_id == order_id).first()
                    if not bucket_row:
                        raise HTTPException(status_code=404, detail="Bucket not found")
                else:
                    bucket_id = body.bucket_id
                    bucket_row = session.query(OMSOrderBucketFuture).filter(OMSOrderBucketFuture.bucket_id == bucket_id).first()
                
                print("payload", body.__dict__)
                print("bucket_row:", bucket_row)
                if not bucket_row:
                    raise HTTPException(status_code=404, detail="Bucket not found")
                order_row = session.query(Future_Order).filter(Future_Order.order_id == body.orderId).first()
                if not order_row:
                    raise HTTPException(status_code=404, detail="Order not found")

            elif body.marketSection == "Commodity":

                session = db.get_session()
                if not body.bucket_id:
                    order_id = body.orderId
                    bucket_row = session.query(OMSOrderBucketCommodity).filter(OMSOrderBucketCommodity.order_id == order_id).first()
                    if not bucket_row:
                        raise HTTPException(status_code=404, detail="Bucket not found")
                else:
                    bucket_id = body.bucket_id
                    bucket_row = session.query(OMSOrderBucketCommodity).filter(OMSOrderBucketCommodity.bucket_id == bucket_id).first()
                
                print("payload", body.__dict__)
                print("bucket_row:", bucket_row)
                if not bucket_row:
                    raise HTTPException(status_code=404, detail="Bucket not found")
                order_row = session.query(Commodity_Order).filter(Commodity_Order.order_id == body.orderId).first()
                if not order_row:
                    raise HTTPException(status_code=404, detail="Order not found")

            else:
                raise HTTPException(status_code=400, detail="Invalid market section")


            has_changes = False

    
            # update Bucket & update Order
            if body.entryChanged:
                bucket_row.entry_price = body.entry 
                order_row.entry_price = body.entry
                has_changes = True
            if body.stoplossChanged:
                print("stoplossChanged", body.stoploss)
                bucket_row.stoploss_price = body.stoploss
                order_row.stoploss_price = body.stoploss
                has_changes = True
            if body.targetChanged:
                print("targetChanged", body.target)
                bucket_row.target_price = body.target
                order_row.target_price = body.target
                has_changes = True
            # Update live


            normalized_prices = normalize_cash_oco_prices(body.entry, body.target, body.stoploss, bucket_row.order_type)

            if bucket_row.is_trade_started == 0:
                # Don't modify live order if trade hasn't started yet
                single_gtt_order = get_pending_gtt_by_id(fyers, bucket_row.bucket_id)
                if single_gtt_order:
                    payload = build_modify_gtt_payload(
                        order=single_gtt_order,
                        entry=normalized_prices['entry'],
                        sl=normalized_prices['stoploss'],
                        tp=normalized_prices['target'],
                        qty=bucket_row.stock_quantity
                    )
                    fyers_response = fyers._client.modify_gtt_order(data=payload)
                    logger.info(f"Single GTT order modified successfully: {fyers_response}")

    
            if bucket_row.is_trade_started == 1:

                oco_order = get_pending_oco_by_id(fyers, bucket_row.gtt_oco_id)
                if oco_order:
                    payload = build_modify_gtt_payload(
                        order=oco_order,
                        entry=normalized_prices['entry'],
                        sl=normalized_prices['stoploss'],
                        tp=normalized_prices['target'],
                        qty=bucket_row.stock_quantity
                    )
                    fyers_response = fyers._client.modify_gtt_order(data=payload)
                    logger.info(f"OCO order modified successfully: {fyers_response}")
                else:
                    logger.warning(f"OCO order not found for gtt_oco_id: {bucket_row.gtt_oco_id}")
                
        # Step 3: call modify API
            # Save changes
            if has_changes:
                session.add(bucket_row)
                session.add(order_row)
                session.commit()
            
        except HTTPException as e:
            raise HTTPException(status_code=e.status_code, detail=e.detail)

        # gtt_payload = build_gtt_oco_payload(body, ltp=ltp)
        # response = fyers._client.place_gtt_order(data=gtt_payload)

        # if not response:
        #     raise HTTPException(
        #         status_code=502,
        #         detail="Empty response from Fyers"
        #     )

        # if response.get("s") != "ok":
        #     raise HTTPException(
        #         status_code=400,
        #         detail=response
        #     )

        return {
            "msg": "success",
            "response": "success"
        }

    except HTTPException:
        raise

    except Exception as e:
        print(e)
        raise HTTPException(
            status_code=500,
            detail=f"Failed to place GTT order: {str(e)}"
        )
    
