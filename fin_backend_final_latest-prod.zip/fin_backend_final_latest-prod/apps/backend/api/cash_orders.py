from fastapi import APIRouter, Request
from shared.utils.logger import logger
from shared.config.settings import stock_data_dir_config
from shared.db.dbconn import DBConnection
from shared.db.api_responce import APIResponse
from scripts.order_update import check_entry_hit, evaluate_order_status
from sqlalchemy import text
from datetime import datetime

dbc = DBConnection()
router = APIRouter()

@router.get("/update_cash_order_stats", tags=['CASH ORDER'])
async def update_cash_order_stats(request: Request):
    apiresponce = APIResponse(request)
    try:
        ords = dbc.raw_query("select * from order_master where is_trade_started=0")
        for orders in ords:
            order_id = orders.get('order_id')
            stock_tick = orders.get('stock_tick')
            buy_price = orders.get('entry_price')
            time_frame = orders.get('time_frame')
            purchased_on = orders.get('purchased_cmp_date')
            # print(purchased_on, type(purchased_on))
            try:
                stat, entry_timestamp = check_entry_hit(stock_tick, buy_price, purchased_on, time_frame, stock_data_dir_config.indian_stock_data_dir)
            except Exception as ex:
                logger.exception(ex, stack_info=True, exc_info=1)
                stat = False
            # print(entry_timestamp, type(entry_timestamp))
            if stat:
                # entry_timestamp = datetime.strptime(entry_timestamp, "%d/%m/%Y %H:%M:%S")
                up_query = f"""update order_master set is_trade_started=1, entry_timestamp='{entry_timestamp}' where order_id={order_id}"""
                rc = dbc.raw_connection()
                rc.execute(text(up_query))
                rc.commit()
                rc.close()

        entry_ords = dbc.raw_query("select * from order_master where is_evaluated=0 and is_trade_started=1;")
        for enty_orders in entry_ords:
            order_id = enty_orders.get('order_id')
            stock_tick = enty_orders.get('stock_tick')
            buy_price = enty_orders.get('entry_price')
            stop_loss = enty_orders.get('stoploss_price')
            target_price = enty_orders.get('target_price')
            stock_quantity = enty_orders.get('stock_quantity')
            time_frame = enty_orders.get('time_frame')
            # purchased_on = orders.get('purchased_cmp_date')
            entry_timestamp = enty_orders.get('entry_timestamp')
            ord_type = enty_orders.get('order_type')
            try:
                entry_dt = datetime.fromisoformat(entry_timestamp)
            except Exception:
                entry_dt = datetime.strptime(entry_timestamp, "%Y-%m-%d %H:%M:%S")

            result = evaluate_order_status(
                data_dir=stock_data_dir_config.indian_stock_data_dir,
                stock_name=stock_tick,
                entry_price=buy_price,
                created_on=entry_dt.strftime("%Y-%m-%dT%H:%M"),
                stop_loss=stop_loss,
                target_price=target_price,
                quantity=stock_quantity,
                order_type=ord_type,
                time_frame=time_frame
            )
            update_sql = f"""
                UPDATE order_master
                SET order_status = :order_status,
                    is_evaluated = :is_eval,
                    completed_on = :completed_on
                WHERE order_id = :order_id
            """
            exec_result = result.copy()
            exec_result.pop('completed_on', None)
            rc = dbc.raw_connection()
            rc.execute(
                text(update_sql),
                {
                    "order_status": str(exec_result),
                    "is_eval": 1 if result.get("status") in ["success", "failed"] else 0,
                    "completed_on": result.get("completed_on").strftime("%Y-%m-%d %H:%M:%S") if result.get("completed_on") else None,
                    "order_id": order_id
                }
            )
            rc.commit()
            rc.close()

        apiresponce.setMsg("success")
        apiresponce.setResponse("Trades Updated Successfully")
    except Exception as ex:
        logger.error(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce