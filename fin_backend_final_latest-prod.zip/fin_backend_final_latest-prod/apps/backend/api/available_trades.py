from fastapi import APIRouter, Request, HTTPException
from shared.db.api_responce import APIResponse
from shared.db.db_model import TradeSignal, ExchangeMaster, Ind_StockMaster, FuturesMaster, CommoditiesMaster, Order, Commodity_Order, Future_Order
from shared.db.dbconn import DBConnection
from scripts.calculate_setup import Calculate_setup_execute
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from sqlalchemy import text
from collections import defaultdict
# from modules.stock_handler import get_all_stock_cmp
import logging, math
import numpy as np
import json
from data_fetchers.fyers.get_stock_prices import StockPriceFetcher
import pytz
import time
from data_fetchers.fyers.fyers_market_data import FyersMarketData
from data_fetchers.fyers.get_commodity_prices import CommodityPriceFetcher
from data_fetchers.fyers.get_future_prices import FuturePriceFetcher


tz_IN = pytz.timezone('Asia/Kolkata')

dbc = DBConnection()
router = APIRouter()
logger = logging.getLogger()
spf = StockPriceFetcher()
time.sleep(2)
fpf = FuturePriceFetcher()
time.sleep(2)
cpf = CommodityPriceFetcher()
time.sleep(2)

# fmd = FyersMarketData()
# session = dbc.get_session()
# stocks = session.query(Ind_StockMaster).filter(Ind_StockMaster.is_active == True, 
#                                                        Ind_StockMaster.fyers_symbol != None).all()
# #print([stock.fyers_symbol for stock in stocks])
# fmd.add_symbols([stock.fyers_symbol for stock in stocks])
# session.close()

country_id_dict = {"india": 1, "us": 3}

def sanitize_json_floats(obj):
    #print(obj)
    #print(type(obj))
    if isinstance(obj, list):
        return [sanitize_json_floats(x) for x in obj]
    elif isinstance(obj, dict):
        return {k: sanitize_json_floats(v) for k, v in obj.items()}
    # elif isinstance(obj, np.float64):
    #     return None
    elif isinstance(obj, float):
        if math.isinf(obj) or math.isnan(obj):
            return None  # or 0.0 or string if you prefer
        return obj
    else:
        return obj


def nse_price_difference(t):
    try:
        latest_price = spf.fyers_data.get_latest_price(t.fyers_symbol)["ltp"]
        entry_price = t.trade_data["entry_price"]
        return abs(latest_price - entry_price) / max(abs(latest_price), 1e-9)
    except Exception as exx:
        logger.exception(exx)
        print(t.fyers_symbol)
        return 0

def nsefo_price_difference(t):
    try:
        exp_date = datetime.strptime(t.exp_date, '%d%m%Y')
        fyers_symbol = f"NSE:{t.stock_name}{datetime.strftime(exp_date, '%y%b').upper()}FUT"
        latest_price = fpf.fyers_data.get_latest_price(fyers_symbol)["ltp"]
        entry_price = t.trade_data["entry_price"]
        return abs(latest_price - entry_price) / max(abs(latest_price), 1e-9)
    except Exception as exx:
        logger.exception(exx)
        print(fyers_symbol)
        return 0

def mcx_price_difference(t):
    try:
        exp_date = datetime.strptime(t.exp_date, '%d%m%Y')
        fyers_symbol = f"MCX:{t.stock_name}{datetime.strftime(exp_date, '%y%b').upper()}FUT"
        latest_price = cpf.fyers_data.get_latest_price(fyers_symbol)["ltp"]
        entry_price = t.trade_data["entry_price"]
        return abs(latest_price - entry_price) / max(abs(latest_price), 1e-9)
    except Exception as exx:
        logger.exception(exx)
        print(fyers_symbol)
        return 0


@router.delete("/delete_available_trades", tags=['AVAILABLE TRADES'])
async def delete_available_trades(trade_id: int, request: Request):
    apiresponce = APIResponse(request)
    try:
        session = dbc.get_session()
        trade_row = session.query(TradeSignal).filter(TradeSignal.id == trade_id).all()
        if len(trade_row) > 0:
            session.delete(trade_row[0])
            session.commit()
            order_row = session.query(Order).filter(Order.trade_signal_id == trade_id,
                                                    Order.order_status == None).all()
            if len(order_row) > 0:
                session.delete(order_row[0])
                session.commit()
        session.close()
        dbc.close_engine()
        apiresponce.setMsg("success")
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.put("/update_available_trade", tags=['AVAILABLE TRADES'])
async def update_available_trade(trade_id: int, entry: float, stop_loss: float, target: float, prediction: str, probability: float, request: Request):
    apiresponce = APIResponse(request)
    try:
        up_data = {"stop_loss": round(stop_loss, 2), 
                   "entry_price": round(entry, 2), 
                   "target_price": round(target, 2)
                   }
        
        rr = abs(target - entry)/ abs(entry - stop_loss)
        rc = dbc.raw_connection()
        order_id = rc.execute(text("""
                                    SELECT order_id FROM order_master WHERE trade_signal_id = :trade_id
                                    """), {"trade_id": trade_id}).fetchone()
        # print(order_id, "666666666666666666666666666666666666666666")
        if order_id:
            rc.execute(text("""
                            UPDATE order_master
                            SET entry_price = :entry_price, stoploss_price = :stop_loss, target_price = :target_price
                            WHERE order_id = :order_id;
                        """), {
                            "entry_price": entry,
                            "stop_loss": stop_loss,
                            "target_price": target,
                            "order_id": order_id[0]
                        })
            rc.commit()
        query = text("""
                    UPDATE trade_signals
                    SET trade_data = :trade_data, rrr = :rrr, prediction = :prediction, probability = :probability, updated_at = :updated_at 
                    WHERE id = :id;
                """)
        
        rc.execute(query, {
            "trade_data": json.dumps(up_data),
            "rrr": round(rr, 2),
            "prediction": prediction,
            "probability": probability,
            "updated_at": datetime.now(tz_IN).strftime("%Y-%m-%d %H:%M:%S"),
            "id": trade_id
        })
        rc.commit()
        rc.close()
        apiresponce.setMsg("success")
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce




@router.get("/get_available_trades_daily_filter", tags=['AVAILABLE TRADES'])
async def get_available_trades_daily_filter(
    request: Request,
    exchange_id: int,
    country_name: str,
    start_date: str = "2025-01-01",
    end_date: str = "2025-12-31",
    page_no: str = None,
    limit: int = 10,
    search_key: str = None,
    order_by_date: bool = False,
    trade_type: str = "all",
    order_by_cmp: bool = False
):
    apiresponce = APIResponse(request)
    try:
        db = dbc.get_session()
        exchange = db.query(ExchangeMaster).filter(ExchangeMaster.exchange_id == exchange_id,
                                                   ExchangeMaster.is_active == 1).all()
        
        if trade_type.lower() == "all":
            trade_types = ["buy", "sell", "Buy", "Sell", "BUY", "SELL"]
        else:
            trade_types = [trade_type.lower(), trade_type.upper(), trade_type.capitalize()]
        
        if "us" in country_name.lower() or "india" in country_name.lower():
            # 1. Convert date strings
            start_date = datetime.combine(datetime.strptime(start_date, "%Y-%m-%d"), datetime.min.time())
            end_date = datetime.combine(datetime.strptime(end_date, "%Y-%m-%d"), datetime.max.time())

            # 2. Base query
            if exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSE":
                query = db.query(TradeSignal.id, TradeSignal.exchange_id,
                                TradeSignal.stock_name, TradeSignal.time_fr,
                                TradeSignal.country_id, TradeSignal.price_cmp,
                                TradeSignal.trade_type, TradeSignal.rrr,
                                TradeSignal.timestamps, TradeSignal.trade_data,
                                TradeSignal.prediction, TradeSignal.probability,
                                TradeSignal.created_at, TradeSignal.is_active,
                                TradeSignal.is_send, TradeSignal.exp_date,
                                Ind_StockMaster.kite_symbol.label("stock_symbol"),
                                Ind_StockMaster.fyers_symbol,
                                Order.trade_signal_id,
                                Ind_StockMaster.id.label("stock_id")).join(
                                    Ind_StockMaster, TradeSignal.stock_name == Ind_StockMaster.stock_tick
                                    ).outerjoin(
                                            Order,
                                            TradeSignal.id == Order.trade_signal_id
                                                ).filter(
                                                TradeSignal.exchange_id == exchange_id,
                                                TradeSignal.country_id == country_id_dict[country_name.lower()],
                                                TradeSignal.time_fr == 1,
                                                TradeSignal.created_at.between(start_date, end_date),
                                                TradeSignal.is_active == 1,
                                                Ind_StockMaster.is_active == 1,
                                                Ind_StockMaster.fyers_symbol != None,
                                                TradeSignal.trade_type.in_(trade_types)
                                            )
            elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "MCX":
                query = db.query(TradeSignal.id, TradeSignal.exchange_id,
                                TradeSignal.stock_name, TradeSignal.time_fr,
                                TradeSignal.country_id, TradeSignal.price_cmp,
                                TradeSignal.trade_type, TradeSignal.rrr,
                                TradeSignal.timestamps, TradeSignal.trade_data,
                                TradeSignal.prediction, TradeSignal.probability,
                                TradeSignal.created_at, TradeSignal.is_active,
                                TradeSignal.is_send, TradeSignal.exp_date,
                                TradeSignal.stock_name.label("stock_symbol"),
                                Commodity_Order.trade_signal_id,
                                Commodity_Order.stock_id).outerjoin(
                                    Commodity_Order,
                                    TradeSignal.id == Commodity_Order.trade_signal_id
                                        ).filter(
                                            TradeSignal.exchange_id == exchange_id,
                                            TradeSignal.country_id == country_id_dict[country_name.lower()],
                                            TradeSignal.time_fr == 1,
                                            TradeSignal.created_at.between(start_date, end_date),
                                            TradeSignal.is_active == 1,
                                            TradeSignal.trade_type.in_(trade_types)
                )
            
            elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSEFO":
                query = db.query(TradeSignal.id, TradeSignal.exchange_id,
                                TradeSignal.stock_name, TradeSignal.time_fr,
                                TradeSignal.country_id, TradeSignal.price_cmp,
                                TradeSignal.trade_type, TradeSignal.rrr,
                                TradeSignal.timestamps, TradeSignal.trade_data,
                                TradeSignal.prediction, TradeSignal.probability,
                                TradeSignal.created_at, TradeSignal.is_active,
                                TradeSignal.is_send, TradeSignal.exp_date,
                                TradeSignal.stock_name.label("stock_symbol"),
                                Future_Order.trade_signal_id,
                                Future_Order.stock_id).outerjoin(
                                    Future_Order,
                                    TradeSignal.id == Future_Order.trade_signal_id
                                        ).filter(
                                            TradeSignal.exchange_id == exchange_id,
                                            TradeSignal.country_id == country_id_dict[country_name.lower()],
                                            TradeSignal.time_fr == 1,
                                            TradeSignal.created_at.between(start_date, end_date),
                                            TradeSignal.is_active == 1,
                                            TradeSignal.trade_type.in_(trade_types)
                )

            # 3. Count total
            total_count = query.count()

            # 4. Search key filtering
            # if search_key and search_key.lower() not in ["null", ""]:
            #     query = query.filter(TradeSignal.stock_name.ilike(f"%{search_key}%"))

            # 5. Sort
            if order_by_date:
                query = query.order_by(TradeSignal.created_at.desc())
            else:
                query = query.order_by(TradeSignal.stock_name.asc())

            

            # 6. If only search_key is given, find page_no where first match appears
            if search_key and not page_no:
                trades = query.all()

                if order_by_cmp:                    
                    if exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSE":                        
                        # trades = sorted(
                        #     trades,
                        #     key=lambda t: abs(
                        #         spf.fyers_data.get_latest_price(t.fyers_symbol)["ltp"] - t.trade_data["entry_price"]
                        #     ) / max(abs(t.trade_data["entry_price"]), 1e-9)
                        # )
                        sorted(trades, key= nse_price_difference)                    
                    elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "MCX":
                        sorted(trades, key= mcx_price_difference)
                    elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSEFO":
                        sorted(trades, key= nsefo_price_difference)


                    
                
                found = False
                for i in range(len(trades)):
                    if trades[i].stock_symbol.lower().startswith(search_key.lower()):
                        found = i+1
                        break
                if not found:
                    for i in range(len(trades)):
                        if search_key.lower() in trades[i].stock_symbol.lower():
                            found = i+1
                            break
                if found:
                    page_no = ((found - 1) // limit) + 1
                    offset = (page_no - 1) * limit
                else:
                    page_no = 0
                    offset = 0
                    limit = 0
                # Apply offset and limit
                # query = query.offset(offset).limit(limit)

                #trades = query.all()

                # if order_by_cmp:
                #     if exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSE":
                #         trades = sorted(
                #             trades,
                #             key=lambda t: abs(spf.fyers_data.get_latest_price(t.fyers_symbol)['ltp'] - t.trade_data["entry_price"])
                #         )

                trades_list = []

                # Apply offset and limit
                trades = trades[offset : offset + limit]

                for trade in trades:
                    #if trade.trade_type.lower() in trade_types:
                        #print(abs(spf.fyers_data.get_latest_price(trade.fyers_symbol)['ltp'] - trade.trade_data["entry_price"]))
                        base = {
                            "TRADE_ID": trade.id,
                            "STOCK_NAME": trade.stock_name,
                            "STOCK_SYMBOL": trade.stock_symbol,
                            "TIME_FR": trade.time_fr,
                            "PRICE_CMP": trade.price_cmp,
                            "TRADE_TYPE": trade.trade_type,
                            "PREDICTION": trade.prediction,
                            "PROBABILITY": trade.probability,
                            "TIMESTAMP": trade.created_at.strftime("%Y-%m-%d %H:%M:%S"),
                            f"{trade.trade_type}_RRR": trade.rrr,
                            f"{trade.trade_type}_TIMESTAMPS": trade.timestamps,
                            trade.trade_type: trade.trade_data,
                            "EXP_NUM" : trade.exp_date,
                            "STOCK_ID": trade.stock_id
                        }
                        try:
                            base["TRADE_SIGNAL_ID"] = trade.trade_signal_id
                        except:
                            base["TRADE_SIGNAL_ID"] = None
                        trades_list.append(base)

                # manual paging simulation
                # search_pg_no = None
                # for i in range(0, total_count, limit):
                #     page_chunk = trades_list[i:i+limit]
                #     if any(search_key.lower() in tr["STOCK_NAME"].lower() for tr in page_chunk):
                #         search_pg_no = (i // limit) + 1
                #         break

                # filtered = page_chunk if search_pg_no else []
                if len(trades_list) == 0:
                    page_no = None
                apiresponce.setMsg("success")
                apiresponce.setResponse({
                    "total_count": total_count,
                    "trades": sanitize_json_floats(trades_list),
                    "page_no": page_no
                })
                return apiresponce

            # 7. Paginate query
            # page_no = int(page_no) if page_no and page_no not in ["null", ""] else 1
            # trades = query.offset((page_no - 1) * limit).limit(limit).all()

            trades = query.all()

            if order_by_cmp:                    
                    if exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSE":                        
                        # trades = sorted(
                        #     trades,
                        #     key=lambda t: abs(
                        #         spf.fyers_data.get_latest_price(t.fyers_symbol)["ltp"] - t.trade_data["entry_price"]
                        #     ) / max(abs(t.trade_data["entry_price"]), 1e-9)
                        # )
                        sorted(trades, key= nse_price_difference)                    
                    elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "MCX":
                        sorted(trades, key= mcx_price_difference)
                    elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSEFO":
                        sorted(trades, key= nsefo_price_difference)

            trades_list = []

            # Apply offset and limit
            page_no = int(page_no) if page_no and page_no not in ["null", ""] else 1
            offset = (page_no - 1) * limit
            trades = trades[offset : offset + limit]

            for trade in trades:
                #if trade.trade_type.lower() in trade_types:
                    #print(abs(spf.fyers_data.get_latest_price(trade.fyers_symbol)['ltp'] - trade.trade_data["entry_price"]))
                    base = {
                        "TRADE_ID": trade.id,
                        "STOCK_NAME": trade.stock_name,
                        "STOCK_SYMBOL": trade.stock_symbol,
                        "TIME_FR": trade.time_fr,
                        "PRICE_CMP": trade.price_cmp,
                        "TRADE_TYPE": trade.trade_type,
                        "PREDICTION": trade.prediction,
                        "PROBABILITY": trade.probability,
                        "TIMESTAMP": trade.created_at.strftime("%Y-%m-%d %H:%M:%S"),
                        f"{trade.trade_type}_RRR": trade.rrr,
                        f"{trade.trade_type}_TIMESTAMPS": trade.timestamps,
                        trade.trade_type: trade.trade_data,
                        "EXP_NUM" : trade.exp_date,
                        "STOCK_ID": trade.stock_id
                    }
                    try:
                        base["TRADE_SIGNAL_ID"] = trade.trade_signal_id
                    except:
                        base["TRADE_SIGNAL_ID"] = None
                    trades_list.append(base)

            if len(trades_list) == 0:
                page_no = None
            apiresponce.setMsg("success")
            apiresponce.setResponse({
                "total_count": total_count,
                "trades": sanitize_json_floats(trades_list),
                "page_no": page_no
            })
        else:
            raise HTTPException(status_code=204, detail='Invalid Country')
        db.close()
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce





@router.get("/get_available_trades_sixty_filter", tags=['AVAILABLE TRADES'])
def get_available_trades_sixty_filter(
    request: Request,
    exchange_id: int,
    country_name: str,
    start_date: str = "2025-01-01",
    end_date: str = "2025-12-31",
    page_no: str = None,
    limit: int = 10,
    search_key: str = None,
    order_by_date: bool = False,
    trade_type: str = "all",
    order_by_cmp: bool = False
):
    apiresponce = APIResponse(request)
    
    try:
        db = dbc.get_session()
        exchange = db.query(ExchangeMaster).filter(ExchangeMaster.exchange_id == exchange_id,
                                                   ExchangeMaster.is_active == 1).all()
        
        if exchange and len(exchange) > 0 and exchange[0].exchange_name == "MCX":
            time_frame = 4
        else:
            time_frame = 2
        
        if trade_type.lower() == "all":
            trade_types = ["buy", "sell", "Buy", "Sell", "BUY", "SELL"]
        else:
            trade_types = [trade_type.lower(), trade_type.upper(), trade_type.capitalize()]
        
        if "us" in country_name.lower() or "india" in country_name.lower():
            # Parse and convert dates
            start_date = datetime.combine(datetime.strptime(start_date, "%Y-%m-%d"), datetime.min.time())
            end_date = datetime.combine(datetime.strptime(end_date, "%Y-%m-%d"), datetime.max.time())

            # Build base query
            if exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSE":
                query = db.query(TradeSignal.id, TradeSignal.exchange_id,
                                TradeSignal.stock_name, TradeSignal.time_fr,
                                TradeSignal.country_id, TradeSignal.price_cmp,
                                TradeSignal.trade_type, TradeSignal.rrr,
                                TradeSignal.timestamps, TradeSignal.trade_data,
                                TradeSignal.prediction, TradeSignal.probability,
                                TradeSignal.created_at, TradeSignal.is_active,
                                TradeSignal.is_send, TradeSignal.exp_date,
                                Ind_StockMaster.kite_symbol.label("stock_symbol"),
                                Ind_StockMaster.fyers_symbol,
                                Order.trade_signal_id,
                                Ind_StockMaster.id.label("stock_id")).join(
                                    Ind_StockMaster, TradeSignal.stock_name == Ind_StockMaster.stock_tick
                                    ).outerjoin(
                                        Order,
                                        TradeSignal.id == Order.trade_signal_id
                                            ).filter(
                                                TradeSignal.exchange_id == exchange_id,
                                                TradeSignal.country_id == country_id_dict[country_name.lower()],
                                                TradeSignal.time_fr == time_frame,
                                                TradeSignal.created_at.between(start_date, end_date),
                                                TradeSignal.is_active == 1,
                                                Ind_StockMaster.is_active == 1,
                                                Ind_StockMaster.fyers_symbol != None,
                                                TradeSignal.trade_type.in_(trade_types)
                                            )
            elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "MCX":
                query = db.query(TradeSignal.id, TradeSignal.exchange_id,
                                TradeSignal.stock_name, TradeSignal.time_fr,
                                TradeSignal.country_id, TradeSignal.price_cmp,
                                TradeSignal.trade_type, TradeSignal.rrr,
                                TradeSignal.timestamps, TradeSignal.trade_data,
                                TradeSignal.prediction, TradeSignal.probability,
                                TradeSignal.created_at, TradeSignal.is_active,
                                TradeSignal.is_send, TradeSignal.exp_date,
                                TradeSignal.stock_name.label("stock_symbol"),
                                Commodity_Order.trade_signal_id,
                                Commodity_Order.stock_id).outerjoin(
                                        Commodity_Order,
                                        TradeSignal.id == Commodity_Order.trade_signal_id
                                            ).filter(
                                                TradeSignal.exchange_id == exchange_id,
                                                TradeSignal.country_id == country_id_dict[country_name.lower()],
                                                TradeSignal.time_fr == time_frame,
                                                TradeSignal.created_at.between(start_date, end_date),
                                                TradeSignal.is_active == 1,
                                                TradeSignal.trade_type.in_(trade_types)
                )
            elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSEFO":
                query = db.query(TradeSignal.id, TradeSignal.exchange_id,
                                TradeSignal.stock_name, TradeSignal.time_fr,
                                TradeSignal.country_id, TradeSignal.price_cmp,
                                TradeSignal.trade_type, TradeSignal.rrr,
                                TradeSignal.timestamps, TradeSignal.trade_data,
                                TradeSignal.prediction, TradeSignal.probability,
                                TradeSignal.created_at, TradeSignal.is_active,
                                TradeSignal.is_send, TradeSignal.exp_date,
                                TradeSignal.stock_name.label("stock_symbol"),
                                Future_Order.trade_signal_id,
                                Future_Order.stock_id).outerjoin(
                                        Future_Order,
                                        TradeSignal.id == Future_Order.trade_signal_id
                                            ).filter(
                                                TradeSignal.exchange_id == exchange_id,
                                                TradeSignal.country_id == country_id_dict[country_name.lower()],
                                                TradeSignal.time_fr == time_frame,
                                                TradeSignal.created_at.between(start_date, end_date),
                                                TradeSignal.is_active == 1,
                                                TradeSignal.trade_type.in_(trade_types)
                )

            # Count total
            total_count = query.count()

            # Apply search filter
            # if search_key and search_key.lower() not in ['null', '']:
            #     query = query.filter(TradeSignal.stock_name.ilike(f"%{search_key}%"))

            # Order by stock name for pagination logic
            if order_by_date:
                query = query.order_by(TradeSignal.created_at.desc())
            else:
                query = query.order_by(TradeSignal.stock_name.asc())

        

            # If only search_key given (simulate paging to find match page)
            if search_key and not page_no:
                #print("search_key", search_key)
                trades = query.all()

                if order_by_cmp:                    
                    if exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSE":                        
                        # trades = sorted(
                        #     trades,
                        #     key=lambda t: abs(
                        #         spf.fyers_data.get_latest_price(t.fyers_symbol)["ltp"] - t.trade_data["entry_price"]
                        #     ) / max(abs(t.trade_data["entry_price"]), 1e-9)
                        # )
                        sorted(trades, key= nse_price_difference)                    
                    elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "MCX":
                        sorted(trades, key= mcx_price_difference)
                    elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSEFO":
                        sorted(trades, key= nsefo_price_difference)
                
                found = False
                for i in range(len(trades)):
                    if trades[i].stock_symbol.lower().startswith(search_key.lower()):
                        found = i+1
                        break
                if not found:
                    for i in range(len(trades)):
                        if search_key.lower() in trades[i].stock_symbol.lower():
                            found = i+1
                            #print("found", found)
                            break
                if found:
                    page_no = ((found - 1) // limit) + 1
                    offset = (page_no - 1) * limit
                    #print("page_no", page_no)
                    #print("offset", offset)
                else:
                    page_no = 0
                    offset = 0
                    limit = 0

                # Apply offset and limit
                # query = query.offset(offset).limit(limit)


                #trades = query.all()
                
                # if order_by_cmp:
                #     if exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSE":
                #         trades = sorted(
                #             trades,
                #             key=lambda t: abs(spf.fyers_data.get_latest_price(t.fyers_symbol)['ltp'] - t.trade_data["entry_price"])
                #         )
                trades_list = []
                
                # Apply offset and limit
                trades = trades[offset : offset + limit]
                
                for trade in trades:
                    #if trade.trade_type.lower() in trade_types:
                        base = {
                            "TRADE_ID": trade.id,
                            "STOCK_NAME": trade.stock_name,
                            "STOCK_SYMBOL": trade.stock_symbol,
                            "TIME_FR": trade.time_fr,
                            "PRICE_CMP": trade.price_cmp,
                            "TRADE_TYPE": trade.trade_type,
                            "PREDICTION": trade.prediction,
                            "PROBABILITY": trade.probability,
                            "TIMESTAMP": trade.created_at.strftime("%Y-%m-%d %H:%M:%S"),
                            f"{trade.trade_type}_RRR": trade.rrr,
                            f"{trade.trade_type}_TIMESTAMPS": trade.timestamps,
                            trade.trade_type: trade.trade_data,
                            "EXP_NUM" : trade.exp_date,
                            "STOCK_ID": trade.stock_id
                        }
                        try:
                            base["TRADE_SIGNAL_ID"] = trade.trade_signal_id
                        except:
                            base["TRADE_SIGNAL_ID"] = None
                        trades_list.append(base)
                # search_pg_no = None
                # for i in range(0, total_count, limit):
                #     chunk = trades_list[i:i+limit]
                #     if any(search_key.lower() in tr["stock_name"].lower() for tr in chunk):
                #         search_pg_no = (i // limit) + 1
                #         break
                if len(trades_list) == 0:
                    page_no = None
                apiresponce.setMsg("success")
                apiresponce.setResponse({
                    "total_count": total_count,
                    "trades": sanitize_json_floats(trades_list),
                    "page_no": page_no
                })
                return apiresponce

            trades = query.all()

            if order_by_cmp:                    
                    if exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSE":                        
                        # trades = sorted(
                        #     trades,
                        #     key=lambda t: abs(
                        #         spf.fyers_data.get_latest_price(t.fyers_symbol)["ltp"] - t.trade_data["entry_price"]
                        #     ) / max(abs(t.trade_data["entry_price"]), 1e-9)
                        # )
                        sorted(trades, key= nse_price_difference)                    
                    elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "MCX":
                        sorted(trades, key= mcx_price_difference)
                    elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSEFO":
                        sorted(trades, key= nsefo_price_difference)

            # Final page number
            page_no = int(page_no) if page_no and page_no.lower() not in ['null', ''] else 1
            offset = (page_no - 1) * limit
            trades = trades[offset : offset + limit]
            # Apply pagination
            # trades = query.offset((page_no - 1) * limit).limit(limit).all()
            
            trades_list  = []
            for trade in trades:
                #if trade.trade_type.lower() in trade_types:
                    base = {
                        "TRADE_ID": trade.id,
                        "STOCK_NAME": trade.stock_name,
                        "STOCK_SYMBOL": trade.stock_symbol,
                        "TIME_FR": trade.time_fr,
                        "PRICE_CMP": trade.price_cmp,
                        "TRADE_TYPE": trade.trade_type,
                        "PREDICTION": trade.prediction,
                        "PROBABILITY": trade.probability,
                        "TIMESTAMP": trade.created_at.strftime("%Y-%m-%d %H:%M:%S"),
                        f"{trade.trade_type}_RRR": trade.rrr,
                        f"{trade.trade_type}_TIMESTAMPS": trade.timestamps,
                        trade.trade_type: trade.trade_data,
                        "EXP_NUM" : trade.exp_date,
                        "STOCK_ID": trade.stock_id
                    }
                    try:
                        base["TRADE_SIGNAL_ID"] = trade.trade_signal_id
                    except:
                        base["TRADE_SIGNAL_ID"] = None
                    trades_list.append(base)
            
            if len(trades_list) == 0:
                page_no = None
            apiresponce.setMsg("success")
            apiresponce.setResponse({
                "total_count": total_count,
                "trades": sanitize_json_floats(trades_list),
                "page_no": page_no
            })
        else:
            raise HTTPException(status_code=204, detail='Invalid Country')
        db.close()
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce



@router.get("/get_available_trades_fifteen_filter", tags=['AVAILABLE TRADES'])
def get_available_trades_fifteen_filter(
    request: Request,
    exchange_id: int,
    country_name: str,
    start_date: str = "2025-01-01",
    end_date: str = "2025-12-31",
    page_no: str = None,
    limit: int = 10,
    search_key: str = None,
    order_by_date: bool = False,
    trade_type: str = "all",
    order_by_cmp: bool = False
):
    apiresponce = APIResponse(request)
    try:
        db = dbc.get_session()
        exchange = db.query(ExchangeMaster).filter(ExchangeMaster.exchange_id == exchange_id,
                                                   ExchangeMaster.is_active == 1).all()
        
        if trade_type.lower() == "all":
            trade_types = ["buy", "sell", "Buy", "Sell", "BUY", "SELL"]
        else:
            trade_types = [trade_type.lower(), trade_type.upper(), trade_type.capitalize()]
        
        if "us" in country_name.lower() or "india" in country_name.lower():
            start_date = datetime.combine(datetime.strptime(start_date, "%Y-%m-%d"), datetime.min.time())
            end_date = datetime.combine(datetime.strptime(end_date, "%Y-%m-%d"), datetime.max.time())

            # Base query for 15-min trades
            if exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSE":
                query = db.query(TradeSignal.id, TradeSignal.exchange_id,
                                TradeSignal.stock_name, TradeSignal.time_fr,
                                TradeSignal.country_id, TradeSignal.price_cmp,
                                TradeSignal.trade_type, TradeSignal.rrr,
                                TradeSignal.timestamps, TradeSignal.trade_data,
                                TradeSignal.prediction, TradeSignal.probability,
                                TradeSignal.created_at, TradeSignal.is_active,
                                TradeSignal.is_send, TradeSignal.exp_date,
                                Ind_StockMaster.kite_symbol.label("stock_symbol"),
                                Ind_StockMaster.fyers_symbol,
                                Order.trade_signal_id,
                                Ind_StockMaster.id.label("stock_id")).join(
                                    Ind_StockMaster, TradeSignal.stock_name == Ind_StockMaster.stock_tick
                                    ).outerjoin(
                                            Order,
                                            TradeSignal.id == Order.trade_signal_id
                                                ).filter(
                                                    TradeSignal.exchange_id == exchange_id,
                                                    TradeSignal.country_id == country_id_dict[country_name.lower()],
                                                    TradeSignal.time_fr == 3,
                                                    TradeSignal.created_at.between(start_date, end_date),
                                                    TradeSignal.is_active == 1,
                                                    Ind_StockMaster.is_active == 1,
                                                    Ind_StockMaster.fyers_symbol != None,
                                                    TradeSignal.trade_type.in_(trade_types)
                                                )
            elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "MCX":
                query = db.query(TradeSignal.id, TradeSignal.exchange_id,
                                TradeSignal.stock_name, TradeSignal.time_fr,
                                TradeSignal.country_id, TradeSignal.price_cmp,
                                TradeSignal.trade_type, TradeSignal.rrr,
                                TradeSignal.timestamps, TradeSignal.trade_data,
                                TradeSignal.prediction, TradeSignal.probability,
                                TradeSignal.created_at, TradeSignal.is_active,
                                TradeSignal.is_send, TradeSignal.exp_date,
                                TradeSignal.stock_name.label("stock_symbol"),
                                Commodity_Order.trade_signal_id,
                                Commodity_Order.stock_id).outerjoin(
                                    Commodity_Order,
                                    TradeSignal.id == Commodity_Order.trade_signal_id
                                        ).filter(
                                            TradeSignal.exchange_id == exchange_id,
                                            TradeSignal.country_id == country_id_dict[country_name.lower()],
                                            TradeSignal.time_fr == 3,
                                            TradeSignal.created_at.between(start_date, end_date),
                                            TradeSignal.is_active == 1,
                                            TradeSignal.trade_type.in_(trade_types)
                )
            elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSEFO":
                query = db.query(TradeSignal.id, TradeSignal.exchange_id,
                                TradeSignal.stock_name, TradeSignal.time_fr,
                                TradeSignal.country_id, TradeSignal.price_cmp,
                                TradeSignal.trade_type, TradeSignal.rrr,
                                TradeSignal.timestamps, TradeSignal.trade_data,
                                TradeSignal.prediction, TradeSignal.probability,
                                TradeSignal.created_at, TradeSignal.is_active,
                                TradeSignal.is_send, TradeSignal.exp_date,
                                TradeSignal.stock_name.label("stock_symbol"),
                                Future_Order.trade_signal_id,
                                Future_Order.stock_id).outerjoin(
                                    Future_Order,
                                    TradeSignal.id == Future_Order.trade_signal_id
                                        ).filter(
                                            TradeSignal.exchange_id == exchange_id,
                                            TradeSignal.country_id == country_id_dict[country_name.lower()],
                                            TradeSignal.time_fr == 3,
                                            TradeSignal.created_at.between(start_date, end_date),
                                            TradeSignal.is_active == 1,
                                            TradeSignal.trade_type.in_(trade_types)
                )

            # Count total
            total_count = query.count()

            # Apply search if needed
            # if search_key and search_key.lower() not in ['null', '']:
            #     query = query.filter(TradeSignal.stock_name.ilike(f"%{search_key}%"))

            if order_by_date:
                query = query.order_by(TradeSignal.created_at.desc())
            else:
                query = query.order_by(TradeSignal.stock_name.asc())
            

            # If only search_key is given (and page_no is missing), simulate page finding
            if search_key and not page_no:
                trades = query.all()

                if order_by_cmp:                    
                    if exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSE":                        
                        # trades = sorted(
                        #     trades,
                        #     key=lambda t: abs(
                        #         spf.fyers_data.get_latest_price(t.fyers_symbol)["ltp"] - t.trade_data["entry_price"]
                        #     ) / max(abs(t.trade_data["entry_price"]), 1e-9)
                        # )
                        sorted(trades, key= nse_price_difference)                    
                    elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "MCX":
                        sorted(trades, key= mcx_price_difference)
                    elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSEFO":
                        sorted(trades, key= nsefo_price_difference)

                found = False
                for i in range(len(trades)):
                    if trades[i].stock_symbol.lower().startswith(search_key.lower()):
                        found = i+1
                        break
                if not found:
                    for i in range(len(trades)):
                        if search_key.lower() in trades[i].stock_symbol.lower():
                            found = i+1
                            break
                if found:
                    page_no = ((found - 1) // limit) + 1
                    offset = (page_no - 1) * limit
                else:
                    page_no = 0
                    offset = 0
                    limit = 0
                # Apply offset and limit
                # query = query.offset(offset).limit(limit)



                #trades = query.all()

                # if order_by_cmp:
                #     if exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSE":
                #         trades = sorted(
                #             trades,
                #             key=lambda t: abs(spf.fyers_data.get_latest_price(t.fyers_symbol)['ltp'] - t.trade_data["entry_price"])
                #         )
                trades_list = []

                # Apply offset and limit
                trades = trades[offset : offset + limit]

                for trade in trades:
                    #if trade.trade_type.lower() in trade_types:
                        #print(abs(spf.fyers_data.get_latest_price(trade.fyers_symbol)['ltp'] - trade.trade_data["entry_price"]))
                        base = {
                            "TRADE_ID": trade.id,
                            "STOCK_NAME": trade.stock_name,
                            "STOCK_SYMBOL": trade.stock_symbol,
                            "TIME_FR": trade.time_fr,
                            "PRICE_CMP": trade.price_cmp,
                            "TRADE_TYPE": trade.trade_type,
                            "PREDICTION": trade.prediction,
                            "PROBABILITY": trade.probability,
                            "TIMESTAMP": trade.created_at.strftime("%Y-%m-%d %H:%M:%S"),
                            f"{trade.trade_type}_RRR": trade.rrr,
                            f"{trade.trade_type}_TIMESTAMPS": trade.timestamps,
                            trade.trade_type: trade.trade_data,
                            "EXP_NUM" : trade.exp_date,
                            "STOCK_ID": trade.stock_id
                        }
                        try:
                            base["TRADE_SIGNAL_ID"] = trade.trade_signal_id
                        except:
                            base["TRADE_SIGNAL_ID"] = None
                        trades_list.append(base)

                # search_pg_no = None
                # for i in range(0, total_count, limit):
                #     chunk = trades_list[i:i + limit]
                #     if any(search_key.lower() in tr["STOCK_NAME"].lower() for tr in chunk):
                #         search_pg_no = (i // limit) + 1
                #         break
                
                if len(trades_list) == 0:
                    page_no = None
                apiresponce.setMsg("success")
                apiresponce.setResponse({
                    "total_count": total_count,
                    "trades": sanitize_json_floats(trades_list),
                    "page_no": page_no
                })
                return apiresponce

            # Determine page number
            # page_no = int(page_no) if page_no and page_no.lower() not in ['null', ''] else 1
            # Paginate query
            # trades = query.offset((page_no - 1) * limit).limit(limit).all()
            
            trades = query.all()
            
            if order_by_cmp:                    
                    if exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSE":                        
                        # trades = sorted(
                        #     trades,
                        #     key=lambda t: abs(
                        #         spf.fyers_data.get_latest_price(t.fyers_symbol)["ltp"] - t.trade_data["entry_price"]
                        #     ) / max(abs(t.trade_data["entry_price"]), 1e-9)
                        # )
                        sorted(trades, key= nse_price_difference)                    
                    elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "MCX":
                        sorted(trades, key= mcx_price_difference)
                    elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSEFO":
                        sorted(trades, key= nsefo_price_difference)
                    
            trades_list = []

            # Apply offset and limit
            page_no = int(page_no) if page_no and page_no not in ["null", ""] else 1
            offset = (page_no - 1) * limit
            trades = trades[offset : offset + limit]
            
            for trade in trades:
                #if trade.trade_type.lower() in trade_types:
                    base = {
                        "TRADE_ID": trade.id,
                        "STOCK_NAME": trade.stock_name,
                        "STOCK_SYMBOL": trade.stock_symbol,
                        "TIME_FR": trade.time_fr,
                        "PRICE_CMP": trade.price_cmp,
                        "TRADE_TYPE": trade.trade_type,
                        "PREDICTION": trade.prediction,
                        "PROBABILITY": trade.probability,
                        "TIMESTAMP": trade.created_at.strftime("%Y-%m-%d %H:%M:%S"),
                        f"{trade.trade_type}_RRR": trade.rrr,
                        f"{trade.trade_type}_TIMESTAMPS": trade.timestamps,
                        trade.trade_type: trade.trade_data,
                        "EXP_NUM" : trade.exp_date,
                        "STOCK_ID": trade.stock_id
                    }
                    try:
                        base["TRADE_SIGNAL_ID"] = trade.trade_signal_id
                    except:
                        base["TRADE_SIGNAL_ID"] = None
                    trades_list.append(base)
            
            if len(trades_list) == 0:
                page_no = None
            apiresponce.setMsg("success")
            apiresponce.setResponse({
                "total_count": total_count,
                "trades": sanitize_json_floats(trades_list),
                "page_no": page_no
            })
        else:
            raise HTTPException(status_code=204, detail='Invalid Country')
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/get_available_trades_seventy_five_filter", tags=['AVAILABLE TRADES'])
async def get_available_trades_seventy_five_filter(
    request: Request,
    exchange_id: int,
    country_name: str,
    start_date: str = "2025-01-01",
    end_date: str = "2025-12-31",
    page_no: str = None,
    limit: int = 10,
    search_key: str = None,
    order_by_date: bool = False,
    trade_type: str = "all",
    order_by_cmp: bool = False
):
    apiresponce = APIResponse(request)
    try:
        db = dbc.get_session()
        exchange = db.query(ExchangeMaster).filter(ExchangeMaster.exchange_id == exchange_id,
                                                   ExchangeMaster.is_active == 1).all()
        
        if trade_type.lower() == "all":
            trade_types = ["buy", "sell", "Buy", "Sell", "BUY", "SELL"]
        else:
            trade_types = [trade_type.lower(), trade_type.upper(), trade_type.capitalize()]
        
        if "us" in country_name.lower() or "india" in country_name.lower():
            # 1. Convert date strings
            start_date = datetime.combine(datetime.strptime(start_date, "%Y-%m-%d"), datetime.min.time())
            end_date = datetime.combine(datetime.strptime(end_date, "%Y-%m-%d"), datetime.max.time())

            # 2. Base query
            if exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSE":
                query = db.query(TradeSignal.id, TradeSignal.exchange_id,
                                TradeSignal.stock_name, TradeSignal.time_fr,
                                TradeSignal.country_id, TradeSignal.price_cmp,
                                TradeSignal.trade_type, TradeSignal.rrr,
                                TradeSignal.timestamps, TradeSignal.trade_data,
                                TradeSignal.prediction, TradeSignal.probability,
                                TradeSignal.created_at, TradeSignal.is_active,
                                TradeSignal.is_send, TradeSignal.exp_date,
                                Ind_StockMaster.kite_symbol.label("stock_symbol"),
                                Ind_StockMaster.fyers_symbol,
                                Order.trade_signal_id,
                                Ind_StockMaster.id.label("stock_id")).join(
                                    Ind_StockMaster, TradeSignal.stock_name == Ind_StockMaster.stock_tick
                                    ).outerjoin(
                                            Order,
                                            TradeSignal.id == Order.trade_signal_id
                                                ).filter(
                                                    TradeSignal.exchange_id == exchange_id,
                                                    TradeSignal.country_id == country_id_dict[country_name.lower()],
                                                    TradeSignal.time_fr == 25,
                                                    TradeSignal.created_at.between(start_date, end_date),
                                                    TradeSignal.is_active == 1,
                                                    Ind_StockMaster.is_active == 1,
                                                    Ind_StockMaster.fyers_symbol != None,
                                                    TradeSignal.trade_type.in_(trade_types)
                                                )
            elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "MCX":
                query = db.query(TradeSignal.id, TradeSignal.exchange_id,
                                TradeSignal.stock_name, TradeSignal.time_fr,
                                TradeSignal.country_id, TradeSignal.price_cmp,
                                TradeSignal.trade_type, TradeSignal.rrr,
                                TradeSignal.timestamps, TradeSignal.trade_data,
                                TradeSignal.prediction, TradeSignal.probability,
                                TradeSignal.created_at, TradeSignal.is_active,
                                TradeSignal.is_send, TradeSignal.exp_date,
                                TradeSignal.stock_name.label("stock_symbol"),
                                Commodity_Order.trade_signal_id,
                                Commodity_Order.stock_id).outerjoin(
                                    Commodity_Order,
                                    TradeSignal.id == Commodity_Order.trade_signal_id
                                        ).filter(
                                        TradeSignal.exchange_id == exchange_id,
                                        TradeSignal.country_id == country_id_dict[country_name.lower()],
                                        TradeSignal.time_fr == 25,
                                        TradeSignal.created_at.between(start_date, end_date),
                                        TradeSignal.is_active == 1,
                                        TradeSignal.trade_type.in_(trade_types)
                )
            elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSEFO":
                query = db.query(TradeSignal.id, TradeSignal.exchange_id,
                                TradeSignal.stock_name, TradeSignal.time_fr,
                                TradeSignal.country_id, TradeSignal.price_cmp,
                                TradeSignal.trade_type, TradeSignal.rrr,
                                TradeSignal.timestamps, TradeSignal.trade_data,
                                TradeSignal.prediction, TradeSignal.probability,
                                TradeSignal.created_at, TradeSignal.is_active,
                                TradeSignal.is_send, TradeSignal.exp_date,
                                TradeSignal.stock_name.label("stock_symbol"),
                                Future_Order.trade_signal_id,
                                Future_Order.stock_id).outerjoin(
                                    Future_Order,
                                    TradeSignal.id == Future_Order.trade_signal_id
                                        ).filter(
                                        TradeSignal.exchange_id == exchange_id,
                                        TradeSignal.country_id == country_id_dict[country_name.lower()],
                                        TradeSignal.time_fr == 25,
                                        TradeSignal.created_at.between(start_date, end_date),
                                        TradeSignal.is_active == 1,
                                        TradeSignal.trade_type.in_(trade_types)
                )

            # 3. Count total
            total_count = query.count()

            # 4. Search key filtering
            # if search_key and search_key.lower() not in ["null", ""]:
            #     query = query.filter(TradeSignal.stock_name.ilike(f"%{search_key}%"))

            # 5. Sort
            if order_by_date:
                query = query.order_by(TradeSignal.created_at.desc())
            else:
                query = query.order_by(TradeSignal.stock_name.asc())

            

            # 6. If only search_key is given, find page_no where first match appears
            if search_key and not page_no:
                trades = query.all()

                if order_by_cmp:                    
                    if exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSE":                        
                        # trades = sorted(
                        #     trades,
                        #     key=lambda t: abs(
                        #         spf.fyers_data.get_latest_price(t.fyers_symbol)["ltp"] - t.trade_data["entry_price"]
                        #     ) / max(abs(t.trade_data["entry_price"]), 1e-9)
                        # )
                        sorted(trades, key= nse_price_difference)                    
                    elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "MCX":
                        sorted(trades, key= mcx_price_difference)
                    elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSEFO":
                        sorted(trades, key= nsefo_price_difference)
                
                found = False
                for i in range(len(trades)):
                    if trades[i].stock_symbol.lower().startswith(search_key.lower()):
                        found = i+1
                        break
                if not found:
                    for i in range(len(trades)):
                        if search_key.lower() in trades[i].stock_symbol.lower():
                            found = i+1
                            break
                if found:
                    page_no = ((found - 1) // limit) + 1
                    offset = (page_no - 1) * limit
                else:
                    page_no = 0
                    offset = 0
                    limit = 0
                # Apply offset and limit
                # query = query.offset(offset).limit(limit)

                #trades = query.all()

                # if order_by_cmp:
                #     if exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSE":
                #         trades = sorted(
                #             trades,
                #             key=lambda t: abs(spf.fyers_data.get_latest_price(t.fyers_symbol)['ltp'] - t.trade_data["entry_price"])
                #         )

                trades_list = []

                # Apply offset and limit
                trades = trades[offset : offset + limit]

                for trade in trades:
                    #if trade.trade_type.lower() in trade_types:
                        #print(abs(spf.fyers_data.get_latest_price(trade.fyers_symbol)['ltp'] - trade.trade_data["entry_price"]))
                        base = {
                            "TRADE_ID": trade.id,
                            "STOCK_NAME": trade.stock_name,
                            "STOCK_SYMBOL": trade.stock_symbol,
                            "TIME_FR": trade.time_fr,
                            "PRICE_CMP": trade.price_cmp,
                            "TRADE_TYPE": trade.trade_type,
                            "PREDICTION": trade.prediction,
                            "PROBABILITY": trade.probability,
                            "TIMESTAMP": trade.created_at.strftime("%Y-%m-%d %H:%M:%S"),
                            f"{trade.trade_type}_RRR": trade.rrr,
                            f"{trade.trade_type}_TIMESTAMPS": trade.timestamps,
                            trade.trade_type: trade.trade_data,
                            "EXP_NUM" : trade.exp_date,
                            "STOCK_ID": trade.stock_id
                        }
                        try:
                            base["TRADE_SIGNAL_ID"] = trade.trade_signal_id
                        except:
                            base["TRADE_SIGNAL_ID"] = None
                        trades_list.append(base)

                # manual paging simulation
                # search_pg_no = None
                # for i in range(0, total_count, limit):
                #     page_chunk = trades_list[i:i+limit]
                #     if any(search_key.lower() in tr["STOCK_NAME"].lower() for tr in page_chunk):
                #         search_pg_no = (i // limit) + 1
                #         break

                # filtered = page_chunk if search_pg_no else []
                if len(trades_list) == 0:
                    page_no = None
                apiresponce.setMsg("success")
                apiresponce.setResponse({
                    "total_count": total_count,
                    "trades": sanitize_json_floats(trades_list),
                    "page_no": page_no
                })
                return apiresponce

            # 7. Paginate query
            # page_no = int(page_no) if page_no and page_no not in ["null", ""] else 1
            # trades = query.offset((page_no - 1) * limit).limit(limit).all()

            trades = query.all()

            if order_by_cmp:                    
                    if exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSE":                        
                        # trades = sorted(
                        #     trades,
                        #     key=lambda t: abs(
                        #         spf.fyers_data.get_latest_price(t.fyers_symbol)["ltp"] - t.trade_data["entry_price"]
                        #     ) / max(abs(t.trade_data["entry_price"]), 1e-9)
                        # )
                        sorted(trades, key= nse_price_difference)                    
                    elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "MCX":
                        sorted(trades, key= mcx_price_difference)
                    elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSEFO":
                        sorted(trades, key= nsefo_price_difference)
            
            trades_list = []

            # Apply offset and limit
            page_no = int(page_no) if page_no and page_no not in ["null", ""] else 1
            offset = (page_no - 1) * limit
            trades = trades[offset : offset + limit]

            for trade in trades:
                #if trade.trade_type.lower() in trade_types:
                    #print(abs(spf.fyers_data.get_latest_price(trade.fyers_symbol)['ltp'] - trade.trade_data["entry_price"]))
                    base = {
                        "TRADE_ID": trade.id,
                        "STOCK_NAME": trade.stock_name,
                        "STOCK_SYMBOL": trade.stock_symbol,
                        "TIME_FR": trade.time_fr,
                        "PRICE_CMP": trade.price_cmp,
                        "TRADE_TYPE": trade.trade_type,
                        "PREDICTION": trade.prediction,
                        "PROBABILITY": trade.probability,
                        "TIMESTAMP": trade.created_at.strftime("%Y-%m-%d %H:%M:%S"),
                        f"{trade.trade_type}_RRR": trade.rrr,
                        f"{trade.trade_type}_TIMESTAMPS": trade.timestamps,
                        trade.trade_type: trade.trade_data,
                        "EXP_NUM" : trade.exp_date,
                        "STOCK_ID": trade.stock_id
                    }
                    try:
                        base["TRADE_SIGNAL_ID"] = trade.trade_signal_id
                    except:
                        base["TRADE_SIGNAL_ID"] = None
                    trades_list.append(base)

            if len(trades_list) == 0:
                page_no = None
            apiresponce.setMsg("success")
            apiresponce.setResponse({
                "total_count": total_count,
                "trades": sanitize_json_floats(trades_list),
                "page_no": page_no
            })
        else:
            raise HTTPException(status_code=204, detail='Invalid Country')
        db.close()
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/get_available_trades_one_twenty_filter", tags=['AVAILABLE TRADES'])
async def get_available_trades_one_twenty_filter(
    request: Request,
    exchange_id: int,
    country_name: str,
    start_date: str = "2025-01-01",
    end_date: str = "2025-12-31",
    page_no: str = None,
    limit: int = 10,
    search_key: str = None,
    order_by_date: bool = False,
    trade_type: str = "all",
    order_by_cmp: bool = False
):
    apiresponce = APIResponse(request)
    try:
        db = dbc.get_session()
        exchange = db.query(ExchangeMaster).filter(ExchangeMaster.exchange_id == exchange_id,
                                                   ExchangeMaster.is_active == 1).all()
        
        if trade_type.lower() == "all":
            trade_types = ["buy", "sell", "Buy", "Sell", "BUY", "SELL"]
        else:
            trade_types = [trade_type.lower(), trade_type.upper(), trade_type.capitalize()]
        
        if "us" in country_name.lower() or "india" in country_name.lower():
            # 1. Convert date strings
            start_date = datetime.combine(datetime.strptime(start_date, "%Y-%m-%d"), datetime.min.time())
            end_date = datetime.combine(datetime.strptime(end_date, "%Y-%m-%d"), datetime.max.time())

            # 2. Base query
            if exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSE":
                query = db.query(TradeSignal.id, TradeSignal.exchange_id,
                                TradeSignal.stock_name, TradeSignal.time_fr,
                                TradeSignal.country_id, TradeSignal.price_cmp,
                                TradeSignal.trade_type, TradeSignal.rrr,
                                TradeSignal.timestamps, TradeSignal.trade_data,
                                TradeSignal.prediction, TradeSignal.probability,
                                TradeSignal.created_at, TradeSignal.is_active,
                                TradeSignal.is_send, TradeSignal.exp_date,
                                Ind_StockMaster.kite_symbol.label("stock_symbol"),
                                Ind_StockMaster.fyers_symbol,
                                Order.trade_signal_id,
                                Ind_StockMaster.id.label("stock_id")).join(
                                    Ind_StockMaster, TradeSignal.stock_name == Ind_StockMaster.stock_tick
                                    ).outerjoin(
                                            Order,
                                            TradeSignal.id == Order.trade_signal_id
                                                ).filter(
                                                TradeSignal.exchange_id == exchange_id,
                                                TradeSignal.country_id == country_id_dict[country_name.lower()],
                                                TradeSignal.time_fr == 3,
                                                TradeSignal.created_at.between(start_date, end_date),
                                                TradeSignal.is_active == 1,
                                                Ind_StockMaster.is_active == 1,
                                                Ind_StockMaster.fyers_symbol != None,
                                                TradeSignal.trade_type.in_(trade_types)
                                            )
            elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "MCX":
                query = db.query(TradeSignal.id, TradeSignal.exchange_id,
                                TradeSignal.stock_name, TradeSignal.time_fr,
                                TradeSignal.country_id, TradeSignal.price_cmp,
                                TradeSignal.trade_type, TradeSignal.rrr,
                                TradeSignal.timestamps, TradeSignal.trade_data,
                                TradeSignal.prediction, TradeSignal.probability,
                                TradeSignal.created_at, TradeSignal.is_active,
                                TradeSignal.is_send, TradeSignal.exp_date,
                                TradeSignal.stock_name.label("stock_symbol"),
                                Commodity_Order.trade_signal_id,
                                Commodity_Order.stock_id).outerjoin(
                                    Commodity_Order,
                                    TradeSignal.id == Commodity_Order.trade_signal_id
                                        ).filter(
                                            TradeSignal.exchange_id == exchange_id,
                                            TradeSignal.country_id == country_id_dict[country_name.lower()],
                                            TradeSignal.time_fr == 3,
                                            TradeSignal.created_at.between(start_date, end_date),
                                            TradeSignal.is_active == 1,
                                            TradeSignal.trade_type.in_(trade_types)
                )
            elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSEFO":
                query = db.query(TradeSignal.id, TradeSignal.exchange_id,
                                TradeSignal.stock_name, TradeSignal.time_fr,
                                TradeSignal.country_id, TradeSignal.price_cmp,
                                TradeSignal.trade_type, TradeSignal.rrr,
                                TradeSignal.timestamps, TradeSignal.trade_data,
                                TradeSignal.prediction, TradeSignal.probability,
                                TradeSignal.created_at, TradeSignal.is_active,
                                TradeSignal.is_send, TradeSignal.exp_date,
                                TradeSignal.stock_name.label("stock_symbol"),
                                Future_Order.trade_signal_id,
                                Future_Order.stock_id).outerjoin(
                                    Future_Order,
                                    TradeSignal.id == Future_Order.trade_signal_id
                                        ).filter(
                                            TradeSignal.exchange_id == exchange_id,
                                            TradeSignal.country_id == country_id_dict[country_name.lower()],
                                            TradeSignal.time_fr == 3,
                                            TradeSignal.created_at.between(start_date, end_date),
                                            TradeSignal.is_active == 1,
                                            TradeSignal.trade_type.in_(trade_types)
                )

            # 3. Count total
            total_count = query.count()

            # 4. Search key filtering
            # if search_key and search_key.lower() not in ["null", ""]:
            #     query = query.filter(TradeSignal.stock_name.ilike(f"%{search_key}%"))

            # 5. Sort
            if order_by_date:
                query = query.order_by(TradeSignal.created_at.desc())
            else:
                query = query.order_by(TradeSignal.stock_name.asc())

            

            # 6. If only search_key is given, find page_no where first match appears
            if search_key and not page_no:
                trades = query.all()

                if order_by_cmp:                    
                    if exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSE":                        
                        # trades = sorted(
                        #     trades,
                        #     key=lambda t: abs(
                        #         spf.fyers_data.get_latest_price(t.fyers_symbol)["ltp"] - t.trade_data["entry_price"]
                        #     ) / max(abs(t.trade_data["entry_price"]), 1e-9)
                        # )
                        sorted(trades, key= nse_price_difference)                    
                    elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "MCX":
                        sorted(trades, key= mcx_price_difference)
                    elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSEFO":
                        sorted(trades, key= nsefo_price_difference)
                
                found = False
                for i in range(len(trades)):
                    if trades[i].stock_symbol.lower().startswith(search_key.lower()):
                        found = i+1
                        break
                if not found:
                    for i in range(len(trades)):
                        if search_key.lower() in trades[i].stock_symbol.lower():
                            found = i+1
                            break
                if found:
                    page_no = ((found - 1) // limit) + 1
                    offset = (page_no - 1) * limit
                else:
                    page_no = 0
                    offset = 0
                    limit = 0
                # Apply offset and limit
                # query = query.offset(offset).limit(limit)

                #trades = query.all()

                # if order_by_cmp:
                #     if exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSE":
                #         trades = sorted(
                #             trades,
                #             key=lambda t: abs(spf.fyers_data.get_latest_price(t.fyers_symbol)['ltp'] - t.trade_data["entry_price"])
                #         )

                trades_list = []

                # Apply offset and limit
                trades = trades[offset : offset + limit]

                for trade in trades:
                    #if trade.trade_type.lower() in trade_types:
                        #print(abs(spf.fyers_data.get_latest_price(trade.fyers_symbol)['ltp'] - trade.trade_data["entry_price"]))
                        base = {
                            "TRADE_ID": trade.id,
                            "STOCK_NAME": trade.stock_name,
                            "STOCK_SYMBOL": trade.stock_symbol,
                            "TIME_FR": trade.time_fr,
                            "PRICE_CMP": trade.price_cmp,
                            "TRADE_TYPE": trade.trade_type,
                            "PREDICTION": trade.prediction,
                            "PROBABILITY": trade.probability,
                            "TIMESTAMP": trade.created_at.strftime("%Y-%m-%d %H:%M:%S"),
                            f"{trade.trade_type}_RRR": trade.rrr,
                            f"{trade.trade_type}_TIMESTAMPS": trade.timestamps,
                            trade.trade_type: trade.trade_data,
                            "EXP_NUM" : trade.exp_date,
                            "STOCK_ID": trade.stock_id
                        }
                        try:
                            base["TRADE_SIGNAL_ID"] = trade.trade_signal_id
                        except:
                            base["TRADE_SIGNAL_ID"] = None
                        trades_list.append(base)

                # manual paging simulation
                # search_pg_no = None
                # for i in range(0, total_count, limit):
                #     page_chunk = trades_list[i:i+limit]
                #     if any(search_key.lower() in tr["STOCK_NAME"].lower() for tr in page_chunk):
                #         search_pg_no = (i // limit) + 1
                #         break

                # filtered = page_chunk if search_pg_no else []
                if len(trades_list) == 0:
                    page_no = None
                apiresponce.setMsg("success")
                apiresponce.setResponse({
                    "total_count": total_count,
                    "trades": sanitize_json_floats(trades_list),
                    "page_no": page_no
                })
                return apiresponce

            # 7. Paginate query
            # page_no = int(page_no) if page_no and page_no not in ["null", ""] else 1
            # trades = query.offset((page_no - 1) * limit).limit(limit).all()

            trades = query.all()

            if order_by_cmp:                    
                    if exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSE":                        
                        # trades = sorted(
                        #     trades,
                        #     key=lambda t: abs(
                        #         spf.fyers_data.get_latest_price(t.fyers_symbol)["ltp"] - t.trade_data["entry_price"]
                        #     ) / max(abs(t.trade_data["entry_price"]), 1e-9)
                        # )
                        sorted(trades, key= nse_price_difference)                    
                    elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "MCX":
                        sorted(trades, key= mcx_price_difference)
                    elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSEFO":
                        sorted(trades, key= nsefo_price_difference)
            
            trades_list = []

            # Apply offset and limit
            page_no = int(page_no) if page_no and page_no not in ["null", ""] else 1
            offset = (page_no - 1) * limit
            trades = trades[offset : offset + limit]

            for trade in trades:
                #if trade.trade_type.lower() in trade_types:
                    #print(abs(spf.fyers_data.get_latest_price(trade.fyers_symbol)['ltp'] - trade.trade_data["entry_price"]))
                    base = {
                        "TRADE_ID": trade.id,
                        "STOCK_NAME": trade.stock_name,
                        "STOCK_SYMBOL": trade.stock_symbol,
                        "TIME_FR": trade.time_fr,
                        "PRICE_CMP": trade.price_cmp,
                        "TRADE_TYPE": trade.trade_type,
                        "PREDICTION": trade.prediction,
                        "PROBABILITY": trade.probability,
                        "TIMESTAMP": trade.created_at.strftime("%Y-%m-%d %H:%M:%S"),
                        f"{trade.trade_type}_RRR": trade.rrr,
                        f"{trade.trade_type}_TIMESTAMPS": trade.timestamps,
                        trade.trade_type: trade.trade_data,
                        "EXP_NUM" : trade.exp_date,
                        "STOCK_ID": trade.stock_id
                    }
                    try:
                        base["TRADE_SIGNAL_ID"] = trade.trade_signal_id
                    except:
                        base["TRADE_SIGNAL_ID"] = None
                    trades_list.append(base)

            if len(trades_list) == 0:
                page_no = None
            apiresponce.setMsg("success")
            apiresponce.setResponse({
                "total_count": total_count,
                "trades": sanitize_json_floats(trades_list),
                "page_no": page_no
            })
        else:
            raise HTTPException(status_code=204, detail='Invalid Country')
        db.close()
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/get_available_trades_two_forty_filter", tags=['AVAILABLE TRADES'])
async def get_available_trades_two_forty_filter(
    request: Request,
    exchange_id: int,
    country_name: str,
    start_date: str = "2025-01-01",
    end_date: str = "2025-12-31",
    page_no: str = None,
    limit: int = 10,
    search_key: str = None,
    order_by_date: bool = False,
    trade_type: str = "all",
    order_by_cmp: bool = False
):
    apiresponce = APIResponse(request)
    try:
        db = dbc.get_session()
        exchange = db.query(ExchangeMaster).filter(ExchangeMaster.exchange_id == exchange_id,
                                                   ExchangeMaster.is_active == 1).all()
        
        if trade_type.lower() == "all":
            trade_types = ["buy", "sell", "Buy", "Sell", "BUY", "SELL"]
        else:
            trade_types = [trade_type.lower(), trade_type.upper(), trade_type.capitalize()]
        
        if "us" in country_name.lower() or "india" in country_name.lower():
            # 1. Convert date strings
            start_date = datetime.combine(datetime.strptime(start_date, "%Y-%m-%d"), datetime.min.time())
            end_date = datetime.combine(datetime.strptime(end_date, "%Y-%m-%d"), datetime.max.time())

            # 2. Base query
            if exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSE":
                query = db.query(TradeSignal.id, TradeSignal.exchange_id,
                                TradeSignal.stock_name, TradeSignal.time_fr,
                                TradeSignal.country_id, TradeSignal.price_cmp,
                                TradeSignal.trade_type, TradeSignal.rrr,
                                TradeSignal.timestamps, TradeSignal.trade_data,
                                TradeSignal.prediction, TradeSignal.probability,
                                TradeSignal.created_at, TradeSignal.is_active,
                                TradeSignal.is_send, TradeSignal.exp_date,
                                Ind_StockMaster.kite_symbol.label("stock_symbol"),
                                Ind_StockMaster.fyers_symbol,
                                Order.trade_signal_id,
                                Ind_StockMaster.id.label("stock_id")).join(
                                    Ind_StockMaster, TradeSignal.stock_name == Ind_StockMaster.stock_tick
                                    ).outerjoin(
                                            Order,
                                            TradeSignal.id == Order.trade_signal_id
                                                ).filter(
                                                    TradeSignal.exchange_id == exchange_id,
                                                    TradeSignal.country_id == country_id_dict[country_name.lower()],
                                                    TradeSignal.time_fr == 4,
                                                    TradeSignal.created_at.between(start_date, end_date),
                                                    TradeSignal.is_active == 1,
                                                    Ind_StockMaster.is_active == 1,
                                                    Ind_StockMaster.fyers_symbol != None,
                                                    TradeSignal.trade_type.in_(trade_types)
                                                )
            elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "MCX":
                query = db.query(TradeSignal.id, TradeSignal.exchange_id,
                                TradeSignal.stock_name, TradeSignal.time_fr,
                                TradeSignal.country_id, TradeSignal.price_cmp,
                                TradeSignal.trade_type, TradeSignal.rrr,
                                TradeSignal.timestamps, TradeSignal.trade_data,
                                TradeSignal.prediction, TradeSignal.probability,
                                TradeSignal.created_at, TradeSignal.is_active,
                                TradeSignal.is_send, TradeSignal.exp_date,
                                TradeSignal.stock_name.label("stock_symbol"),
                                Commodity_Order.trade_signal_id,
                                Commodity_Order.stock_id).outerjoin(
                                    Commodity_Order,
                                    TradeSignal.id == Commodity_Order.trade_signal_id
                                        ).filter(
                                        TradeSignal.exchange_id == exchange_id,
                                        TradeSignal.country_id == country_id_dict[country_name.lower()],
                                        TradeSignal.time_fr == 2,
                                        TradeSignal.created_at.between(start_date, end_date),
                                        TradeSignal.is_active == 1,
                                        TradeSignal.trade_type.in_(trade_types)
                )
            elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSEFO":
                query = db.query(TradeSignal.id, TradeSignal.exchange_id,
                                TradeSignal.stock_name, TradeSignal.time_fr,
                                TradeSignal.country_id, TradeSignal.price_cmp,
                                TradeSignal.trade_type, TradeSignal.rrr,
                                TradeSignal.timestamps, TradeSignal.trade_data,
                                TradeSignal.prediction, TradeSignal.probability,
                                TradeSignal.created_at, TradeSignal.is_active,
                                TradeSignal.is_send, TradeSignal.exp_date,
                                TradeSignal.stock_name.label("stock_symbol"),
                                Future_Order.trade_signal_id,
                                Future_Order.stock_id).outerjoin(
                                    Future_Order,
                                    TradeSignal.id == Future_Order.trade_signal_id
                                        ).filter(
                                        TradeSignal.exchange_id == exchange_id,
                                        TradeSignal.country_id == country_id_dict[country_name.lower()],
                                        TradeSignal.time_fr == 2,
                                        TradeSignal.created_at.between(start_date, end_date),
                                        TradeSignal.is_active == 1,
                                        TradeSignal.trade_type.in_(trade_types)
                )

            # 3. Count total
            total_count = query.count()

            # 4. Search key filtering
            # if search_key and search_key.lower() not in ["null", ""]:
            #     query = query.filter(TradeSignal.stock_name.ilike(f"%{search_key}%"))

            # 5. Sort
            if order_by_date:
                query = query.order_by(TradeSignal.created_at.desc())
            else:
                query = query.order_by(TradeSignal.stock_name.asc())

            

            # 6. If only search_key is given, find page_no where first match appears
            if search_key and not page_no:
                trades = query.all()

                if order_by_cmp:                    
                    if exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSE":                        
                        # trades = sorted(
                        #     trades,
                        #     key=lambda t: abs(
                        #         spf.fyers_data.get_latest_price(t.fyers_symbol)["ltp"] - t.trade_data["entry_price"]
                        #     ) / max(abs(t.trade_data["entry_price"]), 1e-9)
                        # )
                        sorted(trades, key= nse_price_difference)                    
                    elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "MCX":
                        sorted(trades, key= mcx_price_difference)
                    elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSEFO":
                        sorted(trades, key= nsefo_price_difference)
                
                found = False
                for i in range(len(trades)):
                    if trades[i].stock_symbol.lower().startswith(search_key.lower()):
                        found = i+1
                        break
                if not found:
                    for i in range(len(trades)):
                        if search_key.lower() in trades[i].stock_symbol.lower():
                            found = i+1
                            break
                if found:
                    page_no = ((found - 1) // limit) + 1
                    offset = (page_no - 1) * limit
                else:
                    page_no = 0
                    offset = 0
                    limit = 0
                # Apply offset and limit
                # query = query.offset(offset).limit(limit)

                #trades = query.all()

                # if order_by_cmp:
                #     if exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSE":
                #         trades = sorted(
                #             trades,
                #             key=lambda t: abs(spf.fyers_data.get_latest_price(t.fyers_symbol)['ltp'] - t.trade_data["entry_price"])
                #         )

                trades_list = []

                # Apply offset and limit
                trades = trades[offset : offset + limit]

                for trade in trades:
                    #if trade.trade_type.lower() in trade_types:
                        #print(abs(spf.fyers_data.get_latest_price(trade.fyers_symbol)['ltp'] - trade.trade_data["entry_price"]))
                        base = {
                            "TRADE_ID": trade.id,
                            "STOCK_NAME": trade.stock_name,
                            "STOCK_SYMBOL": trade.stock_symbol,
                            "TIME_FR": trade.time_fr,
                            "PRICE_CMP": trade.price_cmp,
                            "TRADE_TYPE": trade.trade_type,
                            "PREDICTION": trade.prediction,
                            "PROBABILITY": trade.probability,
                            "TIMESTAMP": trade.created_at.strftime("%Y-%m-%d %H:%M:%S"),
                            f"{trade.trade_type}_RRR": trade.rrr,
                            f"{trade.trade_type}_TIMESTAMPS": trade.timestamps,
                            trade.trade_type: trade.trade_data,
                            "EXP_NUM" : trade.exp_date,
                            "STOCK_ID": trade.stock_id
                        }
                        try:
                            base["TRADE_SIGNAL_ID"] = trade.trade_signal_id
                        except:
                            base["TRADE_SIGNAL_ID"] = None
                        trades_list.append(base)

                # manual paging simulation
                # search_pg_no = None
                # for i in range(0, total_count, limit):
                #     page_chunk = trades_list[i:i+limit]
                #     if any(search_key.lower() in tr["STOCK_NAME"].lower() for tr in page_chunk):
                #         search_pg_no = (i // limit) + 1
                #         break

                # filtered = page_chunk if search_pg_no else []
                if len(trades_list) == 0:
                    page_no = None
                apiresponce.setMsg("success")
                apiresponce.setResponse({
                    "total_count": total_count,
                    "trades": sanitize_json_floats(trades_list),
                    "page_no": page_no
                })
                return apiresponce

            # 7. Paginate query
            # page_no = int(page_no) if page_no and page_no not in ["null", ""] else 1
            # trades = query.offset((page_no - 1) * limit).limit(limit).all()

            trades = query.all()

            if order_by_cmp:                    
                    if exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSE":                        
                        # trades = sorted(
                        #     trades,
                        #     key=lambda t: abs(
                        #         spf.fyers_data.get_latest_price(t.fyers_symbol)["ltp"] - t.trade_data["entry_price"]
                        #     ) / max(abs(t.trade_data["entry_price"]), 1e-9)
                        # )
                        sorted(trades, key= nse_price_difference)                    
                    elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "MCX":
                        sorted(trades, key= mcx_price_difference)
                    elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSEFO":
                        sorted(trades, key= nsefo_price_difference)
            

            trades_list = []

            # Apply offset and limit
            page_no = int(page_no) if page_no and page_no not in ["null", ""] else 1
            offset = (page_no - 1) * limit
            trades = trades[offset : offset + limit]

            for trade in trades:
                #if trade.trade_type.lower() in trade_types:
                    #print(abs(spf.fyers_data.get_latest_price(trade.fyers_symbol)['ltp'] - trade.trade_data["entry_price"]))
                    base = {
                        "TRADE_ID": trade.id,
                        "STOCK_NAME": trade.stock_name,
                        "STOCK_SYMBOL": trade.stock_symbol,
                        "TIME_FR": trade.time_fr,
                        "PRICE_CMP": trade.price_cmp,
                        "TRADE_TYPE": trade.trade_type,
                        "PREDICTION": trade.prediction,
                        "PROBABILITY": trade.probability,
                        "TIMESTAMP": trade.created_at.strftime("%Y-%m-%d %H:%M:%S"),
                        f"{trade.trade_type}_RRR": trade.rrr,
                        f"{trade.trade_type}_TIMESTAMPS": trade.timestamps,
                        trade.trade_type: trade.trade_data,
                        "EXP_NUM" : trade.exp_date,
                        "STOCK_ID": trade.stock_id
                    }
                    try:
                        base["TRADE_SIGNAL_ID"] = trade.trade_signal_id
                    except:
                        base["TRADE_SIGNAL_ID"] = None
                    trades_list.append(base)

            if len(trades_list) == 0:
                page_no = None
            apiresponce.setMsg("success")
            apiresponce.setResponse({
                "total_count": total_count,
                "trades": sanitize_json_floats(trades_list),
                "page_no": page_no
            })
        else:
            raise HTTPException(status_code=204, detail='Invalid Country')
        db.close()
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/get_available_trades_twenty_five_filter", tags=['AVAILABLE TRADES'])
async def get_available_trades_twenty_five_filter(
    request: Request,
    exchange_id: int,
    country_name: str,
    start_date: str = "2025-01-01",
    end_date: str = "2025-12-31",
    page_no: str = None,
    limit: int = 10,
    search_key: str = None,
    order_by_date: bool = False,
    trade_type: str = "all",
    order_by_cmp: bool = False
):
    apiresponce = APIResponse(request)
    try:
        db = dbc.get_session()
        exchange = db.query(ExchangeMaster).filter(ExchangeMaster.exchange_id == exchange_id,
                                                   ExchangeMaster.is_active == 1).all()
        
        if trade_type.lower() == "all":
            trade_types = ["buy", "sell", "Buy", "Sell", "BUY", "SELL"]
        else:
            trade_types = [trade_type.lower(), trade_type.upper(), trade_type.capitalize()]
        
        if "us" in country_name.lower() or "india" in country_name.lower():
            # 1. Convert date strings
            start_date = datetime.combine(datetime.strptime(start_date, "%Y-%m-%d"), datetime.min.time())
            end_date = datetime.combine(datetime.strptime(end_date, "%Y-%m-%d"), datetime.max.time())

            # 2. Base query
            if exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSE":
                query = db.query(TradeSignal.id, TradeSignal.exchange_id,
                                TradeSignal.stock_name, TradeSignal.time_fr,
                                TradeSignal.country_id, TradeSignal.price_cmp,
                                TradeSignal.trade_type, TradeSignal.rrr,
                                TradeSignal.timestamps, TradeSignal.trade_data,
                                TradeSignal.prediction, TradeSignal.probability,
                                TradeSignal.created_at, TradeSignal.is_active,
                                TradeSignal.is_send, TradeSignal.exp_date,
                                Ind_StockMaster.kite_symbol.label("stock_symbol"),
                                Ind_StockMaster.fyers_symbol,
                                Order.trade_signal_id,
                                Ind_StockMaster.id.label("stock_id")).join(
                                    Ind_StockMaster, TradeSignal.stock_name == Ind_StockMaster.stock_tick
                                    ).outerjoin(
                                            Order,
                                            TradeSignal.id == Order.trade_signal_id
                                                ).filter(
                                                TradeSignal.exchange_id == exchange_id,
                                                TradeSignal.country_id == country_id_dict[country_name.lower()],
                                                TradeSignal.time_fr == 6,
                                                TradeSignal.created_at.between(start_date, end_date),
                                                TradeSignal.is_active == 1,
                                                Ind_StockMaster.is_active == 1,
                                                Ind_StockMaster.fyers_symbol != None,
                                                TradeSignal.trade_type.in_(trade_types)
                                            )
            elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "MCX":
                query = db.query(TradeSignal.id, TradeSignal.exchange_id,
                                TradeSignal.stock_name, TradeSignal.time_fr,
                                TradeSignal.country_id, TradeSignal.price_cmp,
                                TradeSignal.trade_type, TradeSignal.rrr,
                                TradeSignal.timestamps, TradeSignal.trade_data,
                                TradeSignal.prediction, TradeSignal.probability,
                                TradeSignal.created_at, TradeSignal.is_active,
                                TradeSignal.is_send, TradeSignal.exp_date,
                                TradeSignal.stock_name.label("stock_symbol"),
                                Commodity_Order.trade_signal_id,
                                Commodity_Order.stock_id).outerjoin(
                                    Commodity_Order,
                                    TradeSignal.id == Commodity_Order.trade_signal_id
                                        ).filter(
                                            TradeSignal.exchange_id == exchange_id,
                                            TradeSignal.country_id == country_id_dict[country_name.lower()],
                                            TradeSignal.time_fr == 6,
                                            TradeSignal.created_at.between(start_date, end_date),
                                            TradeSignal.is_active == 1,
                                            TradeSignal.trade_type.in_(trade_types)
                )
            
            elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSEFO":
                query = db.query(TradeSignal.id, TradeSignal.exchange_id,
                                TradeSignal.stock_name, TradeSignal.time_fr,
                                TradeSignal.country_id, TradeSignal.price_cmp,
                                TradeSignal.trade_type, TradeSignal.rrr,
                                TradeSignal.timestamps, TradeSignal.trade_data,
                                TradeSignal.prediction, TradeSignal.probability,
                                TradeSignal.created_at, TradeSignal.is_active,
                                TradeSignal.is_send, TradeSignal.exp_date,
                                TradeSignal.stock_name.label("stock_symbol"),
                                Future_Order.trade_signal_id,
                                Future_Order.stock_id).outerjoin(
                                    Future_Order,
                                    TradeSignal.id == Future_Order.trade_signal_id
                                        ).filter(
                                            TradeSignal.exchange_id == exchange_id,
                                            TradeSignal.country_id == country_id_dict[country_name.lower()],
                                            TradeSignal.time_fr == 5,
                                            TradeSignal.created_at.between(start_date, end_date),
                                            TradeSignal.is_active == 1,
                                            TradeSignal.trade_type.in_(trade_types)
                )

            # 3. Count total
            total_count = query.count()

            # 4. Search key filtering
            # if search_key and search_key.lower() not in ["null", ""]:
            #     query = query.filter(TradeSignal.stock_name.ilike(f"%{search_key}%"))

            # 5. Sort
            if order_by_date:
                query = query.order_by(TradeSignal.created_at.desc())
            else:
                query = query.order_by(TradeSignal.stock_name.asc())

            

            # 6. If only search_key is given, find page_no where first match appears
            if search_key and not page_no:
                trades = query.all()

                if order_by_cmp:                    
                    if exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSE":                        
                        # trades = sorted(
                        #     trades,
                        #     key=lambda t: abs(
                        #         spf.fyers_data.get_latest_price(t.fyers_symbol)["ltp"] - t.trade_data["entry_price"]
                        #     ) / max(abs(t.trade_data["entry_price"]), 1e-9)
                        # )
                        sorted(trades, key= nse_price_difference)                    
                    elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "MCX":
                        sorted(trades, key= mcx_price_difference)
                    elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSEFO":
                        sorted(trades, key= nsefo_price_difference)
                
                found = False
                for i in range(len(trades)):
                    if trades[i].stock_symbol.lower().startswith(search_key.lower()):
                        found = i+1
                        break
                if not found:
                    for i in range(len(trades)):
                        if search_key.lower() in trades[i].stock_symbol.lower():
                            found = i+1
                            break
                if found:
                    page_no = ((found - 1) // limit) + 1
                    offset = (page_no - 1) * limit
                else:
                    page_no = 0
                    offset = 0
                    limit = 0
                # Apply offset and limit
                # query = query.offset(offset).limit(limit)

                #trades = query.all()

                # if order_by_cmp:
                #     if exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSE":
                #         trades = sorted(
                #             trades,
                #             key=lambda t: abs(spf.fyers_data.get_latest_price(t.fyers_symbol)['ltp'] - t.trade_data["entry_price"])
                #         )

                trades_list = []

                # Apply offset and limit
                trades = trades[offset : offset + limit]

                for trade in trades:
                    #if trade.trade_type.lower() in trade_types:
                        #print(abs(spf.fyers_data.get_latest_price(trade.fyers_symbol)['ltp'] - trade.trade_data["entry_price"]))
                        base = {
                            "TRADE_ID": trade.id,
                            "STOCK_NAME": trade.stock_name,
                            "STOCK_SYMBOL": trade.stock_symbol,
                            "TIME_FR": trade.time_fr,
                            "PRICE_CMP": trade.price_cmp,
                            "TRADE_TYPE": trade.trade_type,
                            "PREDICTION": trade.prediction,
                            "PROBABILITY": trade.probability,
                            "TIMESTAMP": trade.created_at.strftime("%Y-%m-%d %H:%M:%S"),
                            f"{trade.trade_type}_RRR": trade.rrr,
                            f"{trade.trade_type}_TIMESTAMPS": trade.timestamps,
                            trade.trade_type: trade.trade_data,
                            "EXP_NUM" : trade.exp_date,
                            "STOCK_ID": trade.stock_id
                        }
                        try:
                            base["TRADE_SIGNAL_ID"] = trade.trade_signal_id
                        except:
                            base["TRADE_SIGNAL_ID"] = None
                        trades_list.append(base)

                # manual paging simulation
                # search_pg_no = None
                # for i in range(0, total_count, limit):
                #     page_chunk = trades_list[i:i+limit]
                #     if any(search_key.lower() in tr["STOCK_NAME"].lower() for tr in page_chunk):
                #         search_pg_no = (i // limit) + 1
                #         break

                # filtered = page_chunk if search_pg_no else []
                if len(trades_list) == 0:
                    page_no = None
                apiresponce.setMsg("success")
                apiresponce.setResponse({
                    "total_count": total_count,
                    "trades": sanitize_json_floats(trades_list),
                    "page_no": page_no
                })
                return apiresponce

            # 7. Paginate query
            # page_no = int(page_no) if page_no and page_no not in ["null", ""] else 1
            # trades = query.offset((page_no - 1) * limit).limit(limit).all()

            trades = query.all()

            if order_by_cmp:                    
                    if exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSE":                        
                        # trades = sorted(
                        #     trades,
                        #     key=lambda t: abs(
                        #         spf.fyers_data.get_latest_price(t.fyers_symbol)["ltp"] - t.trade_data["entry_price"]
                        #     ) / max(abs(t.trade_data["entry_price"]), 1e-9)
                        # )
                        sorted(trades, key= nse_price_difference)                    
                    elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "MCX":
                        sorted(trades, key= mcx_price_difference)
                    elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSEFO":
                        sorted(trades, key= nsefo_price_difference)
            
            trades_list = []

            # Apply offset and limit
            page_no = int(page_no) if page_no and page_no not in ["null", ""] else 1
            offset = (page_no - 1) * limit
            trades = trades[offset : offset + limit]

            for trade in trades:
                #if trade.trade_type.lower() in trade_types:
                    #print(abs(spf.fyers_data.get_latest_price(trade.fyers_symbol)['ltp'] - trade.trade_data["entry_price"]))
                    base = {
                        "TRADE_ID": trade.id,
                        "STOCK_NAME": trade.stock_name,
                        "STOCK_SYMBOL": trade.stock_symbol,
                        "TIME_FR": trade.time_fr,
                        "PRICE_CMP": trade.price_cmp,
                        "TRADE_TYPE": trade.trade_type,
                        "PREDICTION": trade.prediction,
                        "PROBABILITY": trade.probability,
                        "TIMESTAMP": trade.created_at.strftime("%Y-%m-%d %H:%M:%S"),
                        f"{trade.trade_type}_RRR": trade.rrr,
                        f"{trade.trade_type}_TIMESTAMPS": trade.timestamps,
                        trade.trade_type: trade.trade_data,
                        "EXP_NUM" : trade.exp_date,
                        "STOCK_ID": trade.stock_id
                    }
                    try:
                        base["TRADE_SIGNAL_ID"] = trade.trade_signal_id
                    except:
                        base["TRADE_SIGNAL_ID"] = None
                    trades_list.append(base)

            if len(trades_list) == 0:
                page_no = None
            apiresponce.setMsg("success")
            apiresponce.setResponse({
                "total_count": total_count,
                "trades": sanitize_json_floats(trades_list),
                "page_no": page_no
            })
        else:
            raise HTTPException(status_code=204, detail='Invalid Country')
        db.close()
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/get_available_trades_one_twenty_five_filter", tags=['AVAILABLE TRADES'])
async def get_available_trades_one_twenty_five_filter(
    request: Request,
    exchange_id: int,
    country_name: str,
    start_date: str = "2025-01-01",
    end_date: str = "2025-12-31",
    page_no: str = None,
    limit: int = 10,
    search_key: str = None,
    order_by_date: bool = False,
    trade_type: str = "all",
    order_by_cmp: bool = False
):
    apiresponce = APIResponse(request)
    try:
        db = dbc.get_session()
        exchange = db.query(ExchangeMaster).filter(ExchangeMaster.exchange_id == exchange_id,
                                                   ExchangeMaster.is_active == 1).all()
        
        if trade_type.lower() == "all":
            trade_types = ["buy", "sell", "Buy", "Sell", "BUY", "SELL"]
        else:
            trade_types = [trade_type.lower(), trade_type.upper(), trade_type.capitalize()]
        
        if "us" in country_name.lower() or "india" in country_name.lower():
            # 1. Convert date strings
            start_date = datetime.combine(datetime.strptime(start_date, "%Y-%m-%d"), datetime.min.time())
            end_date = datetime.combine(datetime.strptime(end_date, "%Y-%m-%d"), datetime.max.time())

            # 2. Base query
            if exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSE":
                query = db.query(TradeSignal.id, TradeSignal.exchange_id,
                                TradeSignal.stock_name, TradeSignal.time_fr,
                                TradeSignal.country_id, TradeSignal.price_cmp,
                                TradeSignal.trade_type, TradeSignal.rrr,
                                TradeSignal.timestamps, TradeSignal.trade_data,
                                TradeSignal.prediction, TradeSignal.probability,
                                TradeSignal.created_at, TradeSignal.is_active,
                                TradeSignal.is_send, TradeSignal.exp_date,
                                Ind_StockMaster.kite_symbol.label("stock_symbol"),
                                Ind_StockMaster.fyers_symbol,
                                Order.trade_signal_id,
                                Ind_StockMaster.id.label("stock_id")).join(
                                    Ind_StockMaster, TradeSignal.stock_name == Ind_StockMaster.stock_tick
                                    ).outerjoin(
                                            Order,
                                            TradeSignal.id == Order.trade_signal_id
                                                ).filter(
                                                TradeSignal.exchange_id == exchange_id,
                                                TradeSignal.country_id == country_id_dict[country_name.lower()],
                                                TradeSignal.time_fr == 5,
                                                TradeSignal.created_at.between(start_date, end_date),
                                                TradeSignal.is_active == 1,
                                                Ind_StockMaster.is_active == 1,
                                                Ind_StockMaster.fyers_symbol != None,
                                                TradeSignal.trade_type.in_(trade_types)
                                            )
            elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "MCX":
                query = db.query(TradeSignal.id, TradeSignal.exchange_id,
                                TradeSignal.stock_name, TradeSignal.time_fr,
                                TradeSignal.country_id, TradeSignal.price_cmp,
                                TradeSignal.trade_type, TradeSignal.rrr,
                                TradeSignal.timestamps, TradeSignal.trade_data,
                                TradeSignal.prediction, TradeSignal.probability,
                                TradeSignal.created_at, TradeSignal.is_active,
                                TradeSignal.is_send, TradeSignal.exp_date,
                                TradeSignal.stock_name.label("stock_symbol"),
                                Commodity_Order.trade_signal_id,
                                Commodity_Order.stock_id).outerjoin(
                                    Commodity_Order,
                                    TradeSignal.id == Commodity_Order.trade_signal_id
                                        ).filter(
                                            TradeSignal.exchange_id == exchange_id,
                                            TradeSignal.country_id == country_id_dict[country_name.lower()],
                                            TradeSignal.time_fr == 5,
                                            TradeSignal.created_at.between(start_date, end_date),
                                            TradeSignal.is_active == 1,
                                            TradeSignal.trade_type.in_(trade_types)
                )
            
            elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSEFO":
                query = db.query(TradeSignal.id, TradeSignal.exchange_id,
                                TradeSignal.stock_name, TradeSignal.time_fr,
                                TradeSignal.country_id, TradeSignal.price_cmp,
                                TradeSignal.trade_type, TradeSignal.rrr,
                                TradeSignal.timestamps, TradeSignal.trade_data,
                                TradeSignal.prediction, TradeSignal.probability,
                                TradeSignal.created_at, TradeSignal.is_active,
                                TradeSignal.is_send, TradeSignal.exp_date,
                                TradeSignal.stock_name.label("stock_symbol"),
                                Future_Order.trade_signal_id,
                                Future_Order.stock_id).outerjoin(
                                    Future_Order,
                                    TradeSignal.id == Future_Order.trade_signal_id
                                        ).filter(
                                            TradeSignal.exchange_id == exchange_id,
                                            TradeSignal.country_id == country_id_dict[country_name.lower()],
                                            TradeSignal.time_fr == 4,
                                            TradeSignal.created_at.between(start_date, end_date),
                                            TradeSignal.is_active == 1,
                                            TradeSignal.trade_type.in_(trade_types)
                )

            # 3. Count total
            total_count = query.count()

            # 4. Search key filtering
            # if search_key and search_key.lower() not in ["null", ""]:
            #     query = query.filter(TradeSignal.stock_name.ilike(f"%{search_key}%"))

            # 5. Sort
            if order_by_date:
                query = query.order_by(TradeSignal.created_at.desc())
            else:
                query = query.order_by(TradeSignal.stock_name.asc())

            

            # 6. If only search_key is given, find page_no where first match appears
            if search_key and not page_no:
                trades = query.all()

                if order_by_cmp:                    
                    if exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSE":                        
                        # trades = sorted(
                        #     trades,
                        #     key=lambda t: abs(
                        #         spf.fyers_data.get_latest_price(t.fyers_symbol)["ltp"] - t.trade_data["entry_price"]
                        #     ) / max(abs(t.trade_data["entry_price"]), 1e-9)
                        # )
                        sorted(trades, key= nse_price_difference)                    
                    elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "MCX":
                        sorted(trades, key= mcx_price_difference)
                    elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSEFO":
                        sorted(trades, key= nsefo_price_difference)
                
                found = False
                for i in range(len(trades)):
                    if trades[i].stock_symbol.lower().startswith(search_key.lower()):
                        found = i+1
                        break
                if not found:
                    for i in range(len(trades)):
                        if search_key.lower() in trades[i].stock_symbol.lower():
                            found = i+1
                            break
                if found:
                    page_no = ((found - 1) // limit) + 1
                    offset = (page_no - 1) * limit
                else:
                    page_no = 0
                    offset = 0
                    limit = 0
                # Apply offset and limit
                # query = query.offset(offset).limit(limit)

                #trades = query.all()

                # if order_by_cmp:
                #     if exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSE":
                #         trades = sorted(
                #             trades,
                #             key=lambda t: abs(spf.fyers_data.get_latest_price(t.fyers_symbol)['ltp'] - t.trade_data["entry_price"])
                #         )

                trades_list = []

                # Apply offset and limit
                trades = trades[offset : offset + limit]

                for trade in trades:
                    #if trade.trade_type.lower() in trade_types:
                        #print(abs(spf.fyers_data.get_latest_price(trade.fyers_symbol)['ltp'] - trade.trade_data["entry_price"]))
                        base = {
                            "TRADE_ID": trade.id,
                            "STOCK_NAME": trade.stock_name,
                            "STOCK_SYMBOL": trade.stock_symbol,
                            "TIME_FR": trade.time_fr,
                            "PRICE_CMP": trade.price_cmp,
                            "TRADE_TYPE": trade.trade_type,
                            "PREDICTION": trade.prediction,
                            "PROBABILITY": trade.probability,
                            "TIMESTAMP": trade.created_at.strftime("%Y-%m-%d %H:%M:%S"),
                            f"{trade.trade_type}_RRR": trade.rrr,
                            f"{trade.trade_type}_TIMESTAMPS": trade.timestamps,
                            trade.trade_type: trade.trade_data,
                            "EXP_NUM" : trade.exp_date,
                            "STOCK_ID": trade.stock_id
                        }
                        try:
                            base["TRADE_SIGNAL_ID"] = trade.trade_signal_id
                        except:
                            base["TRADE_SIGNAL_ID"] = None
                        trades_list.append(base)

                # manual paging simulation
                # search_pg_no = None
                # for i in range(0, total_count, limit):
                #     page_chunk = trades_list[i:i+limit]
                #     if any(search_key.lower() in tr["STOCK_NAME"].lower() for tr in page_chunk):
                #         search_pg_no = (i // limit) + 1
                #         break

                # filtered = page_chunk if search_pg_no else []
                if len(trades_list) == 0:
                    page_no = None
                apiresponce.setMsg("success")
                apiresponce.setResponse({
                    "total_count": total_count,
                    "trades": sanitize_json_floats(trades_list),
                    "page_no": page_no
                })
                return apiresponce

            # 7. Paginate query
            # page_no = int(page_no) if page_no and page_no not in ["null", ""] else 1
            # trades = query.offset((page_no - 1) * limit).limit(limit).all()

            trades = query.all()

            if order_by_cmp:                    
                    if exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSE":                        
                        # trades = sorted(
                        #     trades,
                        #     key=lambda t: abs(
                        #         spf.fyers_data.get_latest_price(t.fyers_symbol)["ltp"] - t.trade_data["entry_price"]
                        #     ) / max(abs(t.trade_data["entry_price"]), 1e-9)
                        # )
                        sorted(trades, key= nse_price_difference)                    
                    elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "MCX":
                        sorted(trades, key= mcx_price_difference)
                    elif exchange and len(exchange) > 0 and exchange[0].exchange_name == "NSEFO":
                        sorted(trades, key= nsefo_price_difference)
            
            trades_list = []

            # Apply offset and limit
            page_no = int(page_no) if page_no and page_no not in ["null", ""] else 1
            offset = (page_no - 1) * limit
            trades = trades[offset : offset + limit]

            for trade in trades:
                #if trade.trade_type.lower() in trade_types:
                    #print(abs(spf.fyers_data.get_latest_price(trade.fyers_symbol)['ltp'] - trade.trade_data["entry_price"]))
                    base = {
                        "TRADE_ID": trade.id,
                        "STOCK_NAME": trade.stock_name,
                        "STOCK_SYMBOL": trade.stock_symbol,
                        "TIME_FR": trade.time_fr,
                        "PRICE_CMP": trade.price_cmp,
                        "TRADE_TYPE": trade.trade_type,
                        "PREDICTION": trade.prediction,
                        "PROBABILITY": trade.probability,
                        "TIMESTAMP": trade.created_at.strftime("%Y-%m-%d %H:%M:%S"),
                        f"{trade.trade_type}_RRR": trade.rrr,
                        f"{trade.trade_type}_TIMESTAMPS": trade.timestamps,
                        trade.trade_type: trade.trade_data,
                        "EXP_NUM" : trade.exp_date,
                        "STOCK_ID": trade.stock_id
                    }
                    try:
                        base["TRADE_SIGNAL_ID"] = trade.trade_signal_id
                    except:
                        base["TRADE_SIGNAL_ID"] = None
                    trades_list.append(base)

            if len(trades_list) == 0:
                page_no = None
            apiresponce.setMsg("success")
            apiresponce.setResponse({
                "total_count": total_count,
                "trades": sanitize_json_floats(trades_list),
                "page_no": page_no
            })
        else:
            raise HTTPException(status_code=204, detail='Invalid Country')
        db.close()
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce



@router.get("/get-stock-id/{trade_id}", tags=['AVAILABLE TRADES'])
async def get_stock_id_by_trade_id(avl_trade_id: int, request: Request):
    apiresponce = APIResponse(request)
    try:
        db = dbc.get_session()
        trade = db.query(TradeSignal).filter(TradeSignal.id == avl_trade_id).first()
        if not trade:
            raise HTTPException(status_code=404, detail="TradeSignal not found")
        exchange = db.query(ExchangeMaster).filter(
            ExchangeMaster.exchange_id == trade.exchange_id,
            ExchangeMaster.is_active == True
        ).first()
        if not exchange:
            raise HTTPException(status_code=404, detail="Exchange not found or inactive")
        stock_name = trade.stock_name.upper()
        exchange_name = exchange.exchange_name
        stock = None
        if exchange_name == 'NSE':  # NSE
            stock = db.query(Ind_StockMaster).filter(Ind_StockMaster.stock_tick == stock_name).first()
        elif exchange_name == 'MCX':  # MCX
            stock = db.query(CommoditiesMaster).filter(CommoditiesMaster.symbol == stock_name).first()
        elif exchange_name == 'NSEFO':  # NSEFO
            stock = db.query(FuturesMaster).filter(FuturesMaster.symbol == stock_name).first()
        else:
            raise HTTPException(status_code=400, detail="Exchange not mapped for stock ID retrieval")

        if not stock:
            raise HTTPException(status_code=404, detail="Stock not found in corresponding master table")
        apiresponce.setMsg("success")
        apiresponce.setResponse({"stock_id": stock.id, "exchange": exchange.exchange_name, "stock_name": stock_name})
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce



@router.get("/get_stock_tick_by_symbol", tags=['AVAILABLE TRADES'])
async def get_stock_tick_by_symbol(stock_name: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        db = dbc.get_session()
        stock = db.query(Ind_StockMaster).filter(Ind_StockMaster.kite_symbol == stock_name).first()
        if not stock:
            raise HTTPException(status_code=404, detail="Stock not found")
        apiresponce.setMsg("success")
        apiresponce.setResponse({"stock_id": stock.id, "stock_tick": stock.stock_tick})
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/share_trade_detail", tags=['AVAILABLE TRADES'])
async def share_trade_detail(trade_id: int, request: Request):
    apiresponce = APIResponse(request)
    try:
        db = dbc.get_session()
        trade = db.query(TradeSignal).filter(TradeSignal.id == trade_id).first()
        if not trade:
            raise HTTPException(status_code=404, detail="Trade not found")
        apiresponce.setMsg("success")
        apiresponce.setResponse(dict(trade.__dict__))
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/get_trading_scope", tags=['AVAILABLE TRADES'])
async def get_trading_scope(request: Request):
    apiresponce = APIResponse(request)
    try:
        # db = dbc.get_session()
        # trade = db.query(TradeSignal).filter(TradeSignal.id == trade_id).first()
        # if not trade:
        #     raise HTTPException(status_code=404, detail="Trade not found")
        data = {
            "NSE" : ['BUY', 'SELL'],
            "NSEFO" : ['BUY', 'SELL'], 
            "MCX" : ['BUY', 'SELL']
        }
        apiresponce.setMsg("success")
        apiresponce.setResponse(data)
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce