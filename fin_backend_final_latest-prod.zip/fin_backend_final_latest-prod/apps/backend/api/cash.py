from fastapi import APIRouter, Request
from shared.db.api_responce import APIResponse
from scripts.calculate_setup import Calculate_setup_execute
from scripts.calculate_setup_future import Calculate_setup_execute_futures
from shared.config.settings import stock_data_dir_config, stock_logic_config
from shared.db.dbconn import DBConnection
from shared.db.db_model import Order, Future_Order, Commodity_Order
from shared.db.db_model import Auto_Order
from shared.db.db_model import TradeSignal
from shared.utils.logger import logger
from datetime import datetime
from scripts.setup_engine_new import format_calculate_setup_response, process_setup

router = APIRouter()

dbc = DBConnection()


@router.get("/calculate_setup", tags=['Stock Calculation'])
async def calculate_setup(country_name: str, tick: str, time_frame: int, last_d_time: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        country_dir = stock_data_dir_config.indian_stock_data_dir
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        time_list = getattr(stock_logic_config, f'TIME_FRAME_EXE_{time_frame}')
        # if time_frame == 1:
        # file_name = f"./processed_data_files/{tick}_{exe_frame}.csv"
        # cse = Calculate_setup_execute(tick, time_frame, last_d_time, country_dir)
        # setup_data = cse.calculate()
        raw_setup = process_setup(tick, time_list, last_d_time)
        setup_data = format_calculate_setup_response(raw_setup, stock_name=tick, time_fr=time_frame, last_d_time=last_d_time, is_future=False, is_cash=True)
        print(setup_data)
        if setup_data is not None:
            apiresponce.setMsg("success")
            apiresponce.setResponse(setup_data)
        else:
            apiresponce.setMsg("failed")
            apiresponce.setResponse("Not Enough Data available")
            
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


# @router.get("/calculate_setup_reason", tags=['Stock Calculation'])
# async def calculate_setup_reason(order_id: int, table_name: str, request: Request):
#     apiresponce = APIResponse(request)
#     try:
#         country_dir = stock_data_dir_config.indian_stock_data_dir
#         if table_name == "auto_order":
#             order_data = dbc.get_session().query(Auto_Order).filter(Auto_Order.order_id == order_id).first()
#         elif table_name == "order":
#             order_data = dbc.get_session().query(Order).filter(Order.order_id == order_id).first()
        
#         if order_data is None:
#             apiresponce.setMsg("failed")
#             apiresponce.setResponse("Order Not Found")
#             return apiresponce
#         stock_name = order_data.stock_tick
#         time_frame = order_data.time_frame
#         last_d_time = datetime.strptime(order_data.purchased_cmp_date, "%Y-%m-%dT%H:%M")
#         cse = Calculate_setup_execute(stock_name, time_frame, last_d_time, country_dir)
#         cse.calculate()
#         setup_reason = cse.get_all_reasons()
#         print(setup_reason)
#         if setup_reason is not None:
#             apiresponce.setMsg("success")
#             apiresponce.setResponse(setup_reason)
#         else:
#             apiresponce.setMsg("failed")
#             apiresponce.setResponse("Not Enough Data available")
            
#     except Exception as ex:
#         logger.exception(ex)
#         apiresponce.setMsg("failed")
#         apiresponce.setResponse(str(ex))
#     return apiresponce



# @router.get("/available_trade_reason", tags=['Stock Calculation'])
# async def available_trade_reason(trade_id: int, request: Request):
#     apiresponce = APIResponse(request)
#     try:
#         trade_data = dbc.get_session().query(TradeSignal).filter(TradeSignal.id == trade_id).first()
        
#         if trade_data is None:
#             apiresponce.setMsg("failed")
#             apiresponce.setResponse("Trade Not Found")
#             return apiresponce
#         if trade_data.exchange_id == 8:
#             segment = "cash"
#             data_dir = stock_data_dir_config.indian_stock_data_dir
#         elif trade_data.exchange_id == 10:
#             segment = "commodity"
#             data_dir = stock_data_dir_config.indian_commodity_data
#         elif trade_data.exchange_id == 11:
#             segment = "futures"
#             data_dir = stock_data_dir_config.indian_stock_future_data_dir
#         else:
#             apiresponce.setMsg("failed")
#             apiresponce.setResponse("Invalid Exchange ID")
#             return apiresponce
        
#         stock_name = trade_data.stock_name
#         time_frame = trade_data.time_fr
#         last_d_time = trade_data.created_at
#         if segment == "cash":
#             cse = Calculate_setup_execute(stock_name, time_frame, last_d_time, data_dir)
#         else:
#             exp_num = trade_data.exp_date
#             cse = Calculate_setup_execute_futures(stock_name, time_frame, last_d_time, exp_num, data_dir, segment)
#         cse.calculate()
#         setup_reason = cse.get_all_reasons()
#         print(setup_reason)
#         if setup_reason is not None:
#             apiresponce.setMsg("success")
#             apiresponce.setResponse(setup_reason)
#         else:
#             apiresponce.setMsg("failed")
#             apiresponce.setResponse("Not Enough Data available")
            
#     except Exception as ex:
#         logger.exception(ex)
#         apiresponce.setMsg("failed")
#         apiresponce.setResponse(str(ex))
#     return apiresponce


# @router.get("/calculate_setup_reason_futures_commodity", tags=['Stock Calculation'])
# async def calculate_setup_reason_futures_commodity(order_id: int, segment: str, request: Request):
#     apiresponce = APIResponse(request)
#     try:
#         if segment == "futures":
#             country_dir = stock_data_dir_config.indian_stock_future_data_dir
#             order_data = dbc.get_session().query(Future_Order).filter(Future_Order.order_id == order_id).first()
#         elif segment == "commodity":
#             country_dir = stock_data_dir_config.indian_commodity_data
#             order_data = dbc.get_session().query(Commodity_Order).filter(Commodity_Order.order_id == order_id).first()
#         else:
#             apiresponce.setMsg("failed")
#             apiresponce.setResponse("Invalid Segment")
#             return apiresponce
        
#         if order_data is None:
#             apiresponce.setMsg("failed")
#             apiresponce.setResponse("Order Not Found")
#             return apiresponce
#         stock_name = order_data.stock_tick
#         time_frame = order_data.time_frame
#         exp_num = order_data.expiry_date
#         last_d_time = datetime.strptime(order_data.purchased_cmp_date, "%Y-%m-%dT%H:%M")
#         cse = Calculate_setup_execute_futures(stock_name, time_frame, last_d_time, exp_num, country_dir, segment)
#         cse.calculate()
#         setup_reason = cse.get_all_reasons()
#         print(setup_reason)
#         if setup_reason is not None:
#             apiresponce.setMsg("success")
#             apiresponce.setResponse(setup_reason)
#         else:
#             apiresponce.setMsg("failed")
#             apiresponce.setResponse("Not Enough Data available")
            
#     except Exception as ex:
#         logger.exception(ex)
#         apiresponce.setMsg("failed")
#         apiresponce.setResponse(str(ex))
#     return apiresponce