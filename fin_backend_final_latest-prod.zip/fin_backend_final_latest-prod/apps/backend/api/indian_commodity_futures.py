from fastapi import APIRouter, Request, Response, WebSocket, WebSocketDisconnect
from shared.db.api_responce import APIResponse
from data_fetchers.nselib.future_data_fetcher import future_data_getter
from shared.config.settings import stock_logic_config as slcfg
from shared.config.settings import stock_data_dir_config as sddcfg
from scripts.calculate_setup_future import Calculate_setup_execute_futures
from scripts.calculate_zones import DemandZoneCalculator, SupplyZoneCalculator, ZoneAnalyzer, ZONE_TIME_FIXATURE_COMMODITY
from scripts.calculate_zones_ext import Calculate_BAD_ZONES, Calculate_Base_Candles
from shared.utils.logger import logger
from datetime import datetime
from sqlitedict import SqliteDict
import re
import numpy as np
from shared.db.db_model import CommoditiesMaster
from shared.db.dbconn import DBConnection
from scripts.models import load_preprocess_chart_data, TF
from scripts.trade_engine import process_zones, process_qualified_zones
from scripts.setup_engine_new import process_setup_fc, format_calculate_setup_response
import asyncio
from data_fetchers.fyers.get_commodity_prices import CommodityPriceFetcher
import time


router = APIRouter()
db = DBConnection()


cpf = CommodityPriceFetcher()
time.sleep(2)

@router.get("/get_expiry_list_by_commodity_symbol", tags=['Indian Commodity'])
async def get_expiry_list_by_commodity_symbol(request: Request, symbol: str = None):
    apiresponce = APIResponse(request)
    try:
        db = SqliteDict('finprod.sqlite')
        expirty_list = db['indian_commodity_expiries']
        db.close()
        if symbol is not None:
            expirty_list = [exp for exp in expirty_list if exp['symbol'] == symbol]
        sql_db = DBConnection()
        session = sql_db.get_session()
        commodities = session.query(CommoditiesMaster).all()
        for exp in expirty_list:
            exp['id'] = next((comm.id for comm in commodities if comm.symbol == exp['symbol']), None)
        session.close()
        sql_db.close_engine()
        if len(expirty_list) > 0:
            apiresponce.setMsg("success")
        else:
            apiresponce.setMsg("failed")
        apiresponce.setResponse(expirty_list)
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/get_commodities_candlestick_data", tags=['Indian Commodity'])
async def get_commodities_candlestick_data(st_sym: str, time_frame: int, exp_dt: str, last_d_time, request: Request):
    apiresponce = APIResponse(request)
    try:
        out_res = {}
        numbers = re.findall(r'\d+', exp_dt)
        # Join all found numbers into one string
        exp_num = ''.join(numbers)
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        for frames in getattr(slcfg, f"COMMODITY_TIME_FRAME_{time_frame}"):
            ft_file_name = f"{sddcfg.indian_commodity_data}/latest_data_csv/{st_sym}_{exp_num}_{frames}.csv"
            df, violation_df = load_preprocess_chart_data(ft_file_name, last_d_time)
            # fdg = future_data_getter()
            # out_res[frames] = fdg.get_commodity_formatted_stock_chart_data(ft_file_name)
            # out_res[frames] = load_preprocess_chart_data(ft_file_name, last_d_time)
            df_1 = df[['tradeDate', 'open', 'high', 'low', 'close']][df.tradeDate <= last_d_time]
            df_1.rename(columns = {'tradeDate': 'time'}, inplace = True)
            df_1['timestamp'] = df_1['time'].copy()
            df_1['time'] = (df_1['time'].astype(np.int64) // 10**9).astype(int)
            df_sorted = df_1.sort_values(by='time', ascending=True)
            df_sorted = df_sorted.drop_duplicates(subset=['time'])
            df_sorted.replace([np.inf, -np.inf], np.nan, inplace=True)
            df_sorted.fillna(0, inplace=True)
            
            out_res[frames] = df_sorted.to_dict(orient='records')
        apiresponce.setMsg("success")
        apiresponce.setResponse(out_res)
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/calculate_setup_commodities", tags=['Indian Commodity'])
async def calculate_setup_commodities(st_sym: str, exp_dt: str, time_frame: int, last_d_time: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        setup_data = {}
        numbers = re.findall(r'\d+', exp_dt)
        exp_num = ''.join(numbers)
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        time_list = getattr(slcfg, f"COMMODITY_TIME_FRAME_{time_frame}")
        
        # csef = Calculate_setup_execute_futures(st_sym, time_frame, last_d_time, exp_num, sddcfg.indian_commodity_data, 'commodity')
        setup_data = process_setup_fc(st_sym, time_list, exp_num, last_d_time, False)
        setup_data = format_calculate_setup_response(setup_data, stock_name=st_sym, time_fr=time_frame, exp_num=exp_num, last_d_time=last_d_time, is_future=False, is_cash=False)
        # print(setup_data)
        if setup_data is not None:
            apiresponce.setMsg("success")
            apiresponce.setResponse(setup_data)
        else:
            apiresponce.setMsg("failed")
            apiresponce.setResponse("Not Enough Data available")
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/get_qualified_zones_commodity", tags=['Indian Commodity'])
async def get_qualified_zones_commodity(st_sym: str, exp_dt: str, time_frame: int, last_d_time: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        numbers = re.findall(r'\d+', exp_dt)
        exp_num = ''.join(numbers)
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        time_list = getattr(slcfg, f"COMMODITY_TIME_FRAME_{time_frame}")
        file_name = f"{sddcfg.indian_commodity_data}/latest_data_csv/{st_sym}_{exp_num}_{time_list[-1]}.csv"
        # dz_cal = DemandZoneCalculator(file_name, st_sym, last_d_time, True)
        # sz_cal = SupplyZoneCalculator(file_name, st_sym, last_d_time, True)
        # zone_cal = ZoneAnalyzer(dz_cal, sz_cal)
        # data = zone_cal.get_qualified_alterated_zones(True)
        data = process_qualified_zones(file_name, TF.X, last_d_time, time_list, st_sym)
        apiresponce.setMsg("success")
        apiresponce.setResponse(data)

    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce

@router.get("/calculate_base_candles_commodity", tags=['Indian Commodity'])
async def calculate_base_candles_commodity(st_sym: str, time_frame: int, exp_dt: str, last_d_time: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        data = {}
        numbers = re.findall(r'\d+', exp_dt)
        exp_num = ''.join(numbers)
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        time_list = getattr(slcfg, f"COMMODITY_TIME_FRAME_{time_frame}")
        for t_frame in time_list:
            file_name = f"{sddcfg.indian_commodity_data}/latest_data_csv/{st_sym}_{exp_num}_{t_frame}.csv"
            cbc = Calculate_Base_Candles(csv_path = file_name, tick=st_sym, last_d_time=last_d_time)
            data[t_frame] = cbc.calculate_zones()
        apiresponce.setMsg("success")
        apiresponce.setResponse(data)
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/bad_zone_records_commodity", tags=['Indian Commodity'])
async def bad_zone_records_commodity(st_sym: str, time_frame: int, exp_dt: str, last_d_time: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        out_res = {}
        numbers = re.findall(r'\d+', exp_dt)
        exp_num = ''.join(numbers)
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        frame = getattr(slcfg, f"COMMODITY_TIME_FRAME_{time_frame}")
        for t_fr in frame:
            file_name = f"{sddcfg.indian_commodity_data}/latest_data_csv/{st_sym}_{exp_num}_{t_fr}.csv"
            cbz = Calculate_BAD_ZONES(csv_path=file_name, last_d_time=last_d_time)
            dat = cbz.get_bad_zones_data()
            if dat:
                out_res[t_fr] = dat #cbz.get_bad_zones_data()
            else:
                out_res[t_fr] = None 
        apiresponce.setMsg("success")
        apiresponce.setResponse(out_res)
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/get_fixed_commodity_time_eae_zones", tags=['Indian Commodity'])
async def get_fixed_commodity_time_eae_zones(st_sym: str, exp_dt: str, time_frame: int, last_d_time: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        out_res = {}
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        numbers = re.findall(r'\d+', exp_dt)
        exp_num = ''.join(numbers)
        ztf = ZONE_TIME_FIXATURE_COMMODITY(st_sym, time_frame, last_d_time, exp_num, sddcfg.indian_commodity_data)
        execute_data = {
            'Buy' : ztf.calculate_and_adjust_dz(),
            'Sell': ztf.calculate_and_adjust_sz()
        }
        analyse_data = ztf.calculate_analyse_eval_overlap()
        out_res['Execute'] = execute_data
        out_res['Analyse'] = analyse_data
        apiresponce.setMsg("success")
        apiresponce.setResponse(out_res)
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/get_commodities_opt_zones", tags=['Indian Commodity'])
async def get_commodities_opt_zones(st_sym: str, exp_dt: str, time_frame: int, last_d_time: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        data = {}
        numbers = re.findall(r'\d+', exp_dt)
        exp_num = ''.join(numbers)
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        time_list = getattr(slcfg, f"COMMODITY_TIME_FRAME_{time_frame}")
        for t_frame in time_list:
            # is_execute = True if time_list[-1] == t_frame else False
            file_name = f"{sddcfg.indian_commodity_data}/latest_data_csv/{st_sym}_{exp_num}_{t_frame}.csv"
            if t_frame == time_list[0]:
                tf = TF.E
            elif t_frame == time_list[1]:
                tf = TF.A
            else:
                tf = TF.X
            # dz_calc = DemandZoneCalculator(file_name, st_sym, last_d_time, is_execute)
            # sz_calc = SupplyZoneCalculator(file_name, st_sym, last_d_time, is_execute)
            # z_ana = ZoneAnalyzer(dz_calc, sz_calc)
            # BB = z_ana.get_filtered_buy_sell_zone(dz_calc.calculate_zones(), sz_calc.calculate_zones())
            resp = process_zones(file_name, tf, last_d_time)
            data[t_frame] = resp
        apiresponce.setMsg("success")
        apiresponce.setResponse(data)
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


# @router.websocket("/ws/commodity_live_price")
# async def commodity_live_price(websocket: WebSocket, symbol: str, expiry_date: str):
#     await websocket.accept()
#     try:
#         while True:      
#             stocks = [{"symbol": symbol.upper(), "expiry_date": expiry_date}]
            
                
#             #print(stocks)    
#             if stocks != None and len(stocks) > 0:
#                 # print(stocks)
#                 #print("before fyers connection")

#                 data = await cpf.get_stock_price_from_fyers(stocks)
#                 # print(datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"), "Printing data")
#                 #print("data------------", data)
#             else:
#                 data = []
#                 #print("data------------", data)
#             # db.close_engine()
#             #logger.info("data------------", data)
#             if data:
#                 # print(datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"), "Sending data to WebSocket")
#                 await websocket.send_json({"data": data})
#             else:
#                 await websocket.send_text("Error fetching stock price")
#             await asyncio.sleep(5)
#     except WebSocketDisconnect as ex:
#         #logger.exception(ex, exc_info=True, stack_info=True)
#         print("WebSocket Error: Client disconnected from price WebSocket")
#     except asyncio.CancelledError:
#         return
#     except Exception as e:
#         logger.exception(e, exc_info=True, stack_info=True)
#         print("WebSocket Error:", e)