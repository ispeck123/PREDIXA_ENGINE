from fastapi import APIRouter, Request, Response, WebSocket, WebSocketDisconnect
from shared.db.api_responce import APIResponse
from data_fetchers.nselib.future_data_fetcher import future_data_getter
from shared.config.settings import stock_logic_config as slcfg
from shared.config.settings import stock_data_dir_config as sddcfg
from shared.utils.logger import logger
from datetime import datetime
from scripts.calculate_zones import DemandZoneCalculator, SupplyZoneCalculator, ZoneAnalyzer, ZONE_TIME_FIXATURE_FUTURES
from scripts.calculate_zones_ext import Calculate_BAD_ZONES, Calculate_Base_Candles
from scripts.calculate_setup_future import Calculate_setup_execute_futures
import re
from shared.db.dbconn import DBConnection
from nselib.derivatives import expiry_dates_future
from shared.db.db_model import FuturesMaster
import requests
import pandas as pd
import numpy as np
from io import StringIO
from data_fetchers.fyers.get_future_prices import FuturePriceFetcher
import time
import asyncio
from fastapi.responses import HTMLResponse
from scripts.models import load_preprocess_chart_data, TF
from scripts.trade_engine import process_zones, process_qualified_zones, processs_all_zones
from scripts.setup_engine_new import process_setup_fc, format_calculate_setup_response


router = APIRouter()
db = DBConnection()

fpf = FuturePriceFetcher()
time.sleep(2)

@router.get("/get_futures_candlestick_data", tags=['India Futures'])
async def get_futures_data(st_sym: str, exp_dt: str, time_frame: int, last_d_time: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        out_res = {}
        numbers = re.findall(r'\d+', exp_dt)
        # Join all found numbers into one string
        exp_num = ''.join(numbers)
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        t_list = getattr(slcfg, f"FUTURE_TIME_FRAME_{time_frame}") if time_frame != 2 else slcfg.TIME_FRAME_ALL_2
        for frames in t_list:
            ft_file_name = f"{sddcfg.indian_stock_future_data_dir}/latest_data_csv/{st_sym}_{exp_num}_{frames}.csv"
            # fdg = future_data_getter()
            df, violation_df = load_preprocess_chart_data(ft_file_name, last_d_time)

            df_1 = df[['tradeDate', 'open', 'high', 'low', 'close']][df.tradeDate <= last_d_time]
            df_1.rename(columns = {'tradeDate': 'time'}, inplace = True)
            df_1['timestamp'] = df_1['time'].copy()
            df_1['time'] = (df_1['time'].astype(np.int64) // 10**9).astype(int)
            df_sorted = df_1.sort_values(by='time', ascending=True)
            df_sorted = df_sorted.drop_duplicates(subset=['time'])
            df_sorted.replace([np.inf, -np.inf], np.nan, inplace=True)
            df_sorted.fillna(0, inplace=True)
            
            out_res[frames] = df_sorted.to_dict(orient='records')
            # fdg.get_formatted_stock_chart_data(ft_file_name)
        apiresponce.setMsg("success")
        apiresponce.setResponse(out_res)
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/get_futures_opt_zones", tags=['India Futures'])
async def get_futures_opt_zones(st_sym: str, exp_dt: str, time_frame: int, last_d_time: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        data = {}
        numbers = re.findall(r'\d+', exp_dt)
        exp_num = ''.join(numbers)
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        time_list = getattr(slcfg, f"FUTURE_TIME_FRAME_{time_frame}")
        for t_frame in time_list:
            # is_execute = True if time_list[-1] == t_frame else False
            file_name = f"{sddcfg.indian_stock_future_data_dir}/latest_data_csv/{st_sym}_{exp_num}_{t_frame}.csv"
            if t_frame == time_list[0]:
                tf = TF.E
            elif t_frame == time_list[1]:
                tf = TF.A
            else:
                tf = TF.X
            # dz_calc = DemandZoneCalculator(file_name, st_sym, last_d_time, is_execute)
            # sz_calc = SupplyZoneCalculator(file_name, st_sym, last_d_time, is_execute)
            # z_ana = ZoneAnalyzer(dz_calc, sz_calc)
            # BB = z_ana.get_filtered_buy_sell_zone(dz_calc.calculate_zones(), sz_calc.calculate_zones())
            print(file_name, "5555555555555555555555555555555555555555555")
            data[t_frame] = process_zones(file_name, tf, last_d_time)
        apiresponce.setMsg("success")
        apiresponce.setResponse(data)
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/get_fixed_futures_time_eae_zones", tags=['India Futures'])
async def get_fixed_futures_time_eae_zones(st_sym: str, exp_dt: str, time_frame: int, last_d_time: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        out_res = {}
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        numbers = re.findall(r'\d+', exp_dt)
        exp_num = ''.join(numbers)
        ztf = ZONE_TIME_FIXATURE_FUTURES(st_sym, time_frame, last_d_time, exp_num, sddcfg.indian_stock_future_data_dir)
        execute_data = {
            'Buy' : ztf.calculate_and_adjust_dz(),
            'Sell': ztf.calculate_and_adjust_sz()
        }
        analyse_data = ztf.calculate_analyse_eval_overlap()
        out_res['Execute'] = execute_data
        out_res['Analyse'] = analyse_data
        apiresponce.setMsg("success")
        apiresponce.setResponse(out_res)
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/bad_zone_records_futures", tags=['India Futures'])
async def bad_zone_records_futures(st_sym: str, exp_dt: str, time_frame: int, last_d_time: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        out_res = {}
        numbers = re.findall(r'\d+', exp_dt)
        exp_num = ''.join(numbers)
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        for t_fr in getattr(slcfg, f"FUTURE_TIME_FRAME_{time_frame}"):
            file_name = f"{sddcfg.indian_stock_future_data_dir}/latest_data_csv/{st_sym}_{exp_num}_{t_fr}.csv"
            cbz = Calculate_BAD_ZONES(csv_path=file_name, last_d_time=last_d_time)
            out_res[t_fr] = cbz.get_bad_zones_data()

        apiresponce.setMsg("success")
        apiresponce.setResponse(out_res)
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/calculate_setup_futures", tags=['India Futures'])
async def calculate_setup_futures(st_sym: str, exp_dt: str, time_frame: int, last_d_time: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        setup_data = {}
        numbers = re.findall(r'\d+', exp_dt)
        exp_num = ''.join(numbers)
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        time_list = getattr(slcfg, f"FUTURE_TIME_FRAME_{time_frame}")
        # csef = Calculate_setup_execute_futures(st_sym, time_frame, last_d_time, exp_num, sddcfg.indian_stock_future_data_dir, 'futures')
        # setup_data = csef.calculate()
        setup_data = process_setup_fc(st_sym, time_list, exp_num, last_d_time, True)
        setup_data = format_calculate_setup_response(setup_data, stock_name=st_sym, time_fr=time_frame, exp_num=exp_num, last_d_time=last_d_time, is_future=True, is_cash=False)
        if setup_data is not None:
            apiresponce.setMsg("success")
            apiresponce.setResponse(setup_data)
        else:
            apiresponce.setMsg("failed")
            apiresponce.setResponse("Not Enough Data available")
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/get_qualified_zones_futures", tags=['India Futures'])
async def get_qualified_zones_futures(st_sym: str, exp_dt: str, time_frame: int, last_d_time: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        numbers = re.findall(r'\d+', exp_dt)
        exp_num = ''.join(numbers)
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        time_list = getattr(slcfg, f"FUTURE_TIME_FRAME_{time_frame}")
        file_name = f"{sddcfg.indian_stock_future_data_dir}/latest_data_csv/{st_sym}_{exp_num}_{time_list[-1]}.csv"
        # dz_cal = DemandZoneCalculator(file_name, st_sym, last_d_time, True)
        # sz_cal = SupplyZoneCalculator(file_name, st_sym, last_d_time, True)
        # zone_cal = ZoneAnalyzer(dz_cal, sz_cal)
        # data = zone_cal.get_qualified_alterated_zones(True)
        data = process_qualified_zones(file_name, TF.X, last_d_time, time_list, st_sym)
        apiresponce.setMsg("success")
        apiresponce.setResponse(data)

    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


@router.get("/calculate_base_candles_futures", tags=['India Futures'])
async def calculate_base_candles_futures(st_sym: str, exp_dt: str, time_frame: int, last_d_time: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        data = {}
        numbers = re.findall(r'\d+', exp_dt)
        exp_num = ''.join(numbers)
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        for t_frame in getattr(slcfg, f"FUTURE_TIME_FRAME_{time_frame}"):
            file_name = f"{sddcfg.indian_stock_future_data_dir}/latest_data_csv/{st_sym}_{exp_num}_{t_frame}.csv"
            cbc = Calculate_Base_Candles(csv_path = file_name, tick=st_sym, last_d_time=last_d_time)
            data[t_frame] = cbc.calculate_zones()
        apiresponce.setMsg("success")
        apiresponce.setResponse(data)
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


def extract_date(entry):
    match = re.search(r'\b(\d{2})\s([A-Za-z]{3})\s(\d{2})\b', entry)
    if match:
        # year, month, day = match.groups()
        day, month, year = match.groups()
        full_date_str = f"20{year} {month} {day}"
        return datetime.strptime(full_date_str, "%Y %b %d")
    return None


def get_fyers_monthly_fut_expiries_top3(product: str):
    """
    Returns the top 3 monthly FUT expiries (near/next/far) for a stock future.

    Output example:
    [
      {"expiry": "30-01-2026"},
      {"expiry": "27-02-2026"},
      {"expiry": "27-03-2026"}
    ]
    """
    try:
        url = "https://public.fyers.in/sym_details/NSE_FO.csv"
        response = requests.get(url, timeout=30)
        response.raise_for_status()

        df = pd.read_csv(StringIO(response.text), header=None)
        print(df.columns)
        # Stock FUT rows (example: "NSE:RELIANCE26JANFUT")
        # sym_col =  # column containing "NSE:XXXX..." in your file
        sym_col = 9

        df = df[df[sym_col].astype(str).str.contains(f"NSE:{product}", na=False)]
        df = df[df[sym_col].astype(str).str.contains("FUT", na=False)]

        # Parse expiry using your existing extractor
        df["parsed_date"] = df[1].apply(extract_date)
        df = df.dropna(subset=["parsed_date"]).sort_values(by="parsed_date")

        # Get unique expiries in ascending order (near -> far)
        expiries = (
            df["parsed_date"]
            .drop_duplicates()
            .sort_values()
            .head(3)
        )

        # Format
        out = [d.strftime("%Y-%m-%d") for d in expiries.tolist()]
        return out

    except Exception as e:
        logger.exception(e)
        print(f"Error fetching FUT expiries: {product}  {e}")
        return None


@router.get("/get_futures_expiry_dates", tags=['India Futures'])
async def get_futures_expiry_dates(key: str, request: Request):
    apiresponce = APIResponse(request)
    try:
        key = key.upper()
        response = []
        expiry_dates = get_fyers_monthly_fut_expiries_top3(key)
        print(expiry_dates)
        #expiry_dates = expiry_dates_future()
        
        session = db.get_session()
        if expiry_dates and len(expiry_dates) > 0:            
            futures = session.query(FuturesMaster).filter(FuturesMaster.symbol.like(f'{key}%')).all()
            if futures and len(futures) > 0:
                # for dt in expiry_dates:
                #     dt = datetime.strptime(dt, "%d-%b-%Y")
                #     response.append({"symbol": futures[0].symbol, "expiry_date": dt.strftime("%d-%B-%Y")})
                #dt = datetime.strptime(expiry_dates[0], "%d-%b-%Y") 
                dt = datetime.strptime(expiry_dates[0], "%Y-%m-%d")
                response.append({"symbol": futures[0].symbol, "expiry_date": dt.strftime("%d-%B-%Y")})
                apiresponce.setMsg("success")
                apiresponce.setResponse(response)
            else:
                apiresponce.setMsg("failed")
                apiresponce.setResponse("No futures found for the given key")
        else:
            apiresponce.setMsg("failed")
            apiresponce.setResponse("Expiry dates not found")
        session.close()
    except Exception as ex:
        logger.exception(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce


# @router.websocket("/ws/all_future_live_prices")
# async def all_future_live_prices(websocket: WebSocket, expiry: str = None):
#     await websocket.accept()
#     try:
#         while True:      
#             stocks = []
#             # stocks = db.raw_query(f"""select fm.id, fm.symbol, fm.exchange, fm.expiry_date
#             #                     from futures_master fm            
#             #                     order by fm.symbol""")
            
#             session = db.get_session()
#             expiry_dates = session.query(FuturesMaster.expiry_date).distinct().order_by(FuturesMaster.expiry_date).all()
#             # logger.info(expiry_dates)
#             if len(expiry_dates) > 0:
#                 expiry_dates_dict = {
#                     "near": expiry_dates[0][0],
#                     "next" : expiry_dates[1][0],
#                     "far" : expiry_dates[2][0]
#                 }

#             if expiry and expiry.lower() not in ("near", "next", "far"):
#                 stocks = session.query(FuturesMaster).order_by(FuturesMaster.symbol).all()
#             else:
#                 stocks = session.query(FuturesMaster).filter(FuturesMaster.expiry_date == expiry_dates_dict[expiry]).order_by(FuturesMaster.symbol).all()
#             session.close()
                

#             #print(stocks)    
#             if stocks != None and len(stocks) > 0:
#                 # print(stocks)
#                 #print("before fyers connection")

#                 data = await fpf.get_stock_price_from_fyers(stocks)
#                 # print(datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"), "Printing data")
#                 #print("data------------", data)
#             else:
#                 data = []
#                 #print("data------------", data)
#             # db.close_engine()
#             #logger.info("data------------", data)
#             if data:
#                 # print(datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"), "Sending data to WebSocket")
#                 await websocket.send_json({"total_stocks": len(data), "stocks": data})
#             else:
#                 await websocket.send_text("Error fetching stock price")
#             await asyncio.sleep(5)
#     except WebSocketDisconnect as ex:
#         #logger.exception(ex, exc_info=True, stack_info=True)
#         print("WebSocket Error: Client disconnected from price WebSocket")
#     except asyncio.CancelledError:
#         return
#     except Exception as e:
#         logger.exception(e, exc_info=True, stack_info=True)
#         print("WebSocket Error:", e)


# @router.get("/all_future_live_prices", tags=['India Futures'])
# async def all_future_live_prices_page(expiry: str = None):
#     html = f"""
#     <html>
#     <head>
#         <title>Future Live Prices</title>
#         <style>
#             table {{
#                 border-collapse: collapse;
#                 width: 80%;
#                 margin: auto;
#             }}
#             th, td {{
#                 border: 1px solid #999;
#                 padding: 8px;
#                 text-align: center;
#             }}
#             th {{
#                 background-color: #f2f2f2;
#             }}
#             .positive {{
#                 color: green;
#                 font-weight: bold;
#             }}
#             .negative {{
#                 color: red;
#                 font-weight: bold;
#             }}
#         </style>
#     </head>
#     <body>
#         <h2 style="text-align: center;">Live Prices of Futures</h2>
#         <div style="text-align:center;"><strong>Total Stocks:</strong> <span id="total-stocks">Loading...</span></div>
#         <div style="text-align:center;"><strong>Page No:</strong> <span id="page-no">Loading...</span></div>
#         <br>
#         <table>
#             <thead>
#                 <tr>
#                     <th>Stock Id</th>
#                     <th>Stock</th>
#                     <th>Expiry Date</th>
#                     <th>Price</th>
#                     <th>Previous Close</th>
#                     <th>Day Change</th>
#                     <th>Day Change %</th>
#                     <th>Watchlist Id</th>
#                 </tr>
#             </thead>
#             <tbody id="data">
#                 <tr><td colspan="8">Waiting for data...</td></tr>
#             </tbody>
#         </table>

#         <script>
#             const expiry = "{expiry}";
#             const ws = new WebSocket(`ws://192.168.1.16:7000/ws/all_future_live_prices?expiry={expiry}`);

#             ws.onmessage = function(event) {{
#                 let response = JSON.parse(event.data);
#                 let data = response.stocks;
#                 let totalStocks = response.total_stocks;
#                 let pageNo = response.page_no;

#                 document.getElementById("total-stocks").textContent = totalStocks;
#                 document.getElementById("page-no").textContent = pageNo;

#                 let body = document.getElementById("data");
#                 body.innerHTML = "";

#                 for (let row of data) {{
#                     let changeClass = row.day_change.startsWith("+") ? "positive" : "negative";

#                     body.innerHTML += `<tr>
#                         <td>${{row.id}}</td>
#                         <td>${{row.symbol}}</td>
#                         <td>${{row.expiry_date}}</td>
#                         <td>${{row.price}}</td>
#                         <td>${{row.prev_close}}</td>
#                         <td class="${{changeClass}}">${{row.day_change}}</td>
#                         <td class="${{changeClass}}">${{row.day_change_percentage}}</td>
#                         <td>${{row.watchlist_id}}</td>
#                     </tr>`;
#                 }}
#             }};

#             ws.onerror = function(event) {{
#                 console.error("WebSocket error:", event);
#             }};

#             ws.onclose = function() {{
#                 console.log("WebSocket closed");
#             }};
#         </script>
#     </body>
#     </html>
#     """
#     return HTMLResponse(html)


# @router.websocket("/ws/future_live_price")
# async def future_live_price(websocket: WebSocket, symbol: str, expiry_date: str):
#     await websocket.accept()
#     try:
#         while True:      
#             stocks = []
#             # stocks = db.raw_query(f"""select fm.id, fm.symbol, fm.exchange, fm.expiry_date
#             #                     from futures_master fm            
#             #                     order by fm.symbol""")
            
#             session = db.get_session()

#             stocks = session.query(FuturesMaster).filter(FuturesMaster.symbol == symbol.upper(), FuturesMaster.expiry_date == expiry_date).all()
#             session.close()
                

#             #print(stocks)    
#             if stocks != None and len(stocks) > 0:
#                 # print(stocks)
#                 #print("before fyers connection")

#                 data = await fpf.get_stock_price_from_fyers(stocks)
#                 # print(datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"), "Printing data")
#                 #print("data------------", data)
#             else:
#                 data = []
#                 #print("data------------", data)
#             # db.close_engine()
#             #logger.info("data------------", data)
#             if data:
#                 # print(datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"), "Sending data to WebSocket")
#                 await websocket.send_json({"data": data})
#             else:
#                 await websocket.send_text("Error fetching stock price")
#             await asyncio.sleep(5)
#     except WebSocketDisconnect as ex:
#         #logger.exception(ex, exc_info=True, stack_info=True)
#         print("WebSocket Error: Client disconnected from price WebSocket")
#     except asyncio.CancelledError:
#         return
#     except Exception as e:
#         logger.exception(e, exc_info=True, stack_info=True)
#         print("WebSocket Error:", e)


@router.get("/calculate_all_zones_future_and_commodity")
async def calculate_all_zones(tick: str, time_frame: int, last_d_time: str, exp_dt: str, is_future: bool, request: Request):
    apiresponce = APIResponse(request)
    try:
        data = {}
        last_d_time = datetime.strptime(last_d_time, "%Y-%m-%d %H:%M:%S")
        
        numbers = re.findall(r'\d+', exp_dt)
        exp_num = ''.join(numbers)
        
        if is_future:
            time_list = getattr(slcfg, f"FUTURE_TIME_FRAME_{time_frame}")
            country_dir = sddcfg.indian_stock_future_data_dir
        else:
            time_list = getattr(slcfg, f"COMMODITY_TIME_FRAME_{time_frame}")
            country_dir = sddcfg.indian_commodity_data
        # if time_frame == 2:
        #     time_list = getattr(cfg, f'TIME_FRAME_EXE_{time_frame}')
        # with ProcessPoolExecutor(max_workers=4) as executor:
        for t_frame in time_list:
            file_name = f"{country_dir}/latest_data_csv/{tick}_{exp_num}_{t_frame}.csv"
            
            if t_frame == time_list[0]:
                tf = TF.E
            elif t_frame == time_list[1]:
                tf = TF.A
            else:
                tf = TF.X
            resp = processs_all_zones(file_name, tf, last_d_time)
            data[t_frame] = resp
                # print(t_frame, sell_data)
                # data[t_frame]['Sell'] = 
        
        apiresponce.setMsg("success")
        apiresponce.setResponse(data)
    except Exception as ex:
        logger.exception(ex)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce