from fastapi import APIRouter, Request, Depends, HTTPException
from shared.db.req_model import TokenPayload
from shared.db.api_responce import APIResponse
from shared.db.dbconn import DBConnection
from shared.utils.logger import logger
from shared.db.db_model import UserDeviceToken
import pytz
from datetime import datetime

router = APIRouter()
timezone = pytz.timezone("Asia/Kolkata")

@router.post("/save_device_fcm_token", tags=['ALERT DEVICE TOKEN'])
def save_device_fcm_token(request: Request, payload: TokenPayload, user_id: int):
    apiresponce = APIResponse(request)
    try:
        dbc = DBConnection()
        db = dbc.get_session()
        token_row = db.query(UserDeviceToken).filter_by(fcm_token = payload.token, user_id = user_id).first()
        if token_row:
            token_row.user_id  = user_id
            token_row.platform = payload.platform
            token_row.updated_at = datetime.now(tz=timezone)
        else:
            token_row = UserDeviceToken(
                user_id   = user_id,
                fcm_token = payload.token,
                platform  = payload.platform,
                created_at = datetime.now(tz=timezone)
            )
            db.add(token_row)
        db.commit()
        apiresponce.setMsg("success")
        apiresponce.setResponse({"detail": "Token stored/updated"}) 
    except Exception as ex:
        logger.error(ex, stack_info=True)
        apiresponce.setMsg("failed")
        apiresponce.setResponse(str(ex))
    return apiresponce