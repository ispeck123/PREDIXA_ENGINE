from typing import Optional
from pydantic import BaseModel
import time
from fastapi import status, Request, Response

class Api_Response():
    def __init__(self,endpoint,timeSpent,msg,response):
        self.endpoint =endpoint
        self.timeSpent =timeSpent
        self.msg=msg
        self.response= response


class APIResponse():
    def __init__(self,request:Request):
        self.endpoint = request.url.path
        self.starttime=time.time()
        self.timeSpent = None
        self.msg = None
        self.response = None

    def _setTimeSpent(self):
        self.timeSpent =time.time() - self.starttime

    def setMsg(self,msg:str):
        self.msg =msg

    def setHeaderStatus(self,response:Response, code=None):
        if code == 400:
            response.status_code = status.HTTP_400_BAD_REQUEST
        if code == 404:
            response.status_code = status.HTTP_404_NOT_FOUND

    def setResponse(self,response:dict):
        self._setTimeSpent()
        self.response =response

    def to_json(self,):
        try:
            del self.__dict__['starttime']
        except:
            pass
        return self.__dict__