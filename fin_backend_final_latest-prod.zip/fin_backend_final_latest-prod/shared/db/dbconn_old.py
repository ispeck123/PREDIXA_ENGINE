from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from shared.config.settings import DB_Config
from urllib.parse import quote as urlquote
import pandas as pd
import json
from sqlalchemy import text
from sqlalchemy.orm import sessionmaker, Session
import logging

# Init the Configuration
# config = Config()
logger = logging.getLogger()

class DBConnection:

    def __init__(self):
        # self.database = config.getDatabaseConfig()
        # Create a sqlite engine instance
        self.engine = create_engine(
            "mysql+pymysql://"+DB_Config.DB_USER+":"+urlquote(DB_Config.DB_PASSWORD)+"@"+DB_Config.DB_HOST+"/"+DB_Config.DB_SCHEMA,
            pool_recycle = 1800,
            pool_pre_ping = True
        )
        # Create a DeclarativeMeta instance
        self.Base = declarative_base()
        # Create the database
        self.Base.metadata.create_all(self.engine)
        # return self.engine

    def get_session(self):
        SessionLocal = Session(bind=self.engine)
        # sessionmaker(bind=engine)
        return SessionLocal

    def raw_connection(self):
        try:
            raw_connection = self.engine.connect()
            return raw_connection
        except Exception as ex:
            logger.exception(ex)
            return None

    def raw_query(self, my_query):
        try:
            with self.raw_connection() as rcc:
                data_list = pd.read_sql(my_query, rcc)
                results = json.loads(data_list.to_json(orient="table", index=False))["data"]
        except Exception as ex:
            logger.exception(ex)
            results = None
            # raise Exception(str(ex))
        return results

    def insert_update_query(self, my_query):
        try:
            with self.raw_connection() as conn:
                conn.execute(text(my_query))
                conn.commit()
                conn.close()
                return True
        except Exception as ex:
            logger.exception(ex)
            print("\nException while inserting/updating:\n", ex)
            # raise Exception(str(ex))
            return False

    def close_engine(self):
        try:
            self.engine.dispose()
            return True
        except Exception as ex:
            logger.exception(ex)
            return False