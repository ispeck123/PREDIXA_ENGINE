# db_connection.py

import json
import pandas as pd
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import QueuePool
from shared.config.settings import DB_Config
from threading import Lock
from urllib.parse import quote as urlquote

# from your project config
# import DB_Config
import logging

logger = logging.getLogger(__name__)

class _Singleton(type):
    """Thread-safe Singleton metaclass."""
    _instances = {}
    _lock = Lock()

    def __call__(cls, *args, **kwargs):
        with cls._lock:
            if cls not in cls._instances:
                cls._instances[cls] = super().__call__(*args, **kwargs)
        return cls._instances[cls]

class DBConnection(metaclass=_Singleton):
    """
    One engine + one session factory shared across all importers of this class.
    Uses SQLAlchemy connection pooling to avoid 'Too many connections'.
    """
    def __init__(self):
        # Guard against re-init if someone calls DBConnection() again
        if hasattr(self, "_initialized") and self._initialized:
            return

        dsn = (
            "mysql+pymysql://"
            f"{DB_Config.DB_USER}:{urlquote(DB_Config.DB_PASSWORD)}"
            f"@{DB_Config.DB_HOST}/{DB_Config.DB_SCHEMA}"
        )

        # Build a single Engine with a bounded pool
        # Tune pool_size / max_overflow to your workload & MySQL max_connections
        self.engine = create_engine(
            dsn,
            poolclass=QueuePool,
            pool_size=10,          # typical default; raise if you have many concurrent requests
            max_overflow=20,       # temporary extra connections beyond pool_size
            pool_timeout=30,       # seconds to wait for a connection before raising
            pool_recycle=1800,     # avoid MySQL 'gone away'
            pool_pre_ping=True,    # validate connections from the pool
            pool_reset_on_return="rollback",  # keep connections clean
            future=True,           # SQLAlchemy 2.0 style
        )

        # One global session factory bound to this engine
        self.SessionLocal = sessionmaker(
            bind=self.engine,
            autoflush=False,
            autocommit=False,
            expire_on_commit=False,
            class_=Session,
            future=True,
        )

        # IMPORTANT: Don't call Base.metadata.create_all() here.
        # Run migrations (Alembic) separately to manage schema.

        self._initialized = True

    # ---------- Public API (kept compatible) ----------

    def get_session(self) -> Session:
        """Return a new SQLAlchemy session from the shared session factory."""
        return self.SessionLocal()

    def raw_connection(self):
        """
        Return a pooled Connection.
        Prefer using context managers: `with db.raw_connection() as conn: ...`
        """
        try:
            return self.engine.connect()
        except Exception as ex:
            # logger.exception(ex)
            return None

    # def raw_query(self, my_query: str):
    #     """
    #     Run a SELECT and return list[dict].
    #     Uses pooled connection; no separate engine created.
    #     """
    #     try:
    #         with self.engine.connect() as conn:
    #             # Ensure textual SQL is wrapped in text()
    #             df = pd.read_sql_query(text(my_query), conn)
    #             return json.loads(df.to_json(orient="table", index=False))["data"]
    #     except Exception as ex:
    #         # logger.exception(ex)
    #         return None
    def raw_query(self, my_query):
        try:
            with self.raw_connection() as rcc:
                data_list = pd.read_sql(my_query, rcc)
                results = json.loads(data_list.to_json(orient="table", index=False))["data"]
        except Exception as ex:
            logger.exception(ex)
            results = None
            # raise Exception(str(ex))
        return results

    def insert_update_query(self, my_query: str) -> bool:
        """
        Execute INSERT/UPDATE/DELETE inside a pooled transactional context.
        """
        try:
            # engine.begin() manages BEGIN/COMMIT and returns a Connection
            with self.engine.begin() as conn:
                conn.execute(text(my_query))
            return True
        except Exception as ex:
            # logger.exception(ex)
            # print("\nException while inserting/updating:\n", ex)
            return False

    def close_engine(self) -> bool:
        """
        Dispose the shared engine & pool. Typically call this only on shutdown.
        """
        try:
            self.engine.dispose()
            return True
        except Exception as ex:
            # logger.exception(ex)
            return False
