"""Analytics packages.  The analytics layer is intentionally separate from live trading."""
