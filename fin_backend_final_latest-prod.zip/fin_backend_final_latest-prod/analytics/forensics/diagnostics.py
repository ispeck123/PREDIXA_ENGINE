"""Read-only identifier diagnostics for the live schema.

Run with ``python -m analytics.forensics.diagnostics``.  Every statement is a
SELECT; this command never creates analytical tables and never writes trading
data.
"""

from __future__ import annotations

import json
from urllib.parse import quote

from sqlalchemy import create_engine, text

from shared.config.settings import Config


DIAGNOSTIC_QUERIES = {
    "order_to_trade_signal": """SELECT COUNT(*) total, SUM(ts.id IS NOT NULL) matched, SUM(ts.id IS NULL) unmatched, COUNT(o.order_id)-COUNT(DISTINCT o.order_id) duplicate_rows FROM order_master o LEFT JOIN trade_signals ts ON ts.id=o.trade_signal_id""",
    "order_to_oms_bucket_by_order": """SELECT COUNT(*) total, SUM(b.bucket_id IS NOT NULL) matched, SUM(b.bucket_id IS NULL) unmatched, COUNT(o.order_id)-COUNT(DISTINCT o.order_id) duplicate_rows FROM order_master o LEFT JOIN oms_order_bucket b ON b.order_id=o.order_id""",
    "order_to_oms_bucket_by_signal": """SELECT COUNT(*) total, SUM(b.bucket_id IS NOT NULL) matched, SUM(b.bucket_id IS NULL) unmatched, COUNT(o.order_id)-COUNT(DISTINCT o.order_id) duplicate_rows FROM order_master o LEFT JOIN oms_order_bucket b ON b.trade_signal_id=o.trade_signal_id""",
    "bucket_to_oms_orders_by_bucket_id": """SELECT COUNT(*) total, SUM(x.pk IS NOT NULL) matched, SUM(x.pk IS NULL) unmatched, COUNT(b.bucket_id)-COUNT(DISTINCT b.bucket_id) duplicate_rows FROM oms_order_bucket b LEFT JOIN oms_orders x ON x.bucket_id=b.bucket_id""",
    "oms_orders_to_events": """SELECT COUNT(*) total, SUM(e.pk IS NOT NULL) matched, SUM(e.pk IS NULL) unmatched, COUNT(x.pk)-COUNT(DISTINCT x.pk) duplicate_rows FROM oms_orders x LEFT JOIN oms_order_events e ON e.internal_order_id=x.internal_order_id""",
}


def run_diagnostics(engine) -> dict[str, dict]:
    with engine.connect() as connection:
        return {name: dict(connection.execute(text(query)).mappings().one()) for name, query in DIAGNOSTIC_QUERIES.items()}


def main() -> int:
    url = f"mysql+pymysql://{Config.DB_USER}:{quote(Config.DB_PASSWORD or '')}@{Config.DB_HOST}:{Config.DB_PORT}/{Config.DB_SCHEMA}"
    engine = create_engine(url, pool_pre_ping=True, connect_args={"connect_timeout": 8})
    print(json.dumps(run_diagnostics(engine), indent=2, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
