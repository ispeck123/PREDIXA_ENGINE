"""Typed, serialisable shapes for forensic evidence."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Optional


@dataclass(frozen=True)
class LinkResult:
    status: str
    count: int = 0
    duplicate_count: int = 0
    null_count: int = 0
    rows: tuple[dict[str, Any], ...] = ()
    reason: Optional[str] = None


@dataclass
class OrderBundle:
    order: Optional[dict[str, Any]] = None
    trade_signal: Optional[dict[str, Any]] = None
    oms_bucket: Optional[dict[str, Any]] = None
    oms_orders: list[dict[str, Any]] = field(default_factory=list)
    oms_events: list[dict[str, Any]] = field(default_factory=list)
    links: dict[str, LinkResult] = field(default_factory=dict)


@dataclass(frozen=True)
class ParsedOrderStatus:
    status: Optional[str]
    reason: Optional[str] = None
    profit_amount: Optional[float] = None
    profit_pct: Optional[float] = None
    loss_amount: Optional[float] = None
    loss_pct: Optional[float] = None
    completed_on: Optional[str] = None
    raw: Any = None
    parse_error: Optional[str] = None


@dataclass(frozen=True)
class CandleWindow:
    name: str
    start: Optional[str]
    end: Optional[str]
    rows: tuple[dict[str, Any], ...]
    source_files: tuple[str, ...]
    warnings: tuple[str, ...] = ()

