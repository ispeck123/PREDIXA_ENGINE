"""Deterministic Phase 2 technical features.

This module operates only on already-cutoff OHLCV windows. It never fetches
data and never inspects candles outside the supplied window.
"""

from __future__ import annotations

from typing import Any, Optional

import numpy as np
import pandas as pd

from .feature_utils import planned_rr


def _number(value: Any) -> Optional[float]:
    try:
        return None if value is None or pd.isna(value) else float(value)
    except (TypeError, ValueError):
        return None


def _clean_frame(rows: list[dict[str, Any]] | tuple[dict[str, Any], ...]) -> pd.DataFrame:
    frame = pd.DataFrame(list(rows or []))
    if frame.empty:
        return frame
    for column in ("open", "high", "low", "close", "volume", "qty", "vol", "Volume"):
        if column in frame.columns:
            frame[column] = pd.to_numeric(frame[column], errors="coerce")
    for source, target in (("qty", "volume"), ("vol", "volume"), ("Volume", "volume")):
        if target not in frame.columns and source in frame.columns:
            frame[target] = frame[source]
    if not all(column in frame.columns for column in ("high", "low", "close")):
        return pd.DataFrame()
    return frame.dropna(subset=["high", "low", "close"]).reset_index(drop=True)


def _last(series: pd.Series) -> Optional[float]:
    if series.empty or pd.isna(series.iloc[-1]):
        return None
    return float(series.iloc[-1])


def _prior_last(series: pd.Series, periods: int) -> Optional[float]:
    if len(series) <= periods or pd.isna(series.iloc[-1]) or pd.isna(series.iloc[-1 - periods]):
        return None
    return float(series.iloc[-1 - periods])


def _ema(close: pd.Series, period: int) -> pd.Series:
    return close.ewm(span=period, adjust=False, min_periods=1).mean()


def _atr(frame: pd.DataFrame, period: int = 14) -> pd.Series:
    previous_close = frame["close"].shift(1)
    true_range = pd.concat(
        [frame["high"] - frame["low"], (frame["high"] - previous_close).abs(), (frame["low"] - previous_close).abs()],
        axis=1,
    ).max(axis=1)
    return true_range.ewm(alpha=1 / period, adjust=False, min_periods=1).mean()


def _rsi(close: pd.Series, period: int = 14) -> pd.Series:
    delta = close.diff()
    gains = delta.clip(lower=0).ewm(alpha=1 / period, adjust=False, min_periods=period).mean()
    losses = (-delta.clip(upper=0)).ewm(alpha=1 / period, adjust=False, min_periods=period).mean()
    relative_strength = gains / losses.replace(0, np.nan)
    result = 100 - (100 / (1 + relative_strength))
    return result.where(losses.ne(0), 100.0)


def _slope(series: pd.Series, lookback: int = 5) -> Optional[float]:
    current, previous = _last(series), _prior_last(series, lookback)
    return None if current is None or previous is None else current - previous


def _nearest_levels(frame: pd.DataFrame, price: float, lookback: int = 50) -> dict[str, Optional[float]]:
    history = frame.iloc[:-1].tail(lookback)
    if history.empty:
        return {"nearest_support": None, "nearest_resistance": None}
    supports = history.loc[history["low"] <= price, "low"]
    resistances = history.loc[history["high"] >= price, "high"]
    support = supports.max() if not supports.empty else history["low"].min()
    resistance = resistances.min() if not resistances.empty else history["high"].max()
    return {"nearest_support": _number(support), "nearest_resistance": _number(resistance)}


def _structure(frame: pd.DataFrame, lookback: int = 5) -> dict[str, Optional[str]]:
    if len(frame) < lookback * 2:
        return {"structure": None}
    recent, prior = frame.tail(lookback), frame.iloc[-2 * lookback : -lookback]
    if recent["high"].max() > prior["high"].max() and recent["low"].min() > prior["low"].min():
        return {"structure": "HIGHER_HIGH_HIGHER_LOW"}
    if recent["high"].max() < prior["high"].max() and recent["low"].min() < prior["low"].min():
        return {"structure": "LOWER_HIGH_LOWER_LOW"}
    return {"structure": "MIXED_OR_SIDEWAYS"}


def _setup_indicators(rows: list[dict[str, Any]] | tuple[dict[str, Any], ...]) -> dict[str, Any]:
    frame = _clean_frame(rows)
    if frame.empty:
        return {"status": "UNAVAILABLE", "reason": "insufficient OHLC columns or rows", "candle_count": 0}
    close = frame["close"]
    ema20, ema50, ema200 = _ema(close, 20), _ema(close, 50), _ema(close, 200)
    atr, rsi = _atr(frame), _rsi(close)
    macd, macd_signal = _ema(close, 12) - _ema(close, 26), None
    macd_signal = _ema(macd, 9)
    roc = close.pct_change(10) * 100
    returns = np.log(close / close.shift(1)).replace([np.inf, -np.inf], np.nan)
    rolling_vol = returns.rolling(20, min_periods=2).std() * 100
    average_volume = current_volume = volume_ratio = None
    if "volume" in frame.columns:
        average_volume = frame["volume"].rolling(20, min_periods=1).mean().iloc[-1]
        current_volume = frame["volume"].iloc[-1]
        if pd.notna(average_volume) and average_volume:
            volume_ratio = float(current_volume / average_volume)
    price, atr_value = float(close.iloc[-1]), _last(atr)
    output = {
        "status": "AVAILABLE", "candle_count": int(len(frame)),
        "close": price, "ema20": _last(ema20), "ema50": _last(ema50),
        "ema200": _last(ema200) if len(frame) >= 200 else None,
        "ema20_slope_5": _slope(ema20, 5), "ema50_slope_5": _slope(ema50, 5),
        "price_vs_ema20": "ABOVE" if price > ema20.iloc[-1] else "BELOW" if price < ema20.iloc[-1] else "AT",
        "price_vs_ema50": "ABOVE" if price > ema50.iloc[-1] else "BELOW" if price < ema50.iloc[-1] else "AT",
        "rsi14": _last(rsi), "macd": _last(macd), "macd_signal": _last(macd_signal),
        "macd_histogram": (_last(macd) - _last(macd_signal)) if _last(macd) is not None and _last(macd_signal) is not None else None,
        "roc10_pct": _last(roc), "atr14": atr_value,
        "normalized_atr_pct": atr_value / price * 100 if atr_value and price else None,
        "rolling_volatility20_pct": _last(rolling_vol),
        "current_volume": _number(current_volume), "average_volume20": _number(average_volume), "volume_ratio20": volume_ratio,
        **_nearest_levels(frame, price), **_structure(frame),
    }
    return output


def _trade_geometry(order: dict[str, Any], setup: dict[str, Any]) -> dict[str, Any]:
    entry, stop, target = _number(order.get("entry_price")), _number(order.get("stoploss_price")), _number(order.get("target_price"))
    atr = _number(setup.get("atr14"))
    risk = abs(entry - stop) if entry is not None and stop is not None else None
    reward = abs(target - entry) if entry is not None and target is not None else None
    return {
        "entry": entry, "stop": stop, "target": target, "risk": risk, "reward": reward,
        "planned_rr": planned_rr(order.get("order_type"), entry, stop, target),
        "stop_distance_pct": risk / abs(entry) * 100 if risk is not None and entry else None,
        "target_distance_pct": reward / abs(entry) * 100 if reward is not None and entry else None,
        "stop_distance_atr": risk / atr if risk is not None and atr else None,
        "target_distance_atr": reward / atr if reward is not None and atr else None,
        "distance_to_support": abs(entry - setup["nearest_support"]) if entry is not None and setup.get("nearest_support") is not None else None,
        "distance_to_resistance": abs(setup["nearest_resistance"] - entry) if entry is not None and setup.get("nearest_resistance") is not None else None,
    }


def _excursions(order: dict[str, Any], active_rows: list[dict[str, Any]] | tuple[dict[str, Any], ...]) -> dict[str, Any]:
    frame = _clean_frame(active_rows)
    entry, stop, target = _number(order.get("entry_price")), _number(order.get("stoploss_price")), _number(order.get("target_price"))
    direction = str(order.get("order_type") or "").upper()
    risk = abs(entry - stop) if entry is not None and stop is not None else None
    if frame.empty or entry is None or direction not in {"BUY", "SELL"}:
        return {"status": "UNAVAILABLE", "candle_count": int(len(frame)), "reason": "missing active candles, entry, or direction"}
    favorable = (frame["high"] - entry if direction == "BUY" else entry - frame["low"]).clip(lower=0)
    adverse = (entry - frame["low"] if direction == "BUY" else frame["high"] - entry).clip(lower=0)
    mfe, mae = float(favorable.max()), float(adverse.max())
    target_distance = abs(target - entry) if target is not None else None
    stop_distance = abs(stop - entry) if stop is not None else None
    return {
        "status": "AVAILABLE", "candle_count": int(len(frame)), "mfe": mfe, "mae": mae,
        "mfe_r": mfe / risk if risk else None, "mae_r": mae / risk if risk else None,
        "progress_to_target_pct": mfe / target_distance * 100 if target_distance else None,
        "progress_to_stop_pct": mae / stop_distance * 100 if stop_distance else None,
        "candles_until_mfe": int(favorable.argmax()) + 1, "candles_until_mae": int(adverse.argmax()) + 1,
        "profitable_before_exit": bool((favorable > 0).any()),
        "target_almost_reached": bool(target_distance and mfe >= target_distance * 0.9),
    }


def build_technical_features(order: dict[str, Any], ohlc: dict[str, Any]) -> dict[str, Any]:
    frames: dict[str, Any] = {}
    for frame_name, windows in (ohlc.get("frames") or {}).items():
        setup = _setup_indicators((windows.get("pre_setup") or {}).get("rows") or [])
        geometry = _trade_geometry(order, setup)
        excursions = _excursions(order, (windows.get("active_trade") or {}).get("rows") or [])
        frames[frame_name] = {"setup": setup, "trade_geometry": geometry, "excursions": excursions}
    return {
        "method": "EMA/ATR/RSI/MACD/ROC/rolling-volume/rolling-log-return-volatility; excursions from active candles",
        "look_ahead_policy": "setup features use only pre_setup rows; excursions use active_trade rows",
        "frames": frames,
    }
