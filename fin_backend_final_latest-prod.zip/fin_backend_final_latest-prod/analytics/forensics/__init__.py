"""Read-only post-trade forensic evidence collection."""

METHODOLOGY_VERSION = "phase2-technical-v1"

__all__ = ["METHODOLOGY_VERSION"]
