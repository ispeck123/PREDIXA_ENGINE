"""Small deterministic utilities shared by the Phase 1 evidence builder."""

from __future__ import annotations

import ast
import json
import re
from datetime import datetime
from typing import Any, Iterable, Optional

from .schemas import ParsedOrderStatus


_TIMESTAMP_RE = re.compile(r"Timestamp\((['\"])(.*?)\1\)")


def parse_datetime(value: Any) -> Optional[datetime]:
    if value is None or value == "":
        return None
    if isinstance(value, datetime):
        return value
    text = str(value).strip()
    text = text.replace("Z", "+00:00")
    for candidate in (text, text.replace("T", " ")):
        try:
            return datetime.fromisoformat(candidate)
        except ValueError:
            pass
    for fmt in ("%d/%m/%Y %H:%M:%S", "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M"):
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            pass
    return None


def iso_datetime(value: Any) -> Optional[str]:
    parsed = parse_datetime(value)
    return parsed.isoformat(sep=" ") if parsed else (str(value) if value else None)


def _safe_status_object(value: Any) -> tuple[Any, Optional[str]]:
    if value is None:
        return None, None
    if isinstance(value, dict):
        return value, None
    if not isinstance(value, str):
        return None, f"unsupported order_status type: {type(value).__name__}"
    text = value.strip()
    if not text:
        return None, None
    # Existing rows may contain pandas Timestamp('...') wrappers.  This is
    # normalization only; evaluation remains ast.literal_eval, never eval().
    normalized = _TIMESTAMP_RE.sub(lambda m: repr(m.group(2)), text)
    try:
        return ast.literal_eval(normalized), None
    except (ValueError, SyntaxError, MemoryError, RecursionError) as exc:
        try:
            return json.loads(text), None
        except (TypeError, ValueError, json.JSONDecodeError):
            return None, f"order_status parse failed: {exc}"


def _number(value: Any) -> Optional[float]:
    try:
        return None if value is None else float(value)
    except (TypeError, ValueError):
        return None


def parse_order_status(value: Any) -> ParsedOrderStatus:
    obj, error = _safe_status_object(value)
    if error:
        return ParsedOrderStatus(status=None, raw=value, parse_error=error)
    if obj is None:
        return ParsedOrderStatus(status=None, raw=value)
    if not isinstance(obj, dict):
        return ParsedOrderStatus(status=None, raw=value, parse_error="parsed order_status is not a mapping")
    status = obj.get("status")
    return ParsedOrderStatus(
        status=str(status).lower() if status is not None else None,
        reason=obj.get("reason"),
        profit_amount=_number(obj.get("profit_amount")),
        profit_pct=_number(obj.get("profit_pct")),
        loss_amount=_number(obj.get("loss_amount")),
        loss_pct=_number(obj.get("loss_pct")),
        completed_on=iso_datetime(obj.get("completed_on")),
        raw=obj,
    )


def planned_rr(direction: Any, entry: Any, stop: Any, target: Any) -> Optional[float]:
    try:
        entry_f, stop_f, target_f = float(entry), float(stop), float(target)
        risk = abs(entry_f - stop_f)
        reward = abs(target_f - entry_f)
        return reward / risk if risk else None
    except (TypeError, ValueError):
        return None


def row_to_dict(row: Any) -> dict[str, Any]:
    if hasattr(row, "_mapping"):
        row = row._mapping
    return {str(k): v for k, v in dict(row).items()}


def status_matches(value: Any, wanted: str) -> bool:
    parsed = parse_order_status(value)
    return (parsed.status or "pending") == wanted.lower()
