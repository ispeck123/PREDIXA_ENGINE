"""Analytical tables for Phase 1.

This module declares tables only.  It never calls create_all and never alters
the live trading schema.
"""

from datetime import datetime

from sqlalchemy import (
    DateTime,
    ForeignKey,
    Index,
    Integer,
    JSON,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class ForensicsBase(DeclarativeBase):
    pass


class TradeForensicRun(ForensicsBase):
    __tablename__ = "trade_forensic_run"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    run_key: Mapped[str] = mapped_column(String(128), nullable=False, unique=True)
    status: Mapped[str] = mapped_column(String(32), nullable=False)
    methodology_version: Mapped[str] = mapped_column(String(64), nullable=False)
    requested_order_ids: Mapped[list] = mapped_column(JSON, nullable=False)
    requested_status: Mapped[str | None] = mapped_column(String(32))
    requested_limit: Mapped[int | None] = mapped_column(Integer)
    started_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, server_default=func.now())
    completed_at: Mapped[datetime | None] = mapped_column(DateTime)
    error_json: Mapped[dict | None] = mapped_column(JSON)

    records: Mapped[list["TradeForensicRecord"]] = relationship(back_populates="run")


class TradeForensicRecord(ForensicsBase):
    __tablename__ = "trade_forensic_record"
    __table_args__ = (
        UniqueConstraint("run_id", "order_id", name="uq_trade_forensic_run_order"),
        Index("ix_trade_forensic_record_order", "order_id"),
        Index("ix_trade_forensic_record_status", "result_status"),
        Index("ix_trade_forensic_record_symbol", "symbol"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    run_id: Mapped[int] = mapped_column(ForeignKey("trade_forensic_run.id"), nullable=False)
    order_id: Mapped[int] = mapped_column(Integer, nullable=False)
    trade_signal_id: Mapped[int | None] = mapped_column(Integer)
    symbol: Mapped[str | None] = mapped_column(String(200))
    direction: Mapped[str | None] = mapped_column(String(16))
    timeframe: Mapped[int | None] = mapped_column(Integer)
    setup_timestamp: Mapped[datetime | None] = mapped_column(DateTime)
    entry_timestamp: Mapped[datetime | None] = mapped_column(DateTime)
    exit_timestamp: Mapped[datetime | None] = mapped_column(DateTime)
    planned_entry: Mapped[str | None] = mapped_column(String(64))
    planned_stop: Mapped[str | None] = mapped_column(String(64))
    planned_target: Mapped[str | None] = mapped_column(String(64))
    planned_rr: Mapped[str | None] = mapped_column(String(64))
    result_status: Mapped[str | None] = mapped_column(String(32))
    setup_evidence_json: Mapped[dict] = mapped_column(JSON, nullable=False)
    execution_evidence_json: Mapped[dict] = mapped_column(JSON, nullable=False)
    data_quality_json: Mapped[dict] = mapped_column(JSON, nullable=False)
    market_cutoff_timestamp: Mapped[datetime | None] = mapped_column(DateTime)
    methodology_version: Mapped[str] = mapped_column(String(64), nullable=False)
    data_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, server_default=func.now(), onupdate=func.now())

    run: Mapped[TradeForensicRun] = relationship(back_populates="records")
    features: Mapped[list["TradeForensicFeature"]] = relationship(back_populates="record")
    execution_evidence: Mapped[list["TradeExecutionEvidence"]] = relationship(back_populates="record")


class TradeExecutionEvidence(ForensicsBase):
    __tablename__ = "trade_execution_evidence"
    __table_args__ = (Index("ix_trade_execution_evidence_record", "forensic_record_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    forensic_record_id: Mapped[int] = mapped_column(ForeignKey("trade_forensic_record.id"), nullable=False)
    availability_status: Mapped[str] = mapped_column(String(32), nullable=False)
    evidence_json: Mapped[dict] = mapped_column(JSON, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, server_default=func.now())

    record: Mapped[TradeForensicRecord] = relationship(back_populates="execution_evidence")


class TradeForensicFeature(ForensicsBase):
    __tablename__ = "trade_forensic_feature"
    __table_args__ = (
        UniqueConstraint("forensic_record_id", "feature_name", name="uq_trade_forensic_feature"),
        Index("ix_trade_forensic_feature_record", "forensic_record_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    forensic_record_id: Mapped[int] = mapped_column(ForeignKey("trade_forensic_record.id"), nullable=False)
    feature_name: Mapped[str] = mapped_column(String(128), nullable=False)
    feature_json: Mapped[dict] = mapped_column(JSON, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, server_default=func.now())

    record: Mapped[TradeForensicRecord] = relationship(back_populates="features")
