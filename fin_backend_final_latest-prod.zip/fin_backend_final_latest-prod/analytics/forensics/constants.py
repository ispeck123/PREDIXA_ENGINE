"""Stable names used by Phase 1 forensic evidence."""

from enum import Enum


class Availability(str, Enum):
    AVAILABLE = "AVAILABLE"
    MISSING = "MISSING"
    UNLINKED = "UNLINKED"
    AMBIGUOUS = "AMBIGUOUS"


class WindowName(str, Enum):
    PRE_SETUP = "pre_setup"
    ACTIVE_TRADE = "active_trade"
    POST_TRADE = "post_trade"


DATA_QUALITY_FLAGS = {
    "SETUP_SIGNAL_MISSING",
    "BROKER_FILL_UNVERIFIED",
    "ENTRY_TIMESTAMP_INFERRED",
    "EXIT_TIMESTAMP_INFERRED",
    "OMS_LINK_MISSING",
    "OMS_LINK_AMBIGUOUS",
    "TRADE_SIGNAL_DELETED",
    "SETUP_SNAPSHOT_UNAVAILABLE",
    "INTRABAR_ORDER_AMBIGUOUS",
    "OHLC_DATA_MISSING",
}
