"""CLI for read-only Phase 1 forensic JSON generation."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from urllib.parse import quote

from sqlalchemy import create_engine

from shared.config.settings import Config

from . import METHODOLOGY_VERSION
from .evidence_builder import build_forensic_record
from .repository import ReadOnlyOrderRepository


def _engine():
    url = f"mysql+pymysql://{Config.DB_USER}:{quote(Config.DB_PASSWORD or '')}@{Config.DB_HOST}:{Config.DB_PORT}/{Config.DB_SCHEMA}"
    return create_engine(url, pool_pre_ping=True, connect_args={"connect_timeout": 8})


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Generate read-only Phase 1 forensic JSON")
    parser.add_argument("--order-ids", help="comma-separated explicit order IDs")
    parser.add_argument("--status", choices=["failed", "success", "pending"], help="filter parsed order_status")
    parser.add_argument("--limit", type=int)
    parser.add_argument("--output-dir", default="outputs/forensics_phase1")
    parser.add_argument("--data-root", default=None)
    args = parser.parse_args(argv)
    ids = [int(item.strip()) for item in args.order_ids.split(",") if item.strip()] if args.order_ids else None
    repo = ReadOnlyOrderRepository(_engine())
    selected = repo.list_order_ids(order_ids=ids, status=args.status, limit=args.limit)
    run_key = hashlib.sha256(json.dumps({"ids": selected, "status": args.status, "limit": args.limit, "methodology": METHODOLOGY_VERSION}, sort_keys=True).encode()).hexdigest()[:32]
    output_dir = Path(args.output_dir) / run_key
    output_dir.mkdir(parents=True, exist_ok=True)
    records = []
    for order_id in selected:
        record = build_forensic_record(repo.get_order_bundle(order_id), args.data_root)
        path = output_dir / f"order_{order_id}.json"
        path.write_text(json.dumps(record, indent=2, sort_keys=True, default=str) + "\n", encoding="utf-8")
        records.append({"order_id": order_id, "data_hash": record["data_hash"], "status": record["outcome"]["status"], "flags": record["data_quality"]["flags"]})
    manifest = {"run_key": run_key, "methodology_version": METHODOLOGY_VERSION, "order_ids": selected, "records": records, "read_only": True}
    (output_dir / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"output_dir": str(output_dir), "count": len(records), "read_only": True}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
