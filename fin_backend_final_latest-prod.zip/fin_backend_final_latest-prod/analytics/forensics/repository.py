"""Read-only repository for live order evidence.

All database statements in this module are SELECT statements.  The module
does not import the application's write helpers and does not expose a write
session.
"""

from __future__ import annotations

from typing import Any, Iterable, Optional

from sqlalchemy import Engine, text

from .constants import Availability
from .schemas import LinkResult, OrderBundle
from .feature_utils import row_to_dict


def _select_one(conn: Any, table: str, where: str, params: dict[str, Any]) -> Optional[dict[str, Any]]:
    row = conn.execute(text(f"SELECT * FROM `{table}` WHERE {where} LIMIT 1"), params).mappings().first()
    return dict(row) if row else None


def _select_many(conn: Any, table: str, where: str, params: dict[str, Any]) -> list[dict[str, Any]]:
    return [dict(row) for row in conn.execute(text(f"SELECT * FROM `{table}` WHERE {where}"), params).mappings()]


class ReadOnlyOrderRepository:
    def __init__(self, engine: Engine):
        self.engine = engine

    def get_order_bundle(self, order_id: int) -> OrderBundle:
        with self.engine.connect() as conn:
            order = _select_one(conn, "order_master", "order_id = :order_id", {"order_id": order_id})
            if not order:
                return OrderBundle()

            signal_id = order.get("trade_signal_id")
            trade_signal = None
            if signal_id is not None:
                trade_signal = _select_one(conn, "trade_signals", "id = :signal_id", {"signal_id": signal_id})

            bucket_by_order = _select_many(conn, "oms_order_bucket", "order_id = :order_id", {"order_id": order_id})
            bucket_by_signal = (
                _select_many(conn, "oms_order_bucket", "trade_signal_id = :signal_id", {"signal_id": signal_id})
                if signal_id is not None else []
            )
            bucket_rows = {row["bucket_id"]: row for row in bucket_by_order + bucket_by_signal if row.get("bucket_id") is not None}
            if len(bucket_rows) == 1:
                bucket = next(iter(bucket_rows.values()))
                bucket_status = Availability.AVAILABLE.value
            elif len(bucket_rows) == 0:
                bucket = None
                bucket_status = Availability.MISSING.value
            else:
                bucket = None
                bucket_status = Availability.AMBIGUOUS.value

            # The current live schema has no reliable universal OMS join.  Use
            # only exact bucket_id/Fyers identifier matches; do not guess from
            # similarly named internal IDs.
            oms_rows: list[dict[str, Any]] = []
            if bucket:
                predicates = ["bucket_id = :bucket_id"]
                params: dict[str, Any] = {"bucket_id": bucket.get("bucket_id")}
                if bucket.get("id_fyers"):
                    predicates.append("fyers_order_id = :id_fyers")
                    params["id_fyers"] = bucket["id_fyers"]
                if bucket.get("gtt_id"):
                    predicates.append("fyers_order_id = :gtt_id")
                    params["gtt_id"] = bucket["gtt_id"]
                oms_rows = [dict(r) for r in conn.execute(text("SELECT * FROM oms_orders WHERE " + " OR ".join(predicates)), params).mappings()]

            oms_status = Availability.AVAILABLE.value if len(oms_rows) == 1 else (
                Availability.AMBIGUOUS.value if len(oms_rows) > 1 else Availability.UNLINKED.value
            )

            event_rows: list[dict[str, Any]] = []
            if len(oms_rows) == 1:
                oms = oms_rows[0]
                predicates = ["internal_order_id = :internal_order_id"]
                params = {"internal_order_id": oms.get("internal_order_id")}
                if oms.get("fyers_order_id"):
                    predicates.append("fyers_order_id = :fyers_order_id")
                    params["fyers_order_id"] = oms["fyers_order_id"]
                event_rows = [dict(r) for r in conn.execute(text("SELECT * FROM oms_order_events WHERE " + " OR ".join(predicates)), params).mappings()]
            event_status = Availability.AVAILABLE.value if event_rows else Availability.MISSING.value

            return OrderBundle(
                order=order,
                trade_signal=trade_signal,
                oms_bucket=bucket,
                oms_orders=oms_rows,
                oms_events=event_rows,
                links={
                    "order_to_trade_signal": LinkResult(
                        Availability.AVAILABLE.value if trade_signal else Availability.MISSING.value,
                        count=1 if trade_signal else 0,
                        null_count=1 if signal_id is None else 0,
                    ),
                    "order_to_oms_bucket": LinkResult(bucket_status, count=1 if bucket else 0),
                    "bucket_to_oms_orders": LinkResult(oms_status, count=len(oms_rows)),
                    "oms_to_oms_events": LinkResult(event_status, count=len(event_rows)),
                },
            )

    def list_order_ids(self, *, order_ids: Optional[Iterable[int]] = None, status: Optional[str] = None, limit: Optional[int] = None) -> list[int]:
        with self.engine.connect() as conn:
            if order_ids:
                ids = sorted({int(x) for x in order_ids})
                placeholders = ",".join(f":id_{i}" for i in range(len(ids)))
                params = {f"id_{i}": value for i, value in enumerate(ids)}
                rows = conn.execute(text(f"SELECT order_id,order_status FROM order_master WHERE order_id IN ({placeholders}) ORDER BY order_id DESC"), params).mappings()
            else:
                rows = conn.execute(text("SELECT order_id,order_status FROM order_master ORDER BY order_id DESC" )).mappings()
            from .feature_utils import status_matches
            result = [int(row["order_id"]) for row in rows if not status or status_matches(row.get("order_status"), status)]
            return result[:limit] if limit else result

    def diagnostics(self) -> dict[str, Any]:
        """Return read-only counts for the verified candidate joins."""
        queries = {
            "order_to_trade_signal": """SELECT COUNT(*) total, SUM(ts.id IS NOT NULL) matched, SUM(ts.id IS NULL) unmatched, COUNT(o.order_id)-COUNT(DISTINCT o.order_id) duplicate_rows FROM order_master o LEFT JOIN trade_signals ts ON ts.id=o.trade_signal_id""",
            "order_to_oms_bucket_by_order": """SELECT COUNT(*) total, SUM(b.bucket_id IS NOT NULL) matched, SUM(b.bucket_id IS NULL) unmatched, COUNT(o.order_id)-COUNT(DISTINCT o.order_id) duplicate_rows FROM order_master o LEFT JOIN oms_order_bucket b ON b.order_id=o.order_id""",
            "order_to_oms_bucket_by_signal": """SELECT COUNT(*) total, SUM(b.bucket_id IS NOT NULL) matched, SUM(b.bucket_id IS NULL) unmatched, COUNT(o.order_id)-COUNT(DISTINCT o.order_id) duplicate_rows FROM order_master o LEFT JOIN oms_order_bucket b ON b.trade_signal_id=o.trade_signal_id""",
            "oms_orders_to_events": """SELECT COUNT(*) total, SUM(e.pk IS NOT NULL) matched, SUM(e.pk IS NULL) unmatched, COUNT(x.pk)-COUNT(DISTINCT x.pk) duplicate_rows FROM oms_orders x LEFT JOIN oms_order_events e ON e.internal_order_id=x.internal_order_id""",
        }
        with self.engine.connect() as conn:
            return {name: dict(conn.execute(text(query)).mappings().one()) for name, query in queries.items()}
