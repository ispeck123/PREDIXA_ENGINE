"""Build a deterministic, read-only Phase 1 forensic JSON record."""

from __future__ import annotations

import hashlib
import json
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

import pandas as pd

from shared.config.settings import Config, stock_data_dir_config

from . import METHODOLOGY_VERSION
from .constants import Availability
from .feature_utils import iso_datetime, parse_datetime, parse_order_status, planned_rr
from .schemas import CandleWindow, OrderBundle
from .technical_features import build_technical_features


def _json_value(value: Any) -> Any:
    if isinstance(value, (datetime, pd.Timestamp)):
        return value.isoformat()
    if hasattr(value, "item"):
        try:
            return value.item()
        except Exception:
            pass
    if pd.isna(value) if not isinstance(value, (dict, list, tuple)) else False:
        return None
    return value


def _read_candles(path: Path) -> tuple[pd.DataFrame, Optional[str]]:
    if not path.exists():
        return pd.DataFrame(), f"missing file: {path}"
    try:
        df = pd.read_csv(path)
    except Exception as exc:
        return pd.DataFrame(), f"unable to read {path}: {exc}"
    time_col = next((col for col in ("tradeDate", "timestamp", "time") if col in df.columns), None)
    if not time_col:
        return pd.DataFrame(), f"no timestamp column in {path}"
    # Prefer ISO parsing because the live files commonly use ISO-like values;
    # only then fall back to the application's legacy day-first formats.
    parsed = pd.to_datetime(df[time_col], errors="coerce", format="mixed")
    if parsed.isna().any():
        legacy = pd.to_datetime(df.loc[parsed.isna(), time_col], errors="coerce", dayfirst=True)
        parsed.loc[parsed.isna()] = legacy
    df = df.assign(_forensic_time=parsed).dropna(subset=["_forensic_time"]).copy()
    if df.empty:
        return df, f"no valid timestamps in {path}"
    return df.sort_values("_forensic_time"), None


def _window(df: pd.DataFrame, name: str, start: Optional[datetime], end: Optional[datetime], path: Path, warning: Optional[str]) -> dict[str, Any]:
    if df.empty or start is None and name != "pre_setup":
        return {"name": name, "start": iso_datetime(start), "end": iso_datetime(end), "rows": [], "source_files": [str(path)], "warnings": [warning] if warning else []}
    if name == "pre_setup":
        selected = df[df["_forensic_time"] <= start] if start is not None else df.iloc[0:0]
    elif name == "active_trade":
        selected = df[(df["_forensic_time"] >= start) & (df["_forensic_time"] <= end)] if start and end else df.iloc[0:0]
    else:
        selected = df[df["_forensic_time"] > end] if end else df.iloc[0:0]
    rows = []
    for row in selected.drop(columns=["_forensic_time"], errors="ignore").to_dict(orient="records"):
        rows.append({key: _json_value(value) for key, value in row.items()})
    return {"name": name, "start": iso_datetime(start), "end": iso_datetime(end), "rows": rows, "source_files": [str(path)], "warnings": [warning] if warning else []}


def build_ohlc_evidence(bundle: OrderBundle, data_root: Optional[str] = None) -> tuple[dict[str, Any], list[str]]:
    order = bundle.order or {}
    root = Path(data_root or stock_data_dir_config.indian_stock_data_dir)
    symbol = str(order.get("stock_tick") or "").lower()
    timeframe = order.get("time_frame")
    frames = getattr(Config, f"TIME_FRAMES_{timeframe}", []) if timeframe is not None else []
    setup_time = parse_datetime(order.get("purchased_cmp_date") or order.get("purchased_on"))
    entry_time = parse_datetime(order.get("entry_timestamp"))
    parsed_status = parse_order_status(order.get("order_status"))
    exit_time = parse_datetime(parsed_status.completed_on or order.get("completed_on"))
    output: dict[str, Any] = {"frames": {}, "cutoffs": {"setup_timestamp": iso_datetime(setup_time), "entry_timestamp": iso_datetime(entry_time), "exit_timestamp": iso_datetime(exit_time)}}
    warnings: list[str] = []
    for frame in frames:
        path = root / "latest_data_csv" / f"{symbol}_{frame}.csv"
        df, warning = _read_candles(path)
        if warning:
            warnings.append(warning)
        output["frames"][frame] = {
            "pre_setup": _window(df, "pre_setup", setup_time, None, path, warning),
            "active_trade": _window(df, "active_trade", entry_time, exit_time, path, warning),
            "post_trade": _window(df, "post_trade", entry_time, exit_time, path, warning),
        }
    if not frames:
        warnings.append("no configured timeframe frame available")
    return output, warnings


def build_forensic_record(bundle: OrderBundle, data_root: Optional[str] = None) -> dict[str, Any]:
    order = bundle.order or {}
    signal = bundle.trade_signal or {}
    parsed_status = parse_order_status(order.get("order_status"))
    setup_time = parse_datetime(order.get("purchased_cmp_date") or order.get("purchased_on"))
    entry_time = parse_datetime(order.get("entry_timestamp"))
    exit_time = parse_datetime(parsed_status.completed_on or order.get("completed_on"))
    ohlc, ohlc_warnings = build_ohlc_evidence(bundle, data_root)
    technical_features = build_technical_features(order, ohlc)
    flags: list[str] = []
    warnings: list[str] = list(ohlc_warnings)
    if not signal:
        flags.extend(["SETUP_SIGNAL_MISSING", "TRADE_SIGNAL_DELETED", "SETUP_SNAPSHOT_UNAVAILABLE"])
    elif not signal.get("trade_data"):
        flags.append("SETUP_SNAPSHOT_UNAVAILABLE")
    if not entry_time:
        flags.append("ENTRY_TIMESTAMP_INFERRED")
    else:
        flags.append("ENTRY_TIMESTAMP_INFERRED")
    if exit_time:
        flags.append("EXIT_TIMESTAMP_INFERRED")
    flags.append("BROKER_FILL_UNVERIFIED")
    bucket_link = bundle.links.get("order_to_oms_bucket")
    oms_link = bundle.links.get("bucket_to_oms_orders")
    if bucket_link and bucket_link.status == Availability.AMBIGUOUS.value:
        flags.append("OMS_LINK_AMBIGUOUS")
    elif oms_link and oms_link.status != Availability.AVAILABLE.value:
        flags.append("OMS_LINK_MISSING")
    if not ohlc.get("frames") or all(not frame["pre_setup"]["rows"] for frame in ohlc.get("frames", {}).values()):
        flags.append("OHLC_DATA_MISSING")
    if parsed_status.parse_error:
        warnings.append(parsed_status.parse_error)
    if parsed_status.status in {"success", "failed"} and not bundle.oms_events:
        warnings.append("Outcome is the existing local OHLC evaluator result; no broker event history was linked.")

    entry = order.get("entry_price")
    stop = order.get("stoploss_price")
    target = order.get("target_price")
    setup_evidence = {
        "order_master": {"planned_entry": entry, "planned_stop": stop, "planned_target": target, "direction": order.get("order_type"), "timeframe": order.get("time_frame"), "setup_timestamp": iso_datetime(setup_time)},
        "trade_signals": signal if signal else None,
        "planned_rr": planned_rr(order.get("order_type"), entry, stop, target),
    }
    execution_evidence = {
        "oms_bucket": bundle.oms_bucket,
        "oms_orders": bundle.oms_orders,
        "oms_order_events": bundle.oms_events,
        "link_status": {key: value.status for key, value in bundle.links.items()},
    }
    source_trace = [
        {"source": "order_master", "columns": ["order_id", "trade_signal_id", "stock_tick", "order_type", "time_frame", "entry_price", "stoploss_price", "target_price", "order_status", "purchased_cmp_date", "entry_timestamp", "completed_on"]},
        {"source": "trade_signals", "status": "AVAILABLE" if signal else "MISSING", "columns": ["trade_data", "timestamps", "rrr", "prediction", "probability", "created_at"]},
        {"source": "oms_order_bucket", "status": bundle.links.get("order_to_oms_bucket").status if bundle.links.get("order_to_oms_bucket") else "UNKNOWN"},
        {"source": "oms_orders", "status": bundle.links.get("bucket_to_oms_orders").status if bundle.links.get("bucket_to_oms_orders") else "UNKNOWN"},
        {"source": "oms_order_events", "status": bundle.links.get("oms_to_oms_events").status if bundle.links.get("oms_to_oms_events") else "UNKNOWN"},
        {"source": "technical_features", "method": technical_features["method"], "look_ahead_policy": technical_features["look_ahead_policy"]},
    ]
    record = {
        "order": {key: _json_value(value) for key, value in order.items()},
        "setup": setup_evidence,
        "execution": execution_evidence,
        "outcome": {"status": parsed_status.status or "pending", "reason": parsed_status.reason, "profit_amount": parsed_status.profit_amount, "profit_pct": parsed_status.profit_pct, "loss_amount": parsed_status.loss_amount, "loss_pct": parsed_status.loss_pct, "completed_on": iso_datetime(parsed_status.completed_on or order.get("completed_on")), "raw_status": parsed_status.raw},
        "ohlc": ohlc,
        "features": technical_features,
        "data_quality": {"flags": sorted(set(flags)), "warnings": sorted(set(warnings))},
        "source_trace": source_trace,
        "methodology_version": METHODOLOGY_VERSION,
        "market_cutoff_timestamp": iso_datetime(setup_time),
    }
    canonical = json.dumps(record, sort_keys=True, default=str, separators=(",", ":"))
    record["data_hash"] = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    return record
