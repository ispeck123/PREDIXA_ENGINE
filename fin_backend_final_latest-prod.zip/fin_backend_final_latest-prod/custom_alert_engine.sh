#!/bin/bash

PID_FILE="custom_alert_engine.pid"
SCRIPT_PATH="./alert_engine/custom_alert_notification.py"
CONDA_ENV_NAME="finpro"

start_custom_alert_engine() {
  echo "Starting Custom Alert Engine..."
  source "$(conda info --base)/etc/profile.d/conda.sh"
  conda activate "$CONDA_ENV_NAME"
  which python

  nohup python "$SCRIPT_PATH" > custom_alert_engine.log 2>&1 &
  echo $! > "$PID_FILE"
  echo "Custom Alert Engine started with PID $(cat $PID_FILE)"
}

stop_custom_alert_engine() {
  if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    echo "Stopping Custom Alert Engine with PID $PID..."
    kill "$PID" && rm -f "$PID_FILE"
    echo "Custom Alert Engine stopped."
  else
    echo "No Custom Alert Engine process found."
  fi
}

restart_custom_alert_engine() {
  stop_custom_alert_engine
  sleep 2
  start_custom_alert_engine
}

case "$1" in
  start)
    start_custom_alert_engine
    ;;
  stop)
    stop_custom_alert_engine
    ;;
  restart)
    restart_custom_alert_engine
    ;;
  *)
    echo "Usage: $0 {start|stop|restart}"
    ;;
esac