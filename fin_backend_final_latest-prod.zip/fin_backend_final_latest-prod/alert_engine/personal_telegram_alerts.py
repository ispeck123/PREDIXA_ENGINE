

import telegram
import asyncio
import logging
from telegram.constants import ParseMode

logger = logging.getLogger()

class PTELEGRAM_MSG:
    def __init__(self):
        self.token = "7443534342:AAGbIiCLjYbkjkI2z2Bt5nOJkzQAnwQqgbs"
        self.channel_id = "-1002168429814"  # Replace with actual chat_id
        self.bot = telegram.Bot(token=self.token)

    async def _send_async(self, message):
        try:
            await self.bot.send_message(
                chat_id=self.channel_id,
                text=message,
                parse_mode=ParseMode.MARKDOWN
            )
            print("✅ Telegram message sent")
        except Exception as ex:
            logger.exception("Telegram send failed:")

    def send_msg(self, message):
        try:
            asyncio.run(self._send_async(message))
        except RuntimeError as e:
            if "event loop is closed" in str(e):
                # fallback for closed loop during shutdown
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                loop.run_until_complete(self._send_async(message))
                loop.close()
            else:
                logger.exception("Telegram send failed due to loop issue:")