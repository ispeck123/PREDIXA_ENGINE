import sys, os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from concurrent.futures import ThreadPoolExecutor, as_completed
from alert_engine.notification import send_push_notification
from shared.db.dbconn import DBConnection
from shared.db.db_model import UserAlert, Ind_StockMaster, TradeSignal, UserDeviceToken, Order
from data_fetchers.fyers.fyers_ticker import FyersTickerManager
#from data_fetchers.fyers.indian_futures_data_updater import Indian_future_data_handler
#from data_fetchers.fyers.indian_commodity_data_updater import MCXFutureDataHandler
#from alert_engine.telegram_alert import SETUP_TELEGRAM_MSG, ENTRY_TELEGRAM_MSG
#from alert_engine.simulate_setup import plot_annotated_trade_setup
from shared.config.settings import stock_data_dir_config
from datetime import datetime, timedelta
from threading import Thread
import traceback
import time
import pytz
from datetime import time as dt_time
import logging  
import json
import requests
import subprocess
from shared.config.settings import validate_required_config

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger()
time_zone = pytz.timezone('Asia/Kolkata')

# Global cache
symbol_token_map = {}


subscribed_tokens = set()
cached_entry_alerts = []
cached_stoploss_target_alerts = []
fyers_ws_manager = FyersTickerManager()


dbc = DBConnection()


def get_alert_fcm_token(alert_id: int) -> str:
    dbc = DBConnection()
    db = dbc.get_session()

    try:
        result = (
            db.query(UserDeviceToken.fcm_token)
            .join(UserAlert, UserDeviceToken.user_id == UserAlert.user_id)
            .filter(UserAlert.id == alert_id)
            .all()
        )
        return [row.fcm_token for row in result] if result else []
    except Exception as ex:
        logger.exception(ex, stack_info=True)
        return None
    finally:
        db.close()


def check_and_notify_entry_hit(alert, order):
    #print(alert.__dict__)
    #print(order.__dict__)
    dbc = DBConnection()
    session = dbc.get_session()

    push_alert = False
    token = None    
    token = symbol_token_map.get(alert.stock_symbol)
    if not token:
        return
    
    current_datetime = datetime.now(tz=time_zone)
    current_price = fyers_ws_manager.get_latest_price(token)
    if current_price is None:
        return
    
    if order.order_type.upper() == "BUY" and current_price <= order.entry_price:
        push_alert = True
    # elif order.order_type.upper() == "SELL" and current_price >= order.entry_price:
    #     push_alert = True
    else:
        return
    
    if push_alert:
        row = session.query(UserAlert).filter(UserAlert.id == alert.id).all()
        if len(row) > 0:
            row[0].entry_notification_sent = True
            row[0].entry_notification_sent_at = current_datetime
            session.add(row[0])
            session.commit()
            logger.info(f"********* Entry Hit Notification pushed: | Alert Id: {row[0].id} | {row[0].stock_symbol} | Trigger Price: {current_price} | {current_datetime} ************")

            #title = f"{alert.stock_symbol} {alert_type.upper()} Alert"
            title = f"Entry Hit Alert Notifications"
            
            notification = dbc.raw_query(f"""select ua.id, ua.user_id, ua.country_id, ua.stock_symbol, ua.exchange, ua.alert_type, 
                                            ua.timeframe, ua.entry_notification_sent, ua.entry_notification_sent_at, ism.stock_tick,
                                            om.stock_id, om.entry_price, om.stoploss_price, om.target_price
                                            from user_alerts as ua 
                                            inner join ind_stock_master as ism on ua.stock_symbol = ism.kite_symbol 
                                            inner join order_master as om on ua.trade_signal_id = om.trade_signal_id
                                            where ua.entry_notification_sent = 1 and ua.entry_notification_sent_at is not null  
                                            and ua.id = {alert.id} and ism.is_active = 1""")
            if len(notification) > 0:
                notification[0]["notification_type"] = "entry_hit"
                logger.info(json.dumps(notification[0]))
                fcm_token = get_alert_fcm_token(alert.id)
                for tokens in fcm_token:
                    logger.info("Sending notification for entry hit...")
                    send_push_notification(
                        token = tokens,
                        title = title,
                        body = json.dumps(notification[0])   # Send as string
                    )
    
    
    session.close()
    dbc.close_engine()
    
    

def check_and_notify_stoploss_target_hit(alert, order):
    # print(alert.__dict__)
    # print(order.__dict__)
    dbc = DBConnection()
    session = dbc.get_session()

    push_alert = False
    notification_type = None
    token = None    
    token = symbol_token_map.get(alert.stock_symbol)
    if not token:
        return
    
    current_datetime = datetime.now(tz=time_zone)
    current_price = fyers_ws_manager.get_latest_price(token)
    if current_price is None:
        return
    
    ###################   stoploss conditions   ###################
    if order.order_type.upper() == "BUY" and current_price <= order.stoploss_price:
        push_alert = True
        notification_type = "stoploss_hit"
    # elif order.order_type.upper() == "SELL" and current_price >= order.stoploss_price:
    #     push_alert = True
    #     notification_type = "stoploss_hit"
    ###################   target conditions   ###################
    elif order.order_type.upper() == "BUY" and current_price >= order.target_price:
        push_alert = True
        notification_type = "target_hit"
    # elif order.order_type.upper() == "SELL" and current_price <= order.target_price:
    #     push_alert = True
    #     notification_type = "target_hit"
    else:
        return
    
    if push_alert:
        row = session.query(UserAlert).filter(UserAlert.id == alert.id).all()
        if len(row) > 0:
            row[0].stoploss_target_notification_sent = True
            row[0].stoploss_target_notification_sent_at = current_datetime
            row[0].notification_type = notification_type
            session.add(row[0])
            session.commit()
            logger.info(f"********* {notification_type.replace('_', ' ').capitalize()} Notification pushed: | Alert Id: {row[0].id} | {row[0].stock_symbol} | Trigger Price: {current_price} | {current_datetime} ************")

            #title = f"{alert.stock_symbol} {alert_type.upper()} Alert"
            title = f"{notification_type.replace('_', ' ').capitalize()} Alert Notifications"
            
            notification = dbc.raw_query(f"""select ua.id, ua.user_id, ua.country_id, ua.stock_symbol, ua.exchange, ua.alert_type, 
                                            ua.timeframe, ua.stoploss_target_notification_sent, ua.stoploss_target_notification_sent_at, 
                                            ua.notification_type, ism.stock_tick, om.stock_id, om.entry_price, om.stoploss_price, om.target_price
                                            from user_alerts as ua 
                                            inner join ind_stock_master as ism on ua.stock_symbol = ism.kite_symbol 
                                            inner join order_master as om on ua.trade_signal_id = om.trade_signal_id
                                            where ua.stoploss_target_notification_sent = 1 and ua.stoploss_target_notification_sent_at is not null  
                                            and ua.id = {alert.id} and ism.is_active = 1""")
            if len(notification) > 0:
                logger.info(json.dumps(notification[0]))
                fcm_token = get_alert_fcm_token(alert.id)
                for tokens in fcm_token:
                    logger.info(f"Sending notification for {notification_type.replace('_', ' ')}...")
                    send_push_notification(
                        token = tokens,
                        title = title,
                        body = json.dumps(notification[0])   # Send as string
                    )
        
    session.close()
    dbc.close_engine()
    
            

def preload_instrument_tokens():
    """Load stock_symbol → instrument_token from ind_stock_master"""
    global symbol_token_map
    db = dbc.get_session()
    records = db.query(Ind_StockMaster).filter(Ind_StockMaster.is_active == 1).all()
    symbol_token_map = {
        record.kite_symbol: record.fyers_symbol
        for record in records if record.fyers_symbol
    }
    db.close()
    logger.info(f"✅ Loaded {len(symbol_token_map)} CASH instrument tokens")








def refresh_alert_subscriptions():
    """Refresh alert cache and subscribe to new tokens"""
    global subscribed_tokens, cached_entry_alerts, cached_stoploss_target_alerts
    db = dbc.get_session()
    # cached_entry_alerts = db.query(UserAlert, Order).join(Order, 
    #                                                UserAlert.trade_signal_id == Order.trade_signal_id
    #                                                ).filter(UserAlert.is_active == True, 
    #                                                         UserAlert.entry_notification_sent == False,
    #                                                         Order.is_trade_started == False).all()
    cached_entry_alerts = db.query(UserAlert, Order).join(Order, 
                                                   UserAlert.trade_signal_id == Order.trade_signal_id
                                                   ).filter(UserAlert.is_active == True, 
                                                            UserAlert.entry_notification_sent == False).all()
    #print(cached_entry_alerts)
    # cached_stoploss_target_alerts = db.query(UserAlert, Order).join(Order, 
    #                                                UserAlert.trade_signal_id == Order.trade_signal_id
    #                                                ).filter(UserAlert.is_active == True, 
    #                                                         UserAlert.stoploss_target_notification_sent == False,
    #                                                         Order.order_status.like('%%pending%%')).all()
    cached_stoploss_target_alerts = db.query(UserAlert, Order).join(Order, 
                                                   UserAlert.trade_signal_id == Order.trade_signal_id
                                                   ).filter(UserAlert.is_active == True, 
                                                            UserAlert.stoploss_target_notification_sent == False,
                                                            Order.is_trade_started == True).all()
    #print(cached_stoploss_target_alerts)
    # print(len(cached_alerts))
    db.close()
    new_tokens = set()
    for alert, order in cached_entry_alerts:
        token = symbol_token_map.get(alert.stock_symbol)
        # print(alert.stock_symbol, token, token not in subscribed_tokens)
        if token and token not in subscribed_tokens:
            new_tokens.add(token)
    for alert, order in cached_stoploss_target_alerts:
        token = symbol_token_map.get(alert.stock_symbol)
        # print(alert.stock_symbol, token, token not in subscribed_tokens)
        if token and token not in subscribed_tokens:
            new_tokens.add(token)

    if new_tokens:
        fyers_ws_manager.subscribe(list(new_tokens), fyers_ws_manager.fyers)
        subscribed_tokens.update(new_tokens)
        logger.info(f"🔄 Subscribed {len(new_tokens)} new tokens dynamically.")


def dynamic_subscription_loop(interval_seconds=10):
    """Refresh subscriptions and alert cache periodically"""
    while True:
        if is_market_open():
            refresh_alert_subscriptions()
            time.sleep(interval_seconds)
        else:
            break

def entry_hit_alert_loop():
    logger.info("🚀 Starting entry hit alert monitoring loop...")
    while True:
        if is_market_open():
            if cached_entry_alerts:
                with ThreadPoolExecutor(max_workers=10) as pool:
                    futures = {pool.submit(check_and_notify_entry_hit, alert, order): alert for alert, order in cached_entry_alerts}
                    for future in as_completed(futures):
                        alert = futures[future]
                        try:
                            future.result()
                        except Exception as e:
                            logger.error(f"❌ Error while processing entry hit alert ID {getattr(alert, 'id', 'N/A')} for stock {alert.stock_symbol}: {e}")
                            traceback.print_exc()
                    # pool.map(check_and_notify, cached_alerts)

            time.sleep(10)
        else:
            logger.info(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} : Market is closed .....")
            break


def stoploss_target_hit_alert_loop():
    logger.info("🚀 Starting stoploss/target hit alert monitoring loop...")
    while True:
        if is_market_open():        
            if cached_stoploss_target_alerts:
                with ThreadPoolExecutor(max_workers=10) as pool:
                    futures = {pool.submit(check_and_notify_stoploss_target_hit, alert, order): alert for alert, order in cached_stoploss_target_alerts}
                    for future in as_completed(futures):
                        alert = futures[future]
                        try:
                            future.result()
                        except Exception as e:
                            logger.error(f"❌ Error while processing stoploss/target hit alert ID {getattr(alert, 'id', 'N/A')} for stock {alert.stock_symbol}: {e}")
                            traceback.print_exc()
                    # pool.map(check_and_notify, cached_alerts)

            time.sleep(10)
        else:
            logger.info(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} : Market is closed .....")
            break


def get_market_holidays():
    try:
        url = "https://www.nseindia.com/api/holiday-master?type=trading"
        headers = {
            "User-Agent": "Mozilla/5.0",
            "Accept": "application/json",
            "Referer": "https://www.nseindia.com/"
        }

        session = requests.Session()
        session.headers.update(headers)

        response = session.get(url)
        response.raise_for_status()

        data = response.json()
        holidays = data["CM"]  # Capital Market (Equity)
        holiday_dates = [datetime.strptime(hol['tradingDate'], "%d-%b-%Y") for hol in holidays]
        #print(holiday_dates)
        holiday_dates = [datetime.strftime(hol, "%Y-%m-%d")for hol in holiday_dates]
        #print(holiday_dates)
        return holiday_dates
    except:
        return []





def is_market_open(now: datetime = None) -> bool:
    """
    Check if current datetime is within NSE/BSE trading hours (India).
    Trading hours: 09:15 AM - 03:30 PM IST, Monday - Friday.
    Weekends and holidays excluded (holidays can be added manually).
    """
    # Use IST timezone
    ist = pytz.timezone("Asia/Kolkata")
    if now is None:
        now = datetime.now(ist)
    else:
        # ensure tz-aware
        if now.tzinfo is None:
            now = ist.localize(now)
        else:
            now = now.astimezone(ist)

    # Weekday check (0 = Monday, 6 = Sunday)
    if now.weekday() >= 5:
        return False  # Saturday or Sunday

    # Market hours
    market_open = dt_time(9, 13)   # 9:15 AM
    market_close = dt_time(15, 30) # 3:30 PM

    if market_open <= now.time() <= market_close:
        # Optional: check holidays (static list)
        holidays = get_market_holidays()
        today_str = now.strftime("%Y-%m-%d")
        if today_str in holidays:
            return False
        return True
    return False


def start_entry_alert_engine():
    preload_instrument_tokens()
    Thread(target=dynamic_subscription_loop, daemon=True).start() # initial
    Thread(target=entry_hit_alert_loop, daemon=True).start()
    Thread(target=stoploss_target_hit_alert_loop, daemon=True).start()


    

if __name__ == "__main__":  
    validate_required_config()
    restart_interval = 2
    start_time = datetime.now()
    while True:
        if (datetime.now() - start_time) >= timedelta(hours = restart_interval):
            logger.info("Restarting now...")
            os.execv(sys.executable, [sys.executable] + sys.argv)
        if is_market_open():            
            start_entry_alert_engine()          
            time.sleep(60)
        else:
            logger.info(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} : Market is closed .....")
            time.sleep(60)



# ADANI_ENTERPRISES None True ADANIENT
# AXIS_BANK None True AXISBANK
# APOLLO_HOSPITALS None True APOLLOHOSP
# ADANI_TOTAL_GAS None True ATGL