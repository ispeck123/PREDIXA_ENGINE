from concurrent.futures import ThreadPoolExecutor, as_completed
# from alert_engine.notification import send_push_notification, get_alert_fcm_token
from shared.db.dbconn import DBConnection
from shared.db.db_model import UserAlert, Ind_StockMaster, TradeSignal
from data_fetchers.fyers.fyers_ticker import FyersTickerManager
from data_fetchers.fyers.indian_futures_data_updater import Indian_future_data_handler
from data_fetchers.fyers.indian_commodity_data_updater import MCXFutureDataHandler
from alert_engine.telegram_alert import SETUP_TELEGRAM_MSG, ENTRY_TELEGRAM_MSG
from alert_engine.simulate_setup import plot_annotated_trade_setup
from shared.config.settings import stock_data_dir_config, stock_logic_config
from datetime import datetime
from threading import Thread, Lock
import traceback
import time
import pytz
from datetime import time as dt_time
import logging  

logger = logging.getLogger()

# Global cache
symbol_token_map = {}

future_and_commodity_token_map = {}

subscribed_tokens = set()
cached_alerts = []
cached_lock = Lock()

fyers_ws_manager = FyersTickerManager()
setup_telegram_bot = SETUP_TELEGRAM_MSG()
entry_telegram_bot = ENTRY_TELEGRAM_MSG()

ifdh = Indian_future_data_handler()
mcxfdh = MCXFutureDataHandler()

dbc = DBConnection()

def check_and_notify(alert: UserAlert):
    token = None
    if alert.expiry_date:
        # token = future_and_commodity_token_map.get(alert.stock_symbol)
        fut_data_list = future_and_commodity_token_map.get(alert.stock_symbol)
        if isinstance(fut_data_list, list):
            for fut_data in fut_data_list:
                if str(fut_data["expiry"]) == str(alert.expiry_date):
                    token = fut_data["symbol"]
                    break  # match found
    else:
        token = symbol_token_map.get(alert.stock_symbol)
    if not token:
        return False
    current_price = fyers_ws_manager.get_latest_price(token)
    if current_price is None:
        return False
    price_min = float(alert.price_range_min or 0)
    price_max = float(alert.price_range_max or 0)
    # print(alert.stock_symbol, current_price, price_min, price_max, price_min <= current_price <= price_max, alert.alert_type.lower())
    if price_min == 0 or price_max == 0:
        return False # skip invalid range
    if price_min <= current_price <= price_max:
        # Choose message based on alert type
        alert_type = alert.alert_type.lower()
        title = f"{alert.stock_symbol} {alert_type.upper()} Alert"
        body = f"Current price ₹{current_price} is within your {alert_type} range: ₹{price_min} - ₹{price_max}"
        if alert_type in ["buy", "sell"] and is_market_open():
            # fcm_token = get_alert_fcm_token(alert.id)
            # for tokens in fcm_token:
            #     send_push_notification(
            #         token=tokens,
            #         title=title,
            #         body=body
            #     )
            if alert_type == "sell":
                return False
                # ist = pytz.timezone("Asia/Kolkata")
                # current_time = datetime.now(ist)
                # if current_time.time() >= dt_time(11, 30):  # discard at/after 11:30
                    # return

            db = dbc.get_session()
            try:
                updated = (
                    db.query(UserAlert)
                      .filter(UserAlert.id == alert.id, UserAlert.is_active == True)
                      .update({UserAlert.is_active: False}, synchronize_session=False)
                )
                db.commit()
                if updated != 1:
                    db.close()
                    return False   # another worker already claimed/sent
            except Exception as ex:
                logger.error(ex)
                db.rollback()
                return False
            finally:
                db.close()

            alert_time_frame = getattr(stock_logic_config, f'TIME_FRAMES_{alert.timeframe}')[-1]
            icon = "🟢" if alert.alert_type == "BUY" else "🔴"
            msg_header = "Trade Segment Futures & Commodity" if alert.expiry_date else "Trade Segment CASH" 
            expiry_line = f"🧾 *Expiry Date*: {datetime.strptime(alert.expiry_date, '%d%m%Y').strftime('%d-%b-%Y')}\n" if alert.expiry_date else ""
            telegram_msg = (
                f"   *{msg_header}*\n\n"
                f"📌 *Entry Alert Triggered*\n\n"
                f"📈 *Stock*: {alert.stock_symbol}\n"
                f"{icon} *Trade Type*: {alert.alert_type}\n"
                f"🕒 *Timeframe*: {alert_time_frame.upper()}\n"
                f"📅 *Setup Date*: {alert.created_at.strftime('%d/%m/%Y')}\n"
                f"{expiry_line}"
                f"💰 *CMP*: ₹{current_price}\n"
                f"🎯 *Entry Range*: ₹{price_min} - ₹{price_max}\n\n"
                f"🎯 *Exact Entry Price as per setup*:  ₹{alert.trigger_price}"
                f"⚠️ *Action*: CMP is near the entry zone of this setup. Prepare for potential entry."
            )
            # telegram_msg = f"📈 *{alert.stock_symbol} {alert_type.upper()} Alert*\n\n" \
            #            f"💰 *Current Price*: ₹{current_price}\n" \
            #            f"🎯 *Target Range*: ₹{price_min} - ₹{price_max}\n\n" \
            #            f"_Alert triggered automatically._"
            entry_telegram_bot.send_msg(message=telegram_msg)
            print(telegram_msg)
            print("telegram alert sent successfully")
            # if not alert.recurrent:
            #     db = dbc.get_session()
            #     alert.is_active = False
            #     db.merge(alert)
            #     db.commit()
            #     db.close()
            return True
        else:
            return False

def preload_instrument_tokens():
    """Load stock_symbol → instrument_token from ind_stock_master"""
    global symbol_token_map
    db = dbc.get_session()
    records = db.query(Ind_StockMaster).all()
    symbol_token_map = {
        record.kite_symbol: record.fyers_symbol
        for record in records if record.fyers_symbol
    }
    db.close()
    print(f"✅ Loaded {len(symbol_token_map)} CASH instrument tokens")

def preload_futures_tokens():
    global future_and_commodity_token_map
    db = dbc.get_session()
    # records = db.query().all()
    future_records = db.query(TradeSignal).filter(
        TradeSignal.exchange_id == 11,
        TradeSignal.is_active == 1).all()
    
    for fut_rec in future_records:
        expiry_list = ifdh.get_latest_fyers_futures_symbol(fut_rec.stock_name)
        # print(expiry_list)
        if isinstance(expiry_list, list) and all("symbol" in e and "expiry" in e for e in expiry_list):
            future_and_commodity_token_map[fut_rec.stock_name] = expiry_list
    db.close()

def preload_commodity_tokens():
    global future_and_commodity_token_map
    db = dbc.get_session()
    # records = db.query().all()
    commodity_records = db.query(TradeSignal).filter(
        TradeSignal.exchange_id == 10,
        TradeSignal.is_active == 1).all()
    for comm_rec in commodity_records:
        expiry_list = mcxfdh.get_latest_fyers_commodity_symbol_expiry(comm_rec.stock_name)
        # print(expiry_list)
        if isinstance(expiry_list, list) and all("symbol" in e and "expiry" in e for e in expiry_list):
            future_and_commodity_token_map[comm_rec.stock_name] = expiry_list
    db.close()

def preload_future_and_commodity_tokens():
    global future_and_commodity_token_map
    future_and_commodity_token_map = {}
    preload_futures_tokens()
    preload_commodity_tokens()
    print(f"✅ Total tokens loaded in future_and_commodity_token_map: {len(future_and_commodity_token_map)}")


def refresh_alert_subscriptions():
    """Refresh alert cache and subscribe to new tokens"""
    global subscribed_tokens, cached_alerts
    db = dbc.get_session()
    new_cache = db.query(UserAlert).filter((UserAlert.is_active == True) & (UserAlert.is_sys == True)).all()
    # print(len(cached_alerts))
    db.close()
    with cached_lock:
        cached_alerts = new_cache
        new_tokens = set()
        for alert in cached_alerts:
            if alert.expiry_date:
                fut_data_list = future_and_commodity_token_map.get(alert.stock_symbol)
                if isinstance(fut_data_list, list):
                    for fut_data in fut_data_list:
                        if str(fut_data["expiry"]) == str(alert.expiry_date):
                            token = fut_data["symbol"]
                            break  # match found
            else:
                token = symbol_token_map.get(alert.stock_symbol)
            # print(alert.stock_symbol, token, token not in subscribed_tokens)
            if token and token not in subscribed_tokens:
                new_tokens.add(token)

    if new_tokens:
        fyers_ws_manager.subscribe(list(new_tokens), fyers_ws_manager.fyers)
        subscribed_tokens.update(new_tokens)
        print(f"🔄 Subscribed {len(new_tokens)} new tokens dynamically.")


def dynamic_subscription_loop(interval_seconds=60):
    """Refresh subscriptions and alert cache periodically"""
    while True:
        # preload_future_and_commodity_tokens()
        refresh_alert_subscriptions()
        time.sleep(interval_seconds)

# def alert_loop():
#     print("🚀 Starting alert monitoring loop...")
#     while True:
#         if cached_alerts:
#             with ThreadPoolExecutor(max_workers=10) as pool:
#                 futures = {pool.submit(check_and_notify, alert): alert for alert in cached_alerts}
#                 for future in as_completed(futures):
#                     alert = futures[future]
#                     try:
#                         future.result()
#                     except Exception as e:
#                         print(f"❌ Error while processing alert ID {getattr(alert, 'id', 'N/A')} for stock {alert.stock_symbol}: {e}")
#                         traceback.print_exc()
#                 # pool.map(check_and_notify, cached_alerts)

#         time.sleep(15)

def alert_loop():
    print("🚀 Starting alert monitoring loop...")
    while True:
        with cached_lock:
            alerts_snapshot = list(cached_alerts)

        if alerts_snapshot:
            to_remove_ids = set()

            with ThreadPoolExecutor(max_workers=10) as pool:
                futures = {pool.submit(check_and_notify, alert): alert for alert in alerts_snapshot}
                for future in as_completed(futures):
                    alert = futures[future]
                    try:
                        sent = future.result()
                        if sent:
                            to_remove_ids.add(alert.id)
                    except Exception as e:
                        print(f"❌ Error alert ID {getattr(alert, 'id', 'N/A')} {alert.stock_symbol}: {e}")
                        traceback.print_exc()

            if to_remove_ids:
                with cached_lock:
                    global cached_alerts
                    cached_alerts = [a for a in cached_alerts if a.id not in to_remove_ids]

        time.sleep(15)


def check_trade_signals():
    """Check for new trade signals and send Telegram alerts."""
    db = dbc.get_session()

    try:
        new_signals = db.query(TradeSignal).filter(TradeSignal.is_send == False).all()

        if new_signals:
            for signal in new_signals:
                print(signal.exp_date, "****************************")
                signal_exe_frame = getattr(stock_logic_config, f'FUTURE_TIME_FRAME_{signal.time_fr}')[-1]
                if signal.exp_date is None:
                    stock_seg = "Cash"
                    csv_file_path = f'{stock_data_dir_config.indian_stock_data_dir}/latest_data_csv/{str(signal.stock_name).lower()}_{signal_exe_frame}.csv'
                    out_image_path = f"./data/alert_setups/{str(signal.stock_name).lower()}_{signal_exe_frame}.png"
                    message = f"📊 *New {stock_seg} Trade Signal*\n\n" \
                          f"📈 *Symbol*: {signal.stock_name}\n" \
                          f"⏱️ *Timeframe*: {str(signal_exe_frame).upper()}\n" \
                          f"🎯 *Signal Type*: {signal.trade_type}\n" \
                          f"💰 *Entry Price*: ₹{round(signal.trade_data['entry_price'], 2)}\n" \
                          f"🎯 *Target*: ₹{round(signal.trade_data['target_price'], 2)}\n" \
                          f"🛑 *Stoploss*: ₹{round(signal.trade_data['stop_loss'], 2)}\n\n" \
                          
                else:
                    stock_seg = "Futures & Commodity"
                    if signal.exchange_id == 10:
                        csv_file_path = f'{stock_data_dir_config.indian_commodity_data}/latest_data_csv/{signal.stock_name}_{signal.exp_date}_{signal_exe_frame}.csv'
                        out_image_path = f"./data/alert_setups/{signal.stock_name}_{signal.exp_date}_{signal_exe_frame}.png"
                    else:
                        csv_file_path = f'{stock_data_dir_config.indian_stock_future_data_dir}/latest_data_csv/{signal.stock_name}_{signal.exp_date}_{signal_exe_frame}.csv'
                        out_image_path = f"./data/alert_setups/{signal.stock_name}_{signal.exp_date}_{signal_exe_frame}.png"
                    formatted_date = datetime.strptime(signal.exp_date, "%d%m%Y").strftime("%d-%m-%Y")
                    message = f"📊 *New {stock_seg} Trade Signal*\n\n" \
                          f"📈 *Symbol*: {signal.stock_name}\n" \
                          f"⏱️ *Timeframe*: {str(signal_exe_frame).upper()}\n" \
                          f"⏱️ *Expiry Date of Contract*: {formatted_date}\n" \
                          f"🎯 *Signal Type*: {signal.trade_type}\n" \
                          f"💰 *Entry Price*: ₹{round(signal.trade_data['entry_price'], 2)}\n" \
                          f"🎯 *Target*: ₹{round(signal.trade_data['target_price'], 2)}\n" \
                          f"🛑 *Stoploss*: ₹{round(signal.trade_data['stop_loss'], 2)}\n\n" \
                          
                # prediction = signal.prediction
                # probability = signal.probability
                # if prediction is not None and probability is not None:
                #     message += f"🧠 *Model Prediction*: {prediction} (🎯 Confidence: {round(probability * 100, 2)}%) \n"
                # else:
                #     message += "⚠️ *Model Prediction unavailable* \n"
                
                message += f"_Signal generated automatically._"
                print(message)
                plot_annotated_trade_setup(csv_file_path, signal.trade_data['entry_price'], signal.trade_data['stop_loss'], signal.trade_data['target_price'], signal.stock_name, signal.trade_type, out_image_path)
                setup_telegram_bot.send_msg(img_path=out_image_path, message=message)
                print(f"✅ Sent trade signal for {stock_seg} {signal.stock_name}")

                # Mark as sent
                signal.is_send = True
                db.merge(signal)

            db.commit()

    except Exception as e:
        print(f"❌ Error in trade signal alert: {e}")
    finally:
        db.close()


def trade_signal_alert_loop():
    while True:
        check_trade_signals()
        time.sleep(900)


def setup_alert_engine():
    Thread(target=trade_signal_alert_loop, daemon=True).start()


def is_market_open(now: datetime = None) -> bool:
    """
    Check if current datetime is within NSE/BSE trading hours (India).
    Trading hours: 09:15 AM - 03:30 PM IST, Monday - Friday.
    Weekends and holidays excluded (holidays can be added manually).
    """
    # Use IST timezone
    ist = pytz.timezone("Asia/Kolkata")
    if now is None:
        now = datetime.now(ist)
    else:
        # ensure tz-aware
        if now.tzinfo is None:
            now = ist.localize(now)
        else:
            now = now.astimezone(ist)

    # Weekday check (0 = Monday, 6 = Sunday)
    if now.weekday() >= 5:
        return False  # Saturday or Sunday

    # Market hours
    market_open = dt_time(9, 15)   # 9:15 AM
    market_close = dt_time(15, 30) # 3:30 PM

    if market_open <= now.time() <= market_close:
        # Optional: check holidays (static list)
        holidays = {
            "2025-01-26", "2025-03-14", "2025-04-18",  # example dates
            "2025-05-01", "2025-08-15", "2025-10-02",
            "2025-11-04", "2025-12-25"
        }
        today_str = now.strftime("%Y-%m-%d")
        if today_str in holidays:
            return False
        return True
    return False


def acquire_singleton_lock() -> bool:
    db = dbc.get_session()
    try:
        # MySQL advisory lock (timeout 0 sec)
        got = db.execute(text("SELECT GET_LOCK('entry_alert_engine_lock', 0)")).scalar()
        return got == 1
    finally:
        db.close()


def start_entry_alert_engine():
    if not acquire_singleton_lock():
        print("Another alert engine instance is running. Exiting.")
        return
    preload_instrument_tokens()
    preload_future_and_commodity_tokens()
    Thread(target=dynamic_subscription_loop, daemon=True).start() # initial
    alert_loop()
    # Thread(target=alert_loop, daemon=True).start()
    


# ADANI_ENTERPRISES None True ADANIENT
# AXIS_BANK None True AXISBANK
# APOLLO_HOSPITALS None True APOLLOHOSP
# ADANI_TOTAL_GAS None True ATGL