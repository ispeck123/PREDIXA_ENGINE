from concurrent.futures import ThreadPoolExecutor, as_completed
from alert_engine.notification import send_push_notification, get_alert_fcm_token
from shared.db.dbconn import DBConnection
from shared.db.db_model import UserAlert, Ind_StockMaster, TradeSignal
from data_fetchers.kiteconnect.kite_ticker import KiteTickerManager
from data_fetchers.kiteconnect.indian_stock_futures import Indian_future_data_handler
from data_fetchers.kiteconnect.indian_commodity_data_updater import MCXFutureDataHandler
from alert_engine.telegram_alert import SETUP_TELEGRAM_MSG, ENTRY_TELEGRAM_MSG
from alert_engine.simulate_setup import plot_annotated_trade_setup
from shared.config.settings import stock_data_dir_config, stock_logic_config
from datetime import datetime
from threading import Thread
import traceback
import time

# Global cache
symbol_token_map = {}

future_and_commodity_token_map = {}

subscribed_tokens = set()
cached_alerts = []

kite_ws_manager = KiteTickerManager()
setup_telegram_bot = SETUP_TELEGRAM_MSG()
entry_telegram_bot = ENTRY_TELEGRAM_MSG()

ifdh = Indian_future_data_handler()
mcxfdh = MCXFutureDataHandler()

def check_and_notify(alert: UserAlert):
    if alert.expiry_date:
        token = future_and_commodity_token_map.get(alert.stock_symbol)
    else:
        token = symbol_token_map.get(alert.stock_symbol)
    if not token:
        return
    current_price = kite_ws_manager.get_latest_price(token)
    if current_price is None:
        return
    price_min = float(alert.price_range_min or 0)
    price_max = float(alert.price_range_max or 0)
    # print(alert.stock_symbol, current_price, price_min, price_max, price_min <= current_price <= price_max, alert.alert_type.lower())
    if price_min == 0 or price_max == 0:
        return  # skip invalid range
    if price_min <= current_price <= price_max:
        # Choose message based on alert type
        alert_type = alert.alert_type.lower()
        title = f"{alert.stock_symbol} {alert_type.upper()} Alert"
        body = f"Current price ₹{current_price} is within your {alert_type} range: ₹{price_min} - ₹{price_max}"
        if alert_type in ["buy", "sell"]:
            fcm_token = get_alert_fcm_token(alert.id)
            for tokens in fcm_token:
                send_push_notification(
                    token=tokens,
                    title=title,
                    body=body
                    )
            alert_time_frame = getattr(stock_logic_config, f'TIME_FRAMES_{alert.timeframe}')[-1]
            icon = "🟢" if alert.alert_type == "BUY" else "🔴"
            msg_header = "Trade Segment Futures & Commodity" if alert.expiry_date else "Trade Segment CASH" 
            expiry_line = f"🧾 *Expiry Date*: {datetime.strptime(alert.expiry_date, '%d%m%Y').strftime('%d-%b-%Y')}\n" if alert.expiry_date else ""
            telegram_msg = (
                f"   *{msg_header}*\n\n"
                f"📌 *Entry Alert Triggered*\n\n"
                f"📈 *Stock*: {alert.stock_symbol}\n"
                f"{icon} *Trade Type*: {alert.alert_type}\n"
                f"🕒 *Timeframe*: {alert_time_frame.upper()}\n"
                f"📅 *Setup Date*: {alert.created_at.strftime('%d/%m/%Y')}\n"
                f"{expiry_line}"
                f"💰 *CMP*: ₹{current_price}\n"
                f"🎯 *Entry Range*: ₹{price_min} - ₹{price_max}\n\n"
                f"🎯 *Exact Entry Price as per setup*:  ₹{alert.trigger_price}"
                f"⚠️ *Action*: CMP is near the entry zone of this setup. Prepare for potential entry."
            )
            # telegram_msg = f"📈 *{alert.stock_symbol} {alert_type.upper()} Alert*\n\n" \
            #            f"💰 *Current Price*: ₹{current_price}\n" \
            #            f"🎯 *Target Range*: ₹{price_min} - ₹{price_max}\n\n" \
            #            f"_Alert triggered automatically._"
            entry_telegram_bot.send_msg(message=telegram_msg)
            print(telegram_msg)
            print("telegram alert sent successfully")
            if not alert.recurrent:
                dbc = DBConnection()
                db = dbc.get_session()
                alert.is_active = False
                db.merge(alert)
                db.commit()
                db.close()

def preload_instrument_tokens():
    """Load stock_symbol → instrument_token from ind_stock_master"""
    global symbol_token_map
    dbc = DBConnection()
    db = dbc.get_session()
    records = db.query(Ind_StockMaster).all()
    symbol_token_map = {
        record.kite_symbol: record.kite_token
        for record in records if record.kite_symbol
    }
    db.close()
    print(f"✅ Loaded {len(symbol_token_map)} CASH instrument tokens")

def preload_futures_tokens():
    global future_and_commodity_token_map
    dbc = DBConnection()
    db = dbc.get_session()
    # records = db.query().all()
    future_records = db.query(TradeSignal).filter(
        TradeSignal.exchange_id == 11,
        TradeSignal.is_active == 1).all()
    
    future_token_map = {
        fut_rec.stock_name : ifdh.get_futures_token(fut_rec.stock_name, datetime.strptime(fut_rec.exp_date, "%d%m%Y").strftime("%d-%m-%Y"))
        for fut_rec in future_records
    }
    future_and_commodity_token_map.update(future_token_map)
    db.close()
    dbc.close_engine()

def preload_commodity_tokens():
    global future_and_commodity_token_map
    dbc = DBConnection()
    db = dbc.get_session()
    # records = db.query().all()
    commodity_records = db.query(TradeSignal).filter(
        TradeSignal.exchange_id == 10,
        TradeSignal.is_active == 1).all()
    commodity_token_map = {
        mcx_rec.stock_name : mcxfdh.get_commodity_token(mcx_rec.stock_name, datetime.strptime(mcx_rec.exp_date, "%d%m%Y").strftime("%d-%m-%Y"))
        for mcx_rec in commodity_records
    }
    future_and_commodity_token_map.update(commodity_token_map)
    db.close()
    dbc.close_engine()

def preload_future_and_commodity_tokens():
    global future_and_commodity_token_map
    future_and_commodity_token_map = {}
    preload_futures_tokens()
    preload_commodity_tokens()
    print(f"✅ Total tokens loaded in future_and_commodity_token_map: {len(future_and_commodity_token_map)}")


def refresh_alert_subscriptions():
    """Refresh alert cache and subscribe to new tokens"""
    global subscribed_tokens, cached_alerts
    # print("Befor Cach", cached_alerts)
    # print("subscribed token", subscribed_tokens)
    dbc = DBConnection()
    db = dbc.get_session()
    cached_alerts = db.query(UserAlert).filter(UserAlert.is_active == True).all()
    # print(len(cached_alerts))
    db.close()
    dbc.close_engine()
    new_tokens = set()
    for alert in cached_alerts:
        if alert.expiry_date:
            token = future_and_commodity_token_map.get(alert.stock_symbol)
        else:
            token = symbol_token_map.get(alert.stock_symbol)
        # print(alert.stock_symbol, token, token not in subscribed_tokens)
        if token and token not in subscribed_tokens:
            new_tokens.add(token)

    if new_tokens:
        kite_ws_manager.subscribe(list(new_tokens), kite_ws_manager.kws)
        subscribed_tokens.update(new_tokens)
        print(f"🔄 Subscribed {len(new_tokens)} new tokens dynamically.")


def dynamic_subscription_loop(interval_seconds=60):
    """Refresh subscriptions and alert cache periodically"""
    while True:
        # preload_future_and_commodity_tokens()
        refresh_alert_subscriptions()
        time.sleep(interval_seconds)

def alert_loop():
    print("🚀 Starting alert monitoring loop...")
    while True:
        if cached_alerts:
            with ThreadPoolExecutor(max_workers=10) as pool:
                futures = {pool.submit(check_and_notify, alert): alert for alert in cached_alerts}
                for future in as_completed(futures):
                    alert = futures[future]
                    try:
                        future.result()
                    except Exception as e:
                        print(f"❌ Error while processing alert ID {getattr(alert, 'id', 'N/A')} for stock {alert.stock_symbol}: {e}")
                        traceback.print_exc()
                # pool.map(check_and_notify, cached_alerts)

        time.sleep(15)

def check_trade_signals():
    """Check for new trade signals and send Telegram alerts."""
    dbc = DBConnection()
    db = dbc.get_session()

    try:
        new_signals = db.query(TradeSignal).filter(TradeSignal.is_send == False).all()

        if new_signals:
            for signal in new_signals:
                print(signal.exp_date, "****************************")
                signal_exe_frame = getattr(stock_logic_config, f'FUTURE_TIME_FRAME_{signal.time_fr}')[-1]
                if signal.exp_date is None:
                    stock_seg = "Cash"
                    csv_file_path = f'{stock_data_dir_config.indian_stock_data_dir}/latest_data_csv/{str(signal.stock_name).lower()}_{signal_exe_frame}.csv'
                    out_image_path = f"./data/alert_setups/{str(signal.stock_name).lower()}_{signal_exe_frame}.png"
                    message = f"📊 *New {stock_seg} Trade Signal*\n\n" \
                          f"📈 *Symbol*: {signal.stock_name}\n" \
                          f"⏱️ *Timeframe*: {str(signal_exe_frame).upper()}\n" \
                          f"🎯 *Signal Type*: {signal.trade_type}\n" \
                          f"💰 *Entry Price*: ₹{round(signal.trade_data['entry_price'], 2)}\n" \
                          f"🎯 *Target*: ₹{round(signal.trade_data['target_price'], 2)}\n" \
                          f"🛑 *Stoploss*: ₹{round(signal.trade_data['stop_loss'], 2)}\n\n" \
                          
                else:
                    stock_seg = "Futures & Commodity"
                    if signal.exchange_id == 10:
                        csv_file_path = f'{stock_data_dir_config.indian_commodity_data}/latest_data_csv/{signal.stock_name}_{signal.exp_date}_{signal_exe_frame}.csv'
                        out_image_path = f"./data/alert_setups/{signal.stock_name}_{signal.exp_date}_{signal_exe_frame}.png"
                    else:
                        csv_file_path = f'{stock_data_dir_config.indian_stock_future_data_dir}/latest_data_csv/{signal.stock_name}_{signal.exp_date}_{signal_exe_frame}.csv'
                        out_image_path = f"./data/alert_setups/{signal.stock_name}_{signal.exp_date}_{signal_exe_frame}.png"
                    formatted_date = datetime.strptime(signal.exp_date, "%d%m%Y").strftime("%d-%m-%Y")
                    message = f"📊 *New {stock_seg} Trade Signal*\n\n" \
                          f"📈 *Symbol*: {signal.stock_name}\n" \
                          f"⏱️ *Timeframe*: {str(signal_exe_frame).upper()}\n" \
                          f"⏱️ *Expiry Date of Contract*: {formatted_date}\n" \
                          f"🎯 *Signal Type*: {signal.trade_type}\n" \
                          f"💰 *Entry Price*: ₹{round(signal.trade_data['entry_price'], 2)}\n" \
                          f"🎯 *Target*: ₹{round(signal.trade_data['target_price'], 2)}\n" \
                          f"🛑 *Stoploss*: ₹{round(signal.trade_data['stop_loss'], 2)}\n\n" \
                          
                # prediction = signal.prediction
                # probability = signal.probability
                # if prediction is not None and probability is not None:
                #     message += f"🧠 *Model Prediction*: {prediction} (🎯 Confidence: {round(probability * 100, 2)}%) \n"
                # else:
                #     message += "⚠️ *Model Prediction unavailable* \n"
                
                message += f"_Signal generated automatically._"
                print(message)
                plot_annotated_trade_setup(csv_file_path, signal.trade_data['entry_price'], signal.trade_data['stop_loss'], signal.trade_data['target_price'], signal.stock_name, signal.trade_type, out_image_path)
                setup_telegram_bot.send_msg(img_path=out_image_path, message=message)
                print(f"✅ Sent trade signal for {stock_seg} {signal.stock_name}")

                # Mark as sent
                signal.is_send = True
                db.merge(signal)

            db.commit()

    except Exception as e:
        print(f"❌ Error in trade signal alert: {e}")
    finally:
        db.close()


def trade_signal_alert_loop():
    while True:
        check_trade_signals()
        time.sleep(900)


def setup_alert_engine():
    Thread(target=trade_signal_alert_loop, daemon=True).start()


def start_entry_alert_engine():
    preload_instrument_tokens()
    preload_future_and_commodity_tokens()
    Thread(target=dynamic_subscription_loop, daemon=True).start() # initial
    alert_loop()
    # Thread(target=alert_loop, daemon=True).start()
    


# ADANI_ENTERPRISES None True ADANIENT
# AXIS_BANK None True AXISBANK
# APOLLO_HOSPITALS None True APOLLOHOSP
# ADANI_TOTAL_GAS None True ATGL