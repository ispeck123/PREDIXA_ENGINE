import sys, os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from alert_engine.alert import start_entry_alert_engine, setup_alert_engine
from shared.config.settings import validate_required_config
import time


if __name__ == "__main__":
    validate_required_config()
    setup_alert_engine()
    while True:
        time.sleep(60)

# from alert_engine.notification import send_push_notification

