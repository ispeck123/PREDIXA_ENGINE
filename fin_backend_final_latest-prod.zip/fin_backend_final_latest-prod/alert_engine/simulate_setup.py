import pandas as pd
import mplfinance as mpf
import matplotlib.pyplot as plt
from datetime import timedelta
from alert_engine.telegram_alert import SETUP_TELEGRAM_MSG
from shared.utils.logger import logger
from shared.config.settings import stock_logic_config, stock_data_dir_config
import os

tmsgs = SETUP_TELEGRAM_MSG()

def plot_annotated_trade_setup(csv_path, entry, stoploss, target, symbol, trade_type, image_path, future_days=10):
    # 1. Prepare last 90 candles and add dummy candles for future
    df = pd.read_csv(csv_path)
    df['tradeDate'] = pd.to_datetime(df['tradeDate'], dayfirst=True)

    df.rename(columns={
        'open': 'Open',
        'high': 'High',
        'low': 'Low',
        'close': 'Close',
        'qty': 'Volume'  # optional
    }, inplace=True)
    df.set_index('tradeDate', inplace=True)
    df = df.tail(365)
    df = df.dropna(subset=['Open', 'High', 'Low', 'Close'])
    df[['Open', 'High', 'Low', 'Close']] = df[['Open', 'High', 'Low', 'Close']].apply(pd.to_numeric, errors='coerce')
    df = df.dropna(subset=['Open', 'High', 'Low', 'Close'])
    # last_ts = df.index[-1]
    # last_row = df.iloc[-1]

    # # Add future candles to allow space for annotations
    # for i in range(1, future_days + 1):
    #     future_ts = last_ts + timedelta(days=i)
    #     df.loc[future_ts] = [None] * len(df.columns)

    # df.sort_index(inplace=True)
    last_candle_idx = len(df) - 1
    future_candle_idx = last_candle_idx + future_days
    
    fig, axes = mpf.plot(
        df,
        type='candle',
        style='charles',
        figsize=(12, 6),
        title=f"{symbol.upper()} - {trade_type.upper()} Setup ON {df.index[-1].strftime('%Y-%b-%d')}",
        ylabel='Price',
        returnfig=True
    )

    ax = axes[0]
    ax.plot([last_candle_idx, future_candle_idx], [entry, entry], color='blue', linestyle='--', linewidth=1.5)
    ax.plot([last_candle_idx, future_candle_idx], [stoploss, stoploss], color='red', linestyle='--', linewidth=1.5)
    ax.plot([last_candle_idx, future_candle_idx], [target, target], color='green', linestyle='--', linewidth=1.5)
    # # === Dynamic Y-axis padding ===


    # # === Add text annotations at the far right ===
    label_x = df.index[-1] + timedelta(days=1)  # slight push to right
    labels = [("Entry", entry, "blue"), ("Stoploss", stoploss, "red"), ("Target", target, "green")]

    for label, price, color in labels:
        ax.text(
            1.005,  # slightly outside the right edge (axes fraction)
            price,  # y = price level
            f"{label}: {price:.2f}",
            transform=ax.get_yaxis_transform(),  # align y in data space, x in axes fraction
            fontsize=9,
            fontweight='bold',
            color=color,
            verticalalignment='center',
            bbox=dict(facecolor='white', edgecolor=color, boxstyle='round,pad=0.3')
        )
    # # Slight X-axis extension to allow text visibility
    # xticks = [df.index[-1]]
    # ax.set_xticks(xticks)
    ax.set_xlim(0, len(df) + future_days)
    # Save
    fig.savefig(image_path, dpi=300)
    plt.close(fig)
    print(f"✅ Final clean setup saved: {image_path}")

def generate_trade_caption(trade_result: dict) -> str:
    stock = trade_result.get("STOCK_NAME", "Unknown")
    timeframe = trade_result.get("TIME_FR", "N/A")
    price_cmp = trade_result.get("PRICE_CMP", "N/A")
    trade_type = trade_result.get("TRADE_TYPE", "N/A").upper()
    timestamp = trade_result.get("TIMESTAMP", "")
    prediction = trade_result.get("PREDICTION")
    probability = max(trade_result.get("PROBABILITY"))
    
    trade_data = trade_result.get(trade_type, {})
    entry_price = trade_data.get("entry_price", "N/A")
    target_price = trade_data.get("target_price", "N/A")
    stop_loss = trade_data.get("stop_loss", "N/A")

    caption = f"[{timestamp}] {trade_type} Trade Signal for {stock} (Timeframe: {timeframe} min)\n"
    caption += f"🔹 CMP: {price_cmp} | Entry: {entry_price} | Target: {target_price} | Stop Loss: {stop_loss}\n"

    if prediction is not None and probability is not None:
        caption += f"🧠 Model Prediction: {prediction} (Confidence: {round(probability * 100, 2)}%)"
    else:
        caption += "⚠️ Model Prediction unavailable"

    return caption


def send_setup_alert_telegram(setup_data):
    try:
        time_fs = setup_data['TIME_FR']
        st_name = str(setup_data['STOCK_NAME']).lower()
        trade_type = str(setup_data['TRADE_TYPE']).upper()
        frame = getattr(stock_logic_config, f'TIME_FRAMES_{time_fs}')[-1]
        caption = generate_trade_caption(setup_data)
        image_path = f"./data/alert_setups/{setup_data['STOCK_NAME']}_{frame}.png"
        csv_path = os.path.join(stock_data_dir_config.indian_stock_data_dir, 'latest_data_csv', f'{st_name}_{frame}.csv')
        plot_annotated_trade_setup(csv_path, setup_data[trade_type]['entry_price'], setup_data[trade_type]['stop_loss'], setup_data[trade_type]['target_price'], setup_data['STOCK_NAME'], setup_data['TRADE_TYPE'], image_path)
        tmsgs.send_msg(img_path=image_path, message=caption)
    except Exception as ex:
        logger.exception(ex, stack_info=True)


