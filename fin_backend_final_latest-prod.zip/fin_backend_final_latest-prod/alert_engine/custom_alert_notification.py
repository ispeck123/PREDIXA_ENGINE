import sys, os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from concurrent.futures import ThreadPoolExecutor, as_completed
from alert_engine.notification import send_push_notification
from shared.db.dbconn import DBConnection
from shared.db.db_model import CustomAlert, Ind_StockMaster, TradeSignal, UserDeviceToken
from data_fetchers.fyers.fyers_ticker import FyersTickerManager
#from data_fetchers.fyers.indian_futures_data_updater import Indian_future_data_handler
#from data_fetchers.fyers.indian_commodity_data_updater import MCXFutureDataHandler
#from alert_engine.telegram_alert import SETUP_TELEGRAM_MSG, ENTRY_TELEGRAM_MSG
#from alert_engine.simulate_setup import plot_annotated_trade_setup
#from shared.config.settings import stock_data_dir_config, stock_logic_config
from datetime import datetime, timedelta
from threading import Thread
import traceback
import time
import pytz
from datetime import time as dt_time
import logging  
import json
import requests
from shared.config.settings import validate_required_config


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger()
time_zone = pytz.timezone('Asia/Kolkata')
# Global cache
symbol_token_map = {}

#future_and_commodity_token_map = {}

subscribed_tokens = set()
cached_alerts = []

fyers_ws_manager = FyersTickerManager()
#setup_telegram_bot = SETUP_TELEGRAM_MSG()
#entry_telegram_bot = ENTRY_TELEGRAM_MSG()

#ifdh = Indian_future_data_handler()
#mcxfdh = MCXFutureDataHandler()

dbc = DBConnection()


def get_alert_fcm_token(alert_id: int) -> str:
    dbc = DBConnection()
    db = dbc.get_session()

    try:
        result = (
            db.query(UserDeviceToken.fcm_token)
            .join(CustomAlert, UserDeviceToken.user_id == CustomAlert.user_id)
            .filter(CustomAlert.id == alert_id)
            .all()
        )
        return [row.fcm_token for row in result] if result else []
    except Exception as ex:
        logger.exception(ex, stack_info=True)
        return None
    finally:
        db.close()


def check_and_notify(alert: CustomAlert):
    dbc = DBConnection()
    session = dbc.get_session()

    #if alert.notification_sent == False:
    push_alert = False
    token = None
    token = symbol_token_map.get(alert.stock_symbol)
    # print("**************************************")
    # print(token)
    # print("**************************************")
    if token:
        current_datetime = datetime.now(tz=time_zone)
        current_price = fyers_ws_manager.get_latest_price(token)
        # print("**************************************")
        # print(token)
        # print(current_price)
        # print(type(current_price))
        # print("**************************************")
        if current_price is not None:
            
            if (alert.condition == 1 or alert.condition == True) and current_price >= alert.threshold:
                push_alert = True
            elif (alert.condition == 0 or alert.condition == False) and current_price <= alert.threshold:
                push_alert = True
            else:
                return
                #pass
            
    if push_alert:
        row = session.query(CustomAlert).filter(CustomAlert.id == alert.id).all()
        if len(row) > 0:
            row[0].notification_sent = True
            row[0].notification_sent_at = current_datetime
            session.add(row[0])
            session.commit()
            logger.info(f"********* Notification pushed: {row[0].stock_symbol} | Trigger Price: {current_price} | {current_datetime} ************")

            #title = f"{alert.stock_symbol} {alert_type.upper()} Alert"
            title = f"Price Alert Triggered Notifications"
            #body = f"Current price ₹{current_price} is within your {alert_type} range: ₹{price_min} - ₹{price_max}"
            #body = f"{current_datetime}: {alert.stock_symbol} has hit target ₹{alert.threshold}"
            
            # all_notifications = dbc.raw_query(f"""select ca.id, ca.user_id, ca.country_id, ca.exchange_id, ca.stock_symbol, 
            #                                     ca.threshold, ca.condition, ca.message, ca.created_at, ca.updated_at, ca.is_active, 
            #                                     ca.notification_sent, ca.notification_sent_at, ca.notification_seen, 
            #                                     ca.notification_seen_at, ism.stock_tick
            #                                     from custom_alerts as ca 
            #                                     inner join ind_stock_master as ism on ca.stock_symbol = ism.kite_symbol 
            #                                     where ca.is_active = 1 and ca.notification_sent = 1 and ca.notification_sent_at is not null  
            #                                     and ca.user_id = {alert.user_id} and ca.country_id = {alert.country_id} and ism.is_active = 1
            #                                     order by ca.notification_sent_at desc limit 100""")

            #print(all_notifications)
            # payload = {
            #     "notification": str(all_notifications)
            # }
            notification = dbc.raw_query(f"""select ca.id, ca.user_id, ca.country_id, ca.exchange_id, ca.stock_symbol, 
                                                 ca.threshold, ca.condition, ca.message, ca.created_at, ca.updated_at, ca.is_active, 
                                                 ca.notification_sent, ca.notification_sent_at, ca.notification_seen, 
                                                 ca.notification_seen_at, ism.stock_tick
                                                 from custom_alerts as ca 
                                                 inner join ind_stock_master as ism on ca.stock_symbol = ism.kite_symbol 
                                                 where ca.is_active = 1 and ca.notification_sent = 1 and ca.notification_sent_at is not null  
                                                 and ca.id = {alert.id} and ism.is_active = 1""")
            if len(notification) > 0:
                print(json.dumps(notification[0]))
                fcm_token = get_alert_fcm_token(alert.id)
                for tokens in fcm_token:
                    logger.info("Sending notification...")
                    send_push_notification(
                        token = tokens,
                        title = title,
                        body = json.dumps(notification[0])   # Send as string
                    )
    
    
    session.close()
    dbc.close_engine()



def preload_instrument_tokens():
    """Load stock_symbol → instrument_token from ind_stock_master"""
    global symbol_token_map
    db = dbc.get_session()
    records = db.query(Ind_StockMaster).filter(Ind_StockMaster.is_active == 1).all()
    symbol_token_map = {
        record.kite_symbol: record.fyers_symbol
        for record in records if record.fyers_symbol
    }
    db.close()
    logger.info(f"✅ Loaded {len(symbol_token_map)} CASH instrument tokens")


def refresh_alert_subscriptions():
    """Refresh alert cache and subscribe to new tokens"""
    global subscribed_tokens, cached_alerts
    #print("cached_alerts :", cached_alerts)
    db = dbc.get_session()
    cached_alerts = db.query(CustomAlert).filter(CustomAlert.is_active == True, CustomAlert.notification_sent == False).all()
    # print(len(cached_alerts))
    db.close()
    new_tokens = set()
    for alert in cached_alerts:
        
        #if alert.notification_sent == False:
            token = symbol_token_map.get(alert.stock_symbol)
            # print(alert.stock_symbol, token, token not in subscribed_tokens)
            if token and token not in subscribed_tokens:
                new_tokens.add(token)

    if new_tokens:
        fyers_ws_manager.subscribe(list(new_tokens), fyers_ws_manager.fyers)
        subscribed_tokens.update(new_tokens)
        logger.info(f"🔄 Subscribed {len(new_tokens)} new tokens dynamically.")


def dynamic_subscription_loop(interval_seconds=10):
    """Refresh subscriptions and alert cache periodically"""
    while True:
        if is_market_open():
            refresh_alert_subscriptions()
            time.sleep(interval_seconds)
        else:
            break

def alert_loop():
    global subscribed_tokens, cached_alerts
    logger.info("🚀 Starting alert monitoring loop...")
    while True:
        if is_market_open():
            if cached_alerts:
                with ThreadPoolExecutor(max_workers=10) as pool:
                    futures = {pool.submit(check_and_notify, alert): alert for alert in cached_alerts}
                    for future in as_completed(futures):
                        alert = futures[future]
                        try:
                            future.result()
                        except Exception as e:
                            logger.error(f"❌ Error while processing alert ID {getattr(alert, 'id', 'N/A')} for stock {alert.stock_symbol}: {e}")
                            traceback.print_exc()
                    # pool.map(check_and_notify, cached_alerts)

            time.sleep(15)
        else:
            logger.info(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} : Market is closed .....")
            break

def get_market_holidays():
    try:
        url = "https://www.nseindia.com/api/holiday-master?type=trading"
        headers = {
            "User-Agent": "Mozilla/5.0",
            "Accept": "application/json",
            "Referer": "https://www.nseindia.com/"
        }

        session = requests.Session()
        session.headers.update(headers)

        response = session.get(url)
        response.raise_for_status()

        data = response.json()
        holidays = data["CM"]  # Capital Market (Equity)
        holiday_dates = [datetime.strptime(hol['tradingDate'], "%d-%b-%Y") for hol in holidays]
        #print(holiday_dates)
        holiday_dates = [datetime.strftime(hol, "%Y-%m-%d")for hol in holiday_dates]
        #print(holiday_dates)
        return holiday_dates
    except:
        return []





def is_market_open(now: datetime = None) -> bool:
    """
    Check if current datetime is within NSE/BSE trading hours (India).
    Trading hours: 09:15 AM - 03:30 PM IST, Monday - Friday.
    Weekends and holidays excluded (holidays can be added manually).
    """
    # Use IST timezone
    ist = pytz.timezone("Asia/Kolkata")
    if now is None:
        now = datetime.now(ist)
    else:
        # ensure tz-aware
        if now.tzinfo is None:
            now = ist.localize(now)
        else:
            now = now.astimezone(ist)

    # Weekday check (0 = Monday, 6 = Sunday)
    if now.weekday() >= 5:
        return False  # Saturday or Sunday

    # Market hours
    market_open = dt_time(9, 13)   # 9:15 AM
    market_close = dt_time(15, 30) # 3:30 PM

    if market_open <= now.time() <= market_close:
        # Optional: check holidays (static list)
        holidays = get_market_holidays()
        today_str = now.strftime("%Y-%m-%d")
        if today_str in holidays:
            return False
        return True
    return False


def start_entry_alert_engine():
    preload_instrument_tokens()
    
    Thread(target=dynamic_subscription_loop, daemon=True).start() # initial
    alert_loop()
    # Thread(target=alert_loop, daemon=True).start()
    

if __name__ == "__main__":   
    validate_required_config()
    restart_interval = 2
    start_time = datetime.now() 
    while True:
        if (datetime.now() - start_time) >= timedelta(hours = restart_interval):
            logger.info("Restarting now...")
            os.execv(sys.executable, [sys.executable] + sys.argv)
        if is_market_open():
            start_entry_alert_engine()
            time.sleep(10)
        else:
            logger.info(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} : Market is closed .....")
            time.sleep(10)

# ADANI_ENTERPRISES None True ADANIENT
# AXIS_BANK None True AXISBANK
# APOLLO_HOSPITALS None True APOLLOHOSP
# ADANI_TOTAL_GAS None True ATGL