import telegram
import asyncio
import logging

logger = logging.getLogger()

class SETUP_TELEGRAM_MSG:
    def __init__(self):
        self.token = "7443534342:AAGbIiCLjYbkjkI2z2Bt5nOJkzQAnwQqgbs"
        self.channel_id = "-1002168429814"  # Replace with actual chat_id

    async def _send(self, message=None, img_path=None, doc_path=None, video_path=None):
        try:
            bot = telegram.Bot(token=self.token)
            if img_path:
                with open(img_path, 'rb') as f:
                    await bot.send_photo(chat_id=self.channel_id, photo=f, caption=message)
            elif doc_path:
                with open(doc_path, 'rb') as f:
                    await bot.send_document(chat_id=self.channel_id, document=f)
            elif video_path:
                with open(video_path, 'rb') as f:
                    await bot.send_video(chat_id=self.channel_id, video=f, caption=message)
            elif message:
                await bot.send_message(chat_id=self.channel_id, text=message, parse_mode=telegram.constants.ParseMode.MARKDOWN)
                print("✅ Message sent to Telegram.")
            return True
        except Exception as e:
            logger.exception("Telegram send failed:")
            return False

    def send_msg(self, message=None, img_path=None, doc_path=None, video_path=None):
        return asyncio.run(self._send(message, img_path, doc_path, video_path))
    

class ENTRY_TELEGRAM_MSG:
    def __init__(self):
        self.token = "7443534342:AAGbIiCLjYbkjkI2z2Bt5nOJkzQAnwQqgbs"
        self.channel_id = "-1002376861027"  # Replace with actual chat_id

    async def _send(self, message=None, img_path=None, doc_path=None, video_path=None):
        try:
            bot = telegram.Bot(token=self.token)
            if img_path:
                with open(img_path, 'rb') as f:
                    await bot.send_photo(chat_id=self.channel_id, photo=f, caption=message)
            elif doc_path:
                with open(doc_path, 'rb') as f:
                    await bot.send_document(chat_id=self.channel_id, document=f)
            elif video_path:
                with open(video_path, 'rb') as f:
                    await bot.send_video(chat_id=self.channel_id, video=f, caption=message)
            elif message:
                await bot.send_message(chat_id=self.channel_id, text=message, parse_mode=telegram.constants.ParseMode.MARKDOWN)
                print("✅ Message sent to Telegram.")
            return True
        except Exception as e:
            logger.exception("Telegram send failed:")
            return False

    def send_msg(self, message=None, img_path=None, doc_path=None, video_path=None):
        return asyncio.run(self._send(message, img_path, doc_path, video_path))