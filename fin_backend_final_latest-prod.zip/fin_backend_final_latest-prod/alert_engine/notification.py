import firebase_admin
from firebase_admin import credentials, messaging
from shared.db.dbconn import DBConnection
from shared.db.db_model import UserAlert, User, UserDeviceToken
from shared.utils.logger import logger
import logging

logger = logging.getLogger()


cred = credentials.Certificate("./firebase_auth/ispeck-finprod-firebase-adminsdk-fbsvc-6f8f6e2364.json")
firebase_admin.initialize_app(cred)

dbc = DBConnection()
session = dbc.get_session()

# def get_active_alerts():
#     dbc = DBConnection()
#     db = dbc.get_session()
#     return db.query(UserAlert).filter(UserAlert.is_active == True).all()




def send_push_notification(token: str, title: str, body: str):
    # message = messaging.Message(
    #     notification=messaging.Notification(title=title, body=body),
    #     token=token,
    # )
    message = messaging.Message(
        data={
            "title": title,
            "body": body,              # your JSON string here
            "notification_type": "custom", # optional
        },
        token=token,
    )
    try:
        response = messaging.send(message)
        logger.info(f"✅ Sent to {token}  : \n{response}")
    except Exception as e:
        logger.exception(e, stack_info=True, exc_info=True)
        logger.error(f"❌ Error sending to {token}  : \n{e}")
        delete_expired_token(token)


def get_alert_fcm_token(alert_id: int) -> str:
    dbc = DBConnection()
    db = dbc.get_session()

    try:
        result = (
            db.query(UserDeviceToken.fcm_token)
            .join(UserAlert, UserDeviceToken.user_id == UserAlert.user_id)
            .filter(UserAlert.id == alert_id)
            .all()
        )
        return [row.fcm_token for row in result] if result else []
    except Exception as ex:
        logger.exception(ex, stack_info=True)
        return None
    finally:
        db.close()


def delete_expired_token(token: str):
    try:
        expired_token = session.query(UserDeviceToken).filter(UserDeviceToken.fcm_token == token).all()
        if expired_token and len(expired_token) > 0:
            logger.info(f"Deleting expired token: {token}")
            session.delete(expired_token[0])
            session.commit()
    except Exception as ex:
        logger.exception(ex, stack_info=True)
        logger.error(f"❌ Error deleting expired token: {token}  : \n{ex}")
    finally:
        session.close()