import os
import pandas as pd
from shared.config.settings import stock_data_dir_config, stock_logic_config
from stock_model.model_inference import SingleFilePreprocessor, SingleStockPredictor
from shared.config.settings import stock_model_config


class Indian_model_predictor:
    def __init__(self, tick: str, time_frame, trade_type, last_d_time):
        self.time_fr = getattr(stock_logic_config, f'TIME_FRAMES_{time_frame}')[-1]
        self.tick = tick #.lower()
        self.last_dt = last_d_time
        self.preprocess_data_count = 120
        self.time_frame = time_frame
        
        if time_frame == 1:
            if trade_type.lower() == "buy":
                self.model_path = stock_model_config.indian_buy_model_path
                self.correlated_features_path = stock_model_config.indian_buy_model_features_path
                self.preprocess_data_count = 180
            else:
                self.model_path = stock_model_config.indian_sell_model_path
                self.correlated_features_path = stock_model_config.indian_sell_model_features_path
        elif time_frame == 2:
            if trade_type.lower() == "buy":
                self.model_path = stock_model_config.indian_buy_60_model_path
                self.correlated_features_path = stock_model_config.indian_buy_60_model_features_path
                self.preprocess_data_count = 720
            else:
                self.model_path = stock_model_config.indian_sell_60_model_path
                self.correlated_features_path = stock_model_config.indian_sell_60_model_features_path
        elif time_frame == 3:
            if trade_type.lower() == "buy":
                self.model_path = stock_model_config.indian_buy_model_path
                self.correlated_features_path = stock_model_config.indian_buy_model_features_path
            else:
                self.model_path = stock_model_config.indian_sell_model_path
                self.correlated_features_path = stock_model_config.indian_sell_model_features_path
                
        elif time_frame == 25:
            if trade_type.lower() == "buy":
                self.model_path = stock_model_config.indian_buy_75_model_path
                self.correlated_features_path = stock_model_config.indian_buy_75_model_features_path
            else:
                self.model_path = stock_model_config.indian_sell_60_model_path
                self.correlated_features_path = stock_model_config.indian_sell_60_model_features_path
        else:
            if trade_type.lower() == "buy":
                self.model_path = stock_model_config.indian_buy_model_path
                self.correlated_features_path = stock_model_config.indian_buy_model_features_path
            else:
                self.model_path = stock_model_config.indian_sell_model_path
                self.correlated_features_path = stock_model_config.indian_sell_model_features_path

    
    def fetch_model_stats(self, entry_p, target_p, stop_p):

        file_path = os.path.join(stock_data_dir_config.indian_stock_data_dir, 'latest_data_csv', f'{self.tick}_{self.time_fr}.csv')
        preprocessor = SingleFilePreprocessor(

            entry_price=entry_p,
            target_price=target_p,
            stoploss_price=stop_p,
            data=pd.read_csv(file_path),
            tick=self.tick,
            last_d_time=self.last_dt,
            preprocess_data_count=self.preprocess_data_count,
            tfr=self.time_frame
        )
        feature_df = preprocessor.run()

        ### Step 2: Predict
        predictor = SingleStockPredictor(
            model_path=self.model_path,
            correlated_features_path=self.correlated_features_path
        )
        prediction,_,list_prob = predictor.run(feature_df)

        # print(f"\n Final Prediction for stock {preprocessor.order_id}: {prediction} {prob[dict_lab[prediction]]} {list_prob}")
        print(f"\n Final Prediction for stock {preprocessor.tick}: {prediction} {max(list_prob)}")
        return prediction, max(list_prob)
    
    def fetch_model_stats_future_and_commodity(self, entry_p, target_p, stop_p, exp_num, segment):
        if segment == 'futures':
            file_path = os.path.join(stock_data_dir_config.indian_stock_future_data_dir, 'latest_data_csv', f'{self.tick}_{exp_num}_{self.time_fr}.csv')
        else:
            file_path = os.path.join(stock_data_dir_config.indian_commodity_data, 'latest_data_csv', f'{self.tick}_{exp_num}_{self.time_fr}.csv')

        preprocessor = SingleFilePreprocessor(

            entry_price=entry_p,
            target_price=target_p,
            stoploss_price=stop_p,
            data=pd.read_csv(file_path),
            tick=self.tick, 
            last_d_time=self.last_dt,
            preprocess_data_count=self.preprocess_data_count
        )
        feature_df = preprocessor.run()

        ### Step 2: Predict
        predictor = SingleStockPredictor(
            model_path=self.model_path,
            correlated_features_path=self.correlated_features_path
        )
        prediction,_,list_prob = predictor.run(feature_df)

        if float(max(list_prob)) < stock_model_config.model_probability_threshold:
            prediction = "failed"
        # print(f"\n Final Prediction for stock {preprocessor.order_id}: {prediction} {prob[dict_lab[prediction]]} {list_prob}")
        print(f"\n Final Prediction for stock {preprocessor.tick}: {prediction} {max(list_prob)}")
        return prediction, float(max(list_prob))
    

class US_model_predictor:
    def __init__(self, tick, time_frame, last_d_time):
        self.time_fr = getattr(stock_logic_config, f'TIME_FRAMES_{time_frame}')[-1]
        self.tick = tick
        self.last_dt = last_d_time

    def fetch_model_stats(self, entry_p, target_p, stop_p):

        file_path = os.path.join(stock_data_dir_config.us_data_dir, 'processed_data_files', f'{self.tick}_{self.time_fr}.csv')
        preprocessor = SingleFilePreprocessor(

            entry_price=entry_p,
            target_price=target_p,
            stoploss_price=stop_p,
            data=pd.read_csv(file_path),
            tick=self.tick,
            last_d_time=self.last_dt
        )
        feature_df = preprocessor.run()

        ### Step 2: Predict
        predictor = SingleStockPredictor(
            model_path=stock_model_config.us_model_path,
            correlated_features_path=stock_model_config.us_model_features_path
        )
        prediction,_,list_prob = predictor.run(feature_df)

        # print(f"\n Final Prediction for stock {preprocessor.order_id}: {prediction} {prob[dict_lab[prediction]]} {list_prob}")
        print(f"\n Final Prediction for stock {preprocessor.tick}: {prediction} {list_prob}")
        return prediction, list_prob