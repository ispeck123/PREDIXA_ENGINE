import pickle
import pandas as pd
# from preprocess import SingleFilePreprocessor
from ta.momentum import RSIIndicator
from ta.trend import MACD, EMAIndicator
import numpy as np
import talib

class SingleStockPredictor:
    def __init__(self, model_path, correlated_features_path):
        self.model_path = model_path
        self.correlated_features_path = correlated_features_path
        self.dict_labels = {0: "failed", 1: "success"}
        self.dict_lab = {"failed":0, "success":1}


    def load_model(self):
        with open(self.model_path, 'rb') as f:
            self.model = pickle.load(f)


    def predict(self, feature_df):
        # Drop correlated features
        with open(self.correlated_features_path, 'rb') as f:
            correlated_features = pickle.load(f)

        feature_df = feature_df.drop(columns=[col for col in correlated_features if col in feature_df.columns])

        y_pred = self.model.predict(feature_df)[0]
        predicted_label = self.dict_labels[y_pred]
        y_proba = self.model.predict_proba(feature_df)[0]   # returns [prob_of_class_0, prob_of_class_1]

        ####### for ensemble -1 and for random forest -3 ########
        if self.model_path.split('/')[-1] == "best_rf_model_INDIA.pkl":
            all_proba = np.mean(np.sort([estimator.predict_proba(feature_df)[0][self.dict_lab[predicted_label]] for estimator in self.model.estimators_])[-60:])
            
        else:
            all_proba = self.model.predict_proba(feature_df)[0]


        #predicted_label = self.dict_labels[y_pred]

        print(f"Predicted Result: {predicted_label}")
        return predicted_label,y_proba, all_proba

    def run(self, feature_df):
        self.load_model()
        return self.predict(feature_df)



class SingleFilePreprocessor:
    def __init__(self, entry_price,target_price,stoploss_price,data,tick, last_d_time, preprocess_data_count = None,tfr=None):

        # self.order_csv_path = order_csv_path
        # self.mapping_csv_path = mapping_csv_path
        self.tfr = tfr
        self.entry_price = entry_price
        self.target_price=target_price
        self.stoploss_price=stoploss_price
        self.order_df=data
        self.tick=tick
        self.last_d_time = last_d_time
        self.preprocess_data_count = preprocess_data_count if preprocess_data_count else 120
        self.EPS = 1e-12
        self.safe_ratio = lambda a,b : a/(b+self.EPS)
        self.new_feat = pd.DataFrame(columns=['return_5','return_10','return_20','ma_30_over_120','ema_50_ratio','rsi_14','atr_abs',
                                        'atr_pct','volatility_20','high_low_range_5','channel_pos20','gap1','macd_diff','risk_reward',
                                        'dist_target_atr','dist_stop_atr','target_vs_entry','entry_vs_stoploss','roc_30','ema_100_ratio',
                                        'volatility_10','close_vs_high_5','close_vs_low_5','entry_vs_close','target_vs_close','stoploss_vs_close'])


    def preprocess(self, atr_period=14):

        # target_price_norm = (self.target_price - self.entry_price) / self.entry_price
        # stoploss_price_norm = (self.stoploss_price - self.entry_price) / self.entry_price
        self.order_df['tradeDate'] = pd.to_datetime(self.order_df['tradeDate'], dayfirst = True)
        self.order_df = self.order_df[self.order_df.tradeDate <= self.last_d_time]
        
        ds = self.order_df[['open', 'high', 'low', 'close']].iloc[-self.preprocess_data_count:, :]
        # ds_normalized = ds / self.entry_price
        open_ = ds['open'].astype(float)
        close = ds['close'].astype(float)
        high = ds['high'].astype(float)
        low = ds['low'].astype(float)
        
        return_5 =	self.safe_ratio(close.iloc[-1] - close.iloc[-6],  close.iloc[-6])
        return_10 =	self.safe_ratio(close.iloc[-1] - close.iloc[-11], close.iloc[-11])
        return_20 =	self.safe_ratio(close.iloc[-1] - close.iloc[-21], close.iloc[-21])
        
        sma30 = close.iloc[-30:].mean()
        sma120 = close.iloc[-120:].mean()
        ma_30_over_120 = self.safe_ratio(sma30, sma120) - 1.0
        
        ema50 = close.ewm(span=50, adjust=False).mean().iloc[-1]
        ema100 = close.ewm(span=100, adjust=False).mean().iloc[-1]
        ema_50_ratio  = self.safe_ratio(close.iloc[-1], ema50)
        ema_100_ratio = self.safe_ratio(close.iloc[-1], ema100)  
        
        rsi_14 = RSIIndicator(close=close, window=14).rsi().iloc[-1]
        
        macd_fast = close.ewm(span=12, adjust=False).mean()
        macd_slow = close.ewm(span=26, adjust=False).mean()
        macd_series = macd_fast - macd_slow
        macd_signal = macd_series.ewm(span=9, adjust=False).mean()
        macd_diff = (macd_series.iloc[-1] - macd_signal.iloc[-1])
        
        vol10 = self.safe_ratio(close.iloc[-10:].std(), close.iloc[-10:].mean())
        vol20 = self.safe_ratio(close.iloc[-20:].std(), close.iloc[-20:].mean())
        
        
        atr_arr = talib.ATR(high.values, low.values, close.values, timeperiod=atr_period)
        atr_abs = float(atr_arr[-1])
        atr_pct = self.safe_ratio(atr_abs, close.iloc[-1])
        
        high_low_range_5 = self.safe_ratio((high.iloc[-5:].max() - low.iloc[-5:].min()), close.iloc[-1])
        
        hi20 = high.iloc[-20:].max()
        lo20 = low.iloc[-20:].min()
        channel_pos20 = self.safe_ratio(close.iloc[-1] - lo20, hi20 - lo20)
        
        gap1 = self.safe_ratio(open_.iloc[-1] - close.iloc[-2], close.iloc[-2])
        
        entry_vs_close    = self.safe_ratio(self.entry_price - close.iloc[-1], close.iloc[-1])
        target_vs_close   = self.safe_ratio(self.target_price - close.iloc[-1], close.iloc[-1])
        stop_vs_close     = self.safe_ratio(self.stoploss_price - close.iloc[-1],   close.iloc[-1])

        target_vs_entry   = self.safe_ratio(self.target_price - self.entry_price, self.entry_price)
        entry_vs_stoploss = self.safe_ratio(self.entry_price - self.stoploss_price,  self.entry_price)
        risk_reward       = self.safe_ratio(self.target_price - self.entry_price, self.entry_price - self.stoploss_price)

        dist_target_atr = self.safe_ratio(self.target_price - self.entry_price, atr_abs)
        dist_stop_atr   = self.safe_ratio(self.entry_price - self.stoploss_price,   atr_abs)

        # --- Longer momentum (optional) ---
        roc_30 = self.safe_ratio(close.iloc[-1] - close.iloc[-31], close.iloc[-31]) 

        # --- Breakout proximity (optional) ---
        close_vs_high_5 = self.safe_ratio(close.iloc[-1] - high.iloc[-5:].max(), high.iloc[-5:].max())
        close_vs_low_5  = self.safe_ratio(close.iloc[-1] - low.iloc[-5:].min(),  low.iloc[-5:].min())
        
        self.new_feat.loc[len(self.new_feat)] = [
                        return_5, return_10, return_20, ma_30_over_120, ema_50_ratio,
                        rsi_14, atr_abs, atr_pct, vol20, high_low_range_5,
                        channel_pos20, gap1, macd_diff, risk_reward, dist_target_atr,
                        dist_stop_atr, target_vs_entry, entry_vs_stoploss,
                        roc_30, ema_100_ratio, vol10,close_vs_high_5,close_vs_low_5,
                        entry_vs_close, target_vs_close, stop_vs_close
                    ]
        

        return self.new_feat
    





    def preprocess_60(self, atr_period=21):

        # target_price_norm = (self.target_price - self.entry_price) / self.entry_price
        # stoploss_price_norm = (self.stoploss_price - self.entry_price) / self.entry_price
        self.order_df['tradeDate'] = pd.to_datetime(self.order_df['tradeDate'], dayfirst = True)
        self.order_df = self.order_df[self.order_df.tradeDate <= self.last_d_time]
        
        ds = self.order_df[['open', 'high', 'low', 'close']].iloc[-self.preprocess_data_count:, :]
        # ds_normalized = ds / self.entry_price
        open_ = ds['open'].astype(float)
        close = ds['close'].astype(float)
        high = ds['high'].astype(float)
        low = ds['low'].astype(float)
        
        return_5 =	self.safe_ratio(close.iloc[-1] - close.iloc[-6],  close.iloc[-6])
        return_10 =	self.safe_ratio(close.iloc[-1] - close.iloc[-11], close.iloc[-11])
        return_20 =	self.safe_ratio(close.iloc[-1] - close.iloc[-21], close.iloc[-21])

        sma30 = close.iloc[-30:].mean()
        sma120 = close.iloc[-90:].mean()
        ma_30_over_120 = self.safe_ratio(sma30, sma120) - 1.0
        
        ema50 = close.ewm(span=20, adjust=False).mean().iloc[-1]
        ema100 = close.ewm(span=60, adjust=False).mean().iloc[-1]
        ema_50_ratio  = self.safe_ratio(close.iloc[-1], ema50)
        ema_100_ratio = self.safe_ratio(close.iloc[-1], ema100)  
        
        rsi_14 = RSIIndicator(close=close, window=21).rsi().iloc[-1]
        
        macd_fast = close.ewm(span=12, adjust=False).mean()
        macd_slow = close.ewm(span=26, adjust=False).mean()
        macd_series = macd_fast - macd_slow
        macd_signal = macd_series.ewm(span=9, adjust=False).mean()
        macd_diff = (macd_series.iloc[-1] - macd_signal.iloc[-1])
        
        vol10 = self.safe_ratio(close.iloc[-20:].std(), close.iloc[-20:].mean())
        vol20 = self.safe_ratio(close.iloc[-60:].std(), close.iloc[-60:].mean())
        
        
        atr_arr = talib.ATR(high.values, low.values, close.values, timeperiod=atr_period)
        atr_abs = float(atr_arr[-1])
        atr_pct = self.safe_ratio(atr_abs, close.iloc[-1])
        
        high_low_range_5 = self.safe_ratio((high.iloc[-20:].max() - low.iloc[-20:].min()), close.iloc[-1])
        
        hi20 = high.iloc[-60:].max()
        lo20 = low.iloc[-60:].min()
        channel_pos20 = self.safe_ratio(close.iloc[-1] - lo20, hi20 - lo20)
        
        gap1 = self.safe_ratio(open_.iloc[-1] - close.iloc[-2], close.iloc[-2])
        
        entry_vs_close    = self.safe_ratio(self.entry_price - close.iloc[-1], close.iloc[-1])
        target_vs_close   = self.safe_ratio(self.target_price - close.iloc[-1], close.iloc[-1])
        stop_vs_close     = self.safe_ratio(self.stoploss_price - close.iloc[-1],   close.iloc[-1])

        target_vs_entry   = self.safe_ratio(self.target_price - self.entry_price, self.entry_price)
        entry_vs_stoploss = self.safe_ratio(self.entry_price - self.stoploss_price,  self.entry_price)
        risk_reward       = self.safe_ratio(self.target_price - self.entry_price, self.entry_price - self.stoploss_price)

        dist_target_atr = self.safe_ratio(self.target_price - self.entry_price, atr_abs)
        dist_stop_atr   = self.safe_ratio(self.entry_price - self.stoploss_price,   atr_abs)

        # --- Longer momentum (optional) ---
        roc_30 = self.safe_ratio(close.iloc[-1] - close.iloc[-61], close.iloc[-61]) 

        # --- Breakout proximity (optional) ---
        # --- Breakout proximity (optional) ---
        close_vs_high_5 = self.safe_ratio(close.iloc[-1] - high.iloc[-10:].max(), high.iloc[-10:].max())
        close_vs_low_5  = self.safe_ratio(close.iloc[-1] - low.iloc[-10:].min(),  low.iloc[-10:].min())
        # label = self.label_dict[label_dir]
        
        # print(label)
        self.new_feat.loc[len(self.new_feat)] = [
                return_5, return_10, return_20, ma_30_over_120, ema_50_ratio,
                rsi_14, atr_abs, atr_pct, vol20, high_low_range_5,
                channel_pos20, gap1, macd_diff, risk_reward, dist_target_atr,
                dist_stop_atr, target_vs_entry, entry_vs_stoploss,
                roc_30, ema_100_ratio, vol10,close_vs_high_5,close_vs_low_5,
                entry_vs_close, target_vs_close, stop_vs_close
            ]
        

        return self.new_feat


    
    def run(self):
        # self.load_data()
        if self.tfr == 1: # daily
            df_features = self.preprocess()

        elif self.tfr == 2: # 60 minute
            df_features = self.preprocess_60()
        
        elif self.tfr == 25: # 75 minute
            df_features = self.preprocess_60()
        
        elif self.tfr == 5: # 125
            df_features = self.preprocess_60()
        
        elif self.tfr == 6:
            df_features = self.preprocess_60()
        
        else:
            df_features = self.preprocess_60()

        # feature_columns = [f'{col}_{stat}' for col in ['open', 'high', 'low', 'close', 'rsi', 'macd_line', 'ema', 'returns', 'target_price', 'stoploss_price'] for stat in ['mean', 'std', 'min', 'max']]
        # df_features = pd.DataFrame([features], columns=feature_columns)
        # print(df_features)
        return df_features