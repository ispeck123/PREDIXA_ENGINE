#!/usr/bin/env python3
import os, sys, time, signal, subprocess, logging
from datetime import datetime, time as dtime, timedelta, timezone, date
from zoneinfo import ZoneInfo
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
# --- config ---
IST = ZoneInfo("Asia/Kolkata")
OPEN_TIME   = dtime(9, 15)   # NSE regular session start
CLOSE_TIME  = dtime(15, 30)  # NSE regular session end

INGESTOR_CMD = os.getenv("INGESTOR_CMD", "python scripts/ingestor_service.py")
HOLIDAYS_FILE = os.getenv("HOLIDAYS_FILE")  # optional path: one YYYY-MM-DD per line
RESTART_BACKOFF_SEC = 5

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
log = logging.getLogger("runner")

def load_holidays():
    s = set()
    if not HOLIDAYS_FILE or not os.path.exists(HOLIDAYS_FILE):
        return s
    with open(HOLIDAYS_FILE, "r") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"): continue
            try:
                y,m,d = map(int, line.split("-"))
                s.add(date(y,m,d))
            except Exception:
                pass
    return s

HOLIDAYS = load_holidays()

def is_trading_day(dt_ist: datetime) -> bool:
    d = dt_ist.date()
    if dt_ist.weekday() >= 5:   # 5=Sat, 6=Sun
        return False
    if d in HOLIDAYS:
        return False
    return True

def todays_session_bounds(dt_ist: datetime):
    start = datetime.combine(dt_ist.date(), OPEN_TIME, tzinfo=IST)
    end   = datetime.combine(dt_ist.date(), CLOSE_TIME, tzinfo=IST)
    return start, end

def next_trading_day_start(after_ist: datetime) -> datetime:
    cur = after_ist + timedelta(days=1)
    while True:
        cur_mid = datetime.combine(cur.date(), OPEN_TIME, tzinfo=IST)
        if is_trading_day(cur_mid):
            return cur_mid
        cur += timedelta(days=1)

class IngestorProc:
    def __init__(self, cmd: str):
        self.cmd = cmd
        self.p: subprocess.Popen | None = None

    def start(self):
        if self.p and self.p.poll() is None:
            return
        log.info("Starting ingestor: %s", self.cmd)
        self.p = subprocess.Popen(self.cmd, shell=True, preexec_fn=os.setsid)

    def stop(self, timeout=20):
        if not self.p:
            return
        if self.p.poll() is not None:
            self.p = None
            return
        log.info("Stopping ingestor (SIGTERM)…")
        try:
            os.killpg(os.getpgid(self.p.pid), signal.SIGTERM)
        except Exception:
            pass
        t0 = time.time()
        while time.time() - t0 < timeout:
            if self.p.poll() is not None:
                self.p = None
                log.info("Ingestor stopped.")
                return
            time.sleep(0.5)
        log.warning("Force killing ingestor (SIGKILL)…")
        try:
            os.killpg(os.getpgid(self.p.pid), signal.SIGKILL)
        except Exception:
            pass
        self.p = None

    def running(self) -> bool:
        return self.p is not None and self.p.poll() is None

def main():
    ing = IngestorProc(INGESTOR_CMD)

    def handle_sig(sig, frame):
        log.info("Runner shutting down (signal %s)…", sig)
        ing.stop()
        sys.exit(0)

    signal.signal(signal.SIGINT, handle_sig)
    signal.signal(signal.SIGTERM, handle_sig)

    while True:
        now = datetime.now(IST)
        start_ist, end_ist = todays_session_bounds(now)

        if not is_trading_day(now):
            # ensure stopped, then sleep to next trading day
            if ing.running(): ing.stop()
            nxt = next_trading_day_start(now)
            sleep_s = max(1, int((nxt - now).total_seconds()))
            log.info("Non-trading day. Sleeping until %s IST (%ss)…", nxt.strftime("%Y-%m-%d %H:%M"), sleep_s)
            time.sleep(min(sleep_s, 3600))
            continue

        if now < start_ist:
            # before open: ensure stopped; sleep till open
            if ing.running(): ing.stop()
            sleep_s = max(1, int((start_ist - now).total_seconds()))
            log.info("Waiting for market open at %s IST (%ss)…", start_ist.strftime("%H:%M"), sleep_s)
            time.sleep(min(sleep_s, 300))  # wake periodically
            continue

        if now >= end_ist:
            # after close: ensure stopped; sleep until next trading day
            if ing.running(): ing.stop()
            nxt = next_trading_day_start(now)
            sleep_s = max(1, int((nxt - now).total_seconds()))
            log.info("Market closed. Next open %s IST (%ss).", nxt.strftime("%Y-%m-%d %H:%M"), sleep_s)
            time.sleep(min(sleep_s, 3600))
            continue

        # market open: ensure running
        if not ing.running():
            ing.start()

        # if it crashed, backoff & restart
        if not ing.running():
            log.warning("Ingestor not running during market hours. Restarting after backoff %ss…", RESTART_BACKOFF_SEC)
            time.sleep(RESTART_BACKOFF_SEC)
            continue

        # sleep a short step, but do not cross close time without loop checks
        time.sleep(5)

if __name__ == "__main__":
    main()
