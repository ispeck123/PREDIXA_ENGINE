# from fyers_apiv3 import fyersModel
# from data_fetchers.fyers.fyers_session import fyers_access_token_handler

# fah = fyers_access_token_handler()
# acc = fah.get_access_token()

# print(acc)

# client_id = str(acc).rsplit(":")[0]
# access_token = str(acc).rsplit(":")[1]

# # Initialize the FyersModel instance with your client_id, access_token, and enable async mode
# fyers = fyersModel.FyersModel(client_id=client_id, token=access_token,is_async=False, log_path="")


# response1 = fyers.holdings()
# response2 = fyers.gtt_orderbook()
# print("Holdings:")
# print(response1)
# print("GTTS:")
# print(response2)




# classified = classify_gtt_orders(response1, response2)
# print(classified)

# fah.main()
import cv2


from datetime import datetime


date = datetime.now().date()
cap = cv2.VideoCapture('rtsp://admin:$ecret123@203.126.119.211:554/Streaming/Channels/601')

while True: 
    ret, frame = cap.read()
    # cv2.imshow('frame', frame)
    print(frame.shape)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()