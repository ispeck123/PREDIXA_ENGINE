#!/bin/bash

# Name of your conda environment
CONDA_ENV_NAME="finprod"
#BACKEND_PATH="/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend"
PID_FILE="finprod_backend.pid"
APP_MODULE="apps.finprod_backend.app:app"

start_backend() {
  echo "Activating Conda environment: $CONDA_ENV_NAME"
  source "$(conda info --base)/etc/profile.d/conda.sh"
  conda activate "$CONDA_ENV_NAME"
  which python
  echo "Starting FastAPI backend from $BACKEND_PATH..."

  gunicorn -w 10 --reload -k uvicorn.workers.UvicornWorker $APP_MODULE \
    -b 0.0.0.0:5000 --timeout 5000 --access-logfile - --error-logfile - > finprod_backend.log 2>&1 &

  echo $! > "$PID_FILE"
  echo "Finprod Backend started with PID $(cat $PID_FILE)"
}
# 2560
stop_backend() {
  if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    echo "Stopping finprod backend with PID $PID..."
    kill "$PID" && rm -f "$PID_FILE"
    echo "Finprod Backend stopped."
  else
    echo "No finprod backend process found."
  fi
}

restart_backend() {
  stop_backend
  sleep 1
  start_backend
}

case "$1" in
  start)
    start_backend
    ;;
  stop)
    stop_backend
    ;;
  restart)
    restart_backend
    ;;
  *)
    echo "Usage: $0 {start|stop|restart}"
    ;;
esac
