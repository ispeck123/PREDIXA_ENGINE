#!/bin/bash

PID_FILE="order_alert_engine.pid"
SCRIPT_PATH="./alert_engine/order_alert.py"
CONDA_ENV_NAME="finpro"

start_order_alert_engine() {
  echo "Starting Order Alert Engine..."
  source "$(conda info --base)/etc/profile.d/conda.sh"
  conda activate "$CONDA_ENV_NAME"
  which python

  nohup python "$SCRIPT_PATH" > order_alert_engine.log 2>&1 &
  echo $! > "$PID_FILE"
  echo "Order Alert Engine started with PID $(cat $PID_FILE)"
}

stop_order_alert_engine() {
  if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    echo "Stopping Order Alert Engine with PID $PID..."
    kill "$PID" && rm -f "$PID_FILE"
    echo "Custom Order Engine stopped."
  else
    echo "No Custom Order Engine process found."
  fi
}

restart_order_alert_engine() {
  stop_order_alert_engine
  sleep 2
  start_order_alert_engine
}

case "$1" in
  start)
    start_order_alert_engine
    ;;
  stop)
    stop_order_alert_engine
    ;;
  restart)
    restart_order_alert_engine
    ;;
  *)
    echo "Usage: $0 {start|stop|restart}"
    ;;
esac