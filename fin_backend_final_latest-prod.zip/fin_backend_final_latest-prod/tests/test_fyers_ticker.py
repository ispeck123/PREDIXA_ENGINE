import asyncio
import argparse
import logging, os, sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from data_fetchers.fyers.fyers_ticker import FyersTickerManager
from datetime import datetime, timezone
from typing import Optional, Any

# Optional FastAPI types (so this script can run without FastAPI installed)
try:
    from fastapi import WebSocket
    from starlette.websockets import WebSocketDisconnect, WebSocketState
except Exception:
    WebSocket = Any
    WebSocketDisconnect = Exception
    WebSocketState = None

logger = logging.getLogger("FyersTicker")

async def run_test(symbols, duration: float = 60, interval: float = 1.0, websocket: Optional[Any] = None):
    """
    If `websocket` is provided (a FastAPI WebSocket), this will `send_json` snapshots.
    Otherwise it prints snapshots to stdout.
    """
    mgr = FyersTickerManager()

    # Use the provided websocket handle for subscribe bookkeeping if present; else a dummy
    sub_handle = websocket if websocket is not None else object()
    mgr.subscribe(symbols, sub_handle)
    logger.info("Subscribed to: %s", ", ".join(s.upper() for s in symbols))

    # allow socket to connect/subscribe
    await asyncio.sleep(1.0)

    loop = asyncio.get_event_loop()
    start = loop.time()
    try:
        while (loop.time() - start) < duration:
            logger.info(mgr.latest_prices)
            snapshot = {s.upper(): mgr.get_latest_price(s) for s in symbols}
            payload = {
                "ts": int(datetime.now(timezone.utc).timestamp()),
                "ltp": snapshot,
            }

            if websocket is not None:
                # stop if client disconnected
                if hasattr(websocket, "application_state") and WebSocketState and websocket.application_state != WebSocketState.CONNECTED:
                    break
                await websocket.send_json(payload)
            else:
                print(payload)

            await asyncio.sleep(interval)
    except (KeyboardInterrupt, WebSocketDisconnect):
        pass
    finally:
        try:
            mgr.unsubscribe(sub_handle)
        except Exception:
            pass
        logger.info("Unsubscribed and exiting.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Async test for FyersTickerManager")
    parser.add_argument("--symbols", nargs="+", required=True, help="e.g. NSE:SBIN-EQ NSE:TCS-EQ")
    parser.add_argument("--duration", type=float, default=60, help="Total seconds to run")
    parser.add_argument("--interval", type=float, default=1.0, help="Print/send interval seconds")
    args = parser.parse_args()

    asyncio.run(run_test(args.symbols, args.duration, args.interval))