import os, sys
import redis
import json
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from fyers_apiv3.FyersWebsocket import data_ws
from data_fetchers.fyers.fyers_session import fyers_access_token_handler
from shared.db.dbconn import DBConnection
from shared.db.db_model import FuturesMaster

db = DBConnection()

class RedisService:
    def __init__(self, host="localhost", port=6379, db=0):
        self.client = redis.Redis(host=host, port=port, db=db, decode_responses=True)

    def save_symbol_data(self, symbol: str, data: dict):
        """
        Store market data for a given symbol in Redis as JSON.
        """
        key = f"fyers:{symbol}"
        self.client.set(key, json.dumps(data))

    def get_symbol_data(self, symbol: str):
        """
        Fetch market data for a given symbol from Redis.
        """
        key = f"fyers:{symbol}"
        data = self.client.get(key)
        return json.loads(data) if data else None



redis_service = RedisService()

def onmessage(message):
    """
    Callback to handle incoming messages from the WebSocket.
    """
    print("Response:", message)

    # Save into Redis if symbol exists
    if isinstance(message, dict) and "symbol" in message:
        symbol = message["symbol"]
        redis_service.save_symbol_data(symbol, message)

def onerror(message):
    print("Error:", message)

def onclose(message):
    print("Connection closed:", message)

def get_all_symbols():
    session = db.get_session()
    symbols = session.query(FuturesMaster).distinct(FuturesMaster.symbol).all()
    return [symbol.symbol for symbol in symbols]

def onopen():
    data_type = "SymbolUpdate"
    symbols = ['NSE:TCS25SEPFUT']
    fyers.subscribe(symbols=symbols, data_type=data_type)
    fyers.keep_running()

# Access token
access_token = fyers_access_token_handler().get_access_token()

# Fyers WebSocket client
fyers = data_ws.FyersDataSocket(
    access_token=access_token,
    log_path="",
    litemode=False,
    write_to_file=False,
    reconnect=True,
    on_connect=onopen,
    on_close=onclose,
    on_error=onerror,
    on_message=onmessage
)

fyers.connect()

# print(get_all_symbols())
