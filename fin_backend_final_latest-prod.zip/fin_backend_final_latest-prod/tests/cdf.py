import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from apps.dashboard import stock
from data_fetchers.fyers.candle_data import CandleDateFetcher
from shared.config.settings import stock_data_dir_config
from shared.db.dbconn import DBConnection
from shared.db.db_model import Ind_StockMaster
from shared.utils.logger import logger
import requests
import pandas as pd
from io import StringIO
import re
from datetime import datetime

dbc = DBConnection()

def get_all_stock_syms():
    db = dbc.get_session()
    res = db.query(Ind_StockMaster).filter(Ind_StockMaster.is_active == True).all()
    return [items.__dict__ for items in res]

cls = CandleDateFetcher()
symbol = "NIFTY 50"

all_stick_syms = [symbol]
# all_stick_syms = get_all_stock_syms()

# for stocks in all_stick_syms:
    # stock_tick = stocks['stock_tick']
    # stock_symbol = stocks['fyers_symbol']
    # fyers_symbol = stock
logger.info(f"Processing stock: bharti_airtel D")
cls.fetch_candle_data_custom_resolution(stock_tick="bharti_airtel", 
                                            symbol="NSE:BHARTIARTL-EQ", 
                                            start_date="2017-01-01", 
                                            resolution="1D")

# def extract_date(entry):
#     print(entry, "eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee")
#     match = re.search(r'\b(\d{2})\s([A-Za-z]{3})\s(\d{2})\b', entry)
#     if match:
#         # year, month, day = match.groups()
#         day, month, year = match.groups()
#         full_date_str = f"20{year} {month} {day}"
#         return datetime.strptime(full_date_str, "%Y %b %d")
#     return None


# def get_fyers_monthly_fut_expiries_top3(product: str):
#     """
#     Returns the top 3 monthly FUT expiries (near/next/far) for a stock future.

#     Output example:
#     [
#       {"expiry": "30-01-2026"},
#       {"expiry": "27-02-2026"},
#       {"expiry": "27-03-2026"}
#     ]
#     """
#     try:
#         url = "https://public.fyers.in/sym_details/NSE_FO.csv"
#         response = requests.get(url, timeout=30)
#         response.raise_for_status()

#         df = pd.read_csv(StringIO(response.text), header=None)
#         print(df.columns)
#         # Stock FUT rows (example: "NSE:RELIANCE26JANFUT")
#         # sym_col =  # column containing "NSE:XXXX..." in your file
#         sym_col = 9

#         df = df[df[sym_col].astype(str).str.contains(f"NSE:{product}", na=False)]
#         df = df[df[sym_col].astype(str).str.contains("FUT", na=False)]

#         # Parse expiry using your existing extractor
#         df["parsed_date"] = df[1].apply(extract_date)
#         df = df.dropna(subset=["parsed_date"]).sort_values(by="parsed_date")

#         # Get unique expiries in ascending order (near -> far)
#         expiries = (
#             df["parsed_date"]
#             .drop_duplicates()
#             .sort_values()
#             .head(3)
#         )

#         # Format
#         out = [d.strftime("%Y-%m-%d") for d in expiries.tolist()]
#         return out

#     except Exception as e:
#         logger.exception(e)
#         print(f"Error fetching FUT expiries: {product}  {e}")
#         return None


# if __name__ == "__main__":
    # get_fyers_monthly_fut_expiries_top3("RELIANCE")
    # cls.fetch_candle_data_custom_resolution(stock_tick="asian_paints", 
    #                                         symbol="NSE:ASIANPAINT-EQ", 
    #                                         start_date="2020-01-01", 
    #                                         resolution="60")
