#!/usr/bin/env python3
"""
Standalone line-profiler for Calculate_setup_execute with fixed inputs.
Run:  python test_profiler.py
(You don't need kernprof for this script.)
"""

import os, sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import time
from datetime import datetime
from line_profiler import LineProfiler
from scripts.calculate_setup import Calculate_setup_execute
from shared.config.settings import stock_data_dir_config

# --- import your code here ---
# Adjust the path/imports to match your project layout
# from scripts.calculate_zones import DemandZoneCalculator, SupplyZoneCalculator, ZoneAnalyzer  # only if you want to add them too

# ---------- CONFIG: put your fixed test inputs here ----------
STOCK_NAME   = os.getenv("TEST_STOCK", "adani_ports")
TIME_FRAME   = int(os.getenv("TEST_TIMEFRAME", "2"))            # uses your TIME_FRAMES_2 in config
LAST_DT_STR  = os.getenv("TEST_LAST_DT", "2025-08-21 15:30:00") # must match your CSV timezone/format
COUNTRY_DIR  = os.getenv("TEST_COUNTRY_DIR", stock_data_dir_config.indian_stock_data_dir)  # <-- change this
DAYFIRST     = True                                             # matches your CSV parsing

# If your CSVs are named like: {COUNTRY_DIR}/processed_data_files/{STOCK_NAME}_{tf}.csv
# ensure those files exist (weekly/daily/your-execute-tf)


def build_instance():
    last_dt = datetime.strptime(LAST_DT_STR, "%Y-%m-%d %H:%M:%S")
    return Calculate_setup_execute(
        stock_name=STOCK_NAME,
        time_frame=TIME_FRAME,
        last_dt=last_dt,
        country_dir=COUNTRY_DIR
    )

def main_profile():
    calc = build_instance()

    # Choose exactly which functions to profile (line-level)
    lp = LineProfiler()

    # Core methods
    lp.add_function(Calculate_setup_execute.calculate)
    lp.add_function(Calculate_setup_execute.get_mtf_zones)

    # Overlap helpers (hotspots)
    lp.add_function(Calculate_setup_execute.find_overlaps_between_zones)
    lp.add_function(Calculate_setup_execute.filter_execute_zones_within)

    # If these are heavy in your run, include them too:
    lp.add_function(Calculate_setup_execute.get_ea_zones_info)
    lp.add_function(Calculate_setup_execute.get_qualified_exe_zones_info)
    lp.add_function(Calculate_setup_execute.predict_trend)
    lp.add_function(Calculate_setup_execute.get_execute_df)
    lp.add_function(Calculate_setup_execute.get_analyse_df)

    # You can also profile buy/sell setup builders:
    lp.add_function(Calculate_setup_execute.calculate_buy_setup)
    lp.add_function(Calculate_setup_execute.calculate_sell_setup)

    # If you want to go deeper (only if accessible/importable):
    # lp.add_function(DemandZoneCalculator.calculate_zone_with_details)
    # lp.add_function(SupplyZoneCalculator.calculate_zone_with_details)
    # lp.add_function(ZoneAnalyzer.calculate_overall_trend)
    # lp.add_function(ZoneAnalyzer.get_qualified_alterated_zones)

    # Run the target function under the profiler
    t0 = time.perf_counter()
    result = lp.runcall(calc.calculate)  # executes your pipeline
    t1 = time.perf_counter()

    # Print the result (optional)
    print("\n--- calculate() output (truncated) ---")
    try:
        # Avoid dumping huge dicts
        preview = {k: result[k] for k in list(result)[:6]} if isinstance(result, dict) else result
        print(preview)
    except Exception:
        print(result)

    print(f"\nTotal wall time: {t1 - t0:.3f}s\n")

    # Show line-by-line stats
    lp.print_stats()


if __name__ == "__main__":
    main_profile()
