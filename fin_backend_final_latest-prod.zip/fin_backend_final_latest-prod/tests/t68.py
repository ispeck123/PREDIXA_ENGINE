import sys, os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from shared.db.dbconn import DBConnection
from sqlalchemy import text
from datetime import datetime
from stock_model.model_predictor import Indian_model_predictor
from shared.config.settings import stock_data_dir_config
from concurrent.futures import ThreadPoolExecutor


db = DBConnection()
res = db.raw_query(text("select * from order_master where time_frame = 1 and order_type = 'BUY' and arima_ab_model_prob = 0;"))
rc = db.raw_connection()
for items in res:
    bind_data = {
        "order_type" : items.get("order_type"),
        "entry_price" : items.get("entry_price"),
        "target_price" : items.get("target_price"),
        "stoploss_price" : items.get("stoploss_price")
    }
    tick = items.get("stock_tick")
    ltd_time = datetime.strptime(items.get("purchased_cmp_date"), "%Y-%m-%dT%H:%M") #items.get("purchased_cmp_date")
    #file_name = f"/home/ispeck/PROJECTS_DEV/FINPRO_OPT/final/stock_project/apps/finprod_backend/processed_data_files/{tick}_daily.csv"
    file_name = os.path.join(stock_data_dir_config.indian_stock_data_dir, "processed_data_files", f"{tick}_daily.csv")
    imp = Indian_model_predictor(tick, 1, 'buy', ltd_time)
    pred, prob = imp.fetch_model_stats(bind_data["entry_price"], bind_data["target_price"], bind_data["stoploss_price"])
    query = f"update order_master set arima_ab_model_prediction='{pred}', arima_ab_model_prob={prob} where order_id={items.get('order_id')}"
    
    rc.execute(text(query))
    rc.commit()
    # rc.close()
    # print(items.get('order_id'))
    print(pred, prob)
rc.close()
db.close_engine()