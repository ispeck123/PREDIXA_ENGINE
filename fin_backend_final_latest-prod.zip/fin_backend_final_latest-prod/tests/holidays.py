import os, sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import requests
from datetime import datetime
url = "https://www.nseindia.com/api/holiday-master?type=trading"
headers = {
    "User-Agent": "Mozilla/5.0",
    "Accept": "application/json",
    "Referer": "https://www.nseindia.com/"
}

session = requests.Session()
session.headers.update(headers)

response = session.get(url)
response.raise_for_status()

data = response.json()
holidays = data["CM"]  # Capital Market (Equity)
holiday_dates = [datetime.strptime(hol['tradingDate'], "%d-%b-%Y") for hol in holidays]
#print(holiday_dates)
holiday_dates = [datetime.strftime(hol, "%Y-%m-%d")for hol in holiday_dates]
print(holiday_dates)