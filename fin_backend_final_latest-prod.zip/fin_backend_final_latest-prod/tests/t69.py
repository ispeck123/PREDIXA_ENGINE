import os
import sys
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
import traceback

# add project root to path (same as your original approach)
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from shared.db.dbconn import DBConnection
from sqlalchemy import text
from stock_model.model_predictor import Indian_model_predictor
from shared.config.settings import stock_data_dir_config

# progress bar
from tqdm import tqdm

# Tunables
MAX_WORKERS = min(32, (os.cpu_count() or 1) * 4)  # adjust as needed
TIMEOUT_SECONDS = None  # if you want per-future timeout, set it

dbw = DBConnection()

rc = dbw.raw_connection()

def process_order(item):
    """
    Worker function: does model prediction and updates the DB for one order.
    Returns (order_id, pred, prob, success_flag, error_message_or_none)
    """
    order_id = item.get("order_id")
    try:
        # Build bind_data (kept from your original)
        bind_data = {
            "order_type": item.get("order_type"),
            "entry_price": item.get("entry_price"),
            "target_price": item.get("target_price"),
            "stoploss_price": item.get("stoploss_price"),
        }

        tick = item.get("stock_tick")

        # parse purchased_cmp_date, tolerant to minor variations
        raw_date = item.get("purchased_cmp_date")
        if raw_date is None:
            raise ValueError("purchased_cmp_date is None for order_id=%s" % order_id)

        try:
            ltd_time = datetime.strptime(raw_date, "%Y-%m-%dT%H:%M")
        except ValueError:
            # try a fallback with seconds
            ltd_time = datetime.strptime(raw_date, "%Y-%m-%dT%H:%M:%S")

        # run predictor (this may be I/O or CPU bound depending on implementation)
        imp = Indian_model_predictor(tick, 1, "buy", ltd_time)
        pred, prob = imp.fetch_model_stats(
            bind_data["entry_price"], bind_data["target_price"], bind_data["stoploss_price"]
        )

        # Use a fresh DBConnection for this worker to avoid sharing connection objects across threads
        
        

        # Parameterized update
        upd = text(
            "UPDATE order_master "
            "SET arima_ab_model_prediction = :pred, arima_ab_model_prob = :prob "
            "WHERE order_id = :order_id"
        )
        rc.execute(upd, {"pred": pred, "prob": prob, "order_id": order_id})
        rc.commit()

        # close worker's connection/engine (depends on your DBConnection impl)
        # try:
        #     rc.close()
        # except Exception:
        #     pass
        # try:
        #     dbw.close_engine()
        # except Exception:
        #     pass

        return (order_id, pred, prob, True, None)

    except Exception as e:
        # capture full traceback for debugging
        tb = traceback.format_exc()
        return (order_id, None, None, False, tb)


def main():
    # read orders on main thread (single DBConnection for read)
    db = DBConnection()
    rows = db.raw_query(text("SELECT * FROM order_master WHERE time_frame = 1;"))
    # convert to list in case rows is generator
    items = list(rows)
    total = len(items)
    if total == 0:
        print("No rows found for time_frame = 1")
        db.close_engine()
        return

    # results collector
    results = []

    # execute in threadpool with tqdm progress bar
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_to_order = {executor.submit(process_order, item): item for item in items}

        # use tqdm to show progress as futures complete
        with tqdm(total=total, desc="Processing orders") as pbar:
            for fut in as_completed(future_to_order, timeout=TIMEOUT_SECONDS):
                item = future_to_order[fut]
                try:
                    order_id, pred, prob, ok, err = fut.result()
                    results.append((order_id, pred, prob, ok, err))
                    if ok:
                        # optional: print small summary per successful order (comment out if noisy)
                        # print(f"order {order_id}: pred={pred} prob={prob}")
                        pass
                    else:
                        # log error for this order
                        print(f"[ERROR] order {order_id} failed:\n{err}")
                except Exception:
                    # This block catches exceptions raised while retrieving the result
                    print(
                        f"[CRITICAL] unexpected exception for order {item.get('order_id')}\n{traceback.format_exc()}"
                    )
                    results.append((item.get("order_id"), None, None, False, traceback.format_exc()))
                finally:
                    pbar.update(1)

    # close the main read engine
    try:
        db.close_engine()
    except Exception:
        pass

    # summary
    succeeded = sum(1 for r in results if r[3])
    failed = sum(1 for r in results if not r[3])
    print(f"Done. Total: {total}, Succeeded: {succeeded}, Failed: {failed}")

    # Optionally, write a CSV or logfile of failures for inspection
    # (left as an exercise; can export results list)

if __name__ == "__main__":
    main()