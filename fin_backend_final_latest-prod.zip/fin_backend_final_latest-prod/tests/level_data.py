import json
import time
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from fyers_apiv3.FyersWebsocket import data_ws
from data_fetchers.fyers.fyers_session import fyers_access_token_handler

# ==========================================
# CONFIGURATION
# ==========================================
# Format: "APP_ID:ACCESS_TOKEN"
fah = fyers_access_token_handler()
ACCESS_TOKEN = fah.get_access_token()

# Symbols to track (ensure they are properly formatted with exchange prefixes)
SYMBOLS_TO_TRACK = ["NSE:ICICIBANK-EQ"]

# File to store the Level 2/3 Order Book data
DATA_FILE = "order_book_depth.jsonl" 

# ==========================================
# WEBSOCKET CALLBACK FUNCTIONS
# ==========================================
def on_message(message):
    """
    Triggered every time the WebSocket receives a depth tick.
    """
    # Append the current Unix timestamp to the incoming Fyers packet
    message['local_timestamp'] = time.time()
    
    # Save the raw Depth dictionary as a JSON Line for efficient storage/reading
    with open(DATA_FILE, "a") as f:
        f.write(json.dumps(message) + "\n")
        
    # Optional: Print to console to verify it is working
    symbol = message.get('symbol', 'Unknown')
    print(f"[{time.strftime('%H:%M:%S')}] Depth recorded for {symbol}")

def on_error(message):
    """Triggered if there is a WebSocket error."""
    print("WebSocket Error:", message)

def on_close(message):
    """Triggered when the WebSocket connection closes."""
    print("Connection Closed:", message)

def on_open():
    """
    Triggered when connection is successfully established.
    We subscribe to DepthUpdate here.
    """
    print("WebSocket Connected! Subscribing to Market Depth...")
    
    # Important: Data type MUST be "DepthUpdate" to get the Level 2/3 Order Book. 
    # Fyers v3 requires separate sockets if you also want "SymbolUpdate" (OHLCV).
    fyers.subscribe(symbols=SYMBOLS_TO_TRACK, data_type="DepthUpdate")

# ==========================================
# INITIALIZATION & EXECUTION
# ==========================================
if __name__ == "__main__":
    # Create the FyersDataSocket instance
    fyers = data_ws.FyersDataSocket(
        access_token=ACCESS_TOKEN,
        log_path="",             # Path for socket logs. Empty creates in current directory.
        litemode=False,          # Must be False for deep data
        write_to_file=False,     # Fyers internal raw logger (we handle our own in on_message)
        reconnect=True,          # Auto-reconnect on drops
        on_connect=on_open,
        on_close=on_close,
        on_error=on_error,
        on_message=on_message
    )

    # Establish connection (this blocks the main thread in a loop)
    fyers.connect()
    
    # Keeps the socket listening
    fyers.keep_running()