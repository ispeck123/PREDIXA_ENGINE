from pathlib import Path
import sys
import pandas as pd

sys.path.insert(0, str(Path(__file__).parents[2] / "audit" / "fresh_trend_backtest"))
from replay import resolve_buy


def candidate():
    return {"scan_timestamp": "2024-01-01T10:00:00", "entry": 100.0, "stop": 95.0, "target": 110.0}


def bars(rows):
    return pd.DataFrame(rows, columns=["timestamp", "open", "high", "low", "close"]).assign(timestamp=lambda x: pd.to_datetime(x.timestamp))


def test_no_decision_bar_used_for_entry_or_outcome():
    frame = bars([
        ["2024-01-01 10:00", 100, 111, 94, 100],
        ["2024-01-01 11:00", 100, 101, 99, 100],
        ["2024-01-01 12:00", 100, 110, 99, 109],
    ])
    result = resolve_buy(candidate(), frame)
    assert result["entry_timestamp"] == "2024-01-01T11:00:00"
    assert result["WIN / LOSS"] == "WIN"


def test_same_bar_target_stop_uses_production_target_first_ordering():
    frame = bars([["2024-01-01 11:00", 100, 111, 94, 100]])
    result = resolve_buy(candidate(), frame)
    assert result["WIN / LOSS"] == "WIN"
    assert result["target_hit"] is True and result["stop_hit"] is True


def test_stop_only_is_against_direction():
    frame = bars([["2024-01-01 11:00", 100, 103, 94, 96]])
    result = resolve_buy(candidate(), frame)
    assert result["WIN / LOSS"] == "LOSS"
    assert result["outcome_direction"] == "AGAINST_TRADE_DIRECTION"
