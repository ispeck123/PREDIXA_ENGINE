from __future__ import annotations
import sqlite3
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parents[2]))

from audit.fresh_trend_backtest.config import ReplayConfig
from audit.fresh_trend_backtest.storage.sqlite_storage import SQLiteBacktestStorage
from audit.fresh_trend_backtest.worker import execute_task
from audit.fresh_trend_backtest.task_generator import generate_tasks
from audit.fresh_trend_backtest.replay import completed_scan_timestamps

def config(tmp_path): return ReplayConfig(run_name="test",symbols=("icici_lombard_gic",),tfs=(2,),start="2024-01-02",end="2024-01-02",storage_path=str(tmp_path/"x.sqlite"),limit_tasks=1)
def task(run): return {"task_id":1,"run_id":run,"symbol":"icici_lombard_gic","strategy_tf":2,"strategy_tf_name":"sixty","evaluation_timestamp":"2024-01-02T09:15:00","attempt_count":1}
def fake_event(t):
 return {"task":t,"duration_ms":1.0,"result":{"scan":{"task_id":t["task_id"],"run_id":t["run_id"],"symbol":t["symbol"],"strategy_tf":2,"evaluation_timestamp":t["evaluation_timestamp"],"cmp":1,"signal_generated":0,"setup_generated":0,"entry_candidate":0,"rejection_reason":"none","final_bias":"Neutral","allow_long":0,"allow_short":0,"permitted_setup":None,"trade_type_long":None,"trade_type_short":None,"dbr_required":0,"rbd_required":0,"htf_veto_longs":0,"htf_veto_shorts":0,"htf_veto_reason":None,"production_runtime_ms":1,"raw_json":None},"regime":{"E_regime":"SW","A_regime":"SW","X_regime":"SW"},"zones":[],"setups":[]}}

def test_task_uniqueness_and_no_signal_persisted(tmp_path):
 s=SQLiteBacktestStorage(tmp_path/"x.sqlite"); c=config(tmp_path); run=s.create_run(c); rows=[{"symbol":"icici_lombard_gic","strategy_tf":2,"strategy_tf_name":"sixty","evaluation_timestamp":"2024-01-02T09:15:00"}]
 s.register_tasks(run,rows); s.register_tasks(run,rows); claimed=s.claim_tasks(run,1); assert len(claimed)==1
 s.save_events([fake_event(claimed[0])]); assert s.conn.execute("select count(*) from scan_results").fetchone()[0]==1; assert s.conn.execute("select signal_generated from scan_results").fetchone()[0]==0

def test_completed_task_not_replayed_and_stale_recovery(tmp_path):
 s=SQLiteBacktestStorage(tmp_path/"x.sqlite"); c=config(tmp_path); run=s.create_run(c); s.register_tasks(run,[{"symbol":"icici_lombard_gic","strategy_tf":2,"strategy_tf_name":"sixty","evaluation_timestamp":"2024-01-02T09:15:00"}]); t=s.claim_tasks(run,1)[0]; s.save_events([fake_event(t)]); assert not s.claim_tasks(run,1)
 s.conn.execute("update scan_tasks set status='RUNNING' where task_id=?",(t["task_id"],));s.conn.commit();s.reclaim_stale(run); assert s.claim_tasks(run,1)

def test_worker_failure_retries_then_fails(tmp_path):
 s=SQLiteBacktestStorage(tmp_path/"x.sqlite"); c=config(tmp_path); run=s.create_run(c); s.register_tasks(run,[{"symbol":"icici_lombard_gic","strategy_tf":2,"strategy_tf_name":"sixty","evaluation_timestamp":"2024-01-02T09:15:00"}]); t=s.claim_tasks(run,1)[0]
 e={"task":t,"error":{"type":"Injected","message":"x","traceback":"x"},"duration_ms":1,"worker_id":"test","max_retries":0};s.save_events([e]);assert s.task_counts(run)["FAILED"]==1

def test_real_worker_no_lookahead_contract_shape():
 # The current production helper receives only T; its preprocessing clips data
 # internally.  This integration test verifies a structured result is returned.
 t={"task_id":1,"run_id":"r","symbol":"icici_lombard_gic","strategy_tf":2,"strategy_tf_name":"sixty","evaluation_timestamp":"2024-01-02T09:15:00","attempt_count":1}
 e=execute_task(t); assert "result" in e and e["result"]["scan"]["evaluation_timestamp"]==t["evaluation_timestamp"]

def test_date_filter_is_inclusive_for_intraday_calendar_day(tmp_path):
 c=config(tmp_path); tasks=list(generate_tasks(c)); assert tasks and all(x["evaluation_timestamp"].startswith("2024-01-02") for x in tasks)

def test_strategy_filters_are_exact(tmp_path):
 c=ReplayConfig(run_name="x",symbols=("icici_lombard_gic",),tfs=(2,),start="2024-01-02",end="2024-01-02",storage_path=str(tmp_path/"x.sqlite")); assert {x["strategy_tf"] for x in generate_tasks(c)}=={2}

def test_regime_snapshot_fields_persist(tmp_path):
 s=SQLiteBacktestStorage(tmp_path/"x.sqlite");run=s.create_run(config(tmp_path));s.register_tasks(run,[{"symbol":"icici_lombard_gic","strategy_tf":2,"strategy_tf_name":"sixty","evaluation_timestamp":"2024-01-02T09:15:00"}]);s.save_events([fake_event(s.claim_tasks(run,1)[0])]); assert tuple(s.conn.execute("select E_regime,A_regime,X_regime from regime_snapshots").fetchone())==("SW","SW","SW")

def test_central_writer_contract_is_atomic(tmp_path):
 s=SQLiteBacktestStorage(tmp_path/"x.sqlite");run=s.create_run(config(tmp_path));rows=[{"symbol":"icici_lombard_gic","strategy_tf":2,"strategy_tf_name":"sixty","evaluation_timestamp":f"2024-01-02T0{i}:15:00"} for i in (9,10)];s.register_tasks(run,rows);s.save_events([fake_event(t) for t in s.claim_tasks(run,2)]);assert s.conn.execute("select count(*) from scan_results").fetchone()[0]==2
