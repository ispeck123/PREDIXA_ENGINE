import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from sqlalchemy import and_, func
from shared.db.db_model import Order, TradeSignal
from shared.db.dbconn import DBConnection
from sqlalchemy import literal_column
from apps.pipelines.trade_accumulator_future_commodity import get_converted_expiry_list
from shared.config.settings import fyers_config_credentials as fcc
import pandas as pd

def norm_sym(s: str) -> str:
    return (s or "").strip().upper()

# session = DBConnection().get_session()
# signals = session.query(TradeSignal).filter(TradeSignal.exp_date == None).all()
# print(len(signals))
# for ts in signals:
#     entry = ts.trade_data.get("entry_price")
#     stoploss = ts.trade_data.get("stop_loss")
#     target = ts.trade_data.get("target_price")
#     if entry is None:
#         continue
    
#     # SECONDS = literal_column("SECOND")  # compiles to the bare token SECOND
#     # print(ts.stock_name, ts.time_fr, ts.trade_type, entry, stoploss, target)
#     q = (
#         session.query(Order)
#         .filter(
#             func.upper(Order.stock_tick) == str(ts.stock_name).upper(),
#             Order.time_frame == ts.time_fr,
#             func.upper(Order.order_type) == str(ts.trade_type).upper(),
#             func.round(Order.entry_price, 1) == round(entry, 1),
#             func.round(Order.stoploss_price, 1) == round(stoploss, 1),
#             func.round(Order.target_price, 1) == round(target, 1),
#         )
#     )
#     om = q.first()
#     # print(om)
#     if om:
#         om.trade_signal_id = ts.id
#         session.add(om)
    
#         # optional: create a correlation_id and stamp both
#         # cid = new_corr_id_bin(); ts.correlation_id = cid; om.correlation_id = cid

# session.commit()

# print(get_converted_expiry_list("GOLD"))


df = pd.read_csv(fcc.SYMBOL_CSV_URL, header=None)
print(df.columns)
print(df.head()[1])


import csv, io, re, requests

# --- 1) Resolve FYERS symbol -> ISIN (via FYERS Symbol Master CSV) ---
FYERS_SYMBOL_MASTER_URL = "https://api-timeline.fyers.in/v3/symbol-master/NSE_CM.csv"  # path can change; see docs/support
# Tip: If the above path changes, follow FYERS docs "Symbol Master" link and update the URL.

def get_isin_from_fyers_symbol(fyers_symbol: str):
    # Accept "NSE:RELIANCE-EQ" or "RELIANCE" or "RELIANCE-EQ"
    sym = fyers_symbol.split(":")[-1]  # drop "NSE:"
    sym = sym.upper()
    # Common normalizations
    base = sym.replace("-EQ", "")
    candidates = {sym, base, f"{base}-EQ"}  # try a few forms seen in master file

    resp = requests.get(FYERS_SYMBOL_MASTER_URL, timeout=30)
    resp.raise_for_status()
    content = resp.content.decode("utf-8", errors="ignore")
    reader = csv.DictReader(io.StringIO(content))

    # FYERS master typically has columns like: "Symbol","Exchange","TickSize","LotSize","ISIN",...
    for row in reader:
        r_sym = (row.get("Symbol") or row.get("symbol") or "").upper()
        if r_sym in candidates:
            isin = row.get("ISIN") or row.get("isin")
            return isin
    return None

# --- 2) Check NSE Indices constituent CSVs for that ISIN ---
# Add/extend this mapping as needed; each URL is an official per-index CSV.
NSE_INDEX_CSVS = {
    "NIFTY 50": "https://www.niftyindices.com/IndexConstituent/ind_nifty50list.csv",
    "NIFTY NEXT 50": "https://www.niftyindices.com/IndexConstituent/ind_niftynext50list.csv",
    "NIFTY BANK": "https://www.niftyindices.com/IndexConstituent/ind_niftybanklist.csv",
    "NIFTY IT": "https://www.niftyindices.com/IndexConstituent/ind_cnxitlist.csv",
    "NIFTY FMCG": "https://www.niftyindices.com/IndexConstituent/ind_cnxfcglist.csv",
    "NIFTY PHARMA": "https://www.niftyindices.com/IndexConstituent/ind_cnxpharmalist.csv",
    "NIFTY AUTO": "https://www.niftyindices.com/IndexConstituent/ind_cnxaulist.csv",
    "NIFTY METAL": "https://www.niftyindices.com/IndexConstituent/ind_cnxmetallist.csv",
    "NIFTY REALTY": "https://www.niftyindices.com/IndexConstituent/ind_cnxrealtylist.csv",
    "NIFTY OIL & GAS": "https://www.niftyindices.com/IndexConstituent/ind_cnxoilgaslist.csv",
    "NIFTY MIDCAP 100": "https://www.niftyindices.com/IndexConstituent/ind_niftymidcap100list.csv",
    "NIFTY SMALLCAP 100": "https://www.niftyindices.com/IndexConstituent/ind_niftysmallcap100list.csv",
    # …add more from the NSE Indices site as needed
}

# Some NSE sites need headers + a session warm-up to serve CSVs.
SESSION = requests.Session()
HEADERS = {"User-Agent": "Mozilla/5.0"}
SESSION.get("https://www.niftyindices.com/", headers=HEADERS, timeout=30)

def indices_for_isin(isin: str) -> list[str]:
    found = []
    for name, url in NSE_INDEX_CSVS.items():
        try:
            r = SESSION.get(url, headers=HEADERS, timeout=30)
            r.raise_for_status()
            text = r.content.decode("utf-8", errors="ignore")
            if re.search(rf"\b{re.escape(isin)}\b", text, flags=re.IGNORECASE):
                found.append(name)
        except Exception:
            # network hiccup or index not accessible; skip this one
            pass
    return found

def indices_for_fyers_symbol(fyers_symbol: str) -> list[str]:
    isin = get_isin_from_fyers_symbol(fyers_symbol)
    if not isin:
        raise ValueError(f"Could not resolve ISIN for symbol: {fyers_symbol}")
    return indices_for_isin(isin)

# Example:
print(indices_for_fyers_symbol("NSE:RELIANCE-EQ"))
