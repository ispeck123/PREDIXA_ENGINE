import sys, os, logging

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from scripts.stock_logic import proc_all_stock_items
from threading import Thread
from concurrent.futures import ProcessPoolExecutor, as_completed
from shared.config.settings import stock_data_dir_config
from tqdm import tqdm

logger = logging.getLogger()

# def all_manual_process():
#     try:
#         th_list = []
#         input_dir = "./data/BACKTEST/latest_data_csv"
#         output_dir = "./data/BACKTEST/processed_data_files"
#         for stock_item in os.listdir(input_dir):
#             # proc_all_stock_items(stock_item, input_dir, output_dir)
#             Th = Thread(target=proc_all_stock_items, args=(stock_item, input_dir, output_dir))
#             th_list.append(Th)
#             Th.start()
#         for threa in th_list:
#             threa.join()
#     except Exception as ex:
#         logger.exception(ex, stack_info=True)

def all_manual_process():
    input_dir = stock_data_dir_config.indian_stock_data_dir + "/latest_data_csv"
    output_dir = stock_data_dir_config.indian_stock_data_dir + "/processed_data_files"
    try:
        stock_list = os.listdir(input_dir)

        with ProcessPoolExecutor() as executor:
            futures = [
                executor.submit(proc_all_stock_items, stock, input_dir, output_dir)
                for stock in stock_list #if str(stock).__contains__('five')
            ]

            for future in tqdm(as_completed(futures), total=len(futures), desc="Processing stocks", unit="file", dynamic_ncols=True):
                try:
                    future.result()
                except Exception as e:
                    logger.exception(f"Error processing stock: {e}", stack_info=True)

    except Exception as ex:
        logger.exception("Main process failed", exc_info=True)



if __name__ == '__main__':
    all_manual_process()