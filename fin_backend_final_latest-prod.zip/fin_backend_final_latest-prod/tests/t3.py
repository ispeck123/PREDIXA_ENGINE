

import sys, os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from data_fetchers.fyers import indian_stock_data_updater
from data_fetchers.fyers.indian_stock_data_updater import INDIAN_STOCK_DATA_UPDATER
from data_fetchers.fyers.indian_commodity_data_updater import MCXFutureDataHandler
from data_fetchers.fyers.indian_futures_data_updater import Indian_future_data_handler, future_data_processer
from nselib import derivatives
from apps.pipelines.miscellaneous_jobs import delete_duplicate_trade_signals, delete_completed_trade_signals
from apps.pipelines.available_trade_validator import AvailableTradeValidator

# isdu = INDIAN_STOCK_DATA_UPDATER()
# isdu.process_all()

# mcx = MCXFutureDataHandler()
# mcx.download_all()
# mcx.process_all()

# print(expiry_dates_future())
# print(derivatives.derivative_data("Nifty"))
# ifdh = Indian_future_data_handler()
# ifdh.process()

# fdp = future_data_processer()
# fdp.process_all_files()

validator = AvailableTradeValidator()
validator.process_all_trades_cash()
# delete_completed_trade_signals()