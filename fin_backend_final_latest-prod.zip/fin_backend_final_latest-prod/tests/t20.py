import sys, os

import logging
from datetime import datetime
from sqlalchemy import text

logger = logging.getLogger()

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from shared.db.dbconn import DBConnection
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed
from stock_model.model_predictor import Indian_model_predictor, US_model_predictor
from shared.db.db_utils import push_trades_to_order, insert_trade_signals, check_and_insert_automated_alert
from shared.utils.logger import logger 
from shared.config.settings import stock_data_dir_config
from alert_engine.simulate_setup import send_setup_alert_telegram
from scripts.calculate_setup import Calculate_setup_execute

DATA_DIR = {"india": stock_data_dir_config.indian_stock_data_dir, 'us': stock_data_dir_config.us_data_dir}
TABLE_NAME = {"india": "ind_stock_master", "us": "us_stock_master"}

CASH_EXCHANGE_ID = {"india": 8, "us": 12}

country_id_dict = {"india" : 1, "us" : 3}

dbc = DBConnection()


def run_calculation_process(stock_name, country_dir, time_fr):
    try:
        cse = Calculate_setup_execute(
            stock_name=stock_name,
            time_frame=time_fr,
            last_dt=datetime(year=2025, month=8, day=11, hour=16, minute=0, second=0),
            country_dir=country_dir,
        )
        return cse.calculate()
    except Exception as e:
        logger.error({"STOCK_NAME": stock_name, "error": str(e)}, stack_info=True, exc_info=True)


def daily_trades_accumulate(country):
    logger.info(f"Starting trade accumulation for {country}")
    
    # data = db.get(country, {})
    avl_trades = []
    C_dir = DATA_DIR[country]

    res = dbc.raw_query(text(f"SELECT * FROM {TABLE_NAME[country]} WHERE is_active=1 and is_proc=0"))
    

    # 2. Process trades in parallel (CPU-bound)
    with ProcessPoolExecutor() as p_pool:
        future_to_stock = {
            p_pool.submit(run_calculation_process, item['stock_tick'], C_dir, 1): item['stock_tick']
            for item in res
        }

        for fut in as_completed(future_to_stock):
            st_name = future_to_stock[fut]
            try:
                result = fut.result()

                # Shared function to evaluate each side
                def evaluate_trade(trade_type: str):
                    side_key = trade_type.upper()
                    rrr_key = f"{side_key}_RRR"
                    trade_data = result.get(side_key)

                    if result and result.get(rrr_key, 0) >= 1.5 and trade_data:
                        trade_result = {
                            "STOCK_NAME": result["STOCK_NAME"],
                            "TIME_FR": 1,
                            "PRICE_CMP": result.get("PRICE_CMP"),
                            "TRADE_TYPE": side_key,
                            rrr_key: result[rrr_key],
                            f"{side_key}_TIMESTAMPS": result.get(f"{side_key}_TIMESTAMPS"),
                            trade_type.upper(): trade_data,
                            "TIMESTAMP": datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
                        }
                        try:
                            if str(country).lower().__contains__('us'):
                                model_stat = US_model_predictor(result["STOCK_NAME"], 1, datetime.now()).fetch_model_stats(
                                    trade_data["entry_price"],
                                    trade_data["target_price"],
                                    trade_data["stop_loss"]
                                )
                            else:
                                model_stat = Indian_model_predictor(result["STOCK_NAME"], 1, trade_type, datetime.now()).fetch_model_stats(
                                    trade_data["entry_price"],
                                    trade_data["target_price"],
                                    trade_data["stop_loss"]
                                )
                            trade_result["PREDICTION"] = model_stat[0]
                            trade_result["PROBABILITY"] = model_stat[1]
                        except Exception as ex:
                            logger.error(f"Error from model predictor for {st_name} ({trade_type}): {ex}")
                            trade_result["PREDICTION"] = None
                            trade_result["PROBABILITY"] = None

                        if trade_result["PREDICTION"] == "success":
                            res_ins_trade = insert_trade_signals(trade_result, country_id_dict[country], CASH_EXCHANGE_ID[country], 1)
                            if res_ins_trade:
                                check_and_insert_automated_alert(trade_result, CASH_EXCHANGE_ID[country], country_id_dict[country], 1)
                                avl_trades.append(trade_result)
                                logger.info(f"Committed {side_key} trade for {st_name} to DB")

                # Evaluate BUY
                if result.get("BUY_RRR", 0) >= 1.5:
                    evaluate_trade("BUY")

                # Evaluate SELL
                # if result.get("SELL_RRR", 0) >= 1.5:
                    # evaluate_trade("SELL")

            except Exception as e:
                logger.error(f"Calculation for {st_name} failed: {e}")

    # 3. Push trades in parallel (I/O-bound)
    if avl_trades:
        with ThreadPoolExecutor(max_workers=5) as t_pool:
            futures = [
                t_pool.submit(push_trades_to_order, time_fr=1, country=country, avl_trades=[trade])
                for trade in avl_trades
            ]
            for fut in as_completed(futures):
                try:
                    fut.result()
                except Exception as e:
                    logger.error(f"Error pushing trade to order: {e}", stack_info=True)

    else:
        logger.info("No trades qualified to push to order.")


def sixty_trades_accumulate(country):
    logger.info(f"[60-min] Starting trade accumulation for {country}")
    # dbc = DBConnection()
    # data = db.get(country, {})
    avl_trades = []
    C_dir = DATA_DIR[country]

    try:
        res = dbc.raw_query(text(f"SELECT * FROM {TABLE_NAME[country]} WHERE is_active=1 and is_proc=0"))
    finally:
        dbc.close_engine()

    with ProcessPoolExecutor() as p_pool:
        future_to_stock = {
            p_pool.submit(run_calculation_process, item['stock_tick'], C_dir, 2): item['stock_tick']
            for item in res
        }

        for fut in as_completed(future_to_stock):
            st_name = future_to_stock[fut]
            try:
                result = fut.result()

                def evaluate_trade(trade_type: str, rrr_threshold: float = 1.15):
                    side_key = trade_type.upper()
                    rrr_key = f"{side_key}_RRR"
                    trade_data = result.get(side_key)

                    if result and result.get(rrr_key, 0) >= rrr_threshold and trade_data:
                        trade_result = {
                            "STOCK_NAME": result["STOCK_NAME"],
                            "TIME_FR": 1,
                            "PRICE_CMP": result.get("PRICE_CMP"),
                            "TRADE_TYPE": side_key,
                            rrr_key: result[rrr_key],
                            f"{side_key}_TIMESTAMPS": result.get(f"{side_key}_TIMESTAMPS"),
                            trade_type.upper(): trade_data,
                            "TIMESTAMP": datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
                        }
                        try:
                            model_stat = Indian_model_predictor(result["STOCK_NAME"], 2, side_key, datetime.now()).fetch_model_stats(
                                trade_data["entry_price"],
                                trade_data["target_price"],
                                trade_data["stop_loss"]
                            )
                            trade_result["PREDICTION"] = model_stat[0]
                            trade_result["PROBABILITY"] = model_stat[1]
                        except Exception as ex:
                            logger.error(f"[60-min] Model predictor error for {st_name} ({side_key}): {ex}")
                            trade_result["PREDICTION"] = None
                            trade_result["PROBABILITY"] = None

                        # sixty_trades = data.get('sixty_trades', [])
                        # sixty_trades.append(trade_result)
                        # data['sixty_trades'] = sixty_trades
                        # db[country] = data
                        # db.commit()
                        if trade_result["PREDICTION"] == "success":
                            res_ins_trade = insert_trade_signals(trade_result, country_id_dict[country], CASH_EXCHANGE_ID[country], 2)
                            if res_ins_trade:
                                check_and_insert_automated_alert(trade_result, CASH_EXCHANGE_ID[country], country_id_dict[country], 2)
                                avl_trades.append(trade_result)
                                logger.info(f"[60-min] {side_key} trade for {st_name} committed to DB")

                # Evaluate both BUY and SELL sides
                if result.get("BUY_RRR", 0) >= 1.15:
                    evaluate_trade("BUY", 1.15)
                if result.get("SELL_RRR", 0) >= 1.15:
                    evaluate_trade("SELL", 1.15)

            except Exception as e:
                logger.error(f"[60-min] Error in processing {st_name}: {e}", stack_info=True, exc_info=True)

    if avl_trades:
        with ThreadPoolExecutor(max_workers=5) as t_pool:
            futures = [
                t_pool.submit(push_trades_to_order, time_fr=2, country=country, avl_trades=[trade])
                for trade in avl_trades
            ]
            for fut in as_completed(futures):
                try:
                    fut.result()
                    
                except Exception as e:
                    logger.error(f"[60-min] Error pushing trade to order: {e}", stack_info=True, exc_info=True)
    else:
        logger.info("[60-min] No qualifying trades to push to order.")


if __name__ == "__main__":
    sixty_trades_accumulate("india")