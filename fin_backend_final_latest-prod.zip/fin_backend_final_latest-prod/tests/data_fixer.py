import os, sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from shared.config.settings import stock_data_dir_config

import pandas as pd
from datetime import datetime


input_path = os.path.join(stock_data_dir_config.indian_stock_data_dir, 'latest_data_csv')
output_path = os.path.join(stock_data_dir_config.indian_stock_data_dir, 'processed_data_files')

EXPECTED_FORMAT = "%d/%m/%Y %H:%M:%S"


def is_valid_date(date_str):
    """
    Check if a given date string matches the expected format.
    """
    try:
        datetime.strptime(str(date_str).strip(), EXPECTED_FORMAT)
        return True
    except Exception:
        return False

def check_file(file_path):
    """
    Check if 'tradeDate' column in a file has any invalid formats.
    """
    try:
        df = pd.read_csv(file_path)  # for Excel use pd.read_excel(file_path)
    except Exception as e:
        print(f"❌ Could not read {file_path}: {e}")
        return False

    if "timestamp" not in df.columns:
        return False  # skip if column not found

    invalid_found = df["timestamp"].apply(lambda x: not is_valid_date(x)).any()
    return invalid_found



def main():
    for filename in os.listdir(output_path):
        file_path = os.path.join(output_path, filename)

        if not os.path.isfile(file_path):
            continue

        if filename.lower().endswith(".csv"):  # add ".xlsx" for Excel support
            if check_file(file_path):
                print(f"⚠️ Invalid date format found in: {filename}")


if __name__ == "__main__":
    main()