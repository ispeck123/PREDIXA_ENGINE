import sys, os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))


from scripts.fc_order_update import check_entry_hit, evaluate_order_status
from shared.db.dbconn import DBConnection
from sqlalchemy import text
from datetime import datetime
import logging

logger = logging.getLogger()

db = DBConnection()

def update_futures():
    ords = db.raw_query(text("select * from future_order_master where is_trade_started=0"))
    for orders in ords:
        order_id = orders.get('order_id')
        stock_tick = orders.get('stock_tick')
        buy_price = orders.get('entry_price')
        time_frame = orders.get('time_frame')
        purchased_on = orders.get('purchased_cmp_date')
        exp_date = orders.get('expiry_date')
        exp_num = datetime.strptime(exp_date, "%d-%m-%Y").strftime('%d%m%Y')
        # print(purchased_on, type(purchased_on))
        try:
            stat, entry_timestamp = check_entry_hit(stock_tick, buy_price, purchased_on, time_frame, exp_num, 'F')
        except Exception as ex:
            logger.exception(ex, stack_info=True, exc_info=1)
            stat = False
        # print(entry_timestamp, type(entry_timestamp))
        if stat:
            # entry_timestamp = datetime.strptime(entry_timestamp, "%d/%m/%Y %H:%M:%S")
            up_query = f"""update future_order_master set is_trade_started=1, entry_timestamp='{entry_timestamp}' where order_id={order_id}"""
            rc = db.raw_connection()
            rc.execute(text(up_query))
            rc.commit()
            rc.close()
    print("Entry hit updated")
    ords = db.raw_query(text("select * from future_order_master where is_evaluated=0 and is_trade_started=1")) # order_master
    for orders in ords:
        order_id = orders.get('order_id')
        stock_tick = orders.get('stock_tick')
        buy_price = orders.get('entry_price')
        stop_loss = orders.get('stoploss_price')
        target_price = orders.get('target_price')
        stock_quantity = orders.get('stock_quantity')
        time_frame = orders.get('time_frame')
        # purchased_on = orders.get('purchased_cmp_date')
        entry_timestamp = orders.get('entry_timestamp')
        ord_type = orders.get('order_type')
        exp_date = orders.get('expiry_date')
        exp_num = datetime.strptime(exp_date, "%d-%m-%Y").strftime('%d%m%Y')

        try:
            entry_dt = datetime.fromisoformat(entry_timestamp)
        except Exception:
            entry_dt = datetime.strptime(entry_timestamp, "%Y-%m-%d %H:%M:%S")

        result = evaluate_order_status(
            stock_name=stock_tick,
            entry_price=buy_price,
            created_on=entry_dt.strftime("%Y-%m-%dT%H:%M"),
            stop_loss=stop_loss,
            target_price=target_price,
            quantity=stock_quantity,
            order_type=ord_type,
            time_frame=time_frame,
            exp_num=exp_num,
            segment='F'
        )
        update_sql = f"""
            UPDATE future_order_master
            SET order_status = :order_status,
                is_evaluated = :is_eval,
                completed_on = :completed_on
            WHERE order_id = :order_id
        """
        exec_result = result.copy()
        exec_result.pop('completed_on', None)
        rc = db.raw_connection()
        rc.execute(
            text(update_sql),
            {
                "order_status": str(exec_result),
                "is_eval": 1 if result.get("status") in ["success", "failed"] else 0,
                "completed_on": result.get("completed_on").strftime("%Y-%m-%d %H:%M:%S") if result.get("completed_on") else None,
                "order_id": order_id
            }
        )
        rc.commit()
        rc.close()
    print("Order evaluated")


def update_commodity():
    ords = db.raw_query(text("select * from commodity_order_master where is_trade_started=0"))
    for orders in ords:
        order_id = orders.get('order_id')
        stock_tick = orders.get('stock_tick')
        buy_price = orders.get('entry_price')
        time_frame = orders.get('time_frame')
        purchased_on = orders.get('purchased_cmp_date')
        exp_date = orders.get('expiry_date')
        exp_num = datetime.strptime(exp_date, "%d-%m-%Y").strftime('%d%m%Y')
        # print(purchased_on, type(purchased_on))
        try:
            stat, entry_timestamp = check_entry_hit(stock_tick, buy_price, purchased_on, time_frame, exp_num, 'C')
        except Exception as ex:
            logger.exception(ex, stack_info=True, exc_info=1)
            stat = False
        # print(entry_timestamp, type(entry_timestamp))
        if stat:
            # entry_timestamp = datetime.strptime(entry_timestamp, "%d/%m/%Y %H:%M:%S")
            up_query = f"""update commodity_order_master set is_trade_started=1, entry_timestamp='{entry_timestamp}' where order_id={order_id}"""
            rc = db.raw_connection()
            rc.execute(text(up_query))
            rc.commit()
            rc.close()
    print("Entry hit updated")
    ords = db.raw_query(text("select * from commodity_order_master where is_evaluated=0 and is_trade_started=1")) # order_master
    for orders in ords:
        order_id = orders.get('order_id')
        stock_tick = orders.get('stock_tick')
        buy_price = orders.get('entry_price')
        stop_loss = orders.get('stoploss_price')
        target_price = orders.get('target_price')
        stock_quantity = orders.get('stock_quantity')
        time_frame = orders.get('time_frame')
        # purchased_on = orders.get('purchased_cmp_date')
        entry_timestamp = orders.get('entry_timestamp')
        ord_type = orders.get('order_type')
        exp_date = orders.get('expiry_date')
        exp_num = datetime.strptime(exp_date, "%d-%m-%Y").strftime('%d%m%Y')

        try:
            entry_dt = datetime.fromisoformat(entry_timestamp)
        except Exception:
            entry_dt = datetime.strptime(entry_timestamp, "%Y-%m-%d %H:%M:%S")

        result = evaluate_order_status(
            stock_name=stock_tick,
            entry_price=buy_price,
            created_on=entry_dt.strftime("%Y-%m-%dT%H:%M"),
            stop_loss=stop_loss,
            target_price=target_price,
            quantity=stock_quantity,
            order_type=ord_type,
            time_frame=time_frame,
            exp_num=exp_num,
            segment='C'
        )
        update_sql = f"""
            UPDATE commodity_order_master
            SET order_status = :order_status,
                is_evaluated = :is_eval,
                completed_on = :completed_on
            WHERE order_id = :order_id
        """
        exec_result = result.copy()
        exec_result.pop('completed_on', None)
        rc = db.raw_connection()
        rc.execute(
            text(update_sql),
            {
                "order_status": str(exec_result),
                "is_eval": 1 if result.get("status") in ["success", "failed"] else 0,
                "completed_on": result.get("completed_on").strftime("%Y-%m-%d %H:%M:%S") if result.get("completed_on") else None,
                "order_id": order_id
            }
        )
        rc.commit()
        rc.close()
    print("Order evaluated")


if __name__ == "__main__":
    update_futures()
    # update_commodity()
    