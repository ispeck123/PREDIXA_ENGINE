import sys, os
import multiprocessing
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, wait, FIRST_COMPLETED, as_completed
from tqdm import tqdm
from datetime import datetime, timedelta
from queue import Queue
from threading import Thread

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from shared.db.db_model import Ind_StockMaster, Order
from shared.db.dbconn import DBConnection
from shared.db.db_utils import insert_alerts
from scripts.calculate_setup import Calculate_setup_execute
from shared.config.settings import stock_data_dir_config
import logging
from stock_model.model_predictor import Indian_model_predictor  # Optional

logger = logging.getLogger(__name__)

tf = 25



dbc = DBConnection()


# def insert_alerts_order(buy_dict, time_fr, stock_name, ord_type, dt):
#     # if not(is_similar_order_exists_auto_order(dt, stock_name, time_fr, buy_dict['entry_price'], buy_dict['stop_loss'], buy_dict['target_price'])):
#         # dbc = DBConnection()
#     db_order = Order(
#             stock_tick=stock_name,
#             order_type=ord_type,
#             time_frame=time_fr,
#             entry_price=buy_dict['entry_price'],
#             stoploss_price=buy_dict['stop_loss'],
#             target_price=buy_dict['target_price'],
#             stock_quantity=100,
#             purchased_cmp_date=dt.strftime("%Y-%m-%dT%H:%M"),
#             purchased_on=datetime.now())
#     session = dbc.get_session()
#     session.add(db_order)
#     session.commit()
#     session.refresh(db_order)
#     print("order pushed successfully")
#     session.close()
#     # dbc.close_engine()
#     print("Order Create Successfully...........................", stock_name)

def get_trading_days(start_date=datetime(2023, 4, 1), end_date=datetime.now()):
    current_date = start_date
    trading_days = []
    while current_date <= end_date:
        if current_date.weekday() < 5:  # Monday to Friday
            trading_days.append(current_date)
        current_date += timedelta(days=1)
    return trading_days

def get_all_stock_syms():
    db = dbc.get_session()
    res = db.query(Ind_StockMaster).filter(Ind_StockMaster.is_active == True).all()
    return [items.stock_tick for items in res][170:]

def run_calculation(stock, tday):
    try:
        cse = Calculate_setup_execute(
            stock_name=stock,
            time_frame=tf,
            last_dt=tday,
            country_dir=stock_data_dir_config.indian_stock_data_dir
        )
        result = cse.calculate()

        if 'BUY' in result and result['BUY_RRR'] >= 2.1:
            return ("BUY", result['BUY'], stock, tday)

        return None
    except Exception as ex:
        logger.error(f"❌ {stock} @ | Error: {str(ex)}", stack_info=True, exc_info=True)
        return f"❌ {stock} @  | Error: {str(ex)}"

def insert_worker(queue: Queue):
    while True:
        item = queue.get()
        if item is None:
            break  # Exit signal
        try:
            action, data, stock, tday = item
            insert_alerts(data, tf, stock, action, tday)
            tqdm.write(f"🟢 Inserted {action} alert for {stock} @ {tday.strftime('%Y-%m-%d')}")
        except Exception as ex:
            tqdm.write(f"❌ Insert error for {stock} @ {tday.strftime('%Y-%m-%d')}: {str(ex)}")
        queue.task_done()

def start_calculation_parallel():
    all_tasks = []
    trading_days = get_trading_days()
    stocks = get_all_stock_syms()
    #["icicibank"]
    #["hdfcbank", "icicibank", "itc", "reliance", "tcs", "asian_paints", "infy", "hindunilvr", "bharti_airtel"] #get_all_stock_syms()

    for stock in stocks:
        for tday in trading_days:
            all_tasks.append((stock, tday))

    insert_queue = Queue()
    insert_thread = Thread(target=insert_worker, args=(insert_queue,), daemon=True)
    insert_thread.start()

    with ProcessPoolExecutor(max_workers=10) as executor:
        futures = [executor.submit(run_calculation, stock, tday) for stock, tday in all_tasks]

        with tqdm(total=len(futures), desc="Processing Alerts", dynamic_ncols=True) as pbar:
            for future in as_completed(futures):
                result = future.result()
                if isinstance(result, tuple):  # Valid result
                    action, data, stock, tday = result
                    tqdm.write(f"✅ {stock} @ {tday.strftime('%Y-%m-%d')} [RRR OK]")
                    insert_queue.put(result)
                elif isinstance(result, str):
                    tqdm.write(result)
                pbar.update(1)

    insert_queue.put(None)  # Signal insert thread to exit
    insert_thread.join()

if __name__ == "__main__":
    start_calculation_parallel()
    # run_calculation("bharti_airtel", datetime(2025, 7, 8))