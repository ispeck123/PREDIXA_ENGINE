import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
import pandas as pd
from audit.trend_engine.phase2.metrics import conditional, episodes
from audit.trend_engine.price_action_oracle import label_as_of

def frame(values): return pd.DataFrame({'open':values,'high':[x+1 for x in values],'low':[x-1 for x in values],'close':values})
def test_oracle_does_not_use_unconfirmed_last_pivot():
    d=frame([5,4,3,4,5,4,3]); assert label_as_of(d)== 'SW' # last low lacks 3 right bars
def test_conditional_rates():
    d=pd.DataFrame({'E_regime':['UP','DN','UP','DN'],'reference_weekly':['DN','UP','DN','UP']});m=conditional(d,'E');assert m['up_given_ref_dn']==1 and m['dn_given_ref_up']==1
def test_episode_construction():
    d=pd.DataFrame({'symbol':['a']*3,'timestamp':['2020-01-01','2020-01-08','2020-01-15'],'E_regime':['UP','UP','SW'],'reference_weekly':['DN','DN','SW'],'E_rule_applied':['Rule B']*3,'X_cmp':[10,9,9]});e=episodes(d,'E');assert len(e)==1 and e.observations.iloc[0]==2
def test_missing_symbol_is_handled_by_runner_contract():
    from audit.trend_engine.phase2.run_universe_audit import DATA
    assert not (DATA/'definitely_missing_weekly.csv').exists()
def test_symbol_weighting_differs_from_row_pooling():
    d=pd.DataFrame({'symbol':['a']*101+['b']*2,'E_regime':['UP']*50+['SW']*50+['SW']+['SW','DN'],'reference_weekly':['DN']*100+['UP']+['DN','UP']})
    pooled=conditional(d,'E')['asymmetry']; equal=sum(conditional(g,'E')['asymmetry'] for _,g in d.groupby('symbol'))/2
    assert pooled != equal
