import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
import pandas as pd
from scripts.trend_engine import Config, TrendEngine, TrendRegime, TF, Zone, ZoneType, ExecutionDecisionEngine

def z(kind, distal, proximal, idx=2):
    return Zone("audit", TF.E, ZoneType(kind), distal, proximal, idx, idx, idx, 1)
def df(closes):
    return pd.DataFrame({"open":closes,"high":[x+1 for x in closes],"low":[x-1 for x in closes],"close":closes})
def calc(closes, bz=None, sz=None, zones=None, htf=None):
    zones=zones or {"BUY":([bz] if bz else []),"SELL":([sz] if sz else [])}
    return TrendEngine(Config()).calculate_trend(TF.E,df(closes),bz,sz,zones,htf_regime=htf)

def test_rule_b_only_bz_and_only_sz_and_no_zone():
    assert calc([100,101,102], z("BZ",90,95)).regime == TrendRegime.UP
    assert calc([100,99,98], None,z("SZ",110,105)).regime == TrendRegime.DN
    assert calc([100,100,100]).regime == TrendRegime.SW
def test_rule_b_htf_guard_is_symmetric():
    assert calc([100,101,102],z("BZ",90,95),htf=TrendRegime.DN).regime == TrendRegime.SW
    assert calc([100,99,98],None,z("SZ",110,105),htf=TrendRegime.UP).regime == TrendRegime.SW
def test_rule_c_one_and_two_opposing_zone_violations():
    bz,sz=z("BZ",90,95),z("SZ",105,103)
    assert calc([100,100,106],bz,sz).regime == TrendRegime.UP
    sz2=z("SZ",110,108,3)
    assert calc([100,100,111],bz,sz,{"BUY":[bz],"SELL":[sz,sz2]}).regime == TrendRegime.UP
    bz2=z("BZ",85,87,3)
    assert calc([100,100,84],bz,sz,{"BUY":[bz,bz2],"SELL":[sz]}).regime == TrendRegime.DN
def test_both_or_neither_violated_is_sideways():
    bz,sz=z("BZ",90,95,0),z("SZ",105,103,0)
    assert calc([100,106,89],bz,sz).regime == TrendRegime.SW
    assert calc([100,101,100],bz,sz).regime == TrendRegime.SW
def test_execution_matrix_ignores_x_quadrant_argument():
    e=ExecutionDecisionEngine()
    a=e.get_permissions(TrendRegime.UP,TrendRegime.UP,None)
    b=e.get_permissions(TrendRegime.UP,TrendRegime.UP,"Q3")
    assert a == b and a["bias"] == "Strong Bullish"
def test_x_regime_is_not_an_execution_matrix_input():
    # API accepts x quadrant only; its regime cannot influence this matrix.
    e=ExecutionDecisionEngine(); assert e.get_permissions(TrendRegime.DN,TrendRegime.DN,None)["bias"] == "Strong Bearish"
