import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from scripts.scanner_fc import SetupScannerOrchestrator_FC, ScanJob_FC, build_futures_expiry_map, build_commodity_expiry_map
from shared.config.settings import stock_logic_config
from datetime import datetime
from apps.pipelines.market_conditions import get_market_depth
from sqlitedict import SqliteDict
from shared.db.db_utils import insert_trade_signals
# from nselib.derivatives import expiry_dates_future
# Example usage


ldb = SqliteDict('finprod.sqlite', autocommit=False)

# commodity_expiry_map = ldb['indian_commodity_expiries']
# print(commodity_expiry_map)

# for iitems in commodity_expiry_map:
#     syms = iitems["symbol"]
#     first_expiry = iitems["expiry"][0]
#     print(syms, first_expiry)


# gg = build_commodity_expiry_map() #build_futures_expiry_map()
# print(gg)
time_frame = 1

orchestrator = SetupScannerOrchestrator_FC()
job = ScanJob_FC(
    time_lists=[getattr(stock_logic_config, f"FUTURE_TIME_FRAME_{time_frame}")],
    time_frame=time_frame,
    last_d_time=datetime.now(),
    output_path="scan_results_future.json",
    append=True,
    is_future=True
)
result = orchestrator.run(job)
print(result)
# market_depth = get_market_depth('NSE:AXISBANK-EQ', True)
# print(market_depth)

# syms = get_all_stock_syms()
# print(syms)