import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import requests
from bs4 import BeautifulSoup
from requests_html import HTMLSession
#import ollama
import json
from datetime import datetime, timedelta
from dateutil import parser
from shared.config.settings import Config as cfg
import feedparser
import ast
from langchain_community.document_loaders import FireCrawlLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma
from langchain_ollama import OllamaEmbeddings
from langchain_core.prompts import ChatPromptTemplate
from langchain_ollama import ChatOllama
from langchain_core.output_parsers.string import StrOutputParser
import pandas as pd
from datetime import datetime, date
import hashlib
# from sqlitedict import SqliteDict
from langchain_classic.retrievers import BM25Retriever, EnsembleRetriever
from langchain_core.documents import Document
import time
import random


class ModificationDb:
    
    def __init__(self, db_directory="/home/ispeck/STOCK_PROJECT/STP_LATEST/shared/lang_db/chroma_langchain_db_finanace/", embedding_model = "nomic-embed-text:latest"):
        
        self.embeddings = OllamaEmbeddings(model=embedding_model)
        self.store = Chroma(persist_directory=db_directory,embedding_function=self.embeddings)
        self.splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
        
    def firecrawl_load_with_retry(self, url: str, meta: dict, max_attempts: int = 6):
        for attempt in range(1, max_attempts + 1):
            try:
                loader = FireCrawlLoader(
                    api_key=cfg.FIRECRAWL_API_KEY,
                    url=url,
                    mode="scrape",
                )
                content = loader.load()
                if not content:
                    return None

                content[0].metadata = meta
                return content[0]

            except Exception as e:
                msg = str(e)

                # Firecrawl rate limit hit
                if "Rate limit exceeded" in msg or "Rate Limit Exceeded" in msg:
                    # backoff (increase each attempt)
                    sleep_s = min(60, 5 * attempt) + random.random()
                    print(f"⏳ Firecrawl rate limit. Sleeping {sleep_s:.1f}s then retry... ({attempt}/{max_attempts})")
                    time.sleep(sleep_s)
                    continue

                # Other error -> don’t crash whole run
                print(f"❌ Firecrawl error for {url}: {e}")
                return None

        print(f"⚠️ Firecrawl retries exhausted for {url}")
        return None
    def is_current_week(self, remove_date):
        """Check if 'published' date is within the current week"""
        
       
        now = datetime.now()
        start = now - timedelta(days=7)
        end = now
        
        return True if start.date() <= remove_date <= end.date() else False
        
    
    def delete_idx(self):
        data = self.store.get()
        metadatas = data["metadatas"]
        ids = data["ids"]

        if not metadatas:
            return  

        ds = pd.DataFrame(metadatas)
        ds["ids"] = ids
        ds["published"] = pd.to_datetime(ds["published"], errors="coerce").dt.date

        cutoff = date.today() - timedelta(days=7)
        outdated_ids = ds.loc[ds["published"] < cutoff, "ids"].dropna().tolist()

        if outdated_ids:
            self.store.delete(ids=outdated_ids)

        # return self.store
            
        
    def get_publisher(self,entry):
        if hasattr(entry, 'source'):
            publisher = entry.source.title
        elif 'title' in entry and '-' in entry.title:
            # Heuristic: Sometimes the publisher is in the title
            publisher = entry.title.split('-')[-1].strip()
        else:
            publisher = "Unknown"
        # print(publisher)  # fallback logo
        return publisher


    def get_publisher_logo(self,publisher: str) -> str:
        domain = cfg.PUBLISHER_DOMAIN_MAP.get(publisher)
        if domain:
            return f"https://www.google.com/s2/favicons?domain={domain}&sz=64"
        else:
            return "https://st2.depositphotos.com/6789684/12262/v/450/depositphotos_122620866-stock-illustration-illustration-of-flat-icon.jpg"  
        
    def google_rss_to_article_url(self,google_rss_url: str) -> str:
        
        HEADERS = {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/132.0.0.0 Safari/537.36"
            )
        }
        
        
        if "news.google.com/rss/articles" not in google_rss_url:
            return google_rss_url

        # 1. Load the splash page
        r = requests.get(google_rss_url, headers=HEADERS, timeout=15)
        r.raise_for_status()
        soup = BeautifulSoup(r.text, "html.parser")

        c_wiz = soup.select_one("c-wiz[data-p]")
        if not c_wiz:
            return google_rss_url

        data_p = c_wiz["data-p"]

        # 2. Reconstruct the payload object
        obj = json.loads(data_p.replace('%.@.', '["garturlreq",'))

        payload = {
            "f.req": json.dumps(
                [[[
                    "Fbv4je",
                    json.dumps(obj[:-6] + obj[-2:]),
                    "null",
                    "generic"
                ]]]
            )
        }

        # 3. Call internal batchexecute API
        r2 = requests.post(
            cfg.FIRECRAWL_BATCH_EXECUTE_API,
            data=payload,
            headers={
                "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
                **HEADERS,
            },
            timeout=15,
        )
        r2.raise_for_status()

        # 4. Parse out article URL
        # Response starts with ")]}'" then JSON
        data = json.loads(r2.text.replace(")]}'", ""))[0][2]
        article_url = json.loads(data)[1]
        return article_url  
    
    
    def get_existing_links(self):
        """Return a set of all article links already stored in Chroma."""
        data = self.store.get(limit=1000000)  # big limit to get all docs
        metadatas = data.get("metadatas", []) or []
        existing_links = set()

        for m in metadatas:
            link = m.get("link")
            if link:
                existing_links.add(link)

        return existing_links

    def current_news_data(self):
        feed = feedparser.parse(cfg.RSS_FEED_URL)
        news_data = []
        today = date.today()

        # Links we already have in the vector DB
        existing_links = self.get_existing_links()
        # Links we see in this run (to avoid duplicates in the same feed)
        seen_links = set()

        for entry in feed.entries:
            # Safely parse published date
            try:
                published_dt = datetime.strptime(
                    entry.published,
                    "%a, %d %b %Y %H:%M:%S %Z"
                )
            except Exception:
                continue

            # Only keep today's news (your original logic)
            if published_dt.date() != today:
                continue

            publisher = self.get_publisher(entry)
            logo = self.get_publisher_logo(publisher)

            # Resolve final article URL once here
            link = self.google_rss_to_article_url(entry.link)

            # 1) Skip if already in DB
            if link in existing_links:
                # print(f"Skipping existing article: {link}")
                continue

            # 2) Skip duplicates in this same run
            if link in seen_links:
                continue
            seen_links.add(link)

            news_data.append({
                "title": entry.title,
                "link": link,
                "published": entry.published,
                "publisher": publisher,
                "logo": logo,
            })

        # Now call FireCrawl **only** for new links in news_data
        docs = []
        for info in news_data:
            doc = self.firecrawl_load_with_retry(
                info["link"],
                meta={
                    "title": info["title"],
                    "published": info["published"],
                    "publisher": info["publisher"],
                    "link": info["link"],
                }
            )
            if doc:
                docs.append(doc)

            # Hard throttle to stay under req/min
            time.sleep(2.0 + random.random() * 1.0)

        if not docs:
            return []

        texts = self.splitter.split_documents(docs)
        return texts


    def update_db(self, texts):
        if not texts:
            return

        # Get ALL existing ids (Chroma .get() defaults to a small limit)
        data = self.store.get(limit=1000000)
        existing_ids = set(data.get("ids", [])) if data.get("ids") else set()

        docs_by_id = {}  # doc_id -> doc (ensures uniqueness in this batch too)

        for doc in texts:
            title = doc.metadata.get("title", "")
            published = doc.metadata.get("published", "")
            publisher = doc.metadata.get("publisher", "")
            link = doc.metadata.get("link", "")

            raw_key = f"{title}|{published}|{publisher}|{link}|{doc.page_content}"
            doc_id = hashlib.md5(raw_key.encode("utf-8")).hexdigest()

            # Skip if already in DB
            if doc_id in existing_ids:
                continue

            # Skip duplicates within this batch
            if doc_id in docs_by_id:
                continue

            docs_by_id[doc_id] = doc

        if docs_by_id:
            self.store.add_documents(
                list(docs_by_id.values()),
                ids=list(docs_by_id.keys())
            )
            self.store.persist()

        
        
        
                
    def result(self,query1,query):
        print("before deletion", len(self.store.get()['ids']))
        self.delete_idx()
        print("after deletion", len(self.store.get()['ids']))
        texts = self.current_news_data()
        # print(texts)
        self.update_db(texts)
        print("after updation", len(self.store.get()['ids']))
        metadatas = self.store.get()['metadatas']
        docs = self.store.get()['documents']
        bm25=BM25Retriever.from_documents([Document(page_content=doc,metadata=metadata) for doc, metadata in zip(docs,metadatas)])
        bm25.k =10
        retreiver = self.store.as_retriever(search_type="mmr",
                        search_kwargs={
                            "k": 10,         # how many final docs you want
                            "fetch_k": 20,  # how many candidates to consider before picking 4
                            "lambda_mult": 0.5,  # balance relevance vs diversity (0–1)
                        })
        ensemble_retrieve = EnsembleRetriever(retrievers=[retreiver,bm25],weights=[0.5,0.5])
        
        rel_docs = retreiver.invoke(query1)
        
        rel = "\n\n".join([doc.page_content for doc in rel_docs])
        relevant = f"""\n\nRelevant Documents:\n"
            + {rel}
            + "\n\nPlease provide an answer based only on the provided documents. If the answer is not found in the documents, respond with 'I'm not sure'."""
                
        
        messages = [('system','You are a professional stock market analyst; using only the retrieved News Context chunks, identify up to 10 INDIAN stocks with the highest short-term trading potential and fill in the fields: stock_name, sentiment, reasoning, suggested_trade, target_price_zone, confidence_level'),
                    ('human',"""Here are some documents that might help answer the question: "
                + {query}
                + {documents}
            """)]
        
        prompt = ChatPromptTemplate.from_messages(messages)
        
        model = ChatOllama(model='llama3.1:8b')

        chain = prompt|model|StrOutputParser()
        
        res = chain.invoke({'query':query,'documents':relevant})
        
        return res
    
    
mod = ModificationDb()
# result = mod.result('identify 10 stocks with the highest short-term trading potential?')
result = mod.result('India stock buy recommendation target upgrade downgrade results order contract expansion acquisition fundraising block deal',
                    """Identify 10 INDIAN stocks with the highest short-term trading potential.
                       For each stock, include:
                        - Stock name / Instrument
                        - Sentiment (Bullish/Bearish/Neutral)
                        - Reasoning (based on news data)
                        - Suggested Trade (Buy/Sell)
                        - Target price zone (approximation based on momentum)
                        - Confidence level (High/Medium/Low)
                        Give me the response in a proper json format. Do not add anything in response which is invalid to be converted to json. 
                        Maintain the format of response like the example below. Keep the keys of the json same as the example given below.
                        "{{
                            "stocks": [
                                        {{
                                            "stock_name": "value",
                                            "sentiment": "value",
                                            "reasoning": "value",
                                            "suggested_trade": "value",
                                            "target_price_zone": "value",
                                            "confidence_level": "value"
                                        }},
                                        {{
                                            "stock_name": "value",
                                            "sentiment": "value",
                                            "reasoning": "value",
                                            "suggested_trade": "value",
                                            "target_price_zone": "value",
                                            "confidence_level": "value"
                                        }}
                                    ]
                                    
                        }}
                        Do not add anything in response which is invalid to be converted to json.""")
print(result)