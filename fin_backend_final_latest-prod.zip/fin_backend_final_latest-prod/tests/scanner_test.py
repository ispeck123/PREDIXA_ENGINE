import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from scripts.scanner import SetupScannerOrchestrator, ScanJob
from shared.config.settings import stock_logic_config
from datetime import datetime
from apps.pipelines.market_conditions import get_market_depth
# Example usage



orchestrator = SetupScannerOrchestrator()
job = ScanJob(
    time_lists=[stock_logic_config.TIME_FRAME_EXE_2],
    time_frame=2,
    last_d_time=datetime.now(),
    output_path="scan_results_sixty.json",
    append=True
)
result = orchestrator.run(job)
print(result)
# market_depth = get_market_depth('NSE:AXISBANK-EQ', True)
# print(market_depth)