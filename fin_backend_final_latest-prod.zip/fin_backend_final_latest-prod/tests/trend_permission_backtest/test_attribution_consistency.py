import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "audit" / "trend_permission_backtest"))
from attribution_common import wet_reconciliation


def test_preserved_wet_run_reproduces_reported_cells():
    _, counts = wet_reconciliation()
    assert counts[("SW", "UP", "AGAINST_TRADE_DIRECTION")] == 5
    assert counts[("UP", "SW", "AGAINST_TRADE_DIRECTION")] == 6
    assert counts[("UP", "SW", "PERMITTED_DIRECTION")] == 1
    assert counts[("UP", "UP", "AGAINST_TRADE_DIRECTION")] == 7
    assert counts[("UP", "UP", "PERMITTED_DIRECTION")] == 3


def test_wet_method_is_not_actual_entry_time():
    rows, _ = wet_reconciliation()
    assert len(rows) == 22
    assert not rows["timestamp_gate"].any()
    assert rows["scan_to_entry_hours"].min() > 0
