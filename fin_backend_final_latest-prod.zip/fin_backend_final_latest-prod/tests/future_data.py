import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from shared.config.settings import stock_data_dir_config
from data_fetchers.fyers.indian_futures_data_custom import Indian_future_data_handler, future_data_processer
input_path = os.path.join(stock_data_dir_config.future_bk_data_dir, 'latest_data_csv')
output_path = os.path.join(stock_data_dir_config.future_bk_data_dir, 'processed_data_files')

# print(f"Input path: {input_path}")
# print(f"Output path: {output_path}")

# Create handler instance
handler = Indian_future_data_handler()
fdp = future_data_processer()
# Test the handler
try:
    # handler.process()
    fdp.process_all_files()
    print("Future data processing completed successfully")
except Exception as e:
    print(f"Error processing future data: {e}")