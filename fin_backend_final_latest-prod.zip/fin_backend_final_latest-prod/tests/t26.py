import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# from data_fetchers.fyers.candle_data import CandleDateFetcher
# from data_fetchers.fyers.indian_stock_data_updater import INDIAN_STOCK_DATA_UPDATER
# cls = CandleDateFetcher()
# # cls.fetch_candle_data_custom_resolution(stock_tick='deepak_fertilizers__petr', symbol="DEEPAKFERT", start_date="2020-01-01", resolution="M")
# # # cls.fetch_candle_data_custom_resolution(stock_tick='deepak_fertilizers__petr', symbol="DEEPAKFERT", start_date="2020-01-01", resolution="W")
# cls.fetch_candle_data_custom_resolution(stock_tick='aeroflex_neu_limited', symbol="AERONEU", start_date="2020-01-01", resolution="1D")
# # cls.fetch_candle_data_custom_resolution(stock_tick='deepak_fertilizers__petr', symbol="DEEPAKFERT", start_date="2020-01-01", resolution="60")
# # cls.fetch_candle_data_custom_resolution(stock_tick='deepak_fertilizers__petr', symbol="DEEPAKFERT", start_date="2020-01-01", resolution="15")

# # from data_fetchers.fyers.indian_stock_data_updater import INDIAN_STOCK_DATA_UPDATER
# # obj = INDIAN_STOCK_DATA_UPDATER()
# # obj.create_75munite_from_15munite("deepak_fertilizers__petr_fifteen.csv")
# # obj.create_monthly_and_weekly_from_daily("deepak_fertilizers__petr_daily.csv", 'W')
# # obj.create_monthly_and_weekly_from_daily("deepak_fertilizers__petr_daily.csv", 'ME')

from shared.db.dbconn import DBConnection
from shared.db.db_model import TradeSignal
import ast
import logging
from apps.finprod_backend.modules.order_update import check_entry_hit, evaluate_order_status
from datetime import datetime
from sqlalchemy import text
from shared.config.settings import Config as cfg
import pandas as pd


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

db = DBConnection()

def delete_pending_trades_entryNotHit_targetHit():
    try:
        
        time_frames = {
            8: {1: "daily", 2: "sixty", 3: "fifteen", 25: "seventy_five"},
            10: {1: "daily", 2: "two_forty", 3: "one_twenty", 4: "sixty"},
            11: {1: "daily", 2: "sixty", 3: "fifteen", 25: "seventy_five"}
        }

        session = db.get_session()
        trade_signals = session.query(TradeSignal).filter(TradeSignal.is_active == 1).all()
        
        for trade in trade_signals:
            try:
                
                if trade.trade_type in ("BUY", "buy", "Buy"):
                    column_name = "low"
                elif trade.trade_type in ("SELL", "sell", "Sell"):
                    column_name = "high"
                #print(trade.trade_data['entry_price'])
                created_at = datetime.strftime(trade.created_at, "%Y-%m-%dT%H:%M")
                # print(trade.exp_date)
                #print(trade.time_fr)
                if trade.exp_date is None:  
                    status, timestamp = check_entry_hit(trade.stock_name,
                                                        trade.trade_data['entry_price'],
                                                        str(created_at),
                                                        trade.time_fr)
                    # print(trade, status, timestamp)
                    
                    if status != True:

                        print(trade.id)
                        if trade.trade_type in ("BUY", "buy", "Buy"):
                            column_name = "low"
                        elif trade.trade_type in ("SELL", "sell", "Sell"):
                            column_name = "high"

                        target_price = trade.trade_data['target_price']

                        time_fr = time_frames.get(trade.exchange_id, None)
                        if time_fr:
                            time_fr = time_fr.get(trade.time_fr, None)
                        if time_fr:
                            
                            if trade.exchange_id == 8:
                                file_path = os.path.join(cfg.india_data_dir, "latest_data_csv", f"{trade.stock_name}_{time_fr}.csv")
                            elif trade.exchange_id == 10:
                                exp_date
                                file_path = os.path.join(cfg.commodity_data_dir, "latest_data_csv", f"{trade.stock_name}_{exp_date}_{time_fr}.csv")
                            elif trade.exchange_id == 11:
                                exp_date
                                file_path = os.path.join(cfg.commodity_data_dir, "latest_data_csv", f"{trade.stock_name}_{exp_date}_{time_fr}.csv")
                            else:
                                file_path = None
                            
                            if file_path:
                                print(file_path)
                                if os.path.exists(file_path):
                                    
                                    df = pd.read_csv(file_path)
                                    df['tradeDate'] = pd.to_datetime(df['tradeDate'], format='%d/%m/%Y %H:%M:%S')
                                    trade.created_at = datetime.strftime(trade.created_at, "%d/%m/%Y %H:%M:%S")
                                    trade.created_at = datetime.strptime(trade.created_at, "%d/%m/%Y %H:%M:%S")
                                    data = df[df['tradeDate'] >= trade.created_at]
                                    unique_dates = data['tradeDate'].dt.date.unique()
                                    #print(unique_dates)
                                    if len(unique_dates) >= 5:
                                        
                                        if trade.trade_type in ("BUY", "buy", "Buy"):
                                            
                                            low = data["low"].min()
                                            threshold = trade.trade_data['entry_price'] * 0.05
                                            if abs(low - trade.trade_data['entry_price']) <= threshold:
                                                high = data["high"].max()
                                                if high >= target_price: 
                                                    #session.delete(trade)
                                                    logger.info(f"Pending trade signal deleted: id {trade.id}")
                                        
                                        elif trade.trade_type in ("SELL", "sell", "Sell"):
                                            
                                            high = data["high"].max()
                                            threshold = trade.trade_data['entry_price'] * 0.05
                                            if abs(trade.trade_data['entry_price'] - high) <= threshold:
                                                low = data["low"].min()
                                                if low <= target_price: 
                                                    #session.delete(trade)
                                                    logger.info(f"Pending trade signal deleted: id {trade.id}")
                                else:
                                    logger.error(f"File not found: {file_path}")
                            else:
                                logger.error(f"Exchange Id not found: {trade.exchange_id}")
                        else:
                            logger.error(f"Time frame not found: time frame {trade.time_fr}")
            except Exception as er:
                logger.exception(f"Error in delete_pending_trades_entryNotHit_targetHit (Trade Id :{trade.id}): {er}", exc_info=1, stack_info=True)        
        session.commit()
        session.close()
        db.close_engine()
    except Exception as ex:
        logger.exception(f"Error in delete_pending_trades_entryNotHit_targetHit: {ex}", exc_info=1, stack_info=True)

delete_pending_trades_entryNotHit_targetHit()