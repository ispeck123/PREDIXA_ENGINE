import pandas as pd
import os
from datetime import datetime
import sys
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from scripts.stock_logic import proc_all_stock_items
from shared.config.settings import stock_data_dir_config
# input_dir = stock_data_dir_config.indian_stock_future_data_dir + "/latest_data_csv"
# output_dir = stock_data_dir_config.indian_stock_future_data_dir + "/processed_data_files"

input_dir = stock_data_dir_config.indian_stock_data_dir + "/latest_data_csv"
output_dir = stock_data_dir_config.indian_stock_data_dir + "/processed_data_files"


def purge_latest_data():
    all_files = os.listdir(input_dir)
    print("purging latest data")
    ctr = 0
    for file in all_files:
        try:
            ctr += 1
            print(ctr, len(all_files))
            full_file_path = os.path.join(input_dir, file)
            df = pd.read_csv(full_file_path)
            df['tradeDate'] = pd.to_datetime(df['tradeDate'], dayfirst=True)
            df = df[df['tradeDate'] <= datetime(2026, 7, 1, hour=0, minute=0, second=0)]
            df['tradeDate'] = df['tradeDate'].dt.strftime('%d/%m/%Y %H:%M:%S')
            df.to_csv(full_file_path, index=False)
        except Exception as e:
            print(full_file_path)
            logger.error(e, exc_info=True)

# def purge_processed_data():
#     all_files = os.listdir(output_dir)
#     print("purging processed data")
#     ctr = 0
#     for file in all_files:
#         try:
#             ctr += 1
#             print(ctr, len(all_files))
#             full_file_path = os.path.join(output_dir, file)
#             df = pd.read_csv(full_file_path)
#             df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst=True)
#             df = df[df['timestamp'] <= datetime(2025, 10, 5, hour=0, minute=0, second=0)]
#             df['timestamp'] = df['timestamp'].dt.strftime('%d/%m/%Y %H:%M:%S')
#             df.to_csv(full_file_path, index=False)
#         except Exception as e:
#             print(full_file_path)
#             logger.error(e, exc_info=True)

# tick = "aditya_birla_real_estate_sixty.csv"
# proc_all_stock_items(tick, input_dir, output_dir)


if __name__ == "__main__":
    purge_latest_data()
    # purge_processed_data()
    # ss = "NSE:ADITYA_BIRLA_REAL_ESTATE_SIXTY-EQ"
    # print(ss.strip().upper())