import sys, os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import pandas as pd
from shared.db.dbconn import DBConnection
from sqlalchemy import text
import re
from datetime import datetime

dbc = DBConnection()


# df = pd.read_csv("Matched_Fyers_Symbols.csv")


# for i in range(len(df)):
#     rc = dbc.raw_connection()
#     query = "update ind_stock_master set fyers_symbol='{}' where stock_tick='{}'".format(df.iloc[i]['fyers_symbol'], df.iloc[i]['stock_tick'])
#     rc.execute(text(query))
#     rc.commit()
#     rc.close()
import requests
from io import StringIO


def extract_date(entry):
    match = re.search(r'\b(\d{2})\s([A-Za-z]{3})\s(\d{2})\b', entry)
    if match:
        year, month, day = match.groups()
        full_date_str = f"20{year} {month} {day}"
        return datetime.strptime(full_date_str, "%Y %b %d")
    return None

def get_latest_fyers_commodity_symbol(product="GOLDM"):
    try:
        # Step 1: Download the latest file  
        url = "https://public.fyers.in/sym_details/NSE_FO.csv"
        response = requests.get(url)
        response.raise_for_status()  # Raise error if request failed
        # Step 2: Read into DataFrame (no headers in file)
        df = pd.read_csv(StringIO(response.text), header=None)
        # Step 3: Filter for product
        df = df[df[9].astype(str).str.contains(f"NSE:{product}", na=False)]
        df = df[df[9].astype(str).str.contains("FUT", na=False)]
        # Step 4: Convert expiry column (index 10) to datetime
        df["parsed_date"] = df[1].apply(extract_date)
        df = df.dropna(subset=["parsed_date"]).sort_values(by="parsed_date")
        df['parsed_date'] = df['parsed_date'].dt.strftime('%d-%m-%Y')

        fdf = pd.DataFrame({
            "symbol": df[9].to_list()[:3],
            "expiry": df["parsed_date"].to_list()[:3]
        })
        # Step 5: Sort and return latest symbol
        return fdf.to_dict('records')

    except Exception as e:
        print(f"Error fetching latest symbol: {e}")
        return None


# print(get_latest_fyers_commodity_symbol("GOLDM"))   # e.g. MCX:GOLDM24JULFUT
print(get_latest_fyers_commodity_symbol("RBL"))