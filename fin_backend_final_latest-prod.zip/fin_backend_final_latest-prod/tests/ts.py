from __future__ import annotations
import re
from typing import Iterable, Dict, List, Optional

import pandas as pd
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

# --- nselib imports ---
# nselib APIs move occasionally; we try a couple of import paths defensively.
try:
    from nselib import capital_market as cm
except Exception:  # pragma: no cover
    # Older/newer releases sometimes expose at top-level
    import nselib as cm  # type: ignore

# ---------------------------
# Indices to check (from your image)
# ---------------------------
INDEXES_TO_CHECK = [
    # Broad market
    "NIFTY 50", "NIFTY 100", "NIFTY 200", "NIFTY 500", "NIFTY MICROCAP 250",
    "NIFTY MIDCAP 150", "NIFTY MIDCAP 50", "NIFTY MIDSMALLCAP 400",
    "NIFTY NEXT 50", "NIFTY SMALLCAP 100", "NIFTY SMALLCAP 250",
    "NIFTY TOTAL MARKET",
    # Sectoral
    "NIFTY AUTO", "NIFTY BANK", "NIFTY CONSUMER DURABLES", "NIFTY FINANCIAL SERVICES",
    "NIFTY FMCG", "NIFTY HEALTHCARE", "NIFTY IT", "NIFTY MEDIA", "NIFTY METAL",
    "NIFTY OIL & GAS", "NIFTY PHARMA", "NIFTY PRIVATE BANK", "NIFTY PSU BANK",
    "NIFTY REALTY",
    # Thematic
    "NIFTY 100 LIQUID 15", "NIFTY COMMODITIES", "NIFTY CONSUMPTION",
    "NIFTY CPSE", "NIFTY ENERGY", "NIFTY INFRASTRUCTURE", "NIFTY MNC",
    "NIFTY MIDCAP LIQUID 15", "NIFTY PSE", "NIFTY SERVICES SECTOR",
    # Strategy
    "NIFTY 50 VALUE 20", "NIFTY ALPHA 50", "NIFTY DIVIDEND OPPORTUNITIES 50",
    "NIFTY GROWTH SECTORS 15", "NIFTY MIDSMALLCAP 400 MOMENTUM QUALITY LOW-VOL",
    "NIFTY QUALITY 30",
]

# If your nselib expects slightly different display names for any item above,
# put a mapping here (left = our name, right = nselib's expected name).
INDEX_NAME_ALIASES: Dict[str, str] = {
    # examples (uncomment if your environment needs them):
    # "NIFTY OIL & GAS": "NIFTY OIL AND GAS",
    # "NIFTY HEALTHCARE": "NIFTY HEALTH CARE",
}

# --------------- utilities ---------------

def _norm_idx_name(name: str) -> str:
    return INDEX_NAME_ALIASES.get(name, name)

def _sanitize_symbol(s: str) -> str:
    # accept "NSE:RELIANCE" / "RELIANCE-EQ" / "RELIANCE"
    s = s.split(":")[-1].upper()
    return s.replace("-EQ", "")

@retry(
    retry=retry_if_exception_type(Exception),
    wait=wait_exponential(multiplier=1, min=1, max=8),
    stop=stop_after_attempt(4),
    reraise=True,
)
def _index_constituents(index_name: str) -> pd.DataFrame:
    """Fetch a DataFrame of constituents for an index via nselib, with retries."""
    idx = _norm_idx_name(index_name)
    df = cm.index_stocks(idx)  # expected columns usually include 'Symbol', 'ISIN Code' or 'ISIN', 'Company Name'
    if not isinstance(df, pd.DataFrame) or df.empty:
        raise RuntimeError(f"Empty result for index {idx}")
    # normalize column names
    cols = {c: c.strip().upper() for c in df.columns}
    df.rename(columns=cols, inplace=True)
    return df

def _try_get_isin(symbol: str) -> Optional[str]:
    """Resolve stock symbol -> ISIN using nselib (best effort)."""
    sym = _sanitize_symbol(symbol)
    # Many nselib builds expose `cm.get_quote_equity(sym)` or `cm.quote_equity(sym)`
    for fn_name in ("get_quote_equity", "quote_equity", "get_quote"):
        fn = getattr(cm, fn_name, None)
        if fn:
            try:
                q = fn(sym)
                if isinstance(q, dict):
                    # common keys across versions
                    for k in ("isin", "ISIN", "isinCode", "ISIN Code"):
                        if k in q and q[k]:
                            return str(q[k]).strip()
            except Exception:
                pass
    return None

def _membership_check_frame(df: pd.DataFrame, sym: str, isin: Optional[str]) -> bool:
    """True if df contains the security by ISIN or Symbol/Name heuristics."""
    sym = _sanitize_symbol(sym)

    # 1) ISIN (preferred)
    if isin:
        isin_cols = [c for c in df.columns if "ISIN" in c]
        for c in isin_cols:
            if df[c].astype(str).str.fullmatch(rf"\s*{re.escape(isin)}\s*", case=False).any():
                return True

    # 2) Symbol (fallback)
    sym_cols = [c for c in df.columns if c in ("SYMBOL", "TICKER")]
    for c in sym_cols:
        series = df[c].astype(str).str.upper().str.replace("-EQ", "", regex=False)
        if (series == sym).any():
            return True

    # 3) Company Name (last resort heuristic)
    name_cols = [c for c in df.columns if "NAME" in c]
    for c in name_cols:
        if df[c].astype(str).str.upper().str.contains(rf"\b{re.escape(sym)}\b").any():
            return True

    return False

# --------------- public API ---------------

def indices_for_symbol(symbol: str, indices: Iterable[str] = INDEXES_TO_CHECK) -> List[str]:
    """Return list of indices (from your set) that include the given symbol."""
    isin = _try_get_isin(symbol)
    hits: List[str] = []

    for idx in indices:
        try:
            df = _index_constituents(idx)
            if _membership_check_frame(df, symbol, isin):
                hits.append(idx)
        except Exception:
            # timeout / transient failure — skip this index silently
            continue

    return hits

# --------------- CLI ---------------
if __name__ == "__main__":
    import argparse, json
    p = argparse.ArgumentParser(description="Find NSE indices that contain a stock (uses nselib).")
    p.add_argument("symbol", help="e.g., RELIANCE or NSE:RELIANCE or RELIANCE-EQ")
    args = p.parse_args()
    out = indices_for_symbol(args.symbol)
    print(json.dumps({"symbol": args.symbol, "indices": out}, indent=2))
