import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.setup_engine_new import SDEnginePipeline, process_setup_fc, format_calculate_setup_response
from scripts.trade_engine import processs_all_zones, process_zones, process_qualified_zones
from scripts.models import TF
import pandas as pd
from scripts.trend_engine import MultiTimeframeTrendCalculator
from shared.config.settings import stock_logic_config, stock_data_dir_config
from datetime import datetime

# tick = 'ICICIBANK'
tick = 'AXISBANK'
time_list = stock_logic_config.FUTURE_TIME_FRAME_25
# print(df.head())
#last_d_time = datetime(year=2026, month=2, day=25, hour=12, minute=17)
last_d_time = datetime.now()
exp_num = '30062026'
file_path = f"{stock_data_dir_config.indian_stock_future_data_dir}/latest_data_csv/{tick}_{exp_num}_seventy_five.csv"
# df = pd.read_csv(file_path)
# df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst=True)

if __name__ == "__main__":
    # pipeline = SDEnginePipeline()
    # resp = pipeline.run(tick, time_list, df.iloc[-1]['timestamp'])
    # print(resp)
    # resp = processs_all_zones(file_path, TF.A, df.iloc[-1]['timestamp'])
    # print(resp)
    # mft = MultiTimeframeTrendCalculator()
    # mft._set_symbol_and_timeframe(time_list, tick, df.iloc[-1]['timestamp'])
    # context = mft.calculate_full_context()
    # api_responce = mft.to_api(context)
    # print(api_responce)
    # proc_set = process_setup_fc(tick, time_list, exp_num, last_d_time, False)
    #print("proc_set", proc_set)
    # formatted_resp = format_calculate_setup_response(proc_set, stock_name=tick, time_fr=2, exp_num=exp_num, last_d_time=last_d_time, is_future=False, is_cash=True)
    # print(formatted_resp)
    # resp = process_zones(file_path, TF.X, df.iloc[-1]['timestamp'])
    resp = process_qualified_zones(file_path, TF.X, last_d_time, time_list, tick)
    print(resp)