import sys, os
import multiprocessing
from concurrent.futures import ProcessPoolExecutor
from tqdm import tqdm
from datetime import datetime, timedelta

# Cap numerical threading (do this BEFORE numpy/pandas import anywhere)
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from shared.db.db_model import Ind_StockMaster
from shared.db.dbconn import DBConnection
from shared.db.db_utils import insert_alerts  # <-- replace with a bulk variant below if you can
from scripts.calculate_setup_bkt import Calculate_setup_execute
from shared.config.settings import stock_data_dir_config

tf = 2

def get_trading_days(start_date=datetime(2023, 5, 1), end_date=datetime(2023, 6, 1)):
    current_date = start_date
    trading_days = []
    while current_date <= end_date:
        if current_date.weekday() < 5:  # Mon-Fri
            trading_days.append(current_date)
        current_date += timedelta(days=1)
    return trading_days

def get_all_stock_syms():
    dbc = DBConnection()
    db = dbc.get_session()
    try:
        res = db.query(Ind_StockMaster).filter(Ind_StockMaster.is_active == True).all()
        return [items.stock_tick for items in res]
    finally:
        db.close()

def process_one_stock(args):
    """
    Heavy work runs here, but NO DB calls.
    Returns: list of tuples (action, data, stock, tday)
    """
    stock, trading_days = args
    alerts = []
    # Initialize once (ideally, this loads data and can reuse it across dates)
    # If your class needs last_dt only at calculate() time, pass it then.
    # If last_dt must be in ctor, you can re-instantiate per-date (slower).
    # try:
    #     # If your class MUST take last_dt in ctor, set to None now and override per loop if possible
    #     cse = Calculate_setup_execute(
    #         stock_name=stock,
    #         time_frame=tf,
    #         last_dt=None,                       # <--- Prefer making last_dt optional
    #         country_dir="./data/BACKTEST"
    #     )
    # except Exception:
    #     # If ctor needs last_dt, we’ll instantiate inside the loop as a fallback
    #     cse = None

    for tday in trading_days:
        try:
            # if cse is not None:
                # Prefer: a calculate() that accepts last_dt:
                # result = cse.calculate(last_dt=tday)  # <-- adjust if your method signature differs
            # else:
            # Fallback: re-create (slower)
            cse_local = Calculate_setup_execute(
                stock_name=stock,
                time_frame=tf,
                last_dt=tday,
                country_dir="./data/BACKTEST"
            )
            result = cse_local.calculate()

            if isinstance(result, dict) and 'BUY' in result and result.get('BUY_RRR', 0) >= 2.1:
                alerts.append(("BUY", result['BUY'], stock, tday))
        except Exception as ex:
            # Return string logs as separate items if you want to surface them
            alerts.append(("__LOG__", f"❌ {stock} @ {tday.strftime('%Y-%m-%d')} | Error: {str(ex)}", stock, tday))
    return alerts

# Optional: a bulk insert wrapper if your DB layer supports it
def insert_alerts_bulk(rows, batch_size=500):
    """
    rows: list of (action, data, stock, tday)
    Implement this in shared.db.db_utils if possible to do executemany in a single transaction.
    """
    from sqlalchemy.orm import Session
    dbc = DBConnection()
    db: Session = dbc.get_session()
    try:
        buffer = []
        for action, data, stock, tday in rows:
            if action == "__LOG__":
                # just print logs
                tqdm.write(data)
                continue
            buffer.append((data, tf, stock, action, tday))
            if len(buffer) >= batch_size:
                insert_alerts(buffer)   # Make insert_alerts accept a list for executemany
                buffer.clear()
        if buffer:
            insert_alerts(buffer)
        db.commit()
    except Exception as ex:
        db.rollback()
        tqdm.write(f"❌ Bulk insert failed: {ex}")
        # Fallback to single inserts if needed:
        for action, data, stock, tday in rows:
            if action == "__LOG__":
                tqdm.write(data)
                continue
            try:
                insert_alerts(data, tf, stock, action, tday)
            except Exception as ex2:
                tqdm.write(f"❌ Insert error for {stock} @ {tday.strftime('%Y-%m-%d')}: {ex2}")
    finally:
        db.close()

def start_calculation_parallel():
    trading_days = get_trading_days()
    stocks = get_all_stock_syms()

    # Build one task per stock (big reduction in futures)
    stock_tasks = [(s, trading_days) for s in stocks]

    # Choose workers ~ CPU count
    max_workers = min( (os.cpu_count() or 4), 12 )  # tune upper cap as you like

    all_alerts = []
    with ProcessPoolExecutor(max_workers=max_workers) as executor:
        # Use map with chunksize to reduce overhead
        it = executor.map(process_one_stock, stock_tasks, chunksize=8)
        for alerts_for_stock in tqdm(it, total=len(stock_tasks), desc="Processing Alerts", dynamic_ncols=True):
            # Collect in memory; you can also flush every N stocks
            all_alerts.extend(alerts_for_stock)

    # Bulk insert at the end (or flush periodically above)
    insert_alerts_bulk(all_alerts)

if __name__ == "__main__":
    start_calculation_parallel()
