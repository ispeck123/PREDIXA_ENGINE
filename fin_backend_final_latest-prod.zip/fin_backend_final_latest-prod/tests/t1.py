# from data_fetchers.kiteconnect.kite_session import get_instrument_token
import sys, os

from PIL.Image import item

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
# from data_fetchers.kiteconnect.indian_stock_data_updater import INDIAN_STOCK_DATA_UPDATER
from data_fetchers.fyers.indian_stock_data_updater import INDIAN_STOCK_DATA_UPDATER
from data_fetchers.fyers.indian_futures_data_updater import Indian_future_data_handler, future_data_processer
from data_fetchers.fyers.fyers_session import fyers_access_token_handler
from data_fetchers.fyers.indian_commodity_data_updater import MCXFutureDataHandler
from shared.config.settings import stock_data_dir_config as sddcfg
# from apps.pipelines.trade_accumulator_future_commodity import sixty_trades_accumulate_futures_and_commodity
from apps.pipelines.trade_accumulator_cash import daily_trades_accumulate, sixty_trades_accumulate
from apps.pipelines.trade_accumulator_future_commodity import sixty_trades_accumulate_futures_and_commodity, fifteen_trades_accumulate_futures_and_commodity
# from alert_engine.alert import check_trade_signals
# from data_fetchers.fyers.fyers_session import get_instrument_token
from data_fetchers.yfinance.us_stock_data_updater import US_STOCK_DATA_UPDATER
from scripts.stock_logic import proc_delta_stock_items
from shared.db.db_utils import is_similar_order_exists_orm
from shared.db.db_model import Ind_StockMaster, OMSOrderBucketCommodity, OMSOrderBucket
from shared.db.fyers_req_model import get_fyers, SingleGttOrderRequest, GttOrderInfo, GttLeg, build_gtt_oco_payload, CreateGTTOCORequest
from shared.db.db_utils import DBConnection
# sixty_trades_accumulate_futures_and_commodity('futures')
# from nselib.derivatives import expiry_dates_future
from shared.config.settings import stock_data_dir_config
from shared.db.fyers_req_model import build_modify_gtt_payload
# from data_fetchers.fyers.market_data_live import fyers_live_symbol_data
# from data_fetchers.fyers.fyers_ingestor import main
from fastapi import WebSocket
# check_trade_signals().
from apps.pipelines.available_trade_validator import AvailableTradeValidator
from scripts.calculate_setup import Calculate_setup_execute
import time
from datetime import datetime
from nselib.derivatives import expiry_dates_future
import re
import logging, requests
from io import StringIO
import pandas as pd
from scripts.calculate_zones import ZONE_TIME_FIXATURE
logger = logging.getLogger()
from data_fetchers.fyers.fyers_utils import bucket_format_futures_contract, normalize_cash_oco_prices
# validator = AvailableTradeValidator()
# validator.process_all_trades_cash()

# isdu = INDIAN_STOCK_DATA_UPDATER()
# isdu.process_all()
# fah = fyers_access_token_handler()
# fah.main()
# isdu.create_monthly_and_weekly_from_daily("bharti_airtel_daily.csv", "W")
# mcxh = MCXFutureDataHandler()
# mcxh.download_all()
# mcxh.process_all()

# ztf = ZONE_TIME_FIXATURE('bharti_airtel', 25, datetime.now(), stock_data_dir_config.indian_stock_data_dir)


# dzz = ztf.calculate_and_adjust_dz()

# print(dzz)
db = DBConnection()
# # db.create_all_tables()


# row = session.query(OMSOrderBucket).filter(OMSOrderBucket.bucket_id == 45).first()
# f_sym = session.query(Ind_StockMaster).filter(Ind_StockMaster.id == row.stock_id).first()
# symbol = f_sym.fyers_symbol
# entry_price = round(row.entry_price, 1)
# stop_loss = round(row.stoploss_price, 1)
# target_price = round(row.target_price, 1)
# quantity = row.stock_quantity
# order_type = row.order_type

# print(symbol)
# side = 1 if order_type == 'BUY' else -1

# leg1 = GttLeg(
#     price=entry_price,
#     triggerPrice=entry_price,
#     qty=quantity
# )

# order_info = GttOrderInfo(
#     leg1=leg1
# )

# fyers = get_fyers()

# pending_orders = fyers._client.gtt_orderbook()['orderBook']

# pending_oco_orders = []
# for items in pending_orders:
#     if items['gtt_oco_ind'] == 2 and items['ord_status'] == 6:
#         pending_oco_orders.append(items)



# # print(pending_oco_orders)
# for items in pending_oco_orders:
#     print(items['id'], type(items['id']))
#     if items['id'] == '26081700001519':
#         print(items)
    # print(items['symbol_exch'])
    # print(items['ordertag'])
# # 80 
# print(len(pending_oco_orders))
# for it in pending_oco_orders:
#     # print(it['symbol_exch'])
#     for key, value in it.items():
#         print(f"{key}: {value}")



# payload = build_modify_gtt_payload(pending_oco_orders[4], sl=pending_oco_orders[4]['price2_limit'], tp=pending_oco_orders[4]['price_limit'])
# print(payload)
# def build_modify_gtt_payload(order: dict, entry: float = None, sl: float = None, tp: float = None, qty: int = None, order_tag=None):
#     """
#     Build payload for fyers.modify_gtt_order based on gtt type.

#     gtt_oco_ind:
#         1 = single
#         2 = oco
#     """

#     gtt_type = order.get("gtt_oco_ind")
#     if qty is None:
#         qty = order.get("qty", 0)
#     else:
#         qty = int(qty)

#     if gtt_type == 1:
#         # Single GTT -> modify only entry
#         if entry is None:
#             raise ValueError("For single GTT, 'entry' is required.")

#         return {
#             "id": order["id"],
#             "orderInfo": {
#                 "leg1": {
#                     "price": entry,
#                     "triggerPrice": entry,
#                     "qty": qty
#                 }
#             },
#             "ordertag": order_tag
#         }

#     elif gtt_type == 2:
#         # OCO GTT -> modify SL and TP only
#         if sl is None or tp is None:
#             raise ValueError("For OCO GTT, both 'sl' and 'tp' are required.")

#         # Existing order book has:
#         # price_limit / price_trigger     -> one leg
#         # price2_limit / price2_trigger   -> second leg
#         #
#         # We must preserve which leg is upper and which is lower.
#         existing_leg1 = float(order.get("price_trigger", 0))
#         existing_leg2 = float(order.get("price2_trigger", 0))

#         # Usually for sell OCO:
#         # higher price = TP
#         # lower price = SL
#         #
#         # We preserve same leg structure as existing order.
#         if existing_leg1 >= existing_leg2:
#             leg1_price = tp
#             leg2_price = sl
#         else:
#             leg1_price = sl
#             leg2_price = tp

#         return {
#             "id": order["id"],
#             "orderInfo": {
#                 "leg1": {
#                     "price": leg1_price,
#                     "triggerPrice": leg1_price,
#                     "qty": qty
#                 },
#                 "leg2": {
#                     "price": leg2_price,
#                     "triggerPrice": leg2_price,
#                     "qty": qty
#                 }
#             },
#             "ordertag": order_tag
#         }

#     else:
#         raise ValueError(f"Unsupported gtt_oco_ind: {gtt_type}")


    # print(gtt_orderbook)

    # matching_order = next((order for order in gtt_orderbook if str(order.get("ordertag")).replace("1:GTT", "") == str(body.bucket_id)), None)
    # if matching_order:
    #     print("Matching order found")
    #     # Delete the matching order
    #     delete_response = fyers._client.cancel_gtt_order(data={
    #         "id": matching_order.get("id")
    #     })
    #     print("Delete response:", delete_response)




    
def place_cash_oco_by_bucket_id(bucket_id):
    session = db.get_session()
    row = (
        session.query(OMSOrderBucket)
        .filter(
            OMSOrderBucket.bucket_id == bucket_id
        )
        .first()
    )
    print(row.__dict__)
    stock_id = row.stock_id
    print(stock_id)
    stock_row = session.query(Ind_StockMaster).filter(Ind_StockMaster.id == stock_id).first()
    print(stock_row.fyers_symbol)

    # if not row:
    #     raise ValueError(
    #         f"Cash bucket not found or already processed: {bucket_id}"
    #     )

    symbol = stock_row.fyers_symbol
    # (
    #     getattr(row, "symbol", None)
    #     or getattr(row, "stock_symbol", None)
    #     or getattr(row, "fyers_symbol", None)
    # )

    if not symbol:
        raise ValueError(f"Symbol not found for bucket: {bucket_id}")

    if not symbol.startswith("NSE:") or not symbol.endswith("-EQ"):
        raise ValueError(f"Invalid cash symbol: {symbol}")

    oco_side = 1 if row.order_type.upper() == "BUY" else -1
    prices = normalize_cash_oco_prices(
            entry=row.entry_price,
            target=row.target_price,
            stoploss=row.stoploss_price,
            order_type=row.order_type,
            # Best option:
            # tick_size=row.tick_size
            )
    print(prices["entry"])
    print(prices["target"])
    print(prices["stoploss"])
    oco_body = CreateGTTOCORequest(
        symbol=symbol,
        side=oco_side,
        entry=prices["entry"],
        target=prices["target"],
        stoploss=prices["stoploss"],
        qty=row.stock_quantity,
        productType="CNC",
        orderTag=str(bucket_id)
    )

    gtt_payload = build_gtt_oco_payload(
        oco_body,
        ltp=row.entry_price
    )

    fyers = get_fyers()
    response = fyers._client.place_gtt_order(data=gtt_payload)

    logger.info(
        "Cash GTT OCO response for bucket %s: %s",
        bucket_id,
        response
    )
    
    

    if not isinstance(response, dict) or response.get("s") != "ok":
        raise RuntimeError(
            f"Cash GTT OCO placement failed for bucket "
            f"{bucket_id}: {response}"
        )
    
    if response.get("code") == 1101:
        row.gtt_oco_id = response.get('id')
        row.id_fyers_gtt_oco = response.get('id_fyers')

    row.order_status = "executed"
    row.is_trade_started = 1

    session.add(row)
    session.commit()
    session.close()

    return response


if __name__ == "__main__":
    place_cash_oco_by_bucket_id(170)
    # clear_all_futures_orders()
    # print(bucket_format_futures_contract("NIFTY", "29092026"))
