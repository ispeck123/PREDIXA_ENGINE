from pathlib import Path

import pytest

from lakehouse.discovery import SourceFile
from lakehouse.migration.nse_cash_batch import (
    chunked,
    group_files_by_symbol,
    load_manifest,
    read_active_symbols,
    run_fingerprint,
    save_manifest,
    should_skip,
    source_fingerprint,
)


def source(path: Path, symbol: str) -> SourceFile:
    path.write_text("open,high,low,close,qty,tradeDate\n", encoding="utf-8")
    return SourceFile(path, symbol, "daily", "1d", (), path.stat().st_size)


def test_grouping_is_sorted_and_preserves_all_files(tmp_path):
    grouped = group_files_by_symbol(
        [source(tmp_path / "z_daily.csv", "z"), source(tmp_path / "a_daily.csv", "a")]
    )
    assert list(grouped) == ["a", "z"]
    assert len(grouped["a"]) == 1


def test_chunked_rejects_invalid_size():
    assert chunked(["a", "b", "c"], 2) == [["a", "b"], ["c"]]
    with pytest.raises(ValueError):
        chunked(["a"], 0)


def test_resume_requires_completed_matching_fingerprint():
    entry = {"status": "completed", "source_fingerprint": "abc"}
    assert should_skip(entry, "abc", True)
    assert not should_skip(entry, "changed", True)
    assert not should_skip(entry, "abc", False)
    assert not should_skip({"status": "failed", "source_fingerprint": "abc"}, "abc", True)


def test_fingerprint_changes_with_source_file(tmp_path):
    item = source(tmp_path / "a_daily.csv", "a")
    before = source_fingerprint([item])
    item.path.write_text(item.path.read_text() + "1,2,0,1,3,01/01/2020 05:30:00\n")
    assert source_fingerprint([item]) != before


def test_run_fingerprint_changes_for_dry_run_or_mapping(tmp_path):
    item = source(tmp_path / "a_daily.csv", "a")
    mapping = tmp_path / "mapping.csv"
    mapping.write_text("id,stock_tick\n1,a\n")
    grouped = {"a": [item]}
    real = run_fingerprint(["a"], grouped, mapping, False)
    assert run_fingerprint(["a"], grouped, mapping, True) != real
    mapping.write_text("id,stock_tick\n2,a\n")
    assert run_fingerprint(["a"], grouped, mapping, False) != real


def test_manifest_is_written_atomically(tmp_path):
    path = tmp_path / "manifest.json"
    manifest = load_manifest(path)
    manifest["batches"]["batch_1"] = {"status": "completed"}
    save_manifest(path, manifest)
    assert load_manifest(path)["batches"]["batch_1"]["status"] == "completed"
    assert not path.with_suffix(".json.tmp").exists()



def test_active_instrument_filter_accepts_alias_and_excludes_inactive(tmp_path):
    mapping = tmp_path / "mapping.csv"
    mapping.write_text(
        "id,stock_tick,is_activate\n1,a,1\n2,b,0\n3,c,true\n",
        encoding="utf-8",
    )
    assert read_active_symbols(mapping) == {"a", "c"}


def test_active_instrument_filter_requires_expected_columns(tmp_path):
    mapping = tmp_path / "mapping.csv"
    mapping.write_text("id,stock_tick\n1,a\n", encoding="utf-8")
    with pytest.raises(ValueError):
        read_active_symbols(mapping)

