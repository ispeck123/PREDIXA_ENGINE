import sys, os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from scripts.setup_engine_new import SDEnginePipeline, process_setup, format_calculate_setup_response
from scripts.trade_engine import processs_all_zones, process_zones, process_qualified_zones
from scripts.models import TF
import pandas as pd
from scripts.trend_engine import MultiTimeframeTrendCalculator
from shared.config.settings import stock_logic_config
from datetime import datetime
from shared.db.db_utils import insert_trade_signals
from scripts.trade_engine import process_zones
from dataclasses import dataclass, field, is_dataclass, asdict
from enum import Enum

tick = 'hindustan_zinc'
file_path = f"data/indian_stock_data/latest_data_csv/{tick}_daily.csv"
# data/indian_stock_data/latest_data_csv/britannia_industries_one_twenty_five.csv
df = pd.read_csv(file_path)
col = 'tradeDate' if 'tradeDate' in df.columns else 'timestamp'
df[col] = pd.to_datetime(df[col], dayfirst=True)
time_fr = 1
time_list = getattr(stock_logic_config, f"TIME_FRAME_EXE_{time_fr}")
# print(df.head())
# last_d_time = datetime(year=2026, month=8, day=3, hour=11, minute=17)
last_d_time = datetime.now()
#datetime(year=2026, month=3, day=30, hour=11, minute=17)


def to_api(obj):
    """Convert dataclasses/enums/nested structures into JSON-safe python types."""
    if obj is None:
        return None
    if isinstance(obj, Enum):
        return obj.value
    if is_dataclass(obj):
        # asdict() recursively converts nested dataclasses to dicts/lists
        return {k: to_api(v) for k, v in asdict(obj).items()}
    if isinstance(obj, dict):
        return {k: to_api(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set)):
        return [to_api(v) for v in obj]
    # numbers/strings/bools fall through
    return obj

if __name__ == "__main__":
    pipeline = SDEnginePipeline()
    resp = pipeline.run(tick, time_list, df.iloc[-1][col], segment='CASH')
    print(resp)


    # setup_api = to_api(resp)
    # print(setup_api)
    # resp = processs_all_zones(file_path, TF.A, df.iloc[-1]['timestamp'])
    # print(resp)
    # mft = MultiTimeframeTrendCalculator()
    # mft._set_symbol_and_timeframe(time_list, tick, df.iloc[-1][col])
    # context = mft.calculate_full_context()
    # api_responce = mft.to_api(context)
    # print(api_responce)
    # proc_set = process_setup(tick, time_list, last_d_time)
    # formatted_resp = format_calculate_setup_response(resp, stock_name=tick, time_fr=time_fr, last_d_time=last_d_time, is_future=False, is_cash=True)
    # print(formatted_resp)
    # res = process_zones(file_path, TF.A, last_d_time)
    # print(res['Buy'])
    # resp = process_zones(file_path, TF.X, df.iloc[-1]['timestamp'])
    # resp = process_qualified_zones(file_path, TF.X, df.iloc[-1]['timestamp'], time_list, tick)
    # print(resp)
    # if 'BUY' in formatted_resp and formatted_resp['BUY_RRR'] >= 2.1:
        # formatted_resp['TRADE_TYPE'] = 'BUY'
        # formatted_resp['PREDICTION'] = "NA"
        # formatted_resp['PROBABILITY'] = 0.0
        # insert_trade_signals(formatted_resp, 1, 8, time_fr)