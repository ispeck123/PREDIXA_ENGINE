import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# from alert_engine.notification import send_push_notification, get_alert_fcm_token


# if __name__ == '__main__':
    # send_push_notification("etzMWL4DrpEJ8v-WPTY00k:APA91bGOtjgqqVUoxhxLkHc5B83ld82U6JhbL0eYQ_ye9czI39TQtIOu3iJ0Xt3DE-_rk_oz0-P05VqasHZ5nF1yp5Nfj5Z6gXmSqHp8Oo9_GIHa2pJVvRg", "BBBBBBBB", "okkkkkkkkkkkk")
