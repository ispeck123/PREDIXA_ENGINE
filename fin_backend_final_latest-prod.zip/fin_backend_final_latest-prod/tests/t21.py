# pip install fyers-apiv3
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from fyers_apiv3 import fyersModel
# from shared.config.settings import fyers_config_credentials as fcc
from data_fetchers.fyers.fyers_session import fyers_access_token_handler
from shared.db.dbconn import DBConnection
from shared.db.db_model import Ind_StockMaster

def get_market_depth(fyers: fyersModel.FyersModel, symbol: str, include_ohlcv: bool = False):
    """
    Fetch market depth (order book) for a Fyers symbol.
    
    Args:
        fyers: an authenticated fyersModel.FyersModel instance
        symbol: e.g. 'NSE:SBIN-EQ', 'NSE:TCS-EQ', 'NSE:NIFTY50-INDEX'
        include_ohlcv: if True, also asks for OHLCV snapshot (when supported)
        
    Returns:
        dict with:
          - best_bid, best_ask
          - bids (top 5 levels: price, qty, orders)
          - asks (top 5 levels: price, qty, orders)
          - totals (bid_qty, ask_qty)
          - (optional) ohlcv: {open, high, low, close, volume}
          - raw: the original API payload for full detail
    """
    payload = {
        "symbol": symbol,
        "ohlcv_flag": 1 if include_ohlcv else 0
    }
    resp = fyers.depth(payload)  # REST call to Market Depth API (v3)
    if not isinstance(resp, dict) or resp.get("s") != "ok":
        raise RuntimeError(f"Depth API error: {resp}")

    data = resp.get("d", {})
    depth = data.get("depth", {})
    bids = depth.get("bids", []) or depth.get("buy", []) or []
    asks = depth.get("asks", []) or depth.get("sell", []) or []

    # Helper to normalize levels (price, qty, orders)
    def _levels(levels):
        out = []
        for lv in levels:
            out.append({
                "price": lv.get("price") or lv.get("p"),
                "qty": lv.get("qty") or lv.get("q"),
                "orders": lv.get("orders") or lv.get("o")
            })
        return out

    n_bids = _levels(bids)
    n_asks = _levels(asks)

    best_bid = n_bids[0]["price"] if n_bids else None
    best_ask = n_asks[0]["price"] if n_asks else None

    result = {
        "best_bid": best_bid,
        "best_ask": best_ask,
        "bids": n_bids[:5],  # top 5
        "asks": n_asks[:5],  # top 5
        "totals": {
            "bid_qty": sum((lv["qty"] or 0) for lv in n_bids),
            "ask_qty": sum((lv["qty"] or 0) for lv in n_asks),
        },
        "raw": resp
    }

    # Include OHLCV snapshot if present
    if include_ohlcv:
        # Some responses include ohlc fields under 'd' or similar key
        ohlcv = {
            "open": data.get("o"),
            "high": data.get("h"),
            "low": data.get("l"),
            "close": data.get("c"),
            "volume": data.get("v"),
        }
        if any(v is not None for v in ohlcv.values()):
            result["ohlcv"] = ohlcv

    return result


def check_levels_within_circuit(
    raw_depth_payload: dict,
    entry: float,
    stoploss: float,
    target: float,
    symbol: str,
    inclusive: bool = True,
    check_tick_size: bool = True
) -> dict:
    """
    Validate that entry/stoploss/target are within circuit limits using a Fyers depth/quote payload.

    Args:
        raw_depth_payload: The whole 'raw' dict you showed (e.g. result['raw'])
        entry, stoploss, target: Price levels to validate
        symbol: Optional; if omitted, uses the first symbol found in payload
        inclusive: If True, boundary values equal to circuit are allowed
        check_tick_size: If True, also verify levels align to tick size when available

    Returns:
        {
          'symbol': <symbol>,
          'upper_ckt': <float>,
          'lower_ckt': <float>,
          'tick_size': <float or None>,
          'levels': {
              'entry':   {'value': float, 'within_circuit': bool, 'distance_to_upper': float, 'distance_to_lower': float, 'tick_ok': bool|None},
              'stoploss': {...},
              'target':   {...}
          },
          'all_within_circuit': bool
        }
    """
    def _get_symbol_block(d):
        # Expecting structure like: {'d': {'NSE:SBIN-EQ': {...}}, 's': 'ok'}
        d_block = raw_depth_payload.get('d', {})
        if not d_block:
            raise ValueError("Invalid payload: missing 'd' key")
        if symbol:
            if symbol not in d_block:
                raise ValueError(f"Symbol '{symbol}' not found in payload keys: {list(d_block.keys())}")
            return symbol, d_block[symbol]
        # fallback: first symbol in dict
        sym, blk = next(iter(d_block.items()))
        return sym, blk

    def _within(v, lo, hi, inclusive=True):
        return (lo <= v <= hi) if inclusive else (lo < v < hi)

    def _tick_ok(v, ts):
        if ts in (None, 0):
            return None  # not checked
        # allow floating tolerance
        r = round((v / ts) - round(v / ts), 6)
        return abs(r) < 1e-6

    sym, block = _get_symbol_block(raw_depth_payload)

    lower_ckt = block.get('lower_ckt')
    upper_ckt = block.get('upper_ckt')
    tick_size = block.get('tick_Size') or block.get('tick_size')  # handle casing variants

    if lower_ckt is None or upper_ckt is None:
        raise ValueError("Circuit limits not present in payload (expected 'lower_ckt' and 'upper_ckt').")

    report = {
        'symbol': sym,
        'upper_ckt': upper_ckt,
        'lower_ckt': lower_ckt,
        'tick_size': tick_size if check_tick_size else None,
        'levels': {},
    }

    for name, val in [('entry', entry), ('stoploss', stoploss), ('target', target)]:
        within = _within(val, lower_ckt, upper_ckt, inclusive=inclusive)
        dist_up = None if upper_ckt is None else round(upper_ckt - val, 6)
        dist_lo = None if lower_ckt is None else round(val - lower_ckt, 6)
        tick_ok = _tick_ok(val, tick_size) if check_tick_size else None
        report['levels'][name] = {
            'value': float(val),
            'within_circuit': bool(within),
            'distance_to_upper': dist_up,
            'distance_to_lower': dist_lo,
            'tick_ok': tick_ok
        }

    report['all_within_circuit'] = all(x['within_circuit'] for x in report['levels'].values())
    return report['all_within_circuit']

    


# ---------- Example ----------
# from fyers_apiv3 import fyersModel
# fy = fyersModel.FyersModel(client_id=APP_ID, token=ACCESS_TOKEN, log_path=".")
# print(get_market_depth(fy, "NSE:SBIN-EQ", include_ohlcv=True))


if __name__ == "__main__":
    fath = fyers_access_token_handler()
    full_token = fath.get_access_token()
    fy = fyersModel.FyersModel(client_id=full_token.rsplit(":", 1)[0], token=full_token.rsplit(":", 1)[1], log_path=".")
    session = DBConnection().get_session()
    stocks = session.query(Ind_StockMaster).filter(
                                                  Ind_StockMaster.is_active == 1,
                                                  Ind_StockMaster.fyers_symbol != None).all()
    # for stock in stocks:
    #     try:
    #         market_depth = get_market_depth(fy, stock.fyers_symbol, include_ohlcv=True)
    #         print(market_depth)
    #     except Exception as e:
    #         import time
    #         time.sleep(5)
    #         print(f"Error fetching market depth for {stock.fyers_symbol}: {e}")
    # print(check_levels_within_circuit(market_depth['raw'], 107.42, 104.34, 111.65, "NSE:CANBK-EQ", inclusive=True, check_tick_size=True))
    market_depth = get_market_depth(fy, "NSE:BPCL-EQ", include_ohlcv=True)
    print(market_depth)
    # print(get_market_depth(fy, "NSE:TCS-EQ", include_ohlcv=True))
    # print(get_market_depth(fy, "NSE:INFY-EQ", include_ohlcv=True))
    # print(get_market_depth(fy, "NSE:AXISBANK-EQ", include_ohlcv=True))
    # print(get_market_depth(fy, "NSE:ICICIBANK-EQ", include_ohlcv=True))
    # print(get_market_depth(fy, "NSE:RELIANCE-EQ", include_ohlcv=True))
    