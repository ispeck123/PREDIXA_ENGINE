import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import requests
from bs4 import BeautifulSoup
from requests_html import HTMLSession
import ollama
import json
from datetime import datetime, timedelta
from dateutil import parser
from shared.config.settings import Config as cfg
import feedparser
import ast
from sqlitedict import SqliteDict


def is_current_week(pub_date_str):
    """Check if 'published' date is within the current week"""
    try:
        # example: 'Tue, 16 Sep 2025 07:00:00 GMT'
        pub_date = datetime.strptime(pub_date_str, "%a, %d %b %Y %H:%M:%S %Z")
        # pub_date = parser.parse(pub_date_str)
        now = datetime.now()
        start = now - timedelta(days=7)
        end = now
        # start_of_week = now - timedelta(days=5)  # Monday
        # end_of_week = start_of_week + timedelta(days=5)
        return start <= pub_date <= end
    except Exception as e:
        print(f"Date parse error: {e}")
        return False


def get_publisher(entry):
    if hasattr(entry, 'source'):
        publisher = entry.source.title
    elif 'title' in entry and '-' in entry.title:
        # Heuristic: Sometimes the publisher is in the title
        publisher = entry.title.split('-')[-1].strip()
    else:
        publisher = "Unknown"
    # print(publisher)  # fallback logo
    return publisher


def get_publisher_logo(publisher: str) -> str:
    domain = cfg.PUBLISHER_DOMAIN_MAP.get(publisher)
    if domain:
        return f"https://www.google.com/s2/favicons?domain={domain}&sz=64"
    else:
        return "https://st2.depositphotos.com/6789684/12262/v/450/depositphotos_122620866-stock-illustration-illustration-of-flat-icon.jpg"


# Your scraper output
# response = requests.get("http://103.13.113.132:2560/market-news")  # your API endpoint
# print(response.json().keys())
# news_data = response.json()["response"]["news"]

feed = feedparser.parse(cfg.RSS_FEED_URL)
news_data = []
for entry in feed.entries:
    publisher = get_publisher(entry)
    logo = get_publisher_logo(publisher)
    news_data.append({
        "title": entry.title,
        "link": entry.link,
        "published": entry.published, 
        "publisher": publisher,
        "logo": logo
    })

for n in news_data:
    print(n.get("published", ""))

current_week_news = [n for n in news_data if is_current_week(n.get("published", ""))]

print(f"✅ Found {len(current_week_news)} news articles from this week")



# Fetch and clean each article``
def fetch_article(url):
    try:
        session = HTMLSession()
        response = session.get(url, timeout=10)
        response.html.render(timeout=20, sleep=2)  # renders JS
        soup = BeautifulSoup(response.html.html, "html.parser")

        # Extract main content
        paragraphs = [p.get_text(strip=True) for p in soup.find_all("p")]
        article_text = " ".join(paragraphs)

        if not article_text.strip():
            raise ValueError("No article text found after render")

        return article_text[:3000]
    except Exception as e:
        print(f"Error fetching {url}: {e}")
        return ""

articles = []
print(len(news_data))

for item in current_week_news:
    # print(item)
    # content = fetch_article(item["link"])
    articles.append({
        "title": item["title"],
        "content": ""
    })

# Prepare input for Ollama
context = "\n\n".join(
    [f"📰 {a['title']}" for a in articles] # {a['content']
)

prompt = f"""
You are a professional stock market analyst.
Based on the following live market news, identify 10 stocks with the highest short-term trading potential.
For each stock, include:
- Stock name / Instrument
- Sentiment (Bullish/Bearish/Neutral)
- Reasoning (based on news data)
- Suggested Trade (Buy/Sell)
- Target price zone (approximation based on momentum)
- Confidence level (High/Medium/Low)
Give me the response in a proper json format. Do not add anything in response which is invalid to be converted to json. 
Maintain the format of response like the example below. Keep the keys of the json same as the example given below.
"{{
    "stocks": [
                {{
                    "stock_name": "value",
                    "sentiment": "value",
                    "reasoning": "value",
                    "suggested_trade": "value",
                    "target_price_zone": "value",
                    "confidence_level": "value"
                }},
                {{
                    "stock_name": "value",
                    "sentiment": "value",
                    "reasoning": "value",
                    "suggested_trade": "value",
                    "target_price_zone": "value",
                    "confidence_level": "value"
                }}
              ]
            
}}
Do not add anything in response which is invalid to be converted to json.

News Context:
{context}
"""
# print(articles)
# Run with Ollama (using, e.g., "mistral" or "llama3")
result = ollama.chat(model="deepseek-r1:8b", messages=[{"role": "user", "content": prompt}])

# print(result['message']['content'])
# result_json = ast.literal_eval(result['message']['content'])
# print(type(result_json))

db = SqliteDict("finprod.sqlite")
content = result['message']['content']
content = content.replace('`','')
content = content.replace("json","")
db["short_term_trading_news"] = ast.literal_eval(content)
db.commit()
db.close()

db = SqliteDict("finprod.sqlite")
print(db["short_term_trading_news"])
print(type(db["short_term_trading_news"]))
db.close()