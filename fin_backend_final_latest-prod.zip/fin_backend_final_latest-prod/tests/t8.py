import sys, os
import multiprocessing
from concurrent.futures import ProcessPoolExecutor, wait, FIRST_COMPLETED
from tqdm import tqdm
from datetime import datetime, timedelta

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from shared.db.db_model import FuturesMaster
from shared.db.dbconn import DBConnection
from shared.db.db_utils import insert_future_and_commodity_order
from scripts.calculate_setup_future import Calculate_setup_execute_futures
from shared.config.settings import stock_data_dir_config
from stock_model.model_predictor import Indian_model_predictor  # Optional, commented for now
from sqlalchemy import distinct
import logging

logger = logging.getLogger(__name__)

tf = 2
start_dt = datetime.now() - timedelta(days=400)
#datetime(2025, 5, 1)

def get_trading_days(start_date=start_dt, end_date=datetime.now()):
    current_date = start_date
    trading_days = []
    while current_date <= end_date:
        if current_date.weekday() < 5:  # Monday = 0, Sunday = 6
            trading_days.append(current_date)
        current_date += timedelta(days=1)
    return trading_days


def get_all_stock_syms():
    dbc = DBConnection()
    db = dbc.get_session()
    res = db.query(distinct(FuturesMaster.symbol)).all()
    return [items[0] for items in res]


def run_single(stock, tday):
    try:
        cse = Calculate_setup_execute_futures(stock_name=stock, time_frame=tf, last_dt=tday, exp_num=31072025, data_dir=stock_data_dir_config.indian_stock_future_data_dir)
        result = cse.calculate()

        if 'BUY' in result and result['BUY_RRR'] >= 1.5:
            print(tday, stock)
            # Optional prediction step
            Impd = Indian_model_predictor(stock, tf, 'BUY', tday)
            pred, prob = Impd.fetch_model_stats_future_and_commodity(result['BUY']['entry_price'], result['BUY']['target_price'], result['BUY']['stop_loss'], 31072025, 'futures')
            if pred == 'success' and prob >= 0.6:
                # pass
                insert_future_and_commodity_order(1, 1, result['BUY'], tf, stock, tday, 'BUY', '31072025', pred, prob, 'futures')
                # insert_alerts(result['BUY'], 1, stock, tday, 'india', 1, "", 0.0)

        return f"✅ {stock} @ {tday.strftime('%Y-%m-%d')}"
    except Exception as ex:
        logger.exception(f"❌ {stock} @ {tday.strftime('%Y-%m-%d')} | Error: {str(ex)}", exc_info=1)
        return f"❌ {stock} @ {tday.strftime('%Y-%m-%d')} | Error: {str(ex)}"



def start_calculation_parallel():
    all_tasks = []
    trading_days = get_trading_days()
    stocks = get_all_stock_syms()

    # Prepare all combinations
    for stock in stocks:
        for tday in trading_days:
            all_tasks.append((stock, tday))

    with ProcessPoolExecutor(max_workers=multiprocessing.cpu_count()) as executor:
        futures = {executor.submit(run_single, stock, tday): (stock, tday) for stock, tday in all_tasks}

        with tqdm(total=len(futures), desc="Processing Alerts", dynamic_ncols=True) as pbar:
            while futures:
                done, _ = wait(futures, return_when=FIRST_COMPLETED)
                for future in done:
                    try:
                        result = future.result()
                        tqdm.write(result)
                    except Exception as ex:
                        tqdm.write(f"❌ Error: {ex}")
                    pbar.update(1)
                    del futures[future]


if __name__ == "__main__":
    start_calculation_parallel()
    # run_single('INDIGO', datetime.now())