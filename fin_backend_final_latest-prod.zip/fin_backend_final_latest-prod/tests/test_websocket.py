import sys, os
sys.path.insert(0, os.path.abspath("/home/ispeck/STOCK_PROJECT/STP_LATEST"))
import asyncio
import websockets


async def connect_external():
    uri = "ws://192.168.1.16:9000/ws/holdings"  # public WebSocket server
    async with websockets.connect(uri) as ws:
        print("Connected to external server!")
        # Send a message
        #await ws.send("Hello external server!")
        #print("Message sent")
        # Receive response
        response = await ws.recv()
        print("Received from server:", response)
asyncio.run(connect_external())