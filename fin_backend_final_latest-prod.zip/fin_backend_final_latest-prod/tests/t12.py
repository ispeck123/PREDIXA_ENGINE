import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from data_fetchers.fyers.fyers_ticker import FyersTickerManager
from shared.db.dbconn import DBConnection
from shared.db.db_model import Ind_StockMaster
from datetime import datetime, timezone
import asyncio
from starlette.websockets import WebSocketDisconnect, WebSocketState
from shared.db.api_responce import APIResponse
from uvicorn.protocols.utils import ClientDisconnected
from fastapi import WebSocket

dbc = DBConnection()

async def check_web(stock_id, websocket: WebSocket):
    try:
        f_ticker = FyersTickerManager()
        session = dbc.get_session()
        stock = session.query(Ind_StockMaster).filter(Ind_StockMaster.id == stock_id, Ind_StockMaster.is_active == 1).first()
        session.close()
        #print(stock)
        # if not stock:
        #     if websocket.application_state == WebSocketState.CONNECTED:
        #         await websocket.send_text("Invalid or inactive stock id")
        #     return  # No loop, just exit
        f_ticker.subscribe([stock.fyers_symbol], websocket)
            # res = get_last_data_from_files(stock[0].stock_tick, time_frame)
            #print(res)
        while True:
            #price = get_latest_stock_price(stock[0].fyers_symbol)
            try:
                returned_symbol, price = await f_ticker.get_latest_stock_price(stock.fyers_symbol)
                candle_data = {
                    "stock_tick": stock.stock_tick,
                    "price": price,
                    "time" : int(datetime.now(timezone.utc).timestamp())
                }
                if returned_symbol != stock.fyers_symbol or price is None:
                    if websocket.application_state == WebSocketState.CONNECTED:
                        await websocket.send_text("Error fetching stock price")
                    await asyncio.sleep(5)
                    continue
                # candle_data = update_ohlc(stock.stock_tick, price, time_frame)
                # candle_data["stock_tick"] = stock.stock_tick
                #print(price)
                # t_stamp = datetime.strptime(datetime.now().today(), )
                if websocket.application_state != WebSocketState.CONNECTED:
                    break
                await websocket.send_json(candle_data)
                await asyncio.sleep(5)
            except (WebSocketDisconnect, ClientDisconnected):
                # client is gone: stop the loop (no close/send here)
                break

    except WebSocketDisconnect:
        await websocket.close()
        print(f"Client disconnected: {stock.stock_tick}")
    except Exception as e:
        await websocket.close()
        print(f"Error: {e}")
    finally:
        try:
            if 'f_ticker' in locals() and f_ticker and 'websocket' in locals():
                f_ticker.unsubscribe(websocket)
        except Exception:
            pass
        try:
            if websocket.application_state == WebSocketState.CONNECTED:
                await websocket.close()
        except Exception:
            pass    


if __name__ == "__main__":
    asyncio.run(check_web(1, WebSocket))