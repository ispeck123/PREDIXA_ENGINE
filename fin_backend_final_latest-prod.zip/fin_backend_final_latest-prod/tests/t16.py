import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
# from shared.db.dbconn import DBConnection
# from shared.db.db_model import TradeSignal
# import ast

# db = DBConnection()

# session = db.get_session()
# trade_signals = session.query(TradeSignal.stock_name, 
#                             TradeSignal.time_fr, 
#                             TradeSignal.exchange_id).distinct().all()
# #print(trade_signals)
# for trade in trade_signals:
#     print(trade)
#     rows = session.query(TradeSignal).filter(
#         TradeSignal.stock_name == trade.stock_name,
#         TradeSignal.time_fr == trade.time_fr,
#         TradeSignal.exchange_id == trade.exchange_id
#     ).order_by(TradeSignal.stock_name.asc()).all()
    
#     for row in rows:
#         all_signals = session.query(TradeSignal).filter(
#             TradeSignal.stock_name == row.stock_name,
#             TradeSignal.time_fr == row.time_fr,
#             TradeSignal.exchange_id == row.exchange_id
#         ).order_by(TradeSignal.created_at.asc()).all()

#         distinct_trade_data = []

#         for signal in all_signals:
#             #trade_data = ast.literal_eval(signal.trade_data)
#             trade_data = {
#                             "stop_loss": int(signal.trade_data["stop_loss"]),
#                             "entry_price": int(signal.trade_data["entry_price"]),
#                             "target_price": int(signal.trade_data["target_price"])
#                         }
#             if trade_data in distinct_trade_data:
#                 # remove row
#                 # session.delete(signal)
#                 print(f"duplicate row removed: {trade_data}")
#             else:
#                 distinct_trade_data.append(trade_data)
#                 print(f"row kept: {trade_data}")

# session.commit()
# session.close()
# db.close_engine()

# # -------------------------------------------------------------------------
# # -------------------------------------------------------------------------

# from fyers_apiv3.FyersWebsocket import data_ws
# from data_fetchers.fyers.fyers_session import fyers_access_token_handler
# from threading import Lock
# import threading
# import time

# class FyersMarketDataLiteMode:

#     def __init__(self):
        
#         self.access_token = fyers_access_token_handler().get_access_token()  # Must be in format APP_ID:ACCESS_TOKEN
#         self.symbols = []
#         self.stock_latest_price = {}
#         self.token_lock = Lock()

#         self.fyers = data_ws.FyersDataSocket(
#             access_token=self.access_token,       # Access token in the format "appid:accesstoken"
#             log_path="",                     # Path to save logs. Leave empty to auto-create logs in the current directory.
#             litemode=False,                  # Lite mode disabled. Set to True if you want a lite response.
#             write_to_file=False,              # Save response in a log file instead of printing it.
#             reconnect=True,                  # Enable auto-reconnection to WebSocket on disconnection.
#             on_connect=self.onopen,               # Callback function to subscribe to data upon connection.
#             on_close=self.onclose,                # Callback function to handle WebSocket connection close events.
#             on_error=self.onerror,                # Callback function to handle WebSocket errors.
#             on_message=self.onmessage             # Callback function to handle incoming messages from the WebSocket.
#         )

#         # Start the WebSocket in a separate thread
#         #threading.Thread(target=self.fyers.connect, daemon=True).start()
#         self.fyers.connect()


#     def onmessage(self, message):
#         """
#         Callback function to handle incoming messages from the FyersDataSocket WebSocket.

#         Parameters:
#             message (dict): The received message from the WebSocket.

#         """
#         #print("Response:", message)
#         symbol = message.get("symbol")
#         ltp = message.get("ltp")
#         if symbol and ltp is not None:
#             if symbol in self.symbols:
#                 print("present")
#             else:
#                 print("not present")
#             self.stock_latest_price[symbol] = message
#         print(self.stock_latest_price)


#     def onerror(self, message):
#         """
#         Callback function to handle WebSocket errors.

#         Parameters:
#             message (dict): The error message received from the WebSocket.


#         """
#         print("Lite Mode WebSocket Error:", message)


#     def onclose(self, message):
#         """
#         Callback function to handle WebSocket connection close events.
#         """
#         print("Lite Mode WebSocket connection closed:", message)


#     def onopen(self):
#         """
#         Callback function to subscribe to data type and symbols upon WebSocket connection.

#         """
#         # Specify the data type and symbols you want to subscribe to
#         data_type = "SymbolUpdate"
#         with self.token_lock:
#             if self.symbols:
#                 # Subscribe to the specified symbols and data type
#                 self.fyers.subscribe(symbols=self.symbols, data_type=data_type)
#                 # Keep the socket running to receive real-time data
#                 self.fyers.keep_running()

#                 print("Connected to Lite Mode WebSocket")


#     def add_symbols(self, symbols):
#         with self.token_lock:
#             add_symbols = []
#             for symbol in symbols:
#                 if symbol not in self.symbols:
#                     add_symbols.append(symbol)
#             self.fyers.subscribe(symbols=add_symbols, data_type="SymbolUpdate")
#             self.symbols.extend(add_symbols)
    
#     def remove_symbols(self, symbols):
#         with self.token_lock:            
#             self.fyers.unsubscribe(symbols=symbols, data_type="SymbolUpdate")
#             for symbol in symbols:
#                 if symbol in self.symbols:
#                     self.symbols.remove(symbol)

#     def get_latest_price(self, symbol):
#         try:
#             return self.stock_latest_price[symbol]
#         except:
#             return None


# fyers = FyersMarketDataLiteMode()
# time.sleep(5)
# fyers.add_symbols(['NSE:RELIANCE-EQ', 'NSE:TCS-EQ'])

# time.sleep(5)
# print(fyers.get_latest_price('NSE:RELIANCE-EQ'), "-------------")
# fyers.remove_symbols(['NSE:RELIANCE-EQ'])

# # -------------------------------------------------------------------------
# # -------------------------------------------------------------------------

# from shared.db.dbconn import DBConnection
# from shared.db.db_model import TradeSignal
# import ast
# import logging
# from apps.finprod_backend.modules.order_update import check_entry_hit, evaluate_order_status
# from datetime import datetime
# import time

# logger = logging.getLogger()
# db = DBConnection()

# def delete_completed_trade_signals():
#     try:
#         session = db.get_session()
#         trade_signals = session.query(TradeSignal).all()
#         for trade in trade_signals:
#             try:
#                 #print(trade.trade_data['entry_price'])
#                 trade.created_at = datetime.strftime(trade.created_at, "%Y-%m-%dT%H:%M")
#                 #print(trade.created_at)
#                 #print(trade.time_fr)
#                 status, timestamp = check_entry_hit(trade.stock_name,
#                                                     trade.trade_data['entry_price'],
#                                                     str(trade.created_at),
#                                                     trade.time_fr)
#                 if status == True:
#                     result = evaluate_order_status(
#                         stock_name = trade.stock_name,
#                         entry_price = trade.trade_data['entry_price'],
#                         created_on = str(trade.created_at),
#                         stop_loss = trade.trade_data['stop_loss'],
#                         target_price = trade.trade_data['target_price'],
#                         quantity = 10,
#                         order_type = trade.trade_type.capitalize(),
#                         time_frame = trade.time_fr
#                     )
#                     if result["status"] == "success" or result["status"] == "failed":
#                         #session.delete(trade)
#                         print(f"Completed trade signal deleted: id {trade.id}")
#             except Exception as ex:
#                 logger.exception(f"Error in delete_completed_trade_signals: {ex}")
#         session.commit()
#         session.close()
#         db.close_engine()
#     except Exception as e:
#         logger.exception(f"Error in delete_completed_trade_signals: {e}")
#         db.close_engine()

# delete_completed_trade_signals()

# --------------------------------------------------------------------
# --------------------------------------------------------------------

# from shared.db.dbconn import DBConnection
# from shared.db.db_model import Ind_StockMaster
# from data_fetchers.fyers.get_stock_prices import StockPriceFetcher
# import time

# db = DBConnection()
# spf = StockPriceFetcher()
# time.sleep(5)
# session = db.get_session()
# stocks = session.query(Ind_StockMaster).filter(Ind_StockMaster.is_active == 1,
#                                                   Ind_StockMaster.fyers_symbol != None).all()
# for stock in stocks:
#     # print(stock.fyers_symbol)
#     latest_price = spf.fyers_data.get_latest_price(stock.fyers_symbol)
#     if latest_price['ltp'] > 3000:
#         stock.is_proc = 1
#         session.add(stock)
#         session.commit()
#         print(f"{stock.stock_tick} is updated ... price {latest_price['ltp']}")
        
# session.close()


# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------

from shared.db.dbconn import DBConnection
from shared.db.db_model import Ind_StockMaster, TradeSignal
db = DBConnection()

session = db.get_session()

trades = session.query(TradeSignal).filter(TradeSignal.exchange_id == 8).all()

for trade in trades:
    stock_row = session.query(Ind_StockMaster).filter(Ind_StockMaster.is_active == 1,
                                                      Ind_StockMaster.kite_symbol == trade.stock_name).all()
    if stock_row and len(stock_row) > 0:
        trade.stock_name = stock_row[0].stock_tick
        session.add(trade)
        session.commit()
        print(f"changed {stock_row[0].kite_symbol} to {stock_row[0].stock_tick}")
session.close()