from pathlib import Path

import pytest

from lakehouse.discovery import discover_csv_files, parse_filename
from lakehouse.timeframes import legacy_timeframe, normalize_timeframe


def test_filename_parsing_preserves_underscore_symbol():
    symbol, timeframe = parse_filename(Path("reliance_industries_nse_one_twenty_five.csv"))
    assert symbol == "reliance_industries_nse"
    assert timeframe == "one_twenty_five"


@pytest.mark.parametrize(
    ("legacy", "canonical"),
    [("five", "5m"), ("seventy_five", "75m"), ("daily", "1d"), ("monthly", "1M")],
)
def test_timeframe_round_trip(legacy, canonical):
    assert normalize_timeframe(legacy) == canonical
    assert legacy_timeframe(canonical) == legacy


def test_discovery_rejects_unknown_and_empty_files(tmp_path):
    good = tmp_path / "axis_bank_daily.csv"
    good.write_text("open,high,low,close,qty,tradeDate\n1,2,0.5,1.5,10,01/01/2020 05:30:00\n")
    (tmp_path / "axis_bank_None.csv").write_text(good.read_text())
    (tmp_path / "empty_five.csv").write_text("")

    files, issues = discover_csv_files(tmp_path)

    assert [(item.symbol, item.timeframe) for item in files] == [("axis_bank", "1d")]
    assert len(issues) == 2

