import json
import requests
import pyotp
import hashlib
from urllib import parse
from sqlitedict import SqliteDict
import sys, os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from shared.config.settings import fyers_config_credentials as fcc


class Update_fyers_access_token:
    def __init__(self):
        self.local_db = SqliteDict("finprod.sqlite")

    def get_access_token(self):
        try:
            return self.local_db["fyers_access_token"]
        except Exception as e:
            print(e)
            return False

    def verify_client_id(self, client_id):
        try:
            payload = {
                "fy_id": client_id,
                "app_id": "2"
            }

            result_string = requests.post(url=fcc.URL_VERIFY_CLIENT_ID, json=payload)
            # print("result_string : ", result_string.text)
            if result_string.status_code != 200:
                return [fcc.ERROR, result_string.text]

            result = json.loads(result_string.text)
            request_key = result["request_key"]

            return [fcc.SUCCESS, request_key]
        
        except Exception as e:
            return [fcc.ERROR, e]
    
    def generate_totp(self, secret):
        try:
            generated_totp = pyotp.TOTP(secret).now()
            return [fcc.SUCCESS, generated_totp]
        
        except Exception as e:
            return [fcc.ERROR, e]
    
    def verify_totp(self, request_key, totp):
        try:
            payload = {
                "request_key": request_key,
                "otp": totp
            }

            result_string = requests.post(url=fcc.URL_VERIFY_TOTP, json=payload)
            if result_string.status_code != 200:
                return [fcc.ERROR, result_string.text]

            result = json.loads(result_string.text)
            request_key = result["request_key"]

            return [fcc.SUCCESS, request_key]
        
        except Exception as e:
            return [fcc.ERROR, e]

    def verify_PIN(self, request_key, pin):
        try:
            payload = {
                "request_key": request_key,
                "identity_type": "pin",
                "identifier": pin
            }

            result_string = requests.post(url=fcc.URL_VERIFY_PIN, json=payload)
            if result_string.status_code != 200:
                return [fcc.ERROR, result_string.text]
    
            result = json.loads(result_string.text)
            access_token = result["data"]["access_token"]

            return [fcc.SUCCESS, access_token]
    
        except Exception as e:
            return [fcc.ERROR, e]
    
    def token(self, client_id, app_id, redirect_uri, app_type, access_token):
        try:
            payload = {
                "fyers_id": client_id,
                "app_id": app_id,
                "redirect_uri": redirect_uri,
                "appType": app_type,
                "code_challenge": "",
                "state": "sample_state",
                "scope": "",
                "nonce": "",
                "response_type": "code",
                "create_cookie": True
            }
            headers={'Authorization': f'Bearer {access_token}'}

            result_string = requests.post(
                url=fcc.URL_TOKEN, json=payload, headers=headers
            )

            if result_string.status_code != 308:
                return [fcc.ERROR, result_string.text]

            result = json.loads(result_string.text)
            url = result["Url"]
            auth_code = parse.parse_qs(parse.urlparse(url).query)['auth_code'][0]

            return [fcc.SUCCESS, auth_code]
    
        except Exception as e:
            return [fcc.ERROR, e]

    def sha256_hash(self, appId, appType, appSecret):
        message = f"{appId}-{appType}:{appSecret}"
        message = message.encode()
        sha256_hash = hashlib.sha256(message).hexdigest()
        return sha256_hash

    def validate_authcode(self, auth_code):
        try:
            app_id_hash = self.sha256_hash(appId=fcc.APP_ID, appType=fcc.APP_TYPE, appSecret=fcc.APP_SECRET)
            payload = {
                "grant_type": "authorization_code",
                "appIdHash": app_id_hash,
                "code": auth_code,
            }

            result_string = requests.post(url=fcc.URL_VALIDATE_AUTH_CODE, json=payload)
            if result_string.status_code != 200:
                return [fcc.ERROR, result_string.text]

            result = json.loads(result_string.text)
            access_token = result["access_token"]

            return [fcc.SUCCESS, access_token]
    
        except Exception as e:
            return [fcc.ERROR, e]


    def main(self):
        # Step 1 - Retrieve request_key from verify_client_id Function
        verify_client_id_result = self.verify_client_id(client_id=fcc.CLIENT_ID)
        if verify_client_id_result[0] != fcc.SUCCESS:
            print(f"verify_client_id failure - {verify_client_id_result[1]}")
            sys.exit()
        else:
            print("verify_client_id success")

        # Step 2 - Generate totp
        generate_totp_result = self.generate_totp(secret=fcc.TOTP_SECRET_KEY)
        if generate_totp_result[0] != fcc.SUCCESS:
            print(f"generate_totp failure - {generate_totp_result[1]}")
            sys.exit()
        else:
            print("generate_totp success")

        # Step 3 - Verify totp and get request key from verify_totp Function.
        request_key = verify_client_id_result[1]
        totp = generate_totp_result[1]
        verify_totp_result = self.verify_totp(request_key=request_key, totp=totp)
        if verify_totp_result[0] != fcc.SUCCESS:
            print(f"verify_totp_result failure - {verify_totp_result[1]}")
            sys.exit()
        else:
            print("verify_totp_result success")
        
        # Step 4 - Verify pin and send back access token
        request_key_2 = verify_totp_result[1]
        verify_pin_result = self.verify_PIN(request_key=request_key_2, pin=fcc.PIN)
        if verify_pin_result[0] != fcc.SUCCESS:
            print(f"verify_pin_result failure - {verify_pin_result[1]}")
            sys.exit()
        else:
            print("verify_pin_result success")
        
        # Step 5 - Get auth code for API V3 App from trade access token
        token_result = self.token(
            client_id=fcc.CLIENT_ID, app_id=fcc.APP_ID, redirect_uri=fcc.REDIRECT_URI, app_type=fcc.APP_TYPE,
            access_token=verify_pin_result[1]
        )
        if token_result[0] != fcc.SUCCESS:
            print(f"token_result failure - {token_result[1]}")
            sys.exit()
        else:
            print("token_result success")

        # Step 6 - Get API V3 access token from validating auth code
        auth_code = token_result[1]
        validate_authcode_result = self.validate_authcode(auth_code=auth_code)
        if validate_authcode_result[0] != fcc.SUCCESS:
            print(f"validate_authcode failure - {validate_authcode_result[1]}")
            sys.exit()
        else:
            print("validate_authcode success")
        
        access_token = fcc.APP_ID + "-" + fcc.APP_TYPE + ":" + validate_authcode_result[1]

        print(f"\naccess_token - {access_token}\n")

        self.local_db["fyers_access_token"] = access_token
        self.local_db.commit()
        self.local_db.close()

if __name__ == "__main__":  
    Update_fyers_access_token().main()
    acc_token = Update_fyers_access_token().get_access_token()
    print(acc_token)
