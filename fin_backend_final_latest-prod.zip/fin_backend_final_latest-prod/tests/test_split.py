import sys, os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from shared.db.db_model import Ind_StockMaster
from shared.db.dbconn import DBConnection
import yfinance as yf
from datetime import date
from dateutil.relativedelta import relativedelta
from apps.finprod_backend.modules.stock_handler import download_single_stock_data, proc_single_tick_item
from shared.config.settings import stock_data_dir_config

class STOCK_SPLIT_CHECKER:
    def __init__(self):
        self.db = DBConnection()
        self.since = date.today() - relativedelta(months=10)
    

    def get_all_active_symbols(self):
        session = self.db.get_session()
        res = session.query(Ind_StockMaster).filter(Ind_StockMaster.is_active == True).all()
        session.close()
        return [{"y_finance": r.y_finance, "stock_tick": r.stock_tick} for r in res]
    

    def check_split_status(self, symbol):
        try:
            splits = yf.Ticker(symbol).splits
            if splits is not None and not splits.empty:
                recent = splits[splits.index.date >= self.since]
                if not recent.empty:
                    return True
                return False
            return False
        except Exception as e:
            print(f"Error checking split status for {symbol}: {e}")
            return False
            

    def calculate(self):
        symbols = self.get_all_active_symbols()
        for symbol in symbols:
            if self.check_split_status(symbol['y_finance']):
                print(f"{symbol['y_finance']} has split")
                self.reprocess_split_stock(symbol)

    def reprocess_split_stock(self, symbol):
        try:
            y_fin_stock_name = symbol['y_finance']
            stock_tick_nn = symbol['stock_tick']
            download_single_stock_data(stock_tick_nn, y_fin_stock_name, stock_data_dir_config.indian_stock_data_dir)
            proc_single_tick_item(stock_tick_nn, stock_data_dir_config.indian_stock_data_dir)
            print("success")
        except Exception as ex:
            print(symbol , ex)




if __name__ == "__main__":
    checker = STOCK_SPLIT_CHECKER()
    checker.calculate()
        