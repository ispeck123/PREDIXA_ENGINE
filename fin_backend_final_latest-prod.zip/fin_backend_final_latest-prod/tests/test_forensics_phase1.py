import json
from datetime import datetime
from pathlib import Path

import pandas as pd

from analytics.forensics.evidence_builder import build_forensic_record, build_ohlc_evidence
from analytics.forensics.feature_utils import parse_order_status, planned_rr
from analytics.forensics.repository import ReadOnlyOrderRepository
from analytics.forensics.schemas import LinkResult, OrderBundle
from analytics.forensics.technical_features import build_technical_features


def test_status_parser_never_requires_eval():
    parsed = parse_order_status("{'status': 'failed', 'reason': 'Stoploss hit', 'loss_pct': -1.2}")
    assert parsed.status == "failed"
    assert parsed.reason == "Stoploss hit"
    assert parsed.loss_pct == -1.2


def test_status_parser_handles_malformed_value():
    parsed = parse_order_status("not a python dict")
    assert parsed.status is None
    assert parsed.parse_error


def test_planned_rr_is_direction_independent():
    assert planned_rr("BUY", 100, 95, 110) == 2.0
    assert planned_rr("SELL", 100, 105, 80) == 4.0


def test_cutoff_windows_exclude_future_candles(tmp_path):
    root = tmp_path / "data"
    (root / "latest_data_csv").mkdir(parents=True)
    df = pd.DataFrame({
        "tradeDate": ["2026-09-10 09:15:00", "2026-09-10 10:15:00", "2026-09-10 11:15:00", "2026-09-10 12:15:00"],
        "open": [100, 101, 99, 98], "high": [101, 102, 100, 99], "low": [99, 100, 98, 97], "close": [100, 101, 99, 98], "volume": [1, 2, 3, 4],
    })
    df.to_csv(root / "latest_data_csv" / "demo_daily.csv", index=False)
    bundle = OrderBundle(order={"stock_tick": "demo", "time_frame": 1, "purchased_cmp_date": "2026-09-10 10:15:00", "entry_timestamp": "2026-09-10 10:15:00", "order_status": "{'status': 'failed', 'completed_on': '2026-09-10 11:15:00'}"})
    evidence, _ = build_ohlc_evidence(bundle, str(root))
    frame = evidence["frames"]["daily"]
    assert len(frame["pre_setup"]["rows"]) == 2
    assert len(frame["active_trade"]["rows"]) == 2
    assert all(row["tradeDate"] <= "2026-09-10 10:15:00" for row in frame["pre_setup"]["rows"])
    assert all(row["tradeDate"] > "2026-09-10 11:15:00" for row in frame["post_trade"]["rows"])


def test_missing_signal_and_oms_are_explicit():
    bundle = OrderBundle(
        order={"order_id": 1, "stock_tick": "missing", "time_frame": 1, "order_type": "BUY", "entry_price": 100, "stoploss_price": 95, "target_price": 110, "purchased_cmp_date": "2026-09-10 10:15:00", "order_status": None},
        links={"order_to_oms_bucket": LinkResult("MISSING"), "bucket_to_oms_orders": LinkResult("UNLINKED")},
    )
    record = build_forensic_record(bundle, "/does/not/exist")
    flags = set(record["data_quality"]["flags"])
    assert {"SETUP_SIGNAL_MISSING", "TRADE_SIGNAL_DELETED", "SETUP_SNAPSHOT_UNAVAILABLE", "OMS_LINK_MISSING", "OHLC_DATA_MISSING"} <= flags


def test_ambiguous_oms_link_is_explicit():
    bundle = OrderBundle(
        order={"order_id": 3, "stock_tick": "missing", "time_frame": 1, "order_type": "BUY", "purchased_cmp_date": "2026-09-10 10:15:00"},
        links={"order_to_oms_bucket": LinkResult("AMBIGUOUS"), "bucket_to_oms_orders": LinkResult("AMBIGUOUS")},
    )
    record = build_forensic_record(bundle, "/does/not/exist")
    assert "OMS_LINK_AMBIGUOUS" in record["data_quality"]["flags"]


def test_invalid_ohlc_schema_is_flagged(tmp_path):
    root = tmp_path / "data"
    (root / "latest_data_csv").mkdir(parents=True)
    pd.DataFrame({"not_time": [1], "close": [100]}).to_csv(root / "latest_data_csv" / "demo_daily.csv", index=False)
    bundle = OrderBundle(order={"stock_tick": "demo", "time_frame": 1, "purchased_cmp_date": "2026-09-10 10:15:00"})
    record = build_forensic_record(bundle, str(root))
    assert "OHLC_DATA_MISSING" in record["data_quality"]["flags"]


def test_same_evidence_is_idempotent():
    bundle = OrderBundle(order={"order_id": 4, "stock_tick": "demo", "time_frame": 1, "order_type": "SELL", "entry_price": 100, "stoploss_price": 105, "target_price": 90, "purchased_cmp_date": "2026-09-10 10:15:00", "order_status": "{'status': 'success'}"})
    first = build_forensic_record(bundle, "/does/not/exist")
    second = build_forensic_record(bundle, "/does/not/exist")
    assert first["data_hash"] == second["data_hash"]


def test_record_has_trace_and_hash():
    bundle = OrderBundle(order={"order_id": 2, "stock_tick": "demo", "time_frame": 1, "order_type": "SELL", "entry_price": 100, "stoploss_price": 105, "target_price": 90, "purchased_cmp_date": "2026-09-10 10:15:00", "order_status": "{'status': 'success'}"})
    record = build_forensic_record(bundle, "/does/not/exist")
    assert record["data_hash"]
    assert record["source_trace"]
    json.dumps(record, default=str)


def test_repository_source_contains_only_selects():
    source = Path("analytics/forensics/repository.py").read_text()
    assert "SELECT" in source
    assert "INSERT" not in source.upper()
    assert "UPDATE" not in source.upper()
    assert "DELETE" not in source.upper()


def test_technical_features_are_setup_cutoff_safe():
    rows = []
    for i in range(60):
        close = 100 + i
        rows.append({"tradeDate": f"2026-09-{i // 20 + 1:02d} 10:{i % 60:02d}:00", "open": close - 0.5, "high": close + 1, "low": close - 1, "close": close, "volume": 100 + i})
    ohlc = {"frames": {"daily": {"pre_setup": {"rows": rows}, "active_trade": {"rows": [{"high": 200, "low": 95, "close": 150}]}, "post_trade": {"rows": [{"high": 999, "low": 1, "close": 500}]}}}}
    features = build_technical_features({"order_type": "BUY", "entry_price": 159, "stoploss_price": 150, "target_price": 180}, ohlc)
    setup = features["frames"]["daily"]["setup"]
    assert setup["close"] == 159.0
    assert setup["close"] != 500.0
    assert features["frames"]["daily"]["excursions"]["mfe"] == 41.0


def test_buy_sell_excursion_geometry():
    rows = [{"high": 110, "low": 95, "close": 105}, {"high": 115, "low": 100, "close": 112}]
    base = {"frames": {"x": {"pre_setup": {"rows": [{"high": 101, "low": 99, "close": 100}]}, "active_trade": {"rows": rows}, "post_trade": {"rows": []}}}}
    buy = build_technical_features({"order_type": "BUY", "entry_price": 100, "stoploss_price": 95, "target_price": 120}, base)
    sell = build_technical_features({"order_type": "SELL", "entry_price": 100, "stoploss_price": 105, "target_price": 80}, base)
    assert buy["frames"]["x"]["excursions"]["mfe"] == 15.0
    assert sell["frames"]["x"]["excursions"]["mfe"] == 5.0
    assert sell["frames"]["x"]["excursions"]["mae"] == 15.0
