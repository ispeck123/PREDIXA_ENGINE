import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from shared.db.dbconn import DBConnection
# from apps.finprod_backend.modules.order_update import check_entry_hit, evaluate_order_status
# from eval_order import check_entry_hit, evaluate_order_status
from scripts.order_update import check_entry_hit, evaluate_order_status
from sqlalchemy import text
from datetime import datetime
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
from tqdm import tqdm
import logging
from shared.config.settings import stock_data_dir_config

logger = logging.getLogger()

dbc = DBConnection()

data_dir = stock_data_dir_config.indian_stock_data_dir

# dbs = db.get_session()
# dbs.rollback()
# dbs.close()
# def update_entry():
#     db = DBConnection()
#     rc = db.raw_connection()
#     table_name = 'auto_order_master' # auto_order_master unique_india_order_master
#     ords = db.raw_query(text(f"select * from {table_name} where is_trade_started=0;"))
#     for orders in ords:
#         try:
#             order_id = orders.get('order_id')
#             stock_tick = orders.get('stock_tick')
#             buy_price = orders.get('entry_price')
#             purchased_on = orders.get('purchased_cmp_date')
#             time_frame = orders.get('time_frame')
#             # print(purchased_on, type(purchased_on))
#             is_started, entry_ts = check_entry_hit(stock_tick, buy_price, purchased_on, time_frame)
#             # stat, entry_timestamp = calculate_entry_hit(stock_tick, buy_price, purchased_on, time_frame)
#             # print(entry_timestamp, type(entry_timestamp))
#             if is_started and entry_ts:
#                 update_sql = text(f"""
#                     UPDATE {table_name}
#                     SET is_trade_started = 1, entry_timestamp = :entry_ts
#                     WHERE order_id = :order_id
#                 """)
#                 rc.execute(update_sql, {"entry_ts": entry_ts.strftime("%Y-%m-%dT%H:%M:%S"), "order_id": order_id})
#                 rc.commit() 
#             print(order_id, is_started, entry_ts)
#         except Exception as ex:
#             print(ex, order_id, "...............")
#     rc.close()


# def update_status():
#     db = DBConnection()
#     table_name = 'auto_order_master' #  unique_india_order_master
#     ords = db.raw_query(text(f"select * from {table_name} where is_evaluated=0 and is_trade_started=1"))
#     for orders in ords:
#         order_id = orders.get('order_id')
#         stock_tick = orders.get('stock_tick')
#         buy_price = orders.get('entry_price')
#         stop_loss = orders.get('stoploss_price')
#         target_price = orders.get('target_price')
#         stock_quantity = orders.get('stock_quantity')
#         time_frame = orders.get('time_frame')
#         # purchased_on = orders.get('purchased_cmp_date')
#         entry_timestamp = orders.get('entry_timestamp')
#         ord_type = orders.get('order_type')
#         try:
#             entry_dt = datetime.fromisoformat(entry_timestamp)
#         except Exception:
#             entry_dt = datetime.strptime(entry_timestamp, "%Y-%m-%d %H:%M:%S")

#         result = evaluate_order_status(
#                 stock_name=stock_tick,
#                 entry_price=buy_price,
#                 created_on=entry_dt.strftime("%Y-%m-%dT%H:%M"),
#                 stop_loss=stop_loss,
#                 target_price=target_price,
#                 quantity=stock_quantity,
#                 order_type=ord_type,
#                 time_frame=time_frame
#             )
#         update_sql = f"""
#                 UPDATE {table_name}
#                 SET order_status = :order_status,
#                     is_evaluated = :is_eval,
#                     completed_on = :completed_on
#                 WHERE order_id = :order_id
#             """
#         rc = db.raw_connection()
#         rc.execute(
#                 text(update_sql),
#                 {
#                     "order_status": str(result),
#                     "is_eval": 1 if result.get("status") in ["success", "failed"] else 0,
#                     "completed_on": result.get("completed_on").strftime("%Y-%m-%d %H:%M:%S") if result.get("completed_on") else None,
#                     "order_id": order_id
#                 }
#             )
#         rc.commit()
#         rc.close()



def process_order(order):
    try:
        order_id = order.get('order_id')
        stock_tick = order.get('stock_tick')
        buy_price = order.get('entry_price')
        purchased_on = order.get('purchased_cmp_date')
        time_frame = order.get('time_frame')

        is_started, entry_ts = check_entry_hit(stock_tick, buy_price, purchased_on, time_frame, data_dir)
        if is_started and entry_ts:
            return {
                "order_id": order_id,
                "entry_ts": entry_ts.strftime("%Y-%m-%dT%H:%M:%S")
            }
        return None
    except Exception as ex:
        print(f"[ERROR][{order.get('order_id')}] {ex}")
        return None

def update_entries_parallel(time_fr: int):
    table_name = 'auto_order_master' # auto_order_master

    # Step 1: Fetch all non-started orders
    orders = dbc.raw_query(text(f"SELECT * FROM {table_name} WHERE is_trade_started = 0 and time_frame={time_fr}"))
    total_orders = len(orders)

    print(f"🚀 Processing {total_orders} orders...")

    # Step 2: Use ProcessPoolExecutor with tqdm for CPU-bound processing
    processed_orders = []
    with ProcessPoolExecutor(max_workers=10) as process_pool:
        results = list(tqdm(
            process_pool.map(process_order, orders),
            total=total_orders,
            desc="🔍 Checking Entries",
            dynamic_ncols=True
        ))

    processed_orders = [res for res in results if res]
    print(f"✅ {len(processed_orders)} entries matched. Updating DB...")

    # Step 3: Use ThreadPoolExecutor with tqdm for DB updates
    def update_entry_db(entry):
         try:
             session = dbc.get_session()
             update_sql = text(f"""
                 UPDATE {table_name}
                 SET is_trade_started = 1, entry_timestamp = :entry_ts
                 WHERE order_id = :order_id;
             """)
             session.execute(update_sql, {"entry_ts": entry["entry_ts"], "order_id": entry["order_id"]})
             session.commit()
         except Exception as ex:
             session.rollback()
             logger.exception(ex, exc_info=1, stack_info=True)
             print(f"[UPDATE ERROR][{entry['order_id']}] {ex}")
         finally:
             session.close()

    with ThreadPoolExecutor(max_workers=10) as thread_pool:
        list(tqdm(
            thread_pool.map(update_entry_db, processed_orders),
            total=len(processed_orders),
            desc="💾 Updating DB",
            dynamic_ncols=True
        ))

    
    dbc.close_engine()
    print("✅ All updates completed.")



def process_order_status(order):
    try:
        order_id = order.get('order_id')
        stock_tick = order.get('stock_tick')
        buy_price = order.get('entry_price')
        stop_loss = order.get('stoploss_price')
        target_price = order.get('target_price')
        stock_quantity = order.get('stock_quantity')
        time_frame = order.get('time_frame')
        entry_timestamp = order.get('entry_timestamp')
        ord_type = order.get('order_type')

        try:
            entry_dt = datetime.fromisoformat(entry_timestamp)
        except Exception:
            entry_dt = datetime.strptime(entry_timestamp, "%Y-%m-%d %H:%M:%S")

        result = evaluate_order_status(
            stock_name=stock_tick,
            entry_price=buy_price,
            created_on=entry_dt.strftime("%Y-%m-%dT%H:%M"),
            stop_loss=stop_loss,
            target_price=target_price,
            quantity=stock_quantity,
            order_type=ord_type,
            time_frame=time_frame,
            data_dir=data_dir
        )

        return {
            "order_id": order_id,
            "order_status": str(result),
            "is_eval": 1 if result.get("status") in ["success", "failed"] else 0,
            "completed_on": result.get("completed_on").strftime("%Y-%m-%d %H:%M:%S") if result.get("completed_on") else None
        }

    except Exception as ex:
        print(f"[ERROR][{order.get('order_id')}] {ex}")
        return None


def update_status_parallel(time_fr: int):
    table_name = 'auto_order_master' # auto_order_master
    orders = dbc.raw_query(text(f"SELECT * FROM {table_name} WHERE is_evaluated = 0 AND is_trade_started = 1 and time_frame={time_fr}"))
    total_orders = len(orders)

    print(f"🚀 Evaluating {total_orders} orders...")

    # Step 1: Use ProcessPoolExecutor for evaluation
    evaluated_results = []
    with ProcessPoolExecutor(max_workers=10) as process_pool:
        results = list(tqdm(
            process_pool.map(process_order_status, orders),
            total=total_orders,
            desc="🧠 Evaluating Orders",
            dynamic_ncols=True
        ))

    evaluated_results = [r for r in results if r]
    print(f"✅ {len(evaluated_results)} orders evaluated. Updating DB...")

    # Step 2: Use ThreadPoolExecutor for DB updates
    def update_db(entry):
        try:
            session = dbc.get_session()
            update_sql = text(f"""
                UPDATE {table_name}
                SET order_status = :order_status,
                    is_evaluated = :is_eval,
                    completed_on = :completed_on
                WHERE order_id = :order_id
            """)
            session.execute(update_sql, {
                "order_status": entry["order_status"],
                "is_eval": entry["is_eval"],
                "completed_on": entry["completed_on"],
                "order_id": entry["order_id"]
            })
            session.commit()
            session.close()
        except Exception as ex:
            print(f"[DB ERROR][{entry['order_id']}] {ex}")

    with ThreadPoolExecutor(max_workers=10) as thread_pool:
        list(tqdm(
            thread_pool.map(update_db, evaluated_results),
            total=len(evaluated_results),
            desc="💾 Updating DB",
            dynamic_ncols=True
        ))

    dbc.close_engine()
    print("✅ All status updates completed.")

if __name__ == "__main__":
    # update_entries_parallel(time_fr=1)
    # update_status_parallel(time_fr=1)
    # update_entries_parallel(time_fr=25)
    update_status_parallel(time_fr=25)
    # update_entries_parallel(time_fr=25)
    # update_status_parallel(time_fr=25)
    # update_status()
    