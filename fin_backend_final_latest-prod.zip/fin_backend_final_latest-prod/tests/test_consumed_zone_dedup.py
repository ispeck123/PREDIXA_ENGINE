import sys
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import scripts.cash_wetrun_scanner as scanner


class _Query:
    def __init__(self, rows):
        self.rows = rows

    def filter(self, *args):
        return self

    def order_by(self, *args):
        return self

    def all(self):
        return self.rows


class _Session:
    def __init__(self, rows):
        self.rows = rows
        self.closed = False

    def query(self, model):
        return _Query(self.rows)

    def close(self):
        self.closed = True


class _DBC:
    def __init__(self, rows):
        self.session = _Session(rows)

    def get_session(self):
        return self.session


def _setup(dead_after=1, **overrides):
    setup = {
        "zone_signature": "ABC:X:100.0:90.0",
        "is_execute_tf": True,
        "consumption_dead_after": dead_after,
        "base_start_idx": 20,
        "legout_end_idx": 22,
        "retest_count": 0,
    }
    setup.update(overrides)
    return setup


def _consumed(**overrides):
    row = {
        "zone_signature": "ABC:X:100.0:90.0",
        "base_start_idx": 10,
        "legout_end_idx": 12,
    }
    row.update(overrides)
    return SimpleNamespace(**row)


def test_execute_bz_is_suppressed_after_one_fill(monkeypatch):
    monkeypatch.setattr(scanner, "dbc", _DBC([_consumed()]))

    suppressed, reason = scanner.consumed_zone_suppression(_setup())

    assert suppressed is True
    assert reason == "CONSUMED_ZONE_REFIRE (sig=ABC:X:100.0:90.0, prior=1, limit=1)"


def test_gdz_allows_one_retest_then_suppresses_third_trade(monkeypatch):
    monkeypatch.setattr(scanner, "dbc", _DBC([_consumed()]))
    assert scanner.consumed_zone_suppression(_setup(dead_after=2)) == (False, None)

    monkeypatch.setattr(scanner, "dbc", _DBC([_consumed(), _consumed()]))
    suppressed, reason = scanner.consumed_zone_suppression(_setup(dead_after=2))
    assert suppressed is True
    assert "prior=2, limit=2" in reason


def test_non_execute_and_ea_sentinel_do_not_query(monkeypatch):
    def fail_if_called():
        raise AssertionError("database should not be queried")

    monkeypatch.setattr(scanner.dbc, "get_session", fail_if_called)
    assert scanner.consumed_zone_suppression(
        _setup(is_execute_tf=False)
    ) == (False, None)
    assert scanner.consumed_zone_suppression(
        _setup(consumption_dead_after=0)
    ) == (False, None)


def test_overlap_boundary_matches_engine_rule():
    new_zone = "ABC:X:100.0:90.0"
    assert scanner._zone_overlap_pct(new_zone, "ABC:X:95.0:85.0") == 0.50
    assert scanner._zone_overlap_pct(new_zone, "ABC:X:94.99:85.0") < 0.50


def test_reactivation_requires_all_three_conditions():
    consumed = _consumed(zone_signature="ABC:X:94.0:84.0")
    assert scanner._is_reactivated_zone(_setup(), consumed) is True
    assert scanner._is_reactivated_zone(_setup(retest_count=1), consumed) is False
    assert scanner._is_reactivated_zone(_setup(base_start_idx=12), consumed) is False


def test_changed_contained_signature_is_suppressed(monkeypatch):
    consumed = _consumed(zone_signature="ABC:X:101.0:91.0")
    monkeypatch.setattr(scanner, "dbc", _DBC([consumed]))
    setup = _setup(zone_signature="ABC:X:100.0:90.0")

    suppressed, reason = scanner.consumed_zone_suppression(setup)

    assert suppressed is True
    assert "CONSUMED_ZONE_REFIRE" in reason


def test_changed_noncontained_signature_is_allowed_when_fresh(monkeypatch):
    consumed = _consumed(zone_signature="ABC:X:101.0:91.0")
    monkeypatch.setattr(scanner, "dbc", _DBC([consumed]))
    setup = _setup(zone_signature="ABC:X:80.0:70.0", base_start_idx=20)

    assert scanner.consumed_zone_suppression(setup) == (False, None)
