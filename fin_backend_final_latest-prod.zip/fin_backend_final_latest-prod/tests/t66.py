import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from scripts.calculate_zones import ZoneAnalyzer, DemandZoneCalculator, SupplyZoneCalculator
from datetime import datetime


if __name__ == "__main__":
    file_apth = "./data/indian_stock_data/processed_data_files/icicibank_daily.csv"
    dz_calculator = DemandZoneCalculator(file_apth, 1, datetime.now(), True)
    sz_calculator = SupplyZoneCalculator(file_apth, 1, datetime.now(), True)
    zone_analyzer = ZoneAnalyzer(dz_calculator, sz_calculator)
    print(dz_calculator.calculate_zones())
    # print(zone_analyzer.get_qualified_sell_zones())