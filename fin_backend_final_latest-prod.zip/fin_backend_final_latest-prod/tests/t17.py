import sys, os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from fyers_apiv3 import fyersModel
from datetime import datetime, timedelta
import pandas as pd
from data_fetchers.fyers.fyers_session import fyers_access_token_handler
from shared.db.db_model import Ind_StockMaster
from shared.db.dbconn import DBConnection
from shared.config.settings import stock_data_dir_config
import time
import csv

class CandleDateFetcher:

    def __init__(self):
        fyers_access_token = fyers_access_token_handler().get_access_token()
        self.client_id = fyers_access_token.split(':')[0]
        self.access_token = fyers_access_token.split(':')[1]
        self.output_path = os.path.join(stock_data_dir_config.indian_stock_data_dir, 'latest_data_csv')
        self.name_interval_dict = {
            "60": "sixty", 
            "15": "fifteen",
            "5": "five"
        }
        self.dbc = DBConnection()

    def get_all_symbols(self):
        session = self.dbc.get_session()
        stock_master = session.query(Ind_StockMaster).filter(Ind_StockMaster.is_active == 1,
                                                             Ind_StockMaster.fyers_symbol != None).order_by(Ind_StockMaster.id.desc()).all()
        session.close()
        return [(stock.stock_tick, stock.fyers_symbol) for stock in stock_master]

    def fetch_candle_data_custom_resolution(self,
                                        symbol: str,
                                        file_name: str,
                                        start_date: str = "2020-01-01",
                                        end_date: str = datetime.now().strftime("%Y-%m-%d"),
                                        resolution: str = "60"):
        start_dt = datetime.strptime(start_date, "%Y-%m-%d")
        end_dt = datetime.strptime(end_date, "%Y-%m-%d")
        
        fyers = fyersModel.FyersModel(
            client_id=self.client_id,
            is_async=False,
            token=self.access_token,
            log_path=""
        )
        out_file_name = os.path.join(self.output_path, f"{file_name}_{self.name_interval_dict[resolution]}.csv")
        if os.path.exists(out_file_name):
            # print("File already exists:", out_file_name)
            ext_df = pd.read_csv(out_file_name)
            # print(ext_df.iloc[0]['tradeDate'], ext_df.iloc[-1]['tradeDate'])
            # return
        else:
            print("File does not exist:", out_file_name, symbol)
            # return
        all_candles = []
        current_from = end_dt

        while current_from > start_dt:
            current_to = current_from
            current_from = current_to - timedelta(days=99)

            # Clamp range_from to not go before start_dt
            if current_from < start_dt:
                current_from = start_dt

            range_from_str = current_from.strftime("%Y-%m-%d")
            range_to_str = current_to.strftime("%Y-%m-%d")
            print(f"Fetching: {range_from_str} → {range_to_str}")

            data = {
                "symbol": symbol,
                "resolution": resolution,
                "date_format": "1",
                "range_from": range_from_str,
                "range_to": range_to_str,
                "cont_flag": "1"
            }

            success = False
            for attempt in range(10):
                response = fyers.history(data=data)
                if 'candles' in response and response['candles']:
                    all_candles = response['candles'] + all_candles  # Prepend to maintain chronological order
                    success = True
                    break
                else:
                    print(response)
                    print(f"Retry {attempt + 1}: No candle data for {symbol} between {range_from_str} and {range_to_str}")
                    if response.get('s') == 'no_data':
                        break
                    elif response.get('message') == 'request limit reached':
                        time.sleep(5)
                    time.sleep(5)


            if not success:
                print(f"⚠️ Skipped chunk: {range_from_str} to {range_to_str}")

        if not all_candles:
            print("❌ No candles fetched. Skipping save.")
            return

        # Save to CSV
        df = pd.DataFrame(all_candles, columns=['tradeDate', 'open', 'high', 'low', 'close', 'qty'])
        df['tradeDate'] = pd.to_datetime(df['tradeDate'], unit='s', utc=True).dt.tz_convert('Asia/Kolkata')
        df['tradeDate'] = df['tradeDate'].dt.strftime('%d/%m/%Y %H:%M:%S')
        df = df[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]

        out_file_name = os.path.join(self.output_path, f"{file_name}_{self.name_interval_dict[resolution]}.csv")
        df.to_csv(out_file_name, index=False)
        print("✅ Saved:", out_file_name)


    def process_all_symbols(self):
        symbols = self.get_all_symbols()
        for stock_tick, fyers_symbol in symbols:
            # self.fetch_candle_data_custom_resolution(symbol=fyers_symbol, file_name=stock_tick, resolution="15")
            self.fetch_candle_data_custom_resolution(symbol=fyers_symbol, file_name=stock_tick, resolution="5")


    def process_all_data(self):
        symbols = self.get_all_symbols()
        for stock_tick, fyers_symbol in symbols:
            # self.create_125_munite_from_5_munite(file_name=f"{stock_tick}_five.csv")
            self.create_25_munite_from_5_munite(file_name=f"{stock_tick}_five.csv")
            # self.create_75munite_from_15munite(file_name=f"{stock_tick}_fifteen.csv")
    

    def create_125_munite_from_5_munite(self, file_name: str):
        txt_dir = os.path.join(stock_data_dir_config.indian_stock_data_dir, 'latest_data_csv') 
        file_path = os.path.join(txt_dir, file_name)
        print("Reading:", file_path)

        df = pd.read_csv(file_path)[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]
        
        chunk_size = 125 // 5
        output = []

        # Define operation map
        agg_map = {
            'open': lambda chunk: chunk.iloc[0]['open'],
            'high': lambda chunk: chunk['high'].max(),
            'low': lambda chunk: chunk['low'].min(),
            'close': lambda chunk: chunk.iloc[-1]['close'],
            'qty': lambda chunk: chunk['qty'].sum(),
            'tradeDate': lambda chunk: chunk.iloc[0]['tradeDate']
        }

        for i in range(0, len(df), chunk_size):
            chunk = df.iloc[i:i + chunk_size]
            if len(chunk) < chunk_size:
                break  # Skip incomplete chunk

            new_row = {col: func(chunk) for col, func in agg_map.items()}
            output.append(new_row)

        if output:
            headers = output[0].keys()
            csv_file_name = file_name.replace("five", "one_twenty_five")
            self.dump_csv(headers, csv_file_name, output)
            print("Saved as:", csv_file_name)
        else:
            print("No complete 125-minute chunks to save.")

    def create_25_munite_from_5_munite(self, file_name: str):
        txt_dir = os.path.join(stock_data_dir_config.indian_stock_data_dir, 'latest_data_csv') 
        file_path = os.path.join(txt_dir, file_name)
        print("Reading:", file_path)

        df = pd.read_csv(file_path)[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]
        
        chunk_size = 25 // 5
        output = []

        # Define operation map
        agg_map = {
            'open': lambda chunk: chunk.iloc[0]['open'],
            'high': lambda chunk: chunk['high'].max(),
            'low': lambda chunk: chunk['low'].min(),
            'close': lambda chunk: chunk.iloc[-1]['close'],
            'qty': lambda chunk: chunk['qty'].sum(),
            'tradeDate': lambda chunk: chunk.iloc[0]['tradeDate']
        }

        for i in range(0, len(df), chunk_size):
            chunk = df.iloc[i:i + chunk_size]
            if len(chunk) < chunk_size:
                break  # Skip incomplete chunk

            new_row = {col: func(chunk) for col, func in agg_map.items()}
            output.append(new_row)

        if output:
            headers = output[0].keys()
            csv_file_name = file_name.replace("five", "twenty_five")
            self.dump_csv(headers, csv_file_name, output)
            print("Saved as:", csv_file_name)
        else:
            print("No complete 25-minute chunks to save.")
    

    def create_75munite_from_15munite(self, file_name: str):
        txt_dir = os.path.join(stock_data_dir_config.indian_stock_data_dir, 'latest_data_csv') 
        file_path = os.path.join(txt_dir, file_name)
        print("Reading:", file_path)
        df = pd.read_csv(file_path)[['open', 'high', 'low', 'close', 'qty', 'tradeDate']] # create_75munite_from_15munite
        chunk_size = 75 // 15
        output = []
        # Define operation map
        agg_map = {
            'open': lambda chunk: chunk.iloc[0]['open'],
            'high': lambda chunk: chunk['high'].max(),
            'low': lambda chunk: chunk['low'].min(),
            'close': lambda chunk: chunk.iloc[-1]['close'],
            'qty': lambda chunk: chunk['qty'].sum(),
            # 'tradeTime': lambda chunk: chunk.iloc[0]['tradeTime'],
            'tradeDate': lambda chunk: chunk.iloc[0]['tradeDate']
        }
        for i in range(0, len(df), chunk_size):
            chunk = df.iloc[i:i + chunk_size]
            if len(chunk) < chunk_size:
                break  # Skip incomplete chunk

            new_row = {col: func(chunk) for col, func in agg_map.items()}
            output.append(new_row)

        if output:
            headers = output[0].keys()
            csv_file_name = file_name.replace("fifteen", "seventy_five")
            self.dump_csv(headers, csv_file_name, output)
            print("Saved as:", csv_file_name)
        else:
            print("No complete 75-minute chunks to save.")
    

    def dump_csv(self, header, csv_file, data):
        print("creating_csv", csv_file)
        csv_dump_path = os.path.join(stock_data_dir_config.indian_stock_data_dir, 'latest_data_csv', csv_file)
        with open(csv_dump_path, 'w', newline='') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=header)
            writer.writeheader()
            writer.writerows(data)
        print(f'CSV file "{csv_file}" created.')
    

cls = CandleDateFetcher()
# cls.fetch_candle_data_custom_resolution(symbol="SBIN", start_date="2023-05-23", resolution="5")
cls.process_all_symbols()
# cls.process_all_data()