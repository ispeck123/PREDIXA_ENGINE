import sys, os
from datetime import datetime, timedelta
from multiprocessing import Process, Queue, cpu_count
from tqdm import tqdm

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from shared.db.db_model import Ind_StockMaster
from shared.db.dbconn import DBConnection
from shared.db.db_utils import insert_alerts
from scripts.calculate_setup import Calculate_setup_execute
# from shared.config.settings import stock_data_dir_config
import logging

logger = logging.getLogger()

data_dir = "/home/ispeck/PROJECTS_DEV/ispeck_finprod_backend"

def get_trading_days(start_date=datetime(2020, 4, 1), end_date=datetime.now()):
    current_date = start_date
    trading_days = []
    while current_date <= end_date:
        if current_date.weekday() < 5:
            trading_days.append(current_date)
        current_date += timedelta(days=1)
    return trading_days


def get_all_stock_syms():
    dbc = DBConnection()
    db = dbc.get_session()
    res = db.query(Ind_StockMaster).filter(Ind_StockMaster.is_active == True).all()
    return [items.stock_tick for items in res]


def worker(task_list, result_queue):
    for stock, tday in task_list:
        try:
            cse = Calculate_setup_execute(stock_name=stock, time_frame=2, last_dt=tday,
                                          country_dir=data_dir)
            result = cse.calculate()
            # if 'BUY' in result and result['BUY_RRR'] >= 1.5:
                # insert_alerts(result['BUY'], 1, stock, 'BUY', tday) # 'india', 1, "", 0.0
            result_queue.put(f"✅ {stock} @ {tday.strftime('%Y-%m-%d')}")
        except Exception as ex:
            result_queue.put(f"❌ {stock} @ {tday.strftime('%Y-%m-%d')} | Error: {str(ex)}")
            logger.exception(ex, stack_info=True, exc_info=1)

def start_calculation_with_progress():
    trading_days = get_trading_days()
    stocks = get_all_stock_syms()

    all_tasks = [(stock, day) for stock in stocks for day in trading_days]
    total_tasks = len(all_tasks)

    # Split tasks into chunks per process
    num_workers = min(cpu_count(), 8)  # Cap to 8 if needed
    chunk_size = (len(all_tasks) + num_workers - 1) // num_workers
    task_chunks = [all_tasks[i:i + chunk_size] for i in range(0, len(all_tasks), chunk_size)]

    result_queue = Queue()
    processes = [Process(target=worker, args=(chunk, result_queue)) for chunk in task_chunks]

    for p in processes:
        p.start()

    with tqdm(total=total_tasks, desc="Calculating Alerts", dynamic_ncols=True) as pbar:
        for _ in range(total_tasks):
            msg = result_queue.get()
            tqdm.write(msg)
            pbar.update(1)

    for p in processes:
        p.join()


if __name__ == "__main__":
    start_calculation_with_progress()
