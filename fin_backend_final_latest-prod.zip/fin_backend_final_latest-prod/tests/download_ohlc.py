import re
import requests
import os
from datetime import datetime, timedelta

stocks = [
    "abb_india",
    "adani_energy_solutions",
    "adani_enterprises",
    "adani_green",
    "adani_ports",
    "adani_power",
    "ambuja_cement",
    "apollo_hospitals",
    "asian_paints",
    "avenue_supermarts",
    "axis_bank",
    "bajaj_auto",
    "bajaj_finance",
    "bajaj_finserv",
    "bajaj_holdings",
    "bajaj_housing_finance",
    "bank_of_baroda",
    "bharat_electronics",
    "bharti_airtel",
    "bosch",
    "bpcl",
    "britannia_industries",
    "canara_bank",
    "cg_power_inds",
    "cholamandalam_investment",
    "cipla",
    "coal_india",
    "dabur",
    "divis_laboratories",
    "dlf",
    "dr_reddys_laboratories",
    "eicher_motors",
    "eternal",
    "gail",
    "godrej_consumer",
    "grasim_industries",
    "havells_india",
    "hcl_technologies",
    "hdfc_life",
    "hdfcbank",
    "hero_motocorp",
    "hindalco_industries",
    "hindunilvr",
    "hindustan_aeronautics",
    "hyundai_motor_india",
    "icici_lombard_gic",
    "icici_prudential_life",
    "icicibank",
    "indian_hotels",
    "indigo",
    "indusindbk",
    "info_edge",
    "infy",
    "iocl",
    "irfc",
    "itc",
    "jindal_steel_power",
    "jio_financial_service",
    "jsw_energy",
    "jsw_steel",
    "kotak_bank",
    "l_t",
    "lic",
    "ltimindtree",
    "mahindra_mahindra",
    "maruti_suzuki",
    "nestle_india",
    "ntpc",
    "ongc",
    "pidilite_industries",
    "pnb",
    "power_finance_corporation",
    "power_grid_corporation",
    "recl",
    "reliance",
    "samvardhana_motherson",
    "sbi_life",
    "shree_cement",
    "shriram_finance",
    "siemens",
    "state_bank_of_india",
    "sun_pharma",
    "swiggy",
    "tata_consumer_products",
    "tata_steel",
    "tatamotors",
    "tatapower",
    "tcs",
    "tech_mahindra",
    "titan",
    "torrent_pharmaceuticals",
    "trent",
    "tvs_motor",
    "ultratech_cement",
    "united_spirits",
    "varun_beverages",
    "vedanta",
    "wipro",
    "zydus_life"
]

start_date = "2023-01-01"
end_date = "2026-07-12"
time_frame = "1"
exchange = "NSE"
expiry_date = ""
time_frame_text = "monthly-weekly-daily"
today = datetime.now().date()

for tick in stocks:
    try:
        url = f"http://192.168.1.16:7000/get_ohlc_stock_data?tick={tick}&category={exchange}&start_date={start_date}&end_date={end_date}&time_frame={time_frame}&expiry_date={expiry_date}"

        response = requests.get(url, stream=True)

        content_disposition = response.headers.get("Content-Disposition", "")
        match = re.search(r'filename="?([^"]+)"?', content_disposition)

        filename = match.group(1) if match else f"{exchange}_{tick}_{start_date}_{end_date}_{time_frame_text}.zip"

        #print(filename)
        folder_path = f"/home/ispeck/STOCK_PROJECT/STP_LATEST/tests/{exchange}_{time_frame_text}_{str(today)}"
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)
        filepath = f"{folder_path}/{filename}"
        with open(filepath, "wb") as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)

        print(f"Downloaded: {filename}")
    except Exception as e:
        print(f"Error downloading {tick}: {e}")

