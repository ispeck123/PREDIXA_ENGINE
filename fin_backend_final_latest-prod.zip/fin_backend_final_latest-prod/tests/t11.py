from sqlitedict import SqliteDict
import sys, os
from datetime import datetime, timedelta
import pandas as pd
import re
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

db = SqliteDict("finprod.sqlite")

from fyers_apiv3 import fyersModel
import pandas as pd

access_tk = db["fyers_access_token"]

client_id = access_tk.rsplit(":", 1)[0]
access_token = access_tk.rsplit(":", 1)[1]

columns = [
    "symbol", "exchange", "token", "lot_size", "tick_size",
    "isin", "trading_session", "last_update", "instrument_type", "segment",
    "expiry", "option_type", "strike_price", "name", "company_name",
    "underlying", "isin_code", "instrument", "series", "issue_start", "issue_end"
]

# Initialize the FyersModel instance with your client_id, access_token, and enable async mode
fyers = fyersModel.FyersModel(client_id=client_id, is_async=False, token=access_token, log_path="")
# Re-import after code execution state reset
# Load Fyers symbol master file again

def extract_expiry(symbol):
    if not isinstance(symbol, str):
        return pd.NaT  # return Not-A-Time if not a string

    # Adjusted regex to be more flexible
    match = re.search(r'(\d{2})([A-Z]{3})', symbol)
    if match:
        yy, mon = match.groups()
        try:
            return pd.to_datetime(f"20{yy}-{mon}-01", format="%Y-%b-%d")
        except:
            return pd.NaT
    return pd.NaT


def get_latest_fyers_expiry_symbol(product="GOLDM"):
    url = "https://public.fyers.in/sym_details/MCX_COM.csv"
    df = pd.read_csv(url, header=None)
    df.columns = columns
    print(df['segment'].head())
    df = df[df['segment'].astype(str).str.startswith(f"MCX:{product}")]
    df["expiry"] = df["symbol"].apply(extract_expiry)
    

    df = df.dropna(subset=["expiry"]).sort_values("expiry")
    return df.iloc[0]["symbol"] if not df.empty else None

latest = get_latest_fyers_expiry_symbol("GOLDM")
print(latest)

#import ace_tools as tools; tools.display_dataframe_to_user(name="Gold MCX Expiry Symbols", dataframe=gold_expiry_df)

# start_date = datetime.now() - timedelta(days=100)
# end_date = datetime.now()


# data = {
#     "symbol":"NSE:SBIN25JULFUT",
#     "resolution":"60",
#     "date_format":"1",
#     "range_from":start_date.strftime("%Y-%m-%d"),
#     "range_to":end_date.strftime("%Y-%m-%d"),
#     "cont_flag":"1"
# }

# response = fyers.history(data=data)

# print(response)


# df = pd.DataFrame(response['candles'], columns=[
#     'tradeDate', 'open', 'high', 'low', 'close', 'qty'
# ])

# df['tradeDate'] = pd.to_datetime(df['tradeDate'], unit='s', utc=True).dt.tz_convert('Asia/Kolkata')
# df['tradeDate'] = df['tradeDate'].dt.strftime('%d/%m/%Y %H:%M:%S')

# df = df[['open', 'high', 'low', 'close', 'qty', 'tradeDate']]

# df.to_csv("sbin_60.csv", index=False)

# print("CSV file 'sbin_60.csv' created successfully.")