import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from fyers_apiv3 import fyersModel
import logging
from shared.config.settings import fyers_config_credentials as fcc
from data_fetchers.fyers.fyers_session import fyers_access_token_handler
from data_fetchers.fyers.fyers_market_data import FyersMarketData
import time
from datetime import datetime
from shared.db.dbconn import DBConnection
from shared.db.db_model import Ind_StockMaster

logger = logging.getLogger()
dbc = DBConnection()

class StockPriceFetcher:

    def __init__(self):
        self.client_id = fyers_access_token_handler().get_access_token().split(':')[0]
        self.access_token = fyers_access_token_handler().get_access_token().split(':')[1]
        self.fyers_data = FyersMarketData()
        self.add_all_symbols()
        
    def add_all_symbols(self):
        session = dbc.get_session()
        stocks = session.query(Ind_StockMaster).filter(Ind_StockMaster.is_active == True, 
                                                       Ind_StockMaster.fyers_symbol != None).all()
        #print([stock.fyers_symbol for stock in stocks])
        self.fyers_data.add_symbols([stock.fyers_symbol for stock in stocks])
        session.close()
    
    # async def get_stock_price_from_fyers(self, stocks):
    #     try:
    #         stock_data = []
    #         stock_dict = {}
    #         for stock in stocks:
    #             stock_dict[stock['fyers_symbol']] = stock

    #         symbols = [stock['fyers_symbol'] for stock in stocks]
    #         if len(symbols) > 0:
    #             if len(symbols) <= 50:
    #                 limit = len(symbols)
    #             else:
    #                 limit = 50
    #             i = 0
    #             while i < len(symbols):
    #             #if i:
    #                 symbols_temp = symbols[i: limit]
    #                 fyers = fyersModel.FyersModel(client_id=self.client_id, token=self.access_token, is_async=False, log_path="")
    #                 # print(symbols_temp)
    #                 # print(len(symbols_temp))
    #                 quote_data = fyers.quotes({"symbols": ",".join(symbols_temp)})
    #                 #print(quote_data)
    #                 if 'd' in quote_data:
    #                     for data in quote_data['d']:
    #                         if data.get('s') == 'ok' and 'v' in data:
    #                             #for stock in stocks:
    #                                 #if stock['fyers_symbol'] == data['v']['symbol']:
    #                                 if data['v']['symbol'] in symbols_temp:
    #                                     stock_data.append({
    #                                         "stock_id": stock_dict[data['v']['symbol']]['id'],
    #                                         "stock": stock_dict[data['v']['symbol']]['stock_tick'].upper(),
    #                                         "price": data['v']['lp'],
    #                                         "prev_close": data['v']["prev_close_price"],
    #                                         "day_change": f"+{data['v']['ch']} Today" if (data['v']['ch'] > 0) else f"{data['v']['ch']} Today",
    #                                         "day_change_percentage": f"+{data['v']['chp']} %" if (data['v']['chp'] > 0) else f"{data['v']['chp']} %"
    #                                     })
    #                                     #break
    #                 else:
    #                     print(quote_data)
    #                 i = limit
    #                 limit = i + 50 if (i+50) <= len(symbols) else len(symbols)

            
    #         return stock_data
    #     except Exception as ex:
    #         logger.exception(ex)
    #         return stock_data
    

    def get_stock_price_from_fyers(self, symbol):
        try:
            stock_data = []
            stock_dict = {}        
            time.sleep(10)               
            latest_price = self.fyers_data.get_latest_price(symbol) 
            print(latest_price)            
        except Exception as ex:
            logger.exception(ex)
            return stock_data
        

cls = StockPriceFetcher()
cls.get_stock_price_from_fyers("NSEFO:TCS30SEPFUT")
cls.get_stock_price_from_fyers("NSE:TCS30SEPFUT")