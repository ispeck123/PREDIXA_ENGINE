import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from fyers_apiv3 import fyersModel
from data_fetchers.fyers.fyers_session import fyers_access_token_handler
from datetime import datetime

access_tk = fyers_access_token_handler().get_access_token()
client_id = access_tk.rsplit(":", 1)[0]
access_token = access_tk.rsplit(":", 1)[1]
# Initialize the FyersModel instance with your client_id, access_token, and enable async mode


def get_futures_option_data(symbol: str, expiry_to_filter: str):

    fyers = fyersModel.FyersModel(client_id=client_id, token=access_token,is_async=False, log_path="")
    data = {
        "symbol":f"NSE:{symbol}-EQ",
        "strikecount":10,
        "timestamp": ""
    }
    response = fyers.optionchain(data=data)
    print(response)
    options_chain = response["data"]["optionsChain"]

    structured_data = {"expiry": expiry_to_filter, "strikes": []}

    # group by strike
    strike_map = {}
    for opt in options_chain:
        if opt.get("option_type") in ["CE", "PE"]:
            strike = opt["strike_price"]
            if strike not in strike_map:
                strike_map[strike] = {"strike": strike, "call": None, "put": None}
            
            if opt["option_type"] == "CE":
                strike_map[strike]["call"] = {
                    "oi": opt["oi"],
                    "oich": opt["oich"],
                    "symbol": opt["symbol"]
                }
            elif opt["option_type"] == "PE":
                strike_map[strike]["put"] = {
                    "oi": opt["oi"],
                    "oich": opt["oich"],
                    "symbol": opt["symbol"]
                }

    structured_data["strikes"] = list(strike_map.values())

    return structured_data

date = "2025-09-30"
date = datetime.strptime(date, "%Y-%m-%d")
print(date.timestamp())
print(type(date.timestamp()))
get_futures_option_data("TCS", str(int(date.timestamp())))

