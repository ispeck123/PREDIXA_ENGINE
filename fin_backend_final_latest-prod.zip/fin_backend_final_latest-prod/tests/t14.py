import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from data_fetchers.fyers.fyers_ticker import FyersTickerManager
# Assume this is a FastAPI WebSocket or similar
ticker_manager = FyersTickerManager()

# To subscribe:
ticker_manager.subscribe(['NSE:SBIN-EQ'], ticker_manager.fyers)

# To get latest price manually:
print(ticker_manager.get_latest_price('NSE:SBIN-EQ'))

# To unsubscribe:
ticker_manager.unsubscribe(ticker_manager.fyers)