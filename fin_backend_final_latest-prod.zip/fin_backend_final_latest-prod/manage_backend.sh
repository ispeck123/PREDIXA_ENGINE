#!/usr/bin/env bash

set -u

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR" || exit 1

PID_FILE="$SCRIPT_DIR/backend.pid"
LOG_FILE="$SCRIPT_DIR/backend.log"
APP_MODULE="apps.backend.main:app"
CONDA_ENV_NAME="finpro"
HOST="0.0.0.0"
PORT="7000"
RELOAD="${BACKEND_RELOAD:-0}"

backend_pids() {
  pgrep -f "uvicorn([[:space:]]|.*[[:space:]])${APP_MODULE//./\\.}([[:space:]]|$)" 2>/dev/null || true
}

is_backend_pid() {
  local pid="$1"
  local command_line
  command_line="$(ps -p "$pid" -o args= 2>/dev/null || true)"
  [[ "$command_line" =~ (^|[[:space:]])uvicorn([[:space:]]|.*[[:space:]])apps\.backend\.main:app([[:space:]]|$) ]]
}

port_is_listening() {
  ss -ltn "sport = :$PORT" 2>/dev/null | tail -n +2 | grep -q .
}

wait_for_port_state() {
  local wanted="$1"
  local attempt
  for attempt in $(seq 1 120); do
    if [ "$wanted" = "free" ] && ! port_is_listening; then return 0; fi
    if [ "$wanted" = "busy" ] && port_is_listening; then return 0; fi
    sleep 0.25
  done
  return 1
}

start_backend() {
  local existing
  existing="$(backend_pids)"
  if [ -n "$existing" ]; then
    echo "Backend is already running: $existing"
    return 1
  fi
  if port_is_listening; then
    echo "Port $PORT is already in use by another process."
    return 1
  fi

  echo "Starting FastAPI backend in Conda environment: $CONDA_ENV_NAME"
  source "$(conda info --base)/etc/profile.d/conda.sh"
  conda activate "$CONDA_ENV_NAME"

  local -a uvicorn_args=("$APP_MODULE" --host "$HOST" --port "$PORT")
  if [ "$RELOAD" = "1" ]; then
    # Restrict watchfiles to source trees. Watching the repository root also
    # traverses generated Dagster/storage directories and hits OS watch limits.
    uvicorn_args+=(--reload --reload-dir apps --reload-dir shared --reload-dir scripts --reload-dir data_fetchers)
  fi
  setsid uvicorn "${uvicorn_args[@]}" >"$LOG_FILE" 2>&1 &
  local pid=$!
  echo "$pid" > "$PID_FILE"

  if ! wait_for_port_state busy; then
    echo "Backend failed to bind port $PORT; inspect $LOG_FILE"
    stop_backend
    return 1
  fi
  echo "Backend started with process-group PID $pid (reload=$RELOAD)"
}

stop_backend() {
  local pid_file_pid=""
  local pids=""
  local pid

  if [ -f "$PID_FILE" ]; then
    read -r pid_file_pid < "$PID_FILE" || true
    if [[ "$pid_file_pid" =~ ^[0-9]+$ ]] && kill -0 "$pid_file_pid" 2>/dev/null \
        && is_backend_pid "$pid_file_pid"; then
      pids="$pid_file_pid"
    fi
  fi

  pids="$(printf '%s\n%s\n' "$pids" "$(backend_pids)" | awk 'NF && !seen[$0]++')"
  if [ -z "$pids" ]; then
    rm -f "$PID_FILE"
    if port_is_listening; then
      echo "No matching backend process found; port $PORT is held by another process."
      return 1
    fi
    echo "Backend is not running."
    return 0
  fi

  echo "Stopping backend process(es): $(tr '\n' ' ' <<< "$pids")"
  while read -r pid; do
    [ -n "$pid" ] || continue
    kill -TERM -- "-$pid" 2>/dev/null || kill -TERM "$pid" 2>/dev/null || true
  done <<< "$pids"

  if ! wait_for_port_state free; then
    while read -r pid; do
      [ -n "$pid" ] || continue
      kill -KILL -- "-$pid" 2>/dev/null || kill -KILL "$pid" 2>/dev/null || true
    done <<< "$pids"
    wait_for_port_state free || { echo "Backend did not release port $PORT"; return 1; }
  fi
  rm -f "$PID_FILE"
  echo "Backend stopped; port $PORT is free."
}

restart_backend() {
  stop_backend || return 1
  start_backend
}

case "${1:-}" in
  start) start_backend ;;
  stop) stop_backend ;;
  restart) restart_backend ;;
  *) echo "Usage: $0 {start|stop|restart}"; exit 2 ;;
esac
